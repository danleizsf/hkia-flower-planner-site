"""The dashboard service for the browser build (Pyodide in a Web Worker).

A browser has no processes or threads, so Generate plan runs in-process.
``start_plan_generation`` only queues it and answers "starting"; ``entry``
runs it right after replying, so the page's status poll sees "starting" turn
into "completed" and reloads the plan, as with the HTTP dashboard. The
forecast runs in a second worker the page starts (see start_flow_forecast).
"""
from __future__ import annotations

import contextlib
import io
import sys
from datetime import datetime, timezone

from hkia_solver.ui_state import FarmUIService


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class BrowserFarmService(FarmUIService):
    auto_flow_forecast = False

    def __init__(self, root) -> None:
        super().__init__(root)
        self._pending_plan: dict | None = None

    def start_plan_generation(self, **kwargs) -> dict:
        if self._generation_status["state"] in ("starting", "running"):
            raise ValueError("Plan generation is already running")
        self._generation_status = {"state": "starting", "message": "Calculating recommendations…",
                                   "started_at": _now()}
        self._pending_plan = kwargs
        return self.plan_generation_status()

    def run_pending(self) -> bool:
        """Generate the queued plan, if any (called after the reply went out)."""
        kwargs, self._pending_plan = self._pending_plan, None
        if kwargs is None:
            return False
        self._generation_status["state"] = "running"
        try:
            result = self.generate_plan(**kwargs)
        except Exception as error:
            self._generation_status.update(state="failed", message=str(error), finished_at=_now())
        else:
            self._generation_status.update(state="completed", message=result.get("message", "Plan generated."),
                                           finished_at=_now())
        return True

    def _run_solver(self, args: list[str]) -> tuple[int, str, str, bool]:
        import run_solver

        out, err = io.StringIO(), io.StringIO()
        saved = sys.argv
        sys.argv = ["run_solver.py", *args]
        code = 0
        try:
            with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
                run_solver.main()
        except SystemExit as stop:
            code = stop.code if isinstance(stop.code, int) else 1
            if not isinstance(stop.code, int) and stop.code:
                err.write(str(stop.code))
        except Exception as error:
            code = 1
            err.write(f"{type(error).__name__}: {error}")
        finally:
            sys.argv = saved
        return code, out.getvalue(), err.getvalue(), False

    def cancel_plan(self) -> dict:
        return {"message": "A plan in the browser can't be cancelled once it starts."}

    # The forecast (minutes of simulation) runs in a second Web Worker the page
    # starts (browser/forecast_worker.js) on a copy of the farm, so this one
    # stays free; its results come back through forecast_update().
    _forecast_running = False

    def flow_forecast_running(self) -> bool:
        return self._forecast_running

    def start_flow_forecast(self, force: bool = False, reuse_only: bool = False, full: bool = False) -> dict:
        if reuse_only or self._forecast_running:
            return self.flow_roadmap()
        from hkia_solver.flow.forecast import partial_path

        partial_path(self.root).unlink(missing_ok=True)
        self._forecast_running = True
        return {**self.flow_roadmap(), "browser_forecast": "full" if full else "start"}

    def forecast_update(self, kind: str, data: dict | None = None) -> None:
        """A partial forecast, the finished one ("final"), or "stop" (failed or abandoned)."""
        from hkia_solver.flow.forecast import (_write_json_atomic, apply_to_plan, forecast_path, inputs_key,
                                               partial_path)

        if kind == "partial" and self._forecast_running:
            _write_json_atomic(partial_path(self.root), data)
        elif kind == "final":
            data["applied_to_plan"] = apply_to_plan(self.root, data, current_key=inputs_key(self.root))
            _write_json_atomic(forecast_path(self.root), data)
            partial_path(self.root).unlink(missing_ok=True)
            self._forecast_running = False
        elif kind == "stop":
            partial_path(self.root).unlink(missing_ok=True)
            self._forecast_running = False
        else:
            raise ValueError(f"Unknown forecast update: {kind}")
