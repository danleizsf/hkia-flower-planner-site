"""Farm backups for the browser version: the whole farm folder as one zip.

The farm lives only in the visitor's browser, so a backup is how it
survives a cleared browser or moves to another device. worker.js calls
these for the Farm menu's Download a backup / Restore from a backup.

A restore never leaves a half-replaced farm: the backup is unpacked
elsewhere and checked first (a zip, safe file names, a reasonable size,
an inventory the planner can load), and only then replaces the farm.
"""
from __future__ import annotations

import json
import shutil
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

INVENTORY = "farm_data/inventory.json"
MAX_BYTES = 500_000_000            # unpacked; a real farm is a few MB


def export_farm(farm: Path, zip_path: Path) -> Path:
    """Write every file of the farm into ``zip_path`` (paths relative to the farm)."""
    farm, zip_path = Path(farm), Path(zip_path)
    if not (farm / INVENTORY).is_file():
        raise ValueError("There is no farm to back up yet.")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(farm.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(farm).as_posix())
    return zip_path


def _check(archive: zipfile.ZipFile) -> None:
    names = archive.namelist()
    for name in names:
        parts = PurePosixPath(name.replace("\\", "/")).parts
        if name.startswith(("/", "\\")) or ".." in parts or (parts and parts[0].endswith(":")):
            raise ValueError("That backup has unsafe file names; nothing was changed.")
    if INVENTORY not in names:
        raise ValueError("That file isn't a farm backup (no farm_data/inventory.json in it).")
    if sum(info.file_size for info in archive.infolist()) > MAX_BYTES:
        raise ValueError("That backup is far too big to be a farm; nothing was changed.")


def import_farm(zip_path: Path, farm: Path, keep_previous: Path | None = None) -> None:
    """Replace the farm in ``farm`` with the backup in ``zip_path``.

    Raises ValueError (and leaves the farm as it was) for anything that
    isn't a whole, loadable farm backup. ``keep_previous``: once the backup
    has passed its checks, the farm it replaces is saved there first (a
    backup zip), so the restore can be undone.
    """
    from hkia_solver.inventory import Inventory

    farm = Path(farm)
    try:
        archive = zipfile.ZipFile(zip_path)
    except (zipfile.BadZipFile, OSError):
        raise ValueError("That file isn't a farm backup (it isn't a zip file).") from None
    with archive, tempfile.TemporaryDirectory() as tmp:
        _check(archive)
        staged = Path(tmp) / "farm"
        try:
            archive.extractall(staged)
        except (zipfile.BadZipFile, OSError, EOFError) as error:
            raise ValueError(f"That backup is damaged ({error}); nothing was changed.") from None
        try:
            Inventory.load(staged / INVENTORY, staged / "farm_data" / "other_patterned_donors.json")
            settings = staged / "farm_data" / "settings.json"
            if settings.exists():
                json.loads(settings.read_text(encoding="utf-8"))
        except (ValueError, KeyError, TypeError) as error:
            raise ValueError(f"That backup's farm can't be read ({error}); nothing was changed.") from None
        # Checked: save the farm being replaced, then replace the farm's contents
        # (the folder itself may be a mount point).
        if keep_previous is not None and (farm / INVENTORY).is_file():
            Path(keep_previous).parent.mkdir(parents=True, exist_ok=True)
            export_farm(farm, keep_previous)
        farm.mkdir(parents=True, exist_ok=True)
        for path in list(farm.iterdir()):
            shutil.rmtree(path) if path.is_dir() else path.unlink()
        shutil.copytree(staged, farm, dirs_exist_ok=True)


def undo_restore(farm: Path, previous: Path) -> None:
    """Bring back the farm saved before the last restore (``previous``).

    The farm it replaces becomes the saved one, so an undo can be undone.
    """
    previous = Path(previous)
    if not previous.is_file():
        raise ValueError("There is no earlier farm to go back to.")
    swap = previous.with_name(previous.name + ".swap")
    import_farm(previous, farm, keep_previous=swap)
    swap.replace(previous)
