"""What the Web Worker calls: one dashboard API request in, (status, JSON text) out."""
from __future__ import annotations

import json
from pathlib import Path

from hkia_solver import api

from browser_service import BrowserFarmService

service: BrowserFarmService | None = None


def init(root: str) -> None:
    global service
    service = BrowserFarmService(Path(root))


def handle(method: str, path: str, body: str = "") -> tuple[int, str]:
    try:
        payload = json.loads(body or "{}") if method == "POST" else None
    except ValueError as error:
        return 400, json.dumps({"error": str(error)})
    status, result = api.dispatch(service, method, path, payload)
    return status, api.encode_json_response(result).decode("utf-8")


def run_pending() -> bool:
    return service.run_pending()


def forecast_update(kind: str, text: str = "") -> None:
    """From the forecast worker, via the page: a partial or final forecast (JSON), or "stop"."""
    service.forecast_update(kind, json.loads(text) if text else None)


def listen_progress(callback) -> None:
    """Send Generate plan's progress updates (as JSON text) to ``callback``, a JS function."""
    from hkia_solver import progress

    progress.set_listener(lambda update: callback(json.dumps(update)))
