"""How far a Generate plan run has got, for the "Making your plan" screen.

The planner reports its stage (and how far into it) as it works; whoever
runs it can listen. The desktop's run_solver.py writes it to a file the
dashboard's plan status reads; the browser version posts it to the page.
Without a listener reporting costs almost nothing.
"""
from __future__ import annotations

import time

# (key, what the player sees, share of a typical run in percent; measured on
# a full farm, Nov 2026: routes ~5 s, scheduling ~5 s, plots ~30 s of ~41 s;
# plot layouts ~10 s when not cached yet, e.g. a new browser session)
STAGES = (
    ("farm", "Reading your farm", 1),
    ("routes", "Finding breeding routes", 14),
    ("schedule", "Choosing what to breed first", 13),
    ("layouts", "Working out each plot's layout", 10),
    ("plots", "Placing flowers in your plots", 60),
    ("save", "Saving the plan", 2),
)
_START = {}
_total = 0
for _key, _label, _weight in STAGES:
    _START[_key] = (_total, _weight, _label)
    _total += _weight

_listener = None
_last = {"percent": -1.0, "stage": None, "at": 0.0}


def listening() -> bool:
    return _listener is not None


def set_listener(listener) -> None:
    """``listener(update)`` gets {"stage", "label", "percent", "detail"}; None stops listening."""
    global _listener
    _listener = listener
    _last.update(percent=-1.0, stage=None, at=0.0)


def report(stage: str, within: float = 0.0, detail: str = "") -> None:
    """The run is at ``stage``, ``within`` (0-1) of the way through it.

    The percentage never goes back, and updates are sent at most a few
    times a second (always when the stage changes).
    """
    if _listener is None:
        return
    start, weight, label = _START[stage]
    percent = max(_last["percent"], start + weight * min(max(within, 0.0), 1.0))
    now = time.monotonic()
    new_detail = detail != _last.get("detail")
    if stage == _last["stage"] and not (
            (percent - _last["percent"] >= 1 and now - _last["at"] >= 0.25)
            or (new_detail and now - _last["at"] >= 1)):      # say what it's on, even when the % is slow
        return
    _last.update(percent=percent, stage=stage, at=now, detail=detail)
    _listener({"stage": stage, "label": label, "percent": round(percent), "detail": detail})
