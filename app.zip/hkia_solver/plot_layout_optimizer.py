"""Bounded plot-level layout scoring and cell-level breeding outcomes.

This module is deliberately separate from the collection graph optimizer.  It
owns only the local question of which ready jobs can share a physical outdoor
plot, which pair zones to use, and how each empty cell contributes to target
probability.  The search has fixed limits so it stays cheap inside Generate
Plan's event loop.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
import math
from typing import Any, Iterable

from .plots import PlotSlot, isolated_pair_zones, neighboring_cells, usable_cells


Cell = tuple[int, int]


@dataclass(frozen=True)
class PairPlacement:
    pair: tuple[Cell, Cell]
    protected_cells: frozenset[Cell]
    zone_index: int


@lru_cache(maxsize=256)
def pair_placements(slot: PlotSlot, limit: int = 24, quick: bool = False) -> tuple[PairPlacement, ...]:
    """Return bounded safe pair placements on one physical plot grid.

    Greenhouse candidates cover the entire shared grid, rather than deriving
    every recommendation from one precomputed maximum independent-set lattice.
    The joint search evaluates offspring chances from all selected parents.
    Outdoor geometry and its isolated zones remain unchanged.
    """
    if slot.greenhouse:
        usable = usable_cells(slot)
        candidates = []
        for a in sorted(usable):
            for delta in ((0, 1), (1, 0)):
                b = (a[0] + delta[0], a[1] + delta[1])
                if b not in usable:
                    continue
                offspring = (neighboring_cells(a, usable) & neighboring_cells(b, usable)) - {a, b}
                if len(offspring) >= 2:
                    candidates.append((a, b, frozenset(offspring)))
        # Spread candidates evenly across the greenhouse. Alternatives at
        # different offsets/orientations let the bounded joint optimizer find
        # arrangements not represented by a fixed lattice.
        candidates.sort(key=lambda row: (-len(row[2]), row[0][0], row[0][1], row[1]))
        if len(candidates) > limit:
            chosen = []
            remaining = candidates[:]
            while remaining and len(chosen) < limit:
                candidate = max(remaining, key=lambda item: (
                    min((abs(item[0][0] - c[0][0]) + abs(item[0][1] - c[0][1]) for c in chosen), default=20),
                    len(item[2]), -item[0][0], -item[0][1],
                ))
                chosen.append(candidate)
                remaining.remove(candidate)
            candidates = chosen
        return tuple(PairPlacement((a, b), cells, index)
                     for index, (a, b, cells) in enumerate(candidates))
    if quick:
        # Provisional plans use a deterministic linear-time geometric packing.
        # The thorough optimizer keeps the established multi-pass packing.
        usable = usable_cells(slot)
        available = set(usable)
        placements = []
        for a in sorted(usable):
            if len(placements) >= limit:
                break
            if a not in available:
                continue
            for delta in ((0, 1), (1, 0)):
                b = (a[0] + delta[0], a[1] + delta[1])
                if b not in available:
                    continue
                targets = (neighboring_cells(a, usable) & neighboring_cells(b, usable)) & available
                if not targets:
                    continue
                target = min(targets)
                # Other parents must not be adjacent to this protected spawn.
                protected = {a, b, target} | neighboring_cells(target, usable)
                if a not in available or b not in available:
                    continue
                placements.append(PairPlacement((a, b), frozenset({target}), len(placements)))
                available.difference_update(protected)
                break
        return tuple(placements)
    return tuple(
        PairPlacement(pair, cells, index)
        for index, (pair, cells) in enumerate(isolated_pair_zones(slot, limit))
    )


def _target_key(job: dict[str, Any]) -> tuple[str, str, str, str | None]:
    return (
        str(job.get("target_type", "")),
        str(job.get("target_color", "")),
        str(job.get("target_pattern", "Solid")),
        job.get("target_secondary_color"),
    )


def _target_label(job: dict[str, Any]) -> str:
    return str(job.get("target") or " ".join(str(x) for x in _target_key(job)[:3]))


def _cell_rate(job: dict[str, Any]) -> float:
    return max(0.0, min(1.0, float(job.get("cell_probability", 0.0))))


def _parent_layout(job: dict[str, Any]) -> tuple[list[Cell], list[Cell]]:
    layout = job.get("layout") if isinstance(job.get("layout"), dict) else {}
    a = [tuple(map(int, cell)) for cell in layout.get("parent_a_cells", ())]
    a.extend(tuple(map(int, cell)) for cell in layout.get("shared_parent_a_cells", ()))
    b = [tuple(map(int, cell)) for cell in layout.get("parent_b_cells", ())]
    return a, b


def evaluate_cell_outcomes(
    slot: PlotSlot,
    jobs: list[dict[str, Any]],
    *,
    planted_cells: list[dict[str, Any]] | None = None,
    allowed_spawn_cells: set[Cell] | None = None,
    include_unused_cells: bool = True,
) -> dict[str, Any]:
    """Score every open outdoor cell once and split shared cell chances.

    A cell that could produce more than one distinct goal has one total spawn
    chance.  That chance is distributed across its possible goal outcomes in
    proportion to their route chance, so one physical cell never grants a full
    independent spawn chance to several targets.
    """
    usable = usable_cells(slot)
    owner_by_cell: dict[Cell, list[tuple[int, str]]] = {}
    goal_index: dict[tuple[str, str, str, str | None], list[int]] = {}
    for index, job in enumerate(jobs):
        goal_index.setdefault(_target_key(job), []).append(index)
        parent_a, parent_b = _parent_layout(job)
        for cell in parent_a:
            owner_by_cell.setdefault(cell, []).append((index, "A"))
        for cell in parent_b:
            owner_by_cell.setdefault(cell, []).append((index, "B"))

    # Actual/manual plant records do not always carry generated layout objects.
    # Attach them to a matching job id when possible, otherwise keep the role
    # visible as an obstruction without claiming it can produce a goal.
    job_by_id = {
        str(job.get("job_id")): index
        for index, job in enumerate(jobs)
        if job.get("job_id")
    }
    for cell_record in planted_cells or ():
        role = str(cell_record.get("parent_role", ""))
        if role not in {"A", "B"}:
            continue
        cell = (int(cell_record["row"]), int(cell_record["col"]))
        if cell not in usable or cell in owner_by_cell:
            continue
        job_index = job_by_id.get(str(cell_record.get("job_id", "")))
        if job_index is None and len(jobs) == 1:
            job_index = 0
        if job_index is not None:
            owner_by_cell.setdefault(cell, []).append((job_index, role))
        else:
            owner_by_cell.setdefault(cell, []).append((-1, role))

    target_shares_by_cell: dict[Cell, dict[tuple[str, str, str, str | None], float]] = {}
    explanations: list[dict[str, Any]] = []
    unique_by_goal: dict[tuple[str, str, str, str | None], list[Cell]] = {}
    shared_by_goal: dict[tuple[str, str, str, str | None], list[Cell]] = {}
    eligible_by_goal: dict[tuple[str, str, str, str | None], int] = {}
    cell_rate_by_goal: dict[tuple[str, str, str, str | None], list[float]] = {}

    inspected_cells = usable if include_unused_cells else {neighbor for parent in owner_by_cell for neighbor in neighboring_cells(parent, usable)}
    for cell in sorted(inspected_cells):
        if cell in owner_by_cell:
            continue
        if allowed_spawn_cells is not None and cell not in allowed_spawn_cells:
            continue
        adjacent = [
            (job_index, role)
            for neighbor in neighboring_cells(cell, usable)
            for job_index, role in owner_by_cell.get(neighbor, ())
        ]
        roles = {role for _job_index, role in adjacent}
        outcomes: dict[tuple[str, str, str, str | None], float] = {}
        for index, job in enumerate(jobs):
            method = str(job.get("method", ""))
            own_roles = {role for job_index, role in adjacent if job_index == index}
            if method == "propagate_solid":
                possible = "A" in own_roles
            elif method.startswith("fertilize_"):
                possible = False
            else:
                possible = {"A", "B"} <= own_roles
            if not possible:
                continue
            goal = _target_key(job)
            outcomes[goal] = max(outcomes.get(goal, 0.0), _cell_rate(job))

        if outcomes:
            # A physical spawn cell has one daily attempt. Competing recipes can
            # change its possible offspring, but cannot each claim their full
            # independent rate. Cap the total at the strongest feasible route.
            total = max(outcomes.values(), default=0.0)
            rate_sum = sum(outcomes.values())
            shares = {
                goal: total * rate / rate_sum
                for goal, rate in outcomes.items()
            } if rate_sum else {}
            target_shares_by_cell[cell] = shares
            labels = sorted(
                _target_label(jobs[goal_index[goal][0]])
                for goal in outcomes
                if goal in goal_index
            )
            if len(outcomes) > 1:
                reason = "Shared offspring cell; its chance is split across " + ", ".join(labels) + "."
            else:
                reason = "Available offspring cell for " + (labels[0] if labels else "one attached goal") + "."
            for goal, chance in shares.items():
                eligible_by_goal[goal] = eligible_by_goal.get(goal, 0) + 1
                cell_rate_by_goal.setdefault(goal, []).append(chance)
                (shared_by_goal if len(outcomes) > 1 else unique_by_goal).setdefault(goal, []).append(cell)
            explanations.append({
                "row": cell[0], "col": cell[1], "reason": reason,
                "kind": "shared" if len(outcomes) > 1 else "offspring",
                "possible_targets": labels,
            })
        elif not adjacent:
            explanations.append({
                "row": cell[0], "col": cell[1],
                "reason": "Unused: no adjacent parents.",
                "kind": "no_adjacent_parents", "possible_targets": [],
            })
        elif roles == {"A"} or roles == {"B"}:
            role_name = "Parent A" if roles == {"A"} else "Parent B"
            explanations.append({
                "row": cell[0], "col": cell[1],
                "reason": f"Unused: adjacent plants provide only {role_name}.",
                "kind": "one_parent_role", "possible_targets": [],
            })
        else:
            explanations.append({
                "row": cell[0], "col": cell[1],
                "reason": "Unused: adjacent parents do not form a complete pair for one attached goal.",
                "kind": "incomplete_pair", "possible_targets": [],
            })

    probabilities: dict[tuple[str, str, str, str | None], float] = {}
    for goal, chances in cell_rate_by_goal.items():
        miss = 1.0
        for chance in chances:
            miss *= 1.0 - chance
        probabilities[goal] = 1.0 - miss

    return {
        "probabilities": probabilities,
        "eligible_cells": eligible_by_goal,
        "unique_cells": unique_by_goal,
        "shared_cells": shared_by_goal,
        "cell_explanations": explanations,
        "cell_outcomes": target_shares_by_cell,
    }


def choose_zone_batch(
    slot: PlotSlot,
    candidates: list[tuple[Any, float, float]],
    zones: Iterable[PairPlacement],
    *,
    max_jobs: int = 5,
    beam_width: int = 16,
    occupied_parent_cells: Iterable[Cell] = (),
    parent_capacities: dict[Any, int] | None = None,
    critical_tail: dict[Any, float] | None = None,
) -> list[dict[str, Any]]:
    """Choose a bounded route-to-zone layout as a small beam-search assignment.

    Candidate tuples are ``(route, scheduler_weight, per_cell_chance)``. The
    search maximizes useful concurrently scheduled goals first, then favors
    layouts with higher shared-cell-adjusted probabilities and scheduler weight.
    It is bounded to five jobs, sixteen partial layouts, and twenty-four zones.
    """
    zone_list = list(zones)[:(14 if slot.greenhouse else 24)]
    if slot.greenhouse:
        beam_width = min(beam_width, 6)
    exploration_limit = 160 if slot.greenhouse else 1600
    route_list = list(candidates)[:max_jobs]
    if not zone_list or not route_list:
        return []

    # Existing concurrent pairs own every neighboring spawn cell for the
    # duration of their job. Keep the fast event simulation conservative here:
    # new jobs cannot claim those cells or silently lower an active job's rate.
    allowed_spawn_cells = set(usable_cells(slot))
    for parent_cell in occupied_parent_cells:
        allowed_spawn_cells.difference_update(neighboring_cells(parent_cell, allowed_spawn_cells))

    def to_job(route: Any, zone: PairPlacement, chance: float) -> dict[str, Any]:
        target = route.target
        parent_a, parent_b = route.parents[:2]
        return {
            "target": target.label(),
            "target_type": target.flower_type,
            "target_color": target.color,
            "target_pattern": target.pattern,
            "target_secondary_color": target.secondary_color,
            "method": route.method,
            "cell_probability": chance,
            "layout": {
                "parent_a_cells": [list(zone.pair[0])],
                "parent_b_cells": [list(zone.pair[1])],
                "target_cells": [list(cell) for cell in sorted(zone.protected_cells)],
            },
            "parent_flowers": [
                {
                    "flower_type": parent.flower_type,
                    "color": parent.color,
                    "pattern": parent.pattern,
                    "secondary_color": parent.secondary_color,
                }
                for parent in (parent_a, parent_b)
            ],
        }

    enforce_parent_capacities = parent_capacities is not None
    parent_capacities = parent_capacities or {}
    critical_tail = critical_tail or {}
    # Beam nodes are (route index, placements, used zone indexes, utility).
    beam: list[tuple[int, tuple[tuple[int, int], ...], frozenset[int], float]] = [
        (0, (), frozenset(), 0.0)
    ]
    explored = 0
    for route_index, (route, weight, chance) in enumerate(route_list):
        expanded: list[tuple[int, tuple[tuple[int, int], ...], frozenset[int], float]] = []
        for _index, selected, used, _old_score in beam:
            # Skipping is needed when a plot has fewer remaining zones than
            # ready jobs or a candidate collides with all remaining pair cells.
            expanded.append((route_index + 1, selected, used, _old_score if selected else -math.inf))
            for zone_position, zone in enumerate(zone_list):
                if zone_position in used:
                    continue
                selected_targets = {
                    route_list[ri][0].target
                    for ri, _zi in selected
                }
                route_target = route.target
                if route_target in selected_targets:
                    # Route alternatives for one target are options, not
                    # separate collection work. A second attempt is considered
                    # in the scheduler's explicit concurrency phase.
                    continue
                if any(
                    zone.pair[0] in other_pair or zone.pair[1] in other_pair
                    for _candidate_index, other_position in selected
                    for other_pair in (zone_list[other_position].pair,)
                ):
                    continue
                next_selected = selected + ((route_index, zone_position),)
                parent_usage: dict[Any, int] = {}
                for selected_route_index, _selected_zone in next_selected:
                    for parent in route_list[selected_route_index][0].parents[:2]:
                        parent_usage[parent] = parent_usage.get(parent, 0) + 1
                if enforce_parent_capacities and any(
                    parent not in parent_capacities
                    or parent_usage[parent] > max(0, int(parent_capacities[parent]))
                    for parent in parent_usage
                ):
                    continue
                jobs = [
                    to_job(route_list[ri][0], zone_list[zi], route_list[ri][2])
                    for ri, zi in next_selected
                ]
                evaluation = evaluate_cell_outcomes(
                    slot, jobs, allowed_spawn_cells=allowed_spawn_cells,
                    include_unused_cells=False,
                )
                goal_prob = evaluation["probabilities"]
                gain = 0.0
                target_finishes: list[float] = []
                for local_index, (ri, _zi) in enumerate(next_selected):
                    job = jobs[local_index]
                    p = goal_prob.get(_target_key(job), 0.0)
                    relative_weight = max(0.05, float(route_list[ri][1]))
                    target = route_list[ri][0].target
                    tail = max(0.0, float(critical_tail.get(target, 0.0)))
                    eta = 1.0 / p + tail if p > 0 else math.inf
                    target_finishes.append(eta)
                    gain += relative_weight * math.log1p(p * 100_000.0)
                # A greenhouse candidate wins by reducing projected completion
                # time, not by simply counting pairs or filling cells. Outdoor
                # scheduling retains its established distinct-goal preference.
                projected_batch_finish = max(target_finishes, default=0.0)
                if slot.greenhouse:
                    # Additional concurrent goals are valuable only if they
                    # improve throughput; do not reward density by itself.
                    score = gain - projected_batch_finish / (1.0 + projected_batch_finish)
                else:
                    score = len(next_selected) * 1000.0 - projected_batch_finish + gain
                expanded.append((route_index + 1, next_selected, used | {zone_position}, score))
                explored += 1
                if explored >= exploration_limit:
                    break
            if explored >= exploration_limit:
                break
        expanded.sort(key=lambda item: (item[3], len(item[1]), tuple(item[1])), reverse=True)
        beam = expanded[:beam_width]
        if explored >= exploration_limit:
            break

    if not beam:
        return []
    _index, selected, _used, _score = max(beam, key=lambda item: (item[3], len(item[1])))
    jobs = [
        to_job(route_list[ri][0], zone_list[zi], route_list[ri][2])
        for ri, zi in selected
    ]
    evaluation = evaluate_cell_outcomes(
        slot, jobs, allowed_spawn_cells=allowed_spawn_cells,
    )
    result: list[dict[str, Any]] = []
    for local_index, (route_index, zone_index) in enumerate(selected):
        job = jobs[local_index]
        key = _target_key(job)
        cells = sorted(
            set(evaluation["unique_cells"].get(key, ()))
            | set(evaluation["shared_cells"].get(key, ()))
        )
        result.append({
            "route": route_list[route_index][0],
            "zone": zone_list[zone_index],
            "probability": evaluation["probabilities"].get(key, 0.0),
            "eligible_cells": evaluation["eligible_cells"].get(key, len(cells)),
            "unique_cells": evaluation["unique_cells"].get(key, []),
            "shared_cells": evaluation["shared_cells"].get(key, []),
        })
    return result


def add_makespan_reducing_pairs(
    slot: PlotSlot,
    batch: list[dict[str, Any]],
    zones: Iterable[PairPlacement],
    cell_rates: dict[Any, float],
    free_parent_copies: dict[Any, int],
    critical_tail: dict[Any, float],
    *,
    max_extra_pairs: int = 4,
    material_fraction: float = 0.02,
    occupied_parent_cells: Iterable[Cell] = (),
) -> dict[str, Any]:
    """Add same-goal breeding pairs only when they shorten local finish proxy.

    Each batch entry represents one distinct collection goal. Additional parent
    pairs are separate attempts for that goal, never an offspring stock goal.
    Their marginal value is measured after shared cell chances are split.
    """
    if not batch:
        return {"probabilities": {}, "eligible_cells": {}, "unique_cells": {}, "shared_cells": {}}
    zone_list = list(zones)
    allowed_spawn_cells = set(usable_cells(slot))
    for parent_cell in occupied_parent_cells:
        allowed_spawn_cells.difference_update(neighboring_cells(parent_cell, allowed_spawn_cells))
    for item in batch:
        item.setdefault("zones", [item["zone"]])

    def jobs_for_batch() -> list[dict[str, Any]]:
        jobs = []
        for item in batch:
            route = item["route"]
            target = route.target
            placements = item["zones"]
            jobs.append({
                "target": target.label(),
                "target_type": target.flower_type,
                "target_color": target.color,
                "target_pattern": target.pattern,
                "target_secondary_color": target.secondary_color,
                "method": route.method,
                "cell_probability": float(
                    cell_rates.get(route, cell_rates.get(target, 0.0))
                ),
                "layout": {
                    "parent_a_cells": [list(zone.pair[0]) for zone in placements],
                    "parent_b_cells": [list(zone.pair[1]) for zone in placements],
                    "target_cells": [],
                },
            })
        return jobs

    def goal_of(item: dict[str, Any]) -> tuple[str, str, str, str | None]:
        target = item["route"].target
        return (target.flower_type, target.color, target.pattern, target.secondary_color)

    def finish_proxy(evaluation: dict[str, Any]) -> float:
        durations = []
        for item in batch:
            target = item["route"].target
            probability = evaluation["probabilities"].get(goal_of(item), 0.0)
            duration = 1.0 / probability if probability > 0 else math.inf
            durations.append(duration + max(0.0, float(critical_tail.get(target, 0.0))))
        return max(durations, default=0.0)

    used_zone_ids = {
        zone.zone_index
        for item in batch
        for zone in item["zones"]
    }
    parent_copies_used: dict[Any, int] = {}
    for item in batch:
        for parent in item["route"].parents[:2]:
            parent_copies_used[parent] = parent_copies_used.get(parent, 0) + len(item["zones"])

    evaluation = evaluate_cell_outcomes(
        slot, jobs_for_batch(),
        allowed_spawn_cells=allowed_spawn_cells,
    )
    for _ in range(max(0, int(max_extra_pairs))):
        old_finish = finish_proxy(evaluation)
        threshold = max(1.0, old_finish * max(0.0, material_fraction))
        best: tuple[float, str, dict[str, Any], PairPlacement, dict[str, Any]] | None = None
        for item in batch:
            route = item["route"]
            target = route.target
            if len(item["zones"]) >= 5:
                continue
            if any(
                parent_copies_used.get(parent, 0) >= int(free_parent_copies.get(parent, 0))
                for parent in route.parents[:2]
            ):
                continue
            for zone in zone_list:
                if zone.zone_index in used_zone_ids:
                    continue
                item["zones"].append(zone)
                trial = evaluate_cell_outcomes(
                    slot, jobs_for_batch(),
                    allowed_spawn_cells=allowed_spawn_cells,
                )
                item["zones"].pop()
                gain = old_finish - finish_proxy(trial)
                if gain < threshold:
                    continue
                candidate = (gain, target.label(), item, zone, trial)
                if best is None or candidate[:2] > best[:2]:
                    best = candidate
        if best is None:
            break
        _gain, _label, item, zone, evaluation = best
        item["zones"].append(zone)
        used_zone_ids.add(zone.zone_index)
        for parent in item["route"].parents[:2]:
            parent_copies_used[parent] = parent_copies_used.get(parent, 0) + 1

    for item in batch:
        goal = goal_of(item)
        item["probability"] = evaluation["probabilities"].get(goal, 0.0)
        item["eligible_cells"] = evaluation["eligible_cells"].get(goal, 0)
        item["unique_cells"] = evaluation["unique_cells"].get(goal, [])
        item["shared_cells"] = evaluation["shared_cells"].get(goal, [])
    return evaluation


def explain_plot_cells(
    slot: PlotSlot,
    jobs: list[dict[str, Any]],
    planted_cells: list[dict[str, Any]] | None = None,
) -> list[dict[str, Any]]:
    """Return concise reasons for every open/offspring cell in the plot."""
    normalized = []
    for job in jobs:
        item = dict(job)
        # Availability reasons describe which goals can use a cell, not their
        # numerical route odds. Equal unit rates keep this classification
        # independent of display probabilities that already aggregate cells.
        item["cell_probability"] = 1.0
        normalized.append(item)
    return evaluate_cell_outcomes(slot, normalized, planted_cells=planted_cells)["cell_explanations"]
