"""Job tags on plot cells (1A / 1B / 2F / 3P), and jobs rebuilt from them.

The map labels every planted cell with its job group and role:

    1A / 1B  a breeding pair: A = first parent (a donor shared by several
             jobs keeps one number), B = each second parent
    2F       a plant in a fertilizer bed
    3P       a single plant propagating copies of itself

The plot editor keeps these tags, so a plot edited by hand records its jobs
with real cell positions, exactly like a recorded recommendation.
"""
from __future__ import annotations

import re
from collections import defaultdict

from .models import Flower
from .rules import FLOWER_TYPES, mix_result

Cell = tuple[int, int]
TAG = re.compile(r"^(\d+)([ABFP])$")
FLOW_BED = "FLOW fertilizer bed"


def _kind(job: dict) -> str:
    method = str(job.get("method", ""))
    if method.startswith("fertilize_"):
        return "F"
    if method in ("propagate_solid", "propagation"):
        return "P"
    return "pair"


def _cells(layout: dict, *keys: str) -> list[Cell]:
    return [(int(c[0]), int(c[1])) for key in keys for c in (layout.get(key) or [])]


def cell_tags(jobs: list[dict]) -> dict[Cell, str]:
    """The tag of every job cell (same numbering as the map's web/job_tags.js)."""
    groups: list[dict] = []
    by_donor: dict[Cell, dict] = {}
    for job in jobs:
        layout = job.get("layout") or {}
        a_cells = _cells(layout, "parent_a_cells", "shared_parent_a_cells")
        b_cells = _cells(layout, "parent_b_cells")
        kind = _kind(job)
        group = by_donor.get(a_cells[0]) if kind == "pair" and a_cells else None
        if group is None:
            group = {"kind": kind, "a": [], "b": []}
            groups.append(group)
            if kind == "pair":
                for cell in a_cells:
                    by_donor[cell] = group
        group["a"].extend(a_cells)
        group["b"].extend(b_cells)

    def first(group):
        return min(group["a"] + group["b"], default=(10**9, 10**9))

    groups.sort(key=first)
    tags: dict[Cell, str] = {}
    for number, group in enumerate(groups, 1):
        letter = "A" if group["kind"] == "pair" else group["kind"]
        for cell in group["a"]:
            tags.setdefault(cell, f"{number}{letter}")
        for cell in group["b"]:
            tags.setdefault(cell, f"{number}B")
    return tags


def pair_job(donor: Flower, recipient: Flower) -> tuple[str, Flower] | None:
    """(method, target) when ``donor`` (A) and ``recipient`` (B) form a planned pair."""
    if recipient.pattern != "Solid":
        return None
    if donor.flower_type == recipient.flower_type:
        if donor.pattern != "Solid":
            return None
        color = mix_result(donor.color, recipient.color)
        return ("color_mix", Flower(donor.flower_type, color, "Solid")) if color else None
    if donor.color == recipient.color:
        if donor.pattern == "Solid":
            return None
        return "pattern_transfer", Flower(recipient.flower_type, donor.color, donor.pattern, donor.secondary_color)
    return "color_transfer", Flower(recipient.flower_type, donor.color, "Solid")


def native(flower: Flower) -> Flower | None:
    ft = FLOWER_TYPES.get(flower.flower_type)
    if ft is None or flower.pattern != "Solid" or not ft.default_pattern:
        return None
    return Flower(flower.flower_type, flower.color, ft.default_pattern)


def _flower_dict(f: Flower) -> dict:
    return {"flower_type": f.flower_type, "color": f.color, "pattern": f.pattern,
            "secondary_color": f.secondary_color}


def _neighbors(cell: Cell) -> set[Cell]:
    r, c = cell
    return {(r + dr, c + dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc}


def _job(meta: dict, method: str, target: Flower, parents: list[Flower], layout: dict,
         previous: dict | None, eligible: int) -> dict:
    job = {
        **meta,
        "eligible_cells": eligible,
        "target": target.label(),
        "target_type": target.flower_type,
        "target_color": target.color,
        "target_pattern": target.pattern,
        "target_secondary_color": target.secondary_color,
        "method": method,
        "parents": [p.label() for p in parents],
        "parent_flowers": [_flower_dict(p) for p in parents],
        "parent_patterns": [p.pattern for p in parents],
        "parent_copies": [len(layout.get("parent_a_cells") or layout.get("shared_parent_a_cells") or [1])]
        + ([1] if len(parents) > 1 else []),
        "daily_probability": 0.0,
        "expected_days": None,
        "event_only": False,
        "stock_goal": 1,
        "stock_goal_reason": FLOW_BED if method == "fertilize_pattern" else "first successful copy",
        "propagation_goal": 1,
        "propagation_goal_reason": "one reusable collection copy",
        "layout": layout,
        "layout_search": "tagged_by_hand",
    }
    if previous:
        # Keep the job's identity and goals (job_states are keyed by job_id).
        for key in ("job_id", "stock_goal", "stock_goal_reason", "propagation_goal",
                    "propagation_goal_reason", "propagation", "daily_probability", "expected_days",
                    "event_only", "manual_target", "manual_target_source", "manual_target_verified"):
            if key in previous:
                job[key] = previous[key]
    return job


def jobs_from_tags(meta: dict, cells: dict[Cell, Flower], tags: dict[Cell, str],
                   usable: set[Cell], previous_jobs: list[dict]) -> tuple[list[dict], list[str]]:
    """Jobs with real cell layouts from tagged cells, plus problems to report.

    ``previous_jobs`` (the plot's recorded jobs) keep their job_id and goals
    when a rebuilt job has the same method and target.
    """
    problems: list[str] = []
    prev_by_key: dict[tuple, list[dict]] = defaultdict(list)
    for job in previous_jobs:
        prev_by_key[(job.get("method"), job.get("target"))].append(job)

    def previous(method: str, target: Flower) -> dict | None:
        found = prev_by_key.get((method, target.label()))
        return found.pop(0) if found else None

    groups: dict[int, dict[str, list[Cell]]] = defaultdict(lambda: defaultdict(list))
    for cell, tag in tags.items():
        match = TAG.match(str(tag or "").upper())
        if cell not in cells or not match:
            continue
        groups[int(match.group(1))][match.group(2)].append(cell)

    occupied = set(cells)
    jobs: list[dict] = []
    for number in sorted(groups):
        roles = groups[number]
        label = lambda role: f"{number}{role}"
        for role in ("F", "P"):
            by_flower: dict[Flower, list[Cell]] = defaultdict(list)
            for cell in sorted(roles.get(role, [])):
                by_flower[cells[cell]].append(cell)
            for flower, bed in by_flower.items():
                if role == "F":
                    target = native(flower)
                    if target is None:
                        problems.append(f"{label('F')}: {flower.label()} is not a solid with a native pattern")
                        continue
                    layout = {"parent_a_cells": [list(c) for c in bed], "parent_b_cells": [],
                              "target_cells": [], "shared_target_cells": []}
                    jobs.append(_job(meta, "fertilize_pattern", target, [flower], layout,
                                     previous("fertilize_pattern", target), len(bed)))
                else:
                    layout = {"parent_a_cells": [list(c) for c in bed], "parent_b_cells": [],
                              "target_cells": [], "shared_target_cells": []}
                    jobs.append(_job(meta, "propagate_solid", flower, [flower], layout,
                                     previous("propagate_solid", flower), len(bed)))
        donors = sorted(roles.get("A", []))
        recipients = sorted(roles.get("B", []))
        if not donors and not recipients:
            continue
        if len(donors) != 1:
            problems.append(f"Group {number} needs exactly one A plant (has {len(donors)})")
            continue
        if not recipients:
            problems.append(f"Group {number} has an A plant but no B plant")
            continue
        donor_cell = donors[0]
        donor = cells[donor_cell]
        first = True
        for rcell in recipients:
            recipient = cells[rcell]
            pair = pair_job(donor, recipient)
            if pair is None:
                problems.append(f"{number}A {donor.label()} and {number}B {recipient.label()} do not breed a target")
                continue
            if max(abs(rcell[0] - donor_cell[0]), abs(rcell[1] - donor_cell[1])) > 2:
                problems.append(f"{number}B {recipient.label()} is too far from {number}A to share a spawn cell")
                continue
            method, target = pair
            spawn = sorted(c for c in (_neighbors(donor_cell) & _neighbors(rcell) & usable) if c not in occupied)
            layout = {"parent_a_cells": [list(donor_cell)] if first else [],
                      "parent_b_cells": [list(rcell)],
                      "target_cells": [list(c) for c in spawn], "shared_target_cells": []}
            if not first:
                layout["shared_parent_a_cells"] = [list(donor_cell)]
            jobs.append(_job(meta, method, target, [donor, recipient], layout, previous(method, target), len(spawn)))
            first = False
    return jobs, problems
