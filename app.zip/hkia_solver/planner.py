from __future__ import annotations

import json
import hashlib
from collections import Counter
from functools import cached_property
from pathlib import Path

from . import progress
from .inventory import Inventory
from .models import Flower
from .optimizer import HypergraphOptimizer
from .paths import farm_data_path, tool_data_path
from .copies import planted_counts
from .plot_status import actual_assignments, load_plot_status
from .plots import configure_farm_plots
from .flow.scheduler import resolve_active_events
from .rules import COLORS, FLOWER_TYPES
from .route_concurrency_optimizer import SchedulerScorePolicy
from .targeting import (
    TARGET_CATEGORY_LABELS,
    TARGET_CATEGORY_ORDER,
    normalized_target_categories,
    target_category,
    target_priority,
)


class CollectionPlanner:
    def __init__(
        self,
        project_root: Path,
        lock_planted: bool = True,
        thorough: bool = False,
        scheduler_policy: SchedulerScorePolicy | dict | None = None,
        quick: bool = False,
    ):
        self.root = project_root
        self.settings = json.loads(farm_data_path(project_root, "settings.json").read_text(encoding="utf-8"))
        # Every plot reader (optimizer, FLOW, dashboard) sees this farm's unlocked plots.
        configure_farm_plots(self.settings)
        self.target_categories = normalized_target_categories(self.settings)
        pattern_data = json.loads(
            tool_data_path("pattern_compatibility.json").read_text(
                encoding="utf-8"
            )
        )
        self.compatible_patterns = {
            name: tuple(patterns)
            for name, patterns in pattern_data["patterns_by_flower_type"].items()
        }
        self.inventory = Inventory.load(
            farm_data_path(project_root, "inventory.json"),
            farm_data_path(project_root, "other_patterned_donors.json"),
        )
        status_path = farm_data_path(project_root, "plot_status.json")
        self.plot_status = load_plot_status(status_path)
        # v11: planted state is displayed as Actual, but never locks future recommendations.
        # Keep the constructor argument for backward compatibility with older scripts.
        self.lock_planted = False
        self.thorough = thorough
        self.quick = quick
        self.scheduler_policy = (
            SchedulerScorePolicy(**scheduler_policy)
            if isinstance(scheduler_policy, dict)
            else scheduler_policy
        )
        self.active_types = {
            name: data
            for name, data in FLOWER_TYPES.items()
            if not (self.settings["exclude_extremophiles"] and data.extreme)
        }
        # "auto" follows the event calendar (as FLOW does); the optimizer reads
        # the resolved names from settings["active_events"].
        self.active_events = resolve_active_events(self.settings.get("active_event", "auto"))
        self.settings["active_events"] = list(self.active_events)
        self.active_event = ", ".join(self.active_events) or None
        self.active_colors = tuple(
            color for color in COLORS
            if self.settings["include_brown"] or color != "Brown"
        )
        self._schedule: dict | None = None
        self._optimizer: HypergraphOptimizer | None = None
        self._targets = frozenset(self._build_targets())

    def _build_targets(self) -> set[Flower]:
        targets: set[Flower] = set()
        for name, flower_type in self.active_types.items():
            solid_category = (
                "extremophile_solids" if flower_type.extreme else "other_solids"
            )
            if self.target_categories[solid_category]:
                targets.update(
                    Flower(name, color, "Solid") for color in self.active_colors
                )
            if self.target_categories["default_patterns_effects"]:
                targets.update(
                    Flower(name, color, pattern)
                    for color in self.active_colors
                    for pattern in self.compatible_patterns[name]
                )
        return targets

    def event_active(self, event: str | None) -> bool:
        """Whether ``event`` is running now (None, a non-event flower, never is)."""
        return event is not None and event in self.active_events

    def locked_assignments(self) -> dict[str, dict]:
        """Legacy compatibility hook. Actual planted state never locks recommendations."""
        return {}

    @property
    def targets(self) -> frozenset[Flower]:
        # Immutable target scope: callers only inspect it, so returning the
        # cached frozenset avoids copying ~10k Flower objects on every lookup.
        return self._targets

    def target_category(self, flower: Flower) -> str:
        return target_category(flower, self.active_types)

    def target_priority(self, flower: Flower) -> int:
        return target_priority(flower, self.active_types)

    @cached_property
    def owned_targets(self) -> frozenset[Flower]:
        return frozenset(self.targets & self.inventory.all)

    @cached_property
    def missing_targets(self) -> frozenset[Flower]:
        return frozenset(self.targets - self.inventory.all)

    @cached_property
    def blocked_types(self) -> frozenset[str]:
        return frozenset({
            name
            for name, flower_type in self.active_types.items()
            if not self.event_active(flower_type.event) and not self.inventory.any_parent_for_type(name)
        })

    @cached_property
    def reachable_missing(self) -> frozenset[Flower]:
        blocked = self.blocked_types
        return frozenset(
            flower for flower in self.missing_targets
            if flower.flower_type not in blocked
        )

    def abundant_colors(self) -> set[str]:
        threshold = self.settings["abundant_coverage_threshold"]
        required = len(self.active_types) * threshold
        return {
            color
            for color in self.active_colors
            if len({
                flower.flower_type for flower in self.inventory.solids
                if flower.color == color and flower.flower_type in self.active_types
            }) >= required
        }

    @cached_property
    def planning_targets(self) -> frozenset[Flower]:
        # A scoped pattern goal still needs uncollected solid prerequisites;
        # excluded collection species may also supply necessary native donors.
        auxiliary = {
            Flower(name, color, pattern)
            for name, species in FLOWER_TYPES.items()
            for color in self.active_colors
            for pattern in ("Solid", species.default_pattern)
        }
        return frozenset(set(self.targets) | auxiliary)

    def optimizer(self) -> HypergraphOptimizer:
        if self._optimizer is None:
            self._optimizer = HypergraphOptimizer(
                inventory=self.inventory, flower_types=FLOWER_TYPES,
                colors=self.active_colors, targets=self.planning_targets,
                reachable=self.planning_targets, required_targets=set(self.targets),
                settings=self.settings, abundant_colors=self.abundant_colors(),
                locked_assignments=self.locked_assignments(),
                target_priorities={target: self.target_priority(target) for target in self.planning_targets},
                quick=self.quick,
            )
        return self._optimizer

    @cached_property
    def unreachable_required(self) -> frozenset[Flower]:
        """optimizer().unreachable_required, without building the full graph
        unless it already exists (that takes ~10 s; Replant plot needs only this)."""
        if self._optimizer is not None:
            return frozenset(self._optimizer.unreachable_required)
        light = HypergraphOptimizer(
            inventory=self.inventory, flower_types=FLOWER_TYPES,
            colors=self.active_colors, targets=self.planning_targets,
            reachable=self.planning_targets, required_targets=set(self.targets),
            settings=self.settings, abundant_colors=self.abundant_colors(),
            build_graph=False, quick=True,
        )
        return frozenset(self.targets - light.reachable_closure())

    @cached_property
    def collection_feasibility(self) -> dict:
        optimizer = self.optimizer()
        blocked = sorted(self.missing_targets & optimizer.unreachable_required)
        groups = {}
        rows = []
        for target in blocked:
            has_stock = any(parent.flower_type == target.flower_type for parent in optimizer.initial_owned)
            code = "missing_species_stock" if not has_stock else "no_legal_dependency_chain"
            reason = (f"No physical {target.flower_type} stock can start a breeding route."
                      if not has_stock else
                      f"No legal {target.color} {target.pattern} donor chain exists from current physical inventory under the configured season and location rules.")
            sources = ([target.flower_type] if not has_stock else [name for name, species in FLOWER_TYPES.items() if species.default_pattern == target.pattern])
            key = (code, target.flower_type if not has_stock else target.pattern)
            group = groups.setdefault(key, {"reason_code": code, "category": key[1], "count": 0,
                                           "reason": reason if not has_stock else f"No legal {target.pattern} donor chain under current inventory/season/location rules.",
                                           "native_source_types": sources})
            group["count"] += 1
            rows.append({"target": target.label(), "flower_type": target.flower_type,
                         "color": target.color, "pattern": target.pattern,
                         "reason_code": code, "reason": reason,
                         "native_source_types": sources})
        return {"feasible": not blocked, "blocked_target_count": len(blocked),
                "required_target_count": len(self.targets),
                "reachable_missing_target_count": len(self.missing_targets) - len(blocked),
                "active_event": self.active_event, "groups": list(groups.values()), "targets": rows,
                "proof": "Fixed-point closure of all modeled recipes from physical inventory; location and season legality enforced. Requested goals are unchanged."}

    def immediate_optimizer(self) -> HypergraphOptimizer:
        """Return a cheap route evaluator for previews and one-plot updates."""
        return HypergraphOptimizer(
            inventory=self.inventory,
            flower_types=self.active_types,
            colors=self.active_colors,
            targets=self.targets,
            reachable=self.reachable_missing | self.owned_targets,
            settings=self.settings,
            abundant_colors=self.abundant_colors(),
            locked_assignments={},
            build_graph=False,
            target_priorities={target: self.target_priority(target) for target in self.targets},
        )

    @cached_property
    def planning_input_key(self) -> str:
        digest = hashlib.sha256()
        for name in ("settings.json", "inventory.json", "other_patterned_donors.json", "plot_status.json"):
            path = farm_data_path(self.root, name)
            digest.update(name.encode())
            digest.update(path.read_bytes() if path.exists() else b"")
        digest.update(json.dumps(sorted(target.label() for target in self.targets)).encode())
        digest.update(json.dumps(self.active_events).encode())  # "auto" changes with the date
        return digest.hexdigest()

    def schedule(self) -> dict:
        if self._schedule is None:
            self.optimizer()                  # breeding routes first (their own progress stage)
            progress.report("schedule")
            # Actual layouts never lock plots for a fresh recommendation, but
            # every planted parent copy remains unavailable inventory until the
            # user physically changes that plot.
            planted_busy = planted_counts(self.plot_status)
            if self.scheduler_policy is not None:
                trials = [self.optimizer().schedule(
                    "background_refinement",
                    score_policy=self.scheduler_policy,
                    busy_seed=planted_busy,
                )]
            else:
                strategies = (
                    ("projected_finish", "earliest_finish", "pool_unlock", "balanced", "critical_path")
                    if self.thorough
                    else ("projected_finish",)
                )
                trials = [
                    self.optimizer().schedule(strategy, busy_seed=planted_busy)
                    for strategy in strategies
                ]
            self._schedule = min(
                trials,
                key=lambda trial: (float("inf") if trial["unscheduled_targets"] else trial["estimated_completion_days"]),
            )
            self._schedule["strategy_trials"] = {
                trial["strategy"]: (None if trial["unscheduled_targets"] else trial["estimated_completion_days"]) for trial in trials
            }
        return self._schedule

    def first_wave(self) -> list[dict]:
        return self.schedule()["first_wave"]

    def hub_type(self) -> str:
        return max(
            self.active_types,
            key=lambda name: len(self.inventory.colors_for(name, "Ombre")),
        )

    def summary(self) -> dict:
        schedule = self.schedule()
        feasibility = self.collection_feasibility
        viable_complete = not schedule["unscheduled_targets"] and not schedule.get("provisional", False)
        complete = viable_complete and feasibility["feasible"]
        excluded = sorted(
            name
            for name, data in FLOWER_TYPES.items()
            if data.extreme and name not in self.active_types
        )
        donor_colors = Counter(flower.color for flower in self.inventory.all_patterned)
        category_counts = Counter(self.target_category(target) for target in self.targets)
        owned_category_counts = Counter(
            self.target_category(target) for target in self.owned_targets
        )
        return {
            "as_of": self.settings["as_of"],
            "platform": self.settings["platform"],
            "active_event": self.active_event,
            "month_of_meh_ended": self.settings["month_of_meh_ended"],
            "colors": len(self.active_colors),
            "active_flower_types": len(self.active_types),
            "total_targets": len(self.targets),
            "owned_targets": len(self.owned_targets),
            "owned_solids_all_screenshot_types": len(self.inventory.solids),
            "owned_ombres_all_screenshot_types": len(self.inventory.ombres),
            "assumed_other_patterned_donors": len(self.inventory.other_patterned),
            "missing_targets": len(self.missing_targets),
            "target_categories": [
                {
                    "key": key,
                    "label": TARGET_CATEGORY_LABELS[key],
                    "priority": index + 1,
                    "enabled": self.target_categories[key],
                    "supported": key != "non_default_secondary_patterns",
                    "targets": category_counts[key],
                    "owned": owned_category_counts[key],
                }
                for index, key in enumerate(TARGET_CATEGORY_ORDER)
            ],
            "reachable_missing_targets": feasibility["reachable_missing_target_count"],
            "blocked_types": sorted(self.blocked_types),
            "blocked_targets": feasibility["blocked_target_count"],
            "excluded_extremophiles": excluded,
            "abundant_colors_inferred": sorted(self.abundant_colors(), key=self.active_colors.index),
            "hub_type": self.hub_type(),
            "hub_owned_ombres": len(self.inventory.colors_for(self.hub_type(), "Ombre")),
            "colors_without_any_patterned_donor": [
                color for color in self.active_colors if donor_colors[color] == 0
            ],
            "estimated_completion_days": schedule["estimated_completion_days"],
            "provisional": schedule.get("provisional", False),
            "collection_feasible": feasibility["feasible"],
            "optimization_objective": "minimize completion time for every currently viable configured target",
            "planning_input_key": self.planning_input_key,
            "viable_target_count": len(self.targets) - feasibility["blocked_target_count"],
            "viable_missing_target_count": feasibility["reachable_missing_target_count"],
            "viable_complete": viable_complete,
            "viable_finish_days": schedule["estimated_completion_days"] if viable_complete else None,
            "collection_complete": complete,
            "collection_finish_days": (schedule["estimated_completion_days"] if complete else None),
            "selected_scheduling_strategy": schedule["strategy"],
            "strategy_trials": schedule["strategy_trials"],
            "background_fertilization_jobs": len(schedule.get("background_first_wave", [])),
            "usable_physical_plots": schedule["usable_physical_plots"],
            "first_wave_physical_plots_used": schedule["first_wave_physical_plots_used"],
            "first_wave_job_count": schedule["first_wave_job_count"],
            "graph_nodes": schedule["graph_nodes"],
            "graph_routes_selected": schedule["graph_routes_selected"],
            "unscheduled_target_count": len(schedule["unscheduled_targets"]),
            "actual_planted_slots": len(actual_assignments(self.plot_status)),
            "locked_active_slots": len(self.locked_assignments()),
            "reserved_parent_copies": sum(planted_counts(self.plot_status).values()),
        }

    def build_plan(self) -> dict:
        schedule = self.schedule()
        other_pattern_transfers = [
            row for row in schedule["completion_schedule"]
            if row["method"] == "color_transfer"
            and any(pattern not in {"Solid", "Ombre"} for pattern in row["parent_patterns"])
        ]
        return {
            "summary": self.summary(),
            "optimization": {
                "objective": "minimize completion time for every currently viable configured target",
                "plot_layout_strategy": schedule.get("plot_layout_strategy", {}),
                "hard_constraints": [
                    "reserve each native extremophile plot for that species' missing solids",
                    "exclude non-default-secondary patterned hybrids from target scope",
                ],
                "pooled_resources": [
                    "color + location coverage",
                    "pattern/effect + primary color + location coverage",
                ],
                "default_rollout": "projected_finish",
                "thorough_rollouts": [
                    "projected_finish", "earliest_finish", "pool_unlock",
                    "balanced", "critical_path",
                ],
                "background_refinement_policy": schedule.get("score_policy"),
                "stop_reason": schedule.get("stop_reason"),
                "provisional": schedule.get("provisional", False),
                "rollout_diagnostics": schedule.get("rollout_diagnostics", {}),
                "readiness_rechecks": schedule.get("readiness_rechecks", 0),
            },
            "method_counts": {
                "first_wave": schedule["first_wave_method_counts"],
                "full_schedule": schedule["full_schedule_method_counts"],
            },
            "first_wave": schedule["first_wave"],
            "background_first_wave": schedule.get("background_first_wave", []),
            "plot_jobs": schedule.get("plot_jobs", {}),
            "completion_schedule": schedule["completion_schedule"],
            "other_pattern_color_transfers": other_pattern_transfers,
            "color_donor_pools": self.optimizer().color_donor_pool_summary(),
            "pattern_donor_pools": self.optimizer().pattern_donor_pool_summary(),
            "feasibility": self.collection_feasibility,
            "unscheduled_targets": schedule["unscheduled_targets"],
            "decision_log": schedule.get("decision_log", []),
        }

    def write_outputs(self) -> tuple[Path, dict]:
        plan = self.build_plan()
        output = self.root / "output"
        output.mkdir(exist_ok=True)
        json_path = output / "latest_plan.json"
        decision_log = plan.pop("decision_log", [])
        (output / "latest_decision_log.json").write_text(
            json.dumps(decision_log, indent=2), encoding="utf-8"
        )
        json_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
        return json_path, plan
