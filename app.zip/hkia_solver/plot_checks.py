"""Daily "checked" marks for plots, cleared every day at the game's daily reset.

The game resets at 06:00 UTC every day of the year (10 pm PST, 11 pm PDT;
it moved from 11 pm to 10 pm Pacific when daylight saving time ended).
A mark stores when it was made; it counts only if it was made after the most
recent reset, so nothing has to run at reset time.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .paths import farm_data_path
from .plot_status import save_plot_status
from .plots import all_slots

CHECKS_FILE = "plot_checks.json"
RESET_UTC_HOUR = 6  # the game's daily reset, 06:00 UTC all year


def last_reset(now: datetime | None = None) -> datetime:
    """The most recent daily reset at or before ``now``, in UTC."""
    utc = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    reset = utc.replace(hour=RESET_UTC_HOUR, minute=0, second=0, microsecond=0)
    return reset if utc >= reset else reset - timedelta(days=1)


def next_reset(now: datetime | None = None) -> datetime:
    return last_reset(now) + timedelta(days=1)


def _path(root: Path) -> Path:
    return farm_data_path(root, CHECKS_FILE)


def _current(root: Path, now: datetime | None) -> dict[str, str]:
    path = _path(root)
    if not path.is_file():
        return {}
    since = last_reset(now)
    checked = json.loads(path.read_text(encoding="utf-8")).get("checked", {})
    return {
        slot: stamp for slot, stamp in checked.items()
        if datetime.fromisoformat(stamp) >= since
    }


def plot_checks(root: Path, now: datetime | None = None) -> dict:
    return {
        "checked": sorted(_current(root, now)),
        "resets_at": next_reset(now).isoformat(),
    }


def set_plots_checked(root: Path, slots: list[str], checked: bool, now: datetime | None = None) -> dict:
    slots = [slot.upper() for slot in slots]
    unknown = set(slots) - {item.slot for item in all_slots()}
    if unknown:
        raise ValueError(f"Unknown plot slot: {', '.join(sorted(unknown))}")
    marks = _current(root, now)  # also drops marks from before the last reset
    stamp = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()
    for slot in slots:
        if checked:
            marks[slot] = stamp
        else:
            marks.pop(slot, None)
    save_plot_status(_path(root), {"checked": marks})
    return plot_checks(root, now)


def set_plot_checked(root: Path, slot: str, checked: bool, now: datetime | None = None) -> dict:
    result = set_plots_checked(root, [slot], checked, now)
    return {"message": f"{slot.upper()} {'checked' if checked else 'unchecked'} for today.", **result}
