"""Daily "checked" marks for plots, cleared every day at the game's daily reset.

The game resets at midnight Mountain Time (wiki: "12:00 AM MST"), so it
follows US daylight saving: 07:00 UTC in winter (11 pm PST), 06:00 UTC in
summer (11 pm PDT). It is 11 pm Pacific all year.
A mark stores when it was made; it counts only if it was made after the most
recent reset, so nothing has to run at reset time.
"""
from __future__ import annotations

import json
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .paths import farm_data_path
from .plot_status import save_plot_status
from .plots import all_slots

CHECKS_FILE = "plot_checks.json"


def _sunday(year: int, month: int, nth: int) -> date:
    first = date(year, month, 1)
    return first + timedelta(days=(6 - first.weekday()) % 7 + 7 * (nth - 1))


def reset_on(day: date) -> datetime:
    """The reset that starts game day ``day``: midnight Mountain Time, in UTC.

    US daylight saving runs from the second Sunday in March to the first Sunday
    in November (both at 2 am, so midnight on those Sundays is still on the old
    clock). Coded by hand: Windows Python and Pyodide have no tz database.
    """
    daylight = _sunday(day.year, 3, 2) < day <= _sunday(day.year, 11, 1)
    return datetime(day.year, day.month, day.day, 6 if daylight else 7, tzinfo=timezone.utc)


def last_reset(now: datetime | None = None) -> datetime:
    """The most recent daily reset at or before ``now``, in UTC."""
    utc = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
    reset = reset_on(utc.date())
    return reset if utc >= reset else reset_on(utc.date() - timedelta(days=1))


def next_reset(now: datetime | None = None) -> datetime:
    return reset_on(last_reset(now).date() + timedelta(days=1))


def game_day(moment: datetime | None = None) -> date:
    """The in-game day ``moment`` falls in (the Mountain Time date)."""
    return last_reset(moment).date()


def _path(root: Path) -> Path:
    return farm_data_path(root, CHECKS_FILE)


def _current(root: Path, now: datetime | None) -> dict[str, str]:
    path = _path(root)
    if not path.is_file():
        return {}
    since = last_reset(now)
    checked = json.loads(path.read_text(encoding="utf-8")).get("checked", {})
    return {
        slot: stamp for slot, stamp in checked.items()
        if datetime.fromisoformat(stamp) >= since
    }


def plot_checks(root: Path, now: datetime | None = None) -> dict:
    return {
        "checked": sorted(_current(root, now)),
        "resets_at": next_reset(now).isoformat(),
    }


def set_plots_checked(root: Path, slots: list[str], checked: bool, now: datetime | None = None) -> dict:
    slots = [slot.upper() for slot in slots]
    unknown = set(slots) - {item.slot for item in all_slots()}
    if unknown:
        raise ValueError(f"Unknown plot slot: {', '.join(sorted(unknown))}")
    marks = _current(root, now)  # also drops marks from before the last reset
    stamp = (now or datetime.now(timezone.utc)).astimezone(timezone.utc).isoformat()
    for slot in slots:
        if checked:
            marks[slot] = stamp
        else:
            marks.pop(slot, None)
    save_plot_status(_path(root), {"checked": marks})
    return plot_checks(root, now)


def set_plot_checked(root: Path, slot: str, checked: bool, now: datetime | None = None) -> dict:
    result = set_plots_checked(root, [slot], checked, now)
    return {"message": f"{slot.upper()} {'checked' if checked else 'unchecked'} for today.", **result}
