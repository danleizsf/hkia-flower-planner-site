from __future__ import annotations

from dataclasses import dataclass
Pattern = str


@dataclass(frozen=True)
class Flower:
    flower_type: str
    color: str
    pattern: Pattern
    secondary_color: str | None = None

    # Flowers key nearly every dict in planning. The generated __hash__
    # rebuilds a tuple on each lookup; this caches that same value, so set
    # and dict order (and with it every plan) are unchanged.
    def __hash__(self) -> int:
        try:
            return self.__dict__["_hash"]
        except KeyError:
            h = hash((self.flower_type, self.color, self.pattern, self.secondary_color))
            object.__setattr__(self, "_hash", h)
            return h

    def __getstate__(self) -> dict:
        # String hashes differ between processes: never carry one across.
        state = dict(self.__dict__)
        state.pop("_hash", None)
        return state

    def sort_key(self) -> tuple[str, str, str, str]:
        return (
            self.flower_type,
            self.color,
            self.pattern,
            self.secondary_color or "",
        )

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, Flower):
            return NotImplemented
        return self.sort_key() < other.sort_key()

    def label(self) -> str:
        secondary = f" & {self.secondary_color}" if self.secondary_color else ""
        suffix = "" if self.pattern == "Solid" else f"{secondary} {self.pattern}"
        return f"{self.color}{suffix} {self.flower_type}"


@dataclass(frozen=True)
class FlowerType:
    name: str
    default_colors: tuple[str, ...]
    default_pattern: str
    native_region: str
    event: str | None = None
    extreme: bool = False


@dataclass(frozen=True)
class Action:
    target: Flower
    method: str
    parent_a: Flower
    parent_b: Flower | None
    per_cell_probability: float
    eligible_cells: int
    location: str
    expected_days: float
    daily_probability: float
    leverage: int
    reason: str
    prerequisite: str | None = None

