"""The dashboard's JSON API, independent of how requests arrive.

``ui.py`` serves it over HTTP; the browser build (``browser/``) calls it from
a Web Worker running Pyodide. Both map errors the same way through
``dispatch``.
"""
from __future__ import annotations

import json
import math

from .history import new_flowers
from .plot_checks import plot_checks, set_plot_checked


def encode_json_response(payload: object) -> bytes:
    """Encode strict JSON, mapping Python's non-finite floats to JSON null.

    Python's default encoder emits ``Infinity`` and ``NaN`` tokens, which are
    not part of the JSON standard and cause browser ``response.json()`` calls
    to fail. Keep internal calculations numeric, but normalize API output.
    """
    def normalize(value: object) -> object:
        if isinstance(value, float) and not math.isfinite(value):
            return None
        if isinstance(value, dict):
            return {key: normalize(item) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [normalize(item) for item in value]
        return value

    try:
        # Payloads almost never hold NaN/Infinity; walking the whole state to
        # normalize it costs ~0.2 s, so only do that when encoding refuses.
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False)
    except ValueError:
        encoded = json.dumps(normalize(payload), ensure_ascii=False, allow_nan=False)
    return encoded.encode("utf-8")


class UnknownEndpoint(LookupError):
    pass


GET_ROUTES = {
    "/api/state": lambda s: s.state(),
    # The page's first load and refreshes: the farm first, its inventory right after.
    "/api/state/core": lambda s: s.state(include_inventory=False),
    "/api/inventory": lambda s: s.inventory_view(),
    "/api/collection/blocking": lambda s: s.collection_blocking_routes(),
    "/api/history/new-flowers": lambda s: {"flowers": new_flowers(s.root)},
    "/api/flow/roadmap": lambda s: s.flow_roadmap(),
    "/api/plan/status": lambda s: s.plan_generation_status(),
    "/api/plots/checks": lambda s: plot_checks(s.root),
    "/api/farm/plots": lambda s: s.farm_plots(),
    "/api/setup": lambda s: s.setup_status(),
    "/api/setup/collection": lambda s: s.collection_setup(),
    "/api/events": lambda s: s.current_events(),
}

# POST routes that change the farm (ui.py runs these one at a time).
MUTATIONS = {
    "/api/spawns": lambda s, p: s.record_spawns(p.get("entries", []), p.get("slot")),
    "/api/inventory": lambda s, p: s.update_inventory(
        p.get("action", "set"), p["flower_type"], p["color"], p["pattern"],
        int(p.get("count", 0)), p.get("secondary_color"),
    ),
    "/api/plots/apply": lambda s, p: s.apply_plots(p.get("slots", []), confirmed=p.get("confirmed") is True),
    "/api/plots/clear": lambda s, p: s.clear_plots(p.get("slots", [])),
    "/api/plots/cells": lambda s, p: s.update_plot_cells(p["slot"], p.get("cells", [])),
    "/api/plots/manual-target/preview": lambda s, p: s.preview_manual_plot_target(
        p["slot"], p["flower_type"], p["color"], p["pattern"],
    ),
    "/api/plots/manual-target": lambda s, p: s.attach_manual_plot_target(
        p["slot"], p["flower_type"], p["color"], p["pattern"], bool(p.get("confirmed", False)),
    ),
    "/api/plots/target/preview": lambda s, p: s.preview_plot_target(
        p["slot"], p["flower_type"], p["color"], p["pattern"],
    ),
    "/api/plots/target": lambda s, p: s.change_plot_target(
        p["slot"], p["flower_type"], p["color"], p["pattern"], bool(p.get("confirmed", False)),
    ),
    "/api/plots/targets/preview": lambda s, p: s.preview_managed_target(
        p["slot"], p["scope"], p["action"], p["flower_type"], p["color"], p["pattern"], p.get("job_id"),
    ),
    "/api/plots/targets": lambda s, p: s.manage_plot_target(
        p["slot"], p["scope"], p["action"], p.get("job_id"), p.get("flower_type"), p.get("color"),
        p.get("pattern"), bool(p.get("confirmed", False)),
    ),
    "/api/plots/recommendation": lambda s, p: s.update_plot_recommendation(p["slot"]),
    "/api/settings/fillers": lambda s, p: s.set_fillers(p.get("enabled") is True),
    "/api/settings/cogimyun": lambda s, p: s.set_cogimyun(p.get("enabled") is True),
    "/api/plots/missing-plant": lambda s, p: s.mark_plant_missing(
        p["slot"], p["flower_type"], p["color"], p["pattern"], p.get("secondary_color"), int(p.get("free", 0)),
    ),
    "/api/plots/map": lambda s, p: s.update_plot_map_details(
        p["slot"], p["name"], p.get("location", ""), int(p["column"]), int(p["row"]), int(p["span"]),
    ),
    "/api/plots/map/move": lambda s, p: s.move_plot_map_card(p["slot"], int(p["column"]), int(p["row"])),
    "/api/plots/map/lock": lambda s, p: s.set_plot_map_lock(p["slot"], bool(p["locked"])),
    "/api/plots/checks": lambda s, p: set_plot_checked(s.root, p["slot"], bool(p["checked"])),
    "/api/regions/collapse": lambda s, p: s.set_region_map_collapsed(p["region"], bool(p["collapsed"])),
    "/api/regions/columns": lambda s, p: s.set_region_map_columns(p["region"], int(p["cards_per_row"])),
    "/api/found": lambda s, p: s.found(
        p["slot"], int(p.get("count", 1)), p.get("job_id"), cell=p.get("cell"),
        dug_up=bool(p.get("dug_up")), replaced=bool(p.get("replaced")),
        found_in=p.get("found_in"),
    ),
    "/api/plots/plant-changed": lambda s, p: s.plant_changed(
        p["slot"], int(p["row"]), int(p["col"]), p["pattern"],
        dug_up=bool(p.get("dug_up")), replaced=bool(p.get("replaced")),
    ),
    "/api/plan": lambda s, p: s.start_plan_generation(
        target_categories=p.get("target_categories"), replant_all=bool(p.get("replant_all", False)),
    ),
    "/api/flow/forecast": lambda s, p: s.start_flow_forecast(force=True, full=p.get("full") is True),
    "/api/farm/plots": lambda s, p: s.set_farm_plots(
        p.get("unlocked_plots"), None if p.get("greenhouse_level") is None else int(p["greenhouse_level"]),
    ),
    "/api/setup": lambda s, p: s.mark_setup_step(p["step"], p.get("value", True)),
    "/api/setup/collection": lambda s, p: s.set_collection(p.get("collect", []), p.get("uncollect", [])),
    "/api/setup/hint": lambda s, p: s.mark_hint_seen(str(p.get("hint", ""))),
}

# POST routes that run outside the mutation lock.
UNLOCKED = {
    "/api/plan/cancel": lambda s, p: s.cancel_plan(),
}


def is_api_get(path: str) -> bool:
    return path in GET_ROUTES


def get(service, path: str) -> dict:
    return GET_ROUTES[path](service)


def post(service, path: str, payload: dict, lock=None) -> dict:
    """Run a POST route; ``lock`` (a context manager) wraps the farm-changing ones."""
    if path in UNLOCKED:
        return {"ok": True, **UNLOCKED[path](service, payload)}
    route = MUTATIONS.get(path)
    if route is None:
        raise UnknownEndpoint(path)
    if lock is None:
        return {"ok": True, **route(service, payload)}
    with lock:
        return {"ok": True, **route(service, payload)}


def dispatch(service, method: str, path: str, payload: dict | None = None, lock=None) -> tuple[int, dict]:
    """(status, JSON body) for one API request, with the HTTP server's error mapping."""
    try:
        if method == "GET":
            if path not in GET_ROUTES:
                raise UnknownEndpoint(path)
            return 200, get(service, path)
        return 200, post(service, path, payload or {}, lock)
    except UnknownEndpoint:
        return 404, {"error": "Unknown API endpoint"}
    except (KeyError, TypeError, ValueError) as error:
        # A failing GET is the server's problem; a bad POST body is the caller's.
        return (500 if method == "GET" else 400), {"error": str(error)}
    except Exception as error:
        return 500, {"error": str(error)}
