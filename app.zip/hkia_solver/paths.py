"""Where things live.

The program folder holds code and the game-rule files in ``data/``. Your farm
lives in a separate *data folder* so a new release can be unzipped anywhere
without touching it. The data folder contains:

    farm_data/   inventory, planted plots, settings, map layout, history
    output/      the current plan, its decision log, and optimizer runs
"""
from __future__ import annotations

import json
import os
from pathlib import Path


PROGRAM_ROOT = Path(__file__).resolve().parents[1]
TOOL_DATA_DIR = "data"
FARM_DATA_DIR = "farm_data"
OUTPUT_DIR = "output"
DATA_DIR_ENV = "HKIA_PLANNER_DATA"
DEFAULT_DATA_DIR_NAME = "HKIA Flower Planner Data"
CONFIG_FILE = PROGRAM_ROOT / "planner_config.json"


def configured_data_dir(config_file: Path = CONFIG_FILE) -> Path | None:
    """The "data_dir" set in planner_config.json, or None when it is empty."""
    if not config_file.is_file():
        return None
    # Accept Windows paths typed with single backslashes ("D:\HKIA Farm"):
    # nothing in this file needs JSON escapes, so treat every backslash as a
    # path separator.
    text = config_file.read_text(encoding="utf-8").replace("\\\\", "/").replace("\\", "/")
    try:
        config = json.loads(text)
    except json.JSONDecodeError as error:
        raise ValueError(
            f"{config_file} is not valid JSON ({error}). "
            'It should look like: {"data_dir": "D:/HKIA Farm"}'
        ) from error
    value = str(config.get("data_dir") or "").strip()
    if not value:
        return None
    path = Path(value).expanduser()
    # A relative path is relative to the program folder.
    return (path if path.is_absolute() else PROGRAM_ROOT / path).resolve()


def default_data_root(config_file: Path = CONFIG_FILE) -> Path:
    """Where your farm lives when --data-dir isn't given.

    In order: the HKIA_PLANNER_DATA environment variable, "data_dir" in
    planner_config.json, then ~/HKIA Flower Planner Data.
    """
    override = os.environ.get(DATA_DIR_ENV, "").strip()
    if override:
        return Path(override).expanduser().resolve()
    configured = configured_data_dir(config_file)
    if configured is not None:
        return configured
    return Path.home() / DEFAULT_DATA_DIR_NAME


def tool_data_path(filename: str) -> Path:
    """Release-owned game rules and display configuration."""
    return PROGRAM_ROOT / TOOL_DATA_DIR / filename


def farm_data_path(root: Path, filename: str) -> Path:
    """User-owned inventory, farm state, settings, and UI layout."""
    return root / FARM_DATA_DIR / filename


def has_farm_data(root: Path) -> bool:
    return (root / FARM_DATA_DIR / "inventory.json").is_file()
