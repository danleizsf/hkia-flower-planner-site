"""Bounded policy helpers for concurrent attempts on one collection goal.

The scheduler uses independent daily chances from separate plots or disjoint
spawn areas. A second attempt is considered only while the goal's combined
chance is below the configured floor; plot and parent availability still decide
whether that attempt can actually be placed.
"""
from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass


TARGET_DAILY_CHANCE_FLOOR = 0.20
MIN_RELATIVE_FINISH_GAIN = 0.02
MIN_ABSOLUTE_FINISH_GAIN_DAYS = 0.05


@dataclass(frozen=True)
class FinishTimeConfig:
    """Bounded route-search settings loaded from ``settings.json``.

    The initial search scope is standard (non-extremophile) flowers. Existing
    rules still schedule out-of-scope goals; this config only controls the new
    all-routes/concurrent-attempt search.
    """

    enabled: bool = True
    include_solids: bool = True
    include_patterns: bool = True
    include_extremophiles: bool = False
    include_secondary_patterns: bool = False
    target_daily_chance_floor: float = TARGET_DAILY_CHANCE_FLOOR
    max_routes_per_target: int = 24
    max_concurrent_attempts_per_target: int = 8
    beam_width: int = 12

    @classmethod
    def from_settings(cls, settings: dict) -> "FinishTimeConfig":
        raw = settings.get("finish_time_optimizer", {})
        if not isinstance(raw, dict):
            raw = {}
        chance_floor = float(raw.get("target_daily_chance_floor", TARGET_DAILY_CHANCE_FLOOR))
        return cls(
            enabled=bool(raw.get("enabled", True)),
            include_solids=bool(raw.get("include_solids", True)),
            include_patterns=bool(raw.get("include_patterns", True)),
            include_extremophiles=bool(raw.get("include_extremophiles", False)),
            include_secondary_patterns=bool(raw.get("include_secondary_patterns", False)),
            target_daily_chance_floor=min(1.0, max(0.0, chance_floor)),
            max_routes_per_target=max(1, min(64, int(raw.get("max_routes_per_target", 24)))),
            max_concurrent_attempts_per_target=max(
                1, min(24, int(raw.get("max_concurrent_attempts_per_target", 8)))
            ),
            beam_width=max(1, min(64, int(raw.get("beam_width", 12)))),
        )

    def applies(self, target, flower_types: dict) -> bool:
        if not self.enabled:
            return False
        flower_type = flower_types.get(target.flower_type)
        if flower_type is None or (flower_type.extreme and not self.include_extremophiles):
            return False
        if target.secondary_color is not None and not self.include_secondary_patterns:
            return False
        return self.include_solids if target.pattern == "Solid" else self.include_patterns


@dataclass(frozen=True)
class SchedulerScorePolicy:
    """Weights for exploring alternative ready-job choices in v71."""

    name: str
    descendant_weight: float
    critical_tail_weight: float
    donor_pool_weight: float
    type_diversity_weight: float = 0.20

    def as_dict(self) -> dict[str, float | str]:
        return {
            "name": self.name,
            "descendant_weight": self.descendant_weight,
            "critical_tail_weight": self.critical_tail_weight,
            "donor_pool_weight": self.donor_pool_weight,
            "type_diversity_weight": self.type_diversity_weight,
        }


BACKGROUND_SCORE_SEEDS = (
    SchedulerScorePolicy("balanced", 0.45, 0.35, 0.75, 0.20),
    SchedulerScorePolicy("short_jobs", 0.05, 0.05, 0.10, 0.20),
    SchedulerScorePolicy("dependency_unlock", 0.95, 0.25, 0.80, 0.20),
    SchedulerScorePolicy("critical_tail", 0.25, 1.00, 0.70, 0.20),
    SchedulerScorePolicy("donor_pool", 0.35, 0.25, 1.50, 0.20),
    SchedulerScorePolicy("type_diversity", 0.55, 0.30, 1.00, 0.60),
)


def next_policy_from_incumbent(incumbent: SchedulerScorePolicy, trial_index: int) -> SchedulerScorePolicy:
    """Produce a deterministic coordinate-search neighbor of the best policy."""
    dimensions = (
        ("descendant_weight", (0.65, 1.35), 0.0, 2.0),
        ("critical_tail_weight", (0.65, 1.35), 0.0, 2.0),
        ("donor_pool_weight", (0.65, 1.35), 0.0, 2.0),
        ("type_diversity_weight", (0.65, 1.35), 0.0, 1.5),
    )
    dimension_index = (trial_index // 2) % len(dimensions)
    direction_index = trial_index % 2
    name, multipliers, minimum, maximum = dimensions[dimension_index]
    values = {
        "descendant_weight": incumbent.descendant_weight,
        "critical_tail_weight": incumbent.critical_tail_weight,
        "donor_pool_weight": incumbent.donor_pool_weight,
        "type_diversity_weight": incumbent.type_diversity_weight,
    }
    values[name] = min(maximum, max(minimum, values[name] * multipliers[direction_index]))
    return SchedulerScorePolicy(
        name=f"{incumbent.name}_{name}_{'down' if direction_index == 0 else 'up'}",
        **values,
    )


def combine_daily_probabilities(probabilities: Iterable[float]) -> float:
    """Return the chance of at least one success across independent attempts."""
    miss_probability = 1.0
    for probability in probabilities:
        chance = max(0.0, min(1.0, float(probability)))
        miss_probability *= 1.0 - chance
    return 1.0 - miss_probability


def farm_makespan_after_attempt(
    probabilities: dict,
    critical_tail: dict,
    target,
    added_probability: float,
    *,
    chance_floor: float = TARGET_DAILY_CHANCE_FLOOR,
) -> tuple[float, float, float] | None:
    """Return ``(new_chance, old_farm_finish, new_farm_finish)`` if useful.

    ``critical_tail`` supplies the modeled remaining downstream work for each
    active collection target. The added route is admitted only if it lowers the
    maximum projected finish among active targets, then must clear the relative
    and absolute gain gate. This prevents a probability boost to a non-critical
    target from taking plot space when it cannot move collection completion.
    """
    current = max(0.0, min(1.0, float(probabilities.get(target, 0.0))))
    if current >= chance_floor:
        return None
    new_chance = combine_daily_probabilities((current, added_probability))
    if new_chance <= current:
        return None

    def finish(chance: float) -> float:
        return 1.0 / chance if chance > 0 else float("inf")

    other_finish = max(
        (
            finish(chance) + max(0.0, float(critical_tail.get(other, 0.0)))
            for other, chance in probabilities.items()
            if other != target and chance > 0
        ),
        default=0.0,
    )
    tail = max(0.0, float(critical_tail.get(target, 0.0)))
    old_finish = max(other_finish, finish(current) + tail)
    new_finish = max(other_finish, finish(new_chance) + tail)
    gain = old_finish - new_finish
    required = max(MIN_ABSOLUTE_FINISH_GAIN_DAYS, old_finish * MIN_RELATIVE_FINISH_GAIN)
    if gain < required:
        return None
    return new_chance, old_finish, new_finish
