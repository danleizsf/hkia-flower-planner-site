from __future__ import annotations

import heapq
import math
from collections import Counter, defaultdict, deque
from dataclasses import dataclass

from . import progress
from .inventory import Inventory
from .models import Flower, FlowerType
from .plots import (
    PlotSlot,
    all_slots,
    isolated_pair_layout,
    isolated_pair_zones,
    neighboring_cells,
    usable_cells,
)
from .rules import BREED_PROBABILITY, FLOWER_TYPES, parents_for_mix
from .plot_status import effective_stock_goal
from .plot_layout_optimizer import (
    add_makespan_reducing_pairs,
    choose_zone_batch,
    evaluate_cell_outcomes,
    pair_placements,
)
from .route_concurrency_optimizer import (
    FinishTimeConfig,
    SchedulerScorePolicy,
    combine_daily_probabilities,
    farm_makespan_after_attempt,
)
from .greenhouse_layout_optimizer import (
    fanout_reduces_donor_wait,
    pattern_transfer_fanout_layout,
)
from .zones import flower_zones, route_allowed


# Outdoor packing first gives each distinct ready collection goal one safe
# micro-zone, then balances remaining zones across active goals. This avoids
# letting the first selected route consume a whole plot before another goal can
# start, while still using spare zones to improve collection throughput.


@dataclass(frozen=True)
class Route:
    target: Flower
    method: str
    parents: tuple[Flower, ...]

class HypergraphOptimizer:
    """Shortest dependency paths plus parallel expected-duration scheduling."""

    def __init__(
        self,
        inventory: Inventory,
        flower_types: dict[str, FlowerType],
        colors: tuple[str, ...],
        targets: set[Flower],
        reachable: set[Flower],
        settings: dict,
        abundant_colors: set[str],
        locked_assignments: dict[str, dict] | None = None,
        build_graph: bool = True,
        target_priorities: dict[Flower, int] | None = None,
        quick: bool = False,
        required_targets: set[Flower] | None = None,
    ) -> None:
        self.quick = quick
        self.inventory = inventory
        self.flower_types = flower_types
        self.colors = colors
        self.targets = targets
        self.required_targets = set(targets if required_targets is None else required_targets)
        self.reachable = reachable
        self.settings = settings
        self.abundant_colors = abundant_colors
        self.locked_assignments = locked_assignments or {}
        self.finish_time_config = FinishTimeConfig.from_settings(settings)
        self._active_score_policy: SchedulerScorePolicy | None = None
        self.target_priorities = target_priorities or {}
        self.progress_callback = None
        # A collected flower with an explicit zero count remains in the
        # collection, but the dependency graph must breed a replacement before
        # it can be used as a parent.
        self.initial_owned = {
            flower for flower in inventory.all
            if inventory.counts.get(flower, 1) > 0
        }
        self._initial_capacity = {
            flower: inventory.capacity(flower, abundant_colors)
            for flower in self.initial_owned
        }
        self._patterned_by_color: dict[str, set[Flower]] = defaultdict(set)
        self._pattern_by_color: dict[tuple[str, str], set[Flower]] = defaultdict(set)
        for flower in self.targets | self.initial_owned:
            if flower.pattern == "Solid":
                continue
            self._patterned_by_color[flower.color].add(flower)
            if flower.secondary_color is None:
                self._pattern_by_color[(flower.pattern, flower.color)].add(flower)
        capacity_key = lambda flower: (
            flower not in self.initial_owned,
            flower.pattern == "Ombre",
            -self._initial_capacity.get(flower, 1),
            flower.label(),
        )
        self._patterned_order_by_color = {
            color: tuple(sorted(flowers, key=capacity_key))
            for color, flowers in self._patterned_by_color.items()
        }
        self._pattern_order_by_color = {
            key: tuple(sorted(flowers, key=capacity_key))
            for key, flowers in self._pattern_by_color.items()
        }
        self._solid_order_by_type = {
            flower_type: tuple(sorted(
                (Flower(flower_type, color, "Solid") for color in self.colors),
                key=capacity_key,
            ))
            for flower_type in self.flower_types
        }
        # Working-stock demand is intentionally separate from generic graph
        # leverage. Color-transfer donors are a shared same-color pool, and
        # color-transfer recipients may be any non-target solid color of the
        # recipient species, so neither side should inflate an exact flower's
        # propagation goal.
        self._color_transfer_demand_by_color: dict[str, tuple[Flower, ...]] = {}
        demand_lists: dict[str, list[Flower]] = defaultdict(list)
        for target in self.reachable:
            if (
                target.pattern == "Solid"
                and target not in self.initial_owned
            ):
                demand_lists[target.color].append(target)
        self._color_transfer_demand_by_color = {
            color: tuple(items) for color, items in demand_lists.items()
        }
        # Coverage depends on donor species + primary color, not on which
        # pattern carries that color, so share profiles across patterned forms.
        self._color_donor_coverage_cache: dict[tuple[str, str], dict] = {}

        # Pattern transfer is also a pooled resource. A donor is identified by
        # pattern/effect + primary color + where its species can be planted.
        # Exact donor species is not intrinsically valuable; it only matters
        # when it changes location coverage or is the same species as a
        # recipient (which cannot receive from itself).
        pattern_demand_lists: dict[tuple[str, str], list[Flower]] = defaultdict(list)
        for target in self.reachable:
            if target.pattern == "Solid" or target in self.initial_owned:
                continue
            if self.flower_types[target.flower_type].default_pattern == target.pattern:
                # Native/default patterns can be obtained by fertilizing their
                # own solid and therefore do not require a transfer donor.
                continue
            pattern_demand_lists[(target.pattern, target.color)].append(target)
        self._pattern_transfer_demand_by_key = {
            key: tuple(items) for key, items in pattern_demand_lists.items()
        }
        self._pattern_donor_coverage_cache: dict[tuple[str, str, str], dict] = {}

        # Static marginal-coverage baselines keep v19 scoring cheap. They are
        # intentionally based on the starting inventory; the competing rollout
        # simulation still captures dynamic unlock timing through readiness,
        # while avoiding a full 10k-target pool-union calculation for every
        # candidate score.
        self._initial_color_pool_coverage: dict[str, frozenset[str]] = {}
        self._initial_color_pool_capacity: dict[str, int] = {}
        for color in self.colors:
            covered: set[str] = set()
            capacity = 0
            for donor in self._patterned_by_color.get(color, ()):
                if donor in self.initial_owned:
                    covered.update(self._color_donor_coverage(donor)["covered_types"])
                    capacity += self._initial_capacity.get(donor, 1)
            self._initial_color_pool_coverage[color] = frozenset(covered)
            self._initial_color_pool_capacity[color] = capacity

        self._initial_pattern_pool_coverage: dict[tuple[str, str], frozenset[str]] = {}
        self._initial_pattern_pool_capacity: dict[tuple[str, str], int] = {}
        for key in self._pattern_transfer_demand_by_key:
            covered: set[str] = set()
            capacity = 0
            for donor in self._pattern_by_color.get(key, ()):
                if donor in self.initial_owned:
                    covered.update(self._pattern_donor_coverage(donor)["covered_types"])
                    capacity += self._initial_capacity.get(donor, 1)
            self._initial_pattern_pool_coverage[key] = frozenset(covered)
            self._initial_pattern_pool_capacity[key] = capacity

        solid_pattern_counts: Counter[tuple[str, str]] = Counter()
        for flower in self.reachable:
            if flower.pattern != "Solid" and flower not in self.initial_owned:
                solid_pattern_counts[(flower.flower_type, flower.color)] += 1
        self._solid_pattern_unlock_potential = dict(solid_pattern_counts)

        # v30: propagation is no longer derived from lifetime descendant/branch
        # counts. Keep a lightweight reverse index of *potential exact-parent*
        # consumers so an extra copy can be requested only when a currently
        # ready downstream job is actually blocked by that parent. Native/default
        # fertilization is deliberately excluded because it runs as background
        # work and does not reserve a breeding slot/copy.
        exact_children: dict[Flower, set[Flower]] = defaultdict(set)
        for child in self.reachable:
            if child in self.initial_owned:
                continue
            if child.pattern == "Solid":
                for color_a, color_b in parents_for_mix(child.color):
                    exact_children[Flower(child.flower_type, color_a, "Solid")].add(child)
                    exact_children[Flower(child.flower_type, color_b, "Solid")].add(child)
            elif self.flower_types[child.flower_type].default_pattern != child.pattern:
                exact_children[Flower(child.flower_type, child.color, "Solid")].add(child)
        self._exact_children_by_parent = {
            parent: tuple(sorted(children, key=lambda flower: flower.label()))
            for parent, children in exact_children.items()
        }

        if build_graph:
            self.distance, self.best_routes = self._shortest_paths()
            # Logical route closure is separate from scheduler readiness. Keep
            # the requested collection intact; only route-proven work and its
            # prerequisites enter the event loop.
            self.unreachable_required = {
                target for target in self.required_targets
                if not math.isfinite(self.distance.get(target, math.inf))
            }
            needed = self.required_targets - self.unreachable_required
            pending = list(needed)
            while pending:
                target = pending.pop()
                route = self.best_routes.get(target)
                for parent in route.parents if route else ():
                    if parent not in self.initial_owned and parent not in needed:
                        needed.add(parent)
                        pending.append(parent)
            self.reachable = needed
            self.stock_utility = self._selected_exact_parent_utility()
            self.descendants = self._descendant_scores()
            self.critical_tail = self._critical_tail_scores()
        else:
            # Target previews and one-plot refreshes only need immediately
            # available routes. Building the collection dependency graph here
            # made a local UI operation as expensive as replanning the farm.
            self.unreachable_required = set()
            self.distance = {}
            self.best_routes = {}
            self.stock_utility = self._potential_exact_parent_utility()
            self.descendants = {}
            self.critical_tail = {}
        self._targets_by_priority: dict[int, list[Flower]] = defaultdict(list)
        for target in self.reachable:
            self._targets_by_priority[self.target_priorities.get(target, 99)].append(target)
        for priority, candidates in self._targets_by_priority.items():
            candidates.sort(
                key=lambda target: (
                    -self.descendants.get(target, 0),
                    -self.critical_tail.get(target, 0.0),
                    self.distance.get(target, math.inf),
                    target.label(),
                )
            )
        self._target_order_rank = {
            target: (priority, rank)
            for priority, candidates in self._targets_by_priority.items()
            for rank, target in enumerate(candidates)
        }
        self._selection_cursor: dict[tuple[int, str], int] = defaultdict(int)
        self._extreme_type_by_region = {
            flower_type.native_region: name
            for name, flower_type in self.flower_types.items()
            if flower_type.extreme and flower_type.native_region
        }
        self._extreme_solids_by_type = {
            name: frozenset(
                Flower(name, color, "Solid")
                for color in self.colors
                if Flower(name, color, "Solid") in self.reachable
            )
            for name, flower_type in self.flower_types.items()
            if flower_type.extreme
        }
        self._greenhouse_exclusive_targets = frozenset(
            target for target in self.reachable
            if self._requires_greenhouse_spawn(target)
        )

    def _event_inactive(self, event: str | None) -> bool:
        # The planner resolves "auto" to settings["active_events"]; bare
        # settings (tests, scripts) give a single "active_event" name.
        active = self.settings.get("active_events")
        if active is None:
            active = [self.settings.get("active_event")]
        return bool(event and event not in active)

    def _is_event_only(self, flower: Flower) -> bool:
        return self._event_inactive(self.flower_types[flower.flower_type].event)

    def _is_inactive_event_type(self, flower_type: str) -> bool:
        """Whether ``flower_type`` belongs to an event that is not active now."""
        return self._event_inactive(self.flower_types.get(flower_type, FLOWER_TYPES[flower_type]).event)

    def _requires_greenhouse_spawn(self, target: Flower) -> bool:
        """Whether a *new* target flower may only spawn in the Greenhouse.

        Out-of-season event species cannot create new offspring outdoors. Their
        native/default pattern is the exception because fertilizer changes the
        existing plant rather than creating a new spawn, so that work may still
        happen anywhere the event flower can be planted.
        """
        if not self._is_inactive_event_type(target.flower_type):
            return False
        flower_type = self.flower_types[target.flower_type]
        return target.pattern == "Solid" or target.pattern != flower_type.default_pattern

    def _route_allowed_for_season(self, route: Route, slot: PlotSlot) -> bool:
        """Biome + event-season legality for one concrete breeding route."""
        if not route_allowed(route.target, route.parents, slot):
            return False
        # Fertilizer changes an existing plant into that species' configured
        # default pattern. Keep this invariant at the final route-eligibility
        # boundary as well as in graph discovery so an alternate scheduling path
        # cannot turn a transferable effect (for example Eggwort Sunbeam) into
        # a fertilizer job.
        if route.method.startswith("fertilize_") and (
            route.target.pattern != self.flower_types[route.target.flower_type].default_pattern
        ):
            return False
        if slot.greenhouse or route.method.startswith("fertilize_"):
            return True
        # Outside the Greenhouse, an inactive event species cannot be the new
        # spawn. Patterned inactive-event flowers may still be *parents* that
        # transfer color/pattern into another species, which is intentionally
        # allowed here because this check is about the route target.
        return not self._is_inactive_event_type(route.target.flower_type)

    def _uses_inactive_event_patterned_parent(self, route: Route) -> bool:
        return any(
            parent.pattern != "Solid"
            and self._is_inactive_event_type(parent.flower_type)
            for parent in route.parents
        )

    def _patterned_candidates(self, color: str, excluded_type: str, distance: dict[Flower, float]) -> list[Flower]:
        zones = flower_zones()
        return [
            flower
            for flower in self._patterned_by_color.get(color, ())
            if flower.flower_type != excluded_type
            and self._cross_type_location_overlap(flower.flower_type, excluded_type, zones)
            and math.isfinite(distance.get(flower, math.inf))
        ]

    def _pattern_candidates(
        self,
        pattern: str,
        color: str,
        excluded_type: str,
        distance: dict[Flower, float],
    ) -> list[Flower]:
        zones = flower_zones()
        return [
            flower
            for flower in self._pattern_by_color.get((pattern, color), ())
            if flower.flower_type != excluded_type
            and self._cross_type_location_overlap(flower.flower_type, excluded_type, zones)
            and math.isfinite(distance.get(flower, math.inf))
        ]

    def _cross_type_location_overlap(
        self,
        donor_type: str,
        recipient_type: str,
        zones: dict[str, frozenset[str]] | None = None,
    ) -> bool:
        """Whether a donor and recipient species share a legal breeding venue.

        If the recipient is an inactive event species, a shared outdoor biome
        does not count because that recipient species cannot be the new spawn
        there. A shared Greenhouse remains valid.
        """
        zones = zones or flower_zones()
        overlap = zones.get(donor_type, frozenset()) & zones.get(
            recipient_type, frozenset()
        )
        if self._is_inactive_event_type(recipient_type):
            return "Greenhouse" in overlap
        return bool(overlap)

    def reachable_closure(self) -> set[Flower]:
        """Flowers _shortest_paths() gives a finite distance, without the costs.

        Finding which targets have any route is a plain fixed point: a target
        is reachable once some route's parents all are. Skipping the best-donor
        choice makes this far cheaper than the full graph (seconds, not tens of
        seconds), for callers that only need ``unreachable_required``.
        """
        zones = flower_zones()
        overlap: dict[tuple[str, str], bool] = {}

        def shares_venue(donor_type: str, recipient_type: str) -> bool:
            key = (donor_type, recipient_type)
            if key not in overlap:
                overlap[key] = self._cross_type_location_overlap(donor_type, recipient_type, zones)
            return overlap[key]

        done = set(self.initial_owned)

        def any_donor(donors, target: Flower) -> bool:
            return any(
                donor in done and donor.flower_type != target.flower_type
                and shares_venue(donor.flower_type, target.flower_type)
                for donor in donors
            )

        pending = [target for target in self.reachable if target not in done]
        changed = True
        while changed:
            changed = False
            still = []
            for target in pending:
                if target.pattern == "Solid":
                    ok = any(
                        Flower(target.flower_type, a, "Solid") in done
                        and Flower(target.flower_type, b, "Solid") in done
                        for a, b in parents_for_mix(target.color)
                    ) or (
                        any(
                            color != target.color and Flower(target.flower_type, color, "Solid") in done
                            for color in self.colors
                        )
                        and any_donor(self._patterned_by_color.get(target.color, ()), target)
                    )
                else:
                    solid = Flower(target.flower_type, target.color, "Solid")
                    ok = solid in done and (
                        self.flower_types[target.flower_type].default_pattern == target.pattern
                        or any_donor(self._pattern_by_color.get((target.pattern, target.color), ()), target)
                    )
                if ok:
                    done.add(target)
                    changed = True
                else:
                    still.append(target)
            pending = still
        return done

    def _shortest_paths(self) -> tuple[dict[Flower, float], dict[Flower, Route]]:
        nodes = set(self.targets) | self.initial_owned
        distance = {node: (0.0 if node in self.initial_owned else math.inf) for node in nodes}
        routes: dict[Flower, Route] = {}

        def relax(target: Flower, method: str, parents: tuple[Flower, ...]) -> bool:
            if target in self.initial_owned or any(not math.isfinite(distance.get(parent, math.inf)) for parent in parents):
                return False
            candidate = max(distance[parent] for parent in parents) + 1.0 / BREED_PROBABILITY[method]
            if candidate + 1e-9 < distance[target]:
                distance[target] = candidate
                routes[target] = Route(target, method, parents)
                return True
            return False

        ordered = sorted(self.reachable)
        for sweep in range(len(self.targets) + 1):
            changed = False
            for index, target in enumerate(ordered):
                if index % 64 == 0:
                    # Sweeps repeat until nothing improves (usually a few): each
                    # one fills a smaller share of the stage, so it never goes back.
                    progress.report("routes", (sweep + index / len(ordered)) / (sweep + 2),
                                    f"{len(ordered):,} flowers to plan for")
                if target.pattern == "Solid":
                    for color_a, color_b in parents_for_mix(target.color):
                        changed |= relax(
                            target,
                            "color_mix",
                            (Flower(target.flower_type, color_a, "Solid"), Flower(target.flower_type, color_b, "Solid")),
                        )
                    donors = self._patterned_candidates(target.color, target.flower_type, distance)
                    recipients = [
                        Flower(target.flower_type, color, "Solid")
                        for color in self.colors
                        if color != target.color and math.isfinite(distance.get(Flower(target.flower_type, color, "Solid"), math.inf))
                    ]
                    if donors and recipients:
                        donor = min(
                            donors,
                            key=lambda flower: (
                                distance[flower],
                                -len(self._color_donor_coverage(flower)["outdoor_covered_types"]),
                                -len(self._color_donor_coverage(flower)["covered_types"]),
                                flower.pattern == "Ombre",
                                -self._initial_capacity.get(flower, 1),
                                flower.label(),
                            ),
                        )
                        recipient = min(
                            recipients,
                            key=lambda flower: (
                                distance[flower],
                                -self._initial_capacity.get(flower, 1),
                                flower.label(),
                            ),
                        )
                        changed |= relax(target, "color_transfer", (donor, recipient))
                else:
                    solid = Flower(target.flower_type, target.color, "Solid")
                    if self.flower_types[target.flower_type].default_pattern == target.pattern:
                        changed |= relax(target, "fertilize_pattern", (solid,))
                    donors = self._pattern_candidates(
                        target.pattern, target.color, target.flower_type, distance
                    )
                    if donors:
                        donor = min(
                            donors,
                            key=lambda flower: (
                                distance[flower],
                                -len(self._pattern_donor_coverage(flower)["outdoor_covered_types"]),
                                -len(self._pattern_donor_coverage(flower)["covered_types"]),
                                -self._initial_capacity.get(flower, 1),
                                flower.label(),
                            ),
                        )
                        changed |= relax(target, "pattern_transfer", (donor, solid))
            if not changed:
                break
        return distance, routes

    def _descendant_scores(self) -> dict[Flower, int]:
        score: dict[Flower, int] = defaultdict(int)
        finite_targets = sorted(
            (target for target in self.reachable if math.isfinite(self.distance.get(target, math.inf))),
            key=lambda target: self.distance[target],
            reverse=True,
        )
        for target in finite_targets:
            route = self.best_routes.get(target)
            if not route:
                continue
            for parent in route.parents:
                score[parent] += 1 + score[target]
        return dict(score)

    def _critical_tail_scores(self) -> dict[Flower, float]:
        """Remaining downstream work on the selected dependency DAG."""
        tail: dict[Flower, float] = defaultdict(float)
        finite_targets = sorted(
            (target for target in self.reachable if math.isfinite(self.distance.get(target, math.inf))),
            key=lambda target: self.distance[target],
            reverse=True,
        )
        for target in finite_targets:
            route = self.best_routes.get(target)
            if not route:
                continue
            work = 1.0 / BREED_PROBABILITY[route.method]
            for parent in route.parents:
                tail[parent] = max(tail[parent], work + tail[target])
        return dict(tail)

    def _potential_exact_parent_utility(self) -> dict[Flower, int]:
        """Cheap preview estimate of uses that truly require an exact flower.

        Color transfer is deliberately excluded. Its patterned donor is
        interchangeable with another same-color patterned species when their
        planting regions overlap, and its solid recipient can be any available
        non-target color of the recipient species. Pattern-transfer donors are
        likewise interchangeable by pattern/color; only the solid recipient is
        exact.
        """
        utility: Counter[Flower] = Counter()
        for child in self.reachable:
            if child in self.initial_owned:
                continue
            if child.pattern == "Solid":
                for color_a, color_b in parents_for_mix(child.color):
                    utility[Flower(child.flower_type, color_a, "Solid")] += 1
                    utility[Flower(child.flower_type, color_b, "Solid")] += 1
                continue

            # Every patterned/effect target needs its exact same-type/color
            # solid either for direct fertilization or as the pattern-transfer
            # recipient. The patterned donor side is pooled and reusable.
            utility[Flower(child.flower_type, child.color, "Solid")] += 1
        return dict(utility)

    def _selected_exact_parent_utility(self) -> dict[Flower, int]:
        """Exact-parent demand on the selected dependency routes.

        This is the authoritative working-stock signal for a full plan. Color
        transfer contributes no exact parent demand. Pattern transfer contributes
        only its solid recipient; its patterned donor is drawn from a reusable
        pattern/color pool.
        """
        utility: Counter[Flower] = Counter()
        for child, route in self.best_routes.items():
            if child in self.initial_owned:
                continue
            if route.method == "color_transfer":
                continue
            if route.method == "pattern_transfer":
                for parent in route.parents:
                    if parent.pattern == "Solid":
                        utility[parent] += 1
                continue
            for parent in route.parents:
                utility[parent] += 1
        return dict(utility)

    def _color_transfer_demand(self, color: str) -> tuple[Flower, ...]:
        """Missing solid targets that could consume a same-color donor pool."""
        return self._color_transfer_demand_by_color.get(color, ())

    def _color_donor_coverage(self, donor: Flower) -> dict:
        """Describe how useful a patterned color donor is across recipient types.

        Coverage is location-aware. Outdoor overlap is tracked separately from
        greenhouse-only overlap because greenhouse capacity is more constrained.
        """
        cache_key = (donor.flower_type, donor.color)
        cached = self._color_donor_coverage_cache.get(cache_key)
        if cached is not None:
            return cached
        zones = flower_zones()
        covered: set[str] = set()
        outdoor: set[str] = set()
        greenhouse_only: set[str] = set()
        overlap_regions: set[str] = set()
        for target in self._color_transfer_demand(donor.color):
            if target.flower_type == donor.flower_type:
                continue
            overlap = zones.get(donor.flower_type, frozenset()) & zones.get(
                target.flower_type, frozenset()
            )
            if self._requires_greenhouse_spawn(target):
                overlap = overlap & {"Greenhouse"}
            if not overlap:
                continue
            covered.add(target.flower_type)
            outdoor_overlap = set(overlap) - {"Greenhouse"}
            if outdoor_overlap:
                outdoor.add(target.flower_type)
                overlap_regions.update(outdoor_overlap)
            else:
                greenhouse_only.add(target.flower_type)
        profile = {
            "covered_types": frozenset(covered),
            "outdoor_covered_types": frozenset(outdoor),
            "greenhouse_only_types": frozenset(greenhouse_only),
            "outdoor_regions": frozenset(overlap_regions),
        }
        self._color_donor_coverage_cache[cache_key] = profile
        return profile

    def _donor_pool_sort_key(
        self,
        donor: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
    ) -> tuple:
        """Rank interchangeable same-color donors without changing target priority."""
        profile = self._color_donor_coverage(donor)
        return (
            -self._free_capacity(donor, owned, busy),
            -len(profile["outdoor_covered_types"]),
            -len(profile["covered_types"]),
            len(profile["greenhouse_only_types"]),
            donor.pattern == "Ombre",
            donor.label(),
        )

    def color_donor_pool_summary(self) -> dict[str, dict]:
        """Machine-readable view of the shared color-transfer donor pools."""
        result: dict[str, dict] = {}
        owned = set(self.initial_owned)
        empty_busy: Counter[Flower] = Counter()
        for color in self.colors:
            demand = self._color_transfer_demand(color)
            recipient_types = sorted({target.flower_type for target in demand})
            donors = [
                donor for donor in self._patterned_by_color.get(color, ())
                if donor in owned
            ]
            if not donors and not recipient_types:
                continue
            donor_rows = []
            pooled_coverage: set[str] = set()
            for donor in sorted(
                donors, key=lambda d: self._donor_pool_sort_key(d, owned, empty_busy)
            ):
                profile = self._color_donor_coverage(donor)
                pooled_coverage.update(profile["covered_types"])
                donor_rows.append({
                    "donor": donor.label(),
                    "flower_type": donor.flower_type,
                    "pattern": donor.pattern,
                    "copies": self._capacity(donor, owned),
                    "covered_recipient_types": sorted(profile["covered_types"]),
                    "outdoor_covered_recipient_types": sorted(profile["outdoor_covered_types"]),
                    "greenhouse_only_recipient_types": sorted(profile["greenhouse_only_types"]),
                    "outdoor_regions": sorted(profile["outdoor_regions"]),
                })
            result[color] = {
                "recipient_types": recipient_types,
                "donors": donor_rows,
                "pool_capacity": sum(row["copies"] for row in donor_rows),
                "covered_recipient_types": sorted(pooled_coverage),
                "uncovered_recipient_types": sorted(set(recipient_types) - pooled_coverage),
            }
        return result

    def _pattern_transfer_demand(self, pattern: str, color: str) -> tuple[Flower, ...]:
        return self._pattern_transfer_demand_by_key.get((pattern, color), ())

    def _pattern_donor_coverage(self, donor: Flower) -> dict:
        """Location-aware coverage for a transferable pattern/effect donor."""
        cache_key = (donor.flower_type, donor.pattern, donor.color)
        cached = self._pattern_donor_coverage_cache.get(cache_key)
        if cached is not None:
            return cached
        zones = flower_zones()
        covered: set[str] = set()
        outdoor: set[str] = set()
        greenhouse_only: set[str] = set()
        overlap_regions: set[str] = set()
        for target in self._pattern_transfer_demand(donor.pattern, donor.color):
            if target.flower_type == donor.flower_type:
                continue
            overlap = zones.get(donor.flower_type, frozenset()) & zones.get(
                target.flower_type, frozenset()
            )
            if self._requires_greenhouse_spawn(target):
                overlap = overlap & {"Greenhouse"}
            if not overlap:
                continue
            covered.add(target.flower_type)
            outdoor_overlap = set(overlap) - {"Greenhouse"}
            if outdoor_overlap:
                outdoor.add(target.flower_type)
                overlap_regions.update(outdoor_overlap)
            else:
                greenhouse_only.add(target.flower_type)
        profile = {
            "covered_types": frozenset(covered),
            "outdoor_covered_types": frozenset(outdoor),
            "greenhouse_only_types": frozenset(greenhouse_only),
            "outdoor_regions": frozenset(overlap_regions),
        }
        self._pattern_donor_coverage_cache[cache_key] = profile
        return profile

    def _pattern_donor_pool_sort_key(
        self,
        donor: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
    ) -> tuple:
        profile = self._pattern_donor_coverage(donor)
        return (
            -self._free_capacity(donor, owned, busy),
            -len(profile["outdoor_covered_types"]),
            -len(profile["covered_types"]),
            len(profile["greenhouse_only_types"]),
            donor.label(),
        )

    def pattern_donor_pool_summary(self) -> dict[str, dict]:
        """Machine-readable view of pattern/effect + location donor pools."""
        result: dict[str, dict] = {}
        owned = set(self.initial_owned)
        empty_busy: Counter[Flower] = Counter()
        for key in sorted(self._pattern_transfer_demand_by_key):
            pattern, color = key
            demand = self._pattern_transfer_demand(pattern, color)
            recipient_types = sorted({target.flower_type for target in demand})
            donors = [
                donor for donor in self._pattern_by_color.get((pattern, color), ())
                if donor in owned
            ]
            donor_rows = []
            pooled_coverage: set[str] = set()
            for donor in sorted(
                donors, key=lambda d: self._pattern_donor_pool_sort_key(d, owned, empty_busy)
            ):
                profile = self._pattern_donor_coverage(donor)
                pooled_coverage.update(profile["covered_types"])
                donor_rows.append({
                    "donor": donor.label(),
                    "flower_type": donor.flower_type,
                    "copies": self._capacity(donor, owned),
                    "covered_recipient_types": sorted(profile["covered_types"]),
                    "outdoor_covered_recipient_types": sorted(profile["outdoor_covered_types"]),
                    "greenhouse_only_recipient_types": sorted(profile["greenhouse_only_types"]),
                    "outdoor_regions": sorted(profile["outdoor_regions"]),
                })
            result[f"{pattern}|{color}"] = {
                "pattern": pattern,
                "color": color,
                "recipient_types": recipient_types,
                "donors": donor_rows,
                "pool_capacity": sum(row["copies"] for row in donor_rows),
                "covered_recipient_types": sorted(pooled_coverage),
                "uncovered_recipient_types": sorted(set(recipient_types) - pooled_coverage),
            }
        return result

    def _capacity(self, flower: Flower, owned: set[Flower]) -> int:
        if flower not in owned:
            return 0
        if flower in self.initial_owned:
            return self._initial_capacity[flower]
        return 1

    def _stock_goal(self, target: Flower) -> tuple[int, str]:
        """Baseline stock goal before any concrete concurrency bottleneck exists.

        v30 makes propagation strictly on-demand. One owned copy is enough for
        collection/dependency purposes; extra copies are requested separately
        only when the current farm schedule proves that another exact-parent
        consumer is ready but blocked by copy capacity.
        """
        if target.pattern != "Solid":
            return 1, "reusable member of shared same-color donor pool"
        return 1, "one reusable collection copy; propagate only on demand"

    def _on_demand_propagation_need(
        self,
        target: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
        in_progress: set[Flower] | None = None,
    ) -> tuple[int, str, tuple[str, ...]] | None:
        """Return one incremental propagation goal when live concurrency needs it.

        v30 treats exact solids as reusable resources, not stockpiles. We look at
        currently-ready downstream consumers, match them to distinct physical
        plot slots, and estimate whether one more copy shortens their completion
        time enough to repay the clone job. This prevents region-set differences
        from masquerading as concurrency when the routes all compete for the same
        single plot/Greenhouse slot.

        Only one additional copy is requested per planning pass.
        """
        if target.pattern != "Solid" or target not in owned:
            return None
        current = self.inventory.physical_count(target)
        capacity = self._capacity(target, owned)
        if current <= 0 or capacity <= 0:
            return None

        in_progress = in_progress or set()
        children = self._exact_children_by_parent.get(target, ())
        if not children:
            return None

        free = max(0, capacity - busy[target])
        # A clone cannot start while every existing copy is already committed.
        # Avoid probing every child route in this common case; reconsider when
        # a consumer releases its parent.
        if free <= 0:
            return None
        # Give route selection at least one conceptual copy of this parent so we
        # can ask which live jobs would actually consume it and where. This does
        # not reserve anything; it is only a demand probe.
        probe_busy = Counter(busy)
        if free <= 0:
            probe_busy[target] -= 1

        consumer_options: dict[Flower, list[tuple[PlotSlot, float]]] = {}
        slots = all_slots()
        for child in children:
            if child in owned or child in in_progress:
                continue
            options: list[tuple[PlotSlot, float]] = []
            for candidate_slot in slots:
                if not self._hard_slot_allows(child, candidate_slot, owned):
                    continue
                route = self._ready_route(child, owned, probe_busy, candidate_slot)
                if route is None or target not in route.parents:
                    continue
                probability, _eligible, _copies = self._daily_probability(
                    route, candidate_slot, owned, probe_busy
                )
                if probability > 0:
                    options.append((candidate_slot, 1.0 / probability))
            if not options:
                continue
            consumer_options[child] = options

        if not consumer_options:
            return None

        # Count only consumers that can occupy distinct real plot slots at the
        # same time. Sort constrained jobs first and greedily claim their
        # quickest available slot; duplicate consumers in one region therefore
        # count only as far as that region has physical slots.
        claimed_slots: set[str] = set()
        matched_durations: list[float] = []
        for child, options in sorted(
            consumer_options.items(),
            key=lambda item: (len({slot.slot for slot, _ in item[1]}), item[0].label()),
        ):
            available_options = [
                (slot, duration) for slot, duration in options
                if slot.slot not in claimed_slots
            ]
            if not available_options:
                continue
            slot, duration = min(available_options, key=lambda item: (item[1], item[0].slot))
            claimed_slots.add(slot.slot)
            matched_durations.append(duration)

        if len(matched_durations) <= free:
            return None

        def lpt_makespan(durations: list[float], workers: int) -> float:
            loads = [0.0] * max(1, workers)
            for duration in sorted(durations, reverse=True):
                index = min(range(len(loads)), key=loads.__getitem__)
                loads[index] += duration
            return max(loads, default=0.0)

        # Estimate the time saved by one extra reusable copy, using actual
        # ready-job durations and currently usable plot slots. Propagation itself
        # must finish before the added capacity is usable, so reject it unless
        # the best available clone route is faster than the scheduling delay it
        # removes. We use the quickest legal clone location; callers still have
        # to find a genuinely spare safe zone before reserving it.
        before = lpt_makespan(matched_durations, free)
        after_work = lpt_makespan(matched_durations, free + 1)
        saved = before - after_work
        if saved <= 0:
            return None
        clone_durations: list[float] = []
        for candidate_slot in slots:
            if not self._route_allowed_for_season(
                Route(target, "propagate_solid", (target,)), candidate_slot
            ):
                continue
            if candidate_slot.greenhouse:
                placements = pair_placements(candidate_slot, 24, quick=self.quick)
                eligible = max(
                    (len(placement.protected_cells) for placement in placements),
                    default=0,
                )
            else:
                zones = isolated_pair_zones(candidate_slot, 1)
                if not zones:
                    continue
                pair, shared = zones[0]
                usable = usable_cells(candidate_slot)
                eligible = len((set(shared) | {pair[1]}) & usable)
            if eligible <= 0:
                continue
            chance = 1.0 - (1.0 - self.settings["outdoor_spawn_probability_fertilized"]) ** eligible
            if chance > 0:
                clone_durations.append(1.0 / chance)
        if not clone_durations or min(clone_durations) >= saved:
            return None

        region_names = tuple(sorted({slot.region for slot, _ in [
            option for options in consumer_options.values() for option in options
        ]}))
        goal = current + 1
        reason = (
            f"on-demand extra copy: {len(matched_durations)} concurrently schedulable "
            f"ready exact-parent job(s), {free} free copy/copies; estimated "
            f"collection delay avoided {saved:.1f} days"
        )
        return goal, reason, region_names

    def _available(self, flower: Flower, owned: set[Flower], busy: Counter[Flower]) -> bool:
        return busy[flower] < self._capacity(flower, owned)

    def _has_owned_route(self, target: Flower, owned: set[Flower]) -> bool:
        """Whether any breeding route is available from flowers already owned.

        The shortest dependency route is useful for long-range planning, but it
        is not the only valid recipe. A target should enter the ready queue as
        soon as *any* route can be performed; otherwise a theoretically shorter
        recipe can delay a target that is breedable right now.
        """
        zones = flower_zones()
        if target.pattern == "Solid":
            for color_a, color_b in parents_for_mix(target.color):
                if (
                    Flower(target.flower_type, color_a, "Solid") in owned
                    and Flower(target.flower_type, color_b, "Solid") in owned
                ):
                    return True
            if not any(
                flower.color != target.color and flower in owned
                for flower in self._solid_order_by_type.get(target.flower_type, ())
            ):
                return False
            return any(
                flower.pattern != "Solid"
                and flower.color == target.color
                and flower.flower_type != target.flower_type
                and self._cross_type_location_overlap(
                    flower.flower_type, target.flower_type, zones
                )
                for flower in self._patterned_by_color.get(target.color, ())
                if flower in owned
            )

        solid = Flower(target.flower_type, target.color, "Solid")
        if solid not in owned:
            return False
        if self.flower_types[target.flower_type].default_pattern == target.pattern:
            return True
        return any(
            flower.pattern == target.pattern
            and flower.secondary_color is None
            and flower.color == target.color
            and flower.flower_type != target.flower_type
            and self._cross_type_location_overlap(
                flower.flower_type, target.flower_type, zones
            )
            for flower in self._pattern_by_color.get((target.pattern, target.color), ())
            if flower in owned
        )

    def _owned_route_regions(self, target: Flower, owned: set[Flower]) -> set[str]:
        """Regions where at least one currently-owned recipe can make target.

        This is the static, no-reservation counterpart to ``_ready_route``. It is
        used only to seed regional ready queues, so it intentionally ignores busy
        parent copies and plot geometry. Those dynamic constraints are checked
        later when a concrete slot is filled. Avoiding a full ``_ready_route``
        call for every target × region is a major whole-plan speedup.
        """
        zones = flower_zones()
        target_regions = set(zones.get(target.flower_type, ()))
        if not target_regions:
            return set()

        # New out-of-season event flowers cannot spawn outdoors. Keep those
        # ready-queue entries Greenhouse-only up front so the scheduler does not
        # waste time repeatedly probing impossible outdoor plots. The species'
        # default pattern is different: fertilizer can add it to an existing
        # plant anywhere, so it remains eligible for background fertilization.
        if self._requires_greenhouse_spawn(target):
            target_regions.intersection_update({"Greenhouse"})
            if not target_regions:
                return set()

        if target.pattern == "Solid":
            regions: set[str] = set()
            for color_a, color_b in parents_for_mix(target.color):
                if (
                    Flower(target.flower_type, color_a, "Solid") in owned
                    and Flower(target.flower_type, color_b, "Solid") in owned
                ):
                    regions.update(target_regions)
                    break
            if any(
                flower.color != target.color and flower in owned
                for flower in self._solid_order_by_type.get(target.flower_type, ())
            ):
                for donor in self._patterned_by_color.get(target.color, ()):
                    if donor in owned and donor.flower_type != target.flower_type:
                        regions.update(
                            target_regions & set(zones.get(donor.flower_type, ()))
                        )
            return regions

        solid = Flower(target.flower_type, target.color, "Solid")
        if solid not in owned:
            return set()
        if self.flower_types[target.flower_type].default_pattern == target.pattern:
            return target_regions
        regions: set[str] = set()
        for donor in self._pattern_by_color.get((target.pattern, target.color), ()):
            if (
                donor in owned
                and donor.flower_type != target.flower_type
                and donor.secondary_color is None
            ):
                regions.update(target_regions & set(zones.get(donor.flower_type, ())))
        return regions

    def _free_capacity(
        self,
        flower: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
    ) -> int:
        return max(0, self._capacity(flower, owned) - busy[flower])

    def _ready_route_legacy(
        self,
        target: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
        slot: PlotSlot,
    ) -> Route | None:
        """Choose the best route using *free* parent copies on this plot.

        Route discovery used to choose a color-transfer recipient from the
        dependency graph (and, on ties, effectively by label). That could make
        a scarce base color such as Cloud Eggwort limit a job even when hundreds
        of another Eggwort color were free. Immediate assignment now ranks
        feasible routes by the actual daily probability they can achieve in the
        physical plot, then by remaining parent capacity.
        """
        candidates: list[Route] = []
        if target.pattern == "Solid":
            for color_a, color_b in parents_for_mix(target.color):
                parents = (
                    Flower(target.flower_type, color_a, "Solid"),
                    Flower(target.flower_type, color_b, "Solid"),
                )
                route = Route(target, "color_mix", parents)
                if (
                    all(self._available(parent, owned, busy) for parent in parents)
                    and self._route_allowed_for_season(route, slot)
                ):
                    candidates.append(route)

            recipients = [
                flower
                for flower in self._solid_order_by_type[target.flower_type]
                if flower.color != target.color
                and flower in owned
                and self._available(flower, owned, busy)
            ]
            # All recipients are the target species, so biome compatibility is
            # identical. Prefer the recipient with the most *free* copies, not
            # merely the largest total recorded count.
            recipients.sort(
                key=lambda flower: (
                    -self._free_capacity(flower, owned, busy),
                    -self._capacity(flower, owned),
                    flower.label(),
                )
            )
            recipient = recipients[0] if recipients else None
            if recipient is not None:
                donors = [
                    flower
                    for flower in self._patterned_order_by_color.get(target.color, ())
                    if flower in owned
                    and flower.flower_type != target.flower_type
                    and self._available(flower, owned, busy)
                    and self._route_allowed_for_season(
                        Route(target, "color_transfer", (flower, recipient)), slot
                    )
                ]
                donors.sort(
                    key=lambda flower: self._donor_pool_sort_key(
                        flower, owned, busy
                    )
                )
                if donors:
                    candidates.append(Route(target, "color_transfer", (donors[0], recipient)))
        else:
            solid = Flower(target.flower_type, target.color, "Solid")
            if self._available(solid, owned, busy):
                if self.flower_types[target.flower_type].default_pattern == target.pattern:
                    route = Route(target, "fertilize_pattern", (solid,))
                    if self._route_allowed_for_season(route, slot):
                        candidates.append(route)
                donors = [
                    flower
                    for flower in self._pattern_order_by_color.get(
                        (target.pattern, target.color), ()
                    )
                    if flower in owned
                    and flower.flower_type != target.flower_type
                    and self._available(flower, owned, busy)
                ]
                donors.sort(
                    key=lambda flower: self._pattern_donor_pool_sort_key(
                        flower, owned, busy
                    )
                )
                for donor in donors:
                    route = Route(target, "pattern_transfer", (donor, solid))
                    if self._route_allowed_for_season(route, slot):
                        candidates.append(route)
                        break

        if not candidates:
            return None
        method_rank = {
            "color_mix": 0,
            "color_transfer": 1,
            "fertilize_ombre": 2,
            "fertilize_pattern": 2,
            "pattern_transfer": 3,
        }

        def route_rank(route: Route) -> tuple:
            probability, _eligible, _copies = self._daily_probability(
                route, slot, owned, busy
            )
            free = tuple(
                self._free_capacity(parent, owned, busy)
                for parent in route.parents
            )
            bottleneck = min(free) if free else 0
            total_free = sum(free)
            return (
                probability,
                bottleneck,
                total_free,
                -method_rank[route.method],
                tuple(parent.label() for parent in route.parents),
            )

        return max(candidates, key=route_rank)

    def _ready_route(
        self,
        target: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
        slot: PlotSlot,
    ) -> Route | None:
        """Select the fastest currently feasible legal route for one target.

        Standard non-extremophile goals use the bounded route-set search. The
        remaining goals keep the established single-route policy, including
        the extremophile-specific scheduling priorities.
        """
        if self.finish_time_config.applies(target, self.flower_types):
            candidates = self._ready_routes(
                target,
                owned,
                busy,
                slot,
                limit=self.finish_time_config.max_routes_per_target,
            )
            return candidates[0] if candidates else None
        return self._ready_route_legacy(target, owned, busy, slot)

    def _ready_routes(
        self,
        target: Flower,
        owned: set[Flower],
        busy: Counter[Flower],
        slot: PlotSlot,
        limit: int = 24,
    ) -> list[Route]:
        """Return bounded, inventory-feasible routes for a scoped target."""
        if not self.finish_time_config.applies(target, self.flower_types):
            route = self._ready_route_legacy(target, owned, busy, slot)
            return [route] if route is not None else []
        candidates: list[Route] = []
        if target.pattern == "Solid":
            for color_a, color_b in parents_for_mix(target.color):
                parents = (
                    Flower(target.flower_type, color_a, "Solid"),
                    Flower(target.flower_type, color_b, "Solid"),
                )
                route = Route(target, "color_mix", parents)
                if (
                    all(self._available(parent, owned, busy) for parent in parents)
                    and self._route_allowed_for_season(route, slot)
                ):
                    candidates.append(route)

            recipients = [
                flower for flower in self._solid_order_by_type[target.flower_type]
                if flower.color != target.color
                and flower in owned
                and self._available(flower, owned, busy)
            ]
            recipients.sort(key=lambda flower: (
                -self._free_capacity(flower, owned, busy),
                -self._capacity(flower, owned),
                flower.label(),
            ))
            donors = [
                flower for flower in self._patterned_order_by_color.get(target.color, ())
                if flower in owned
                and flower.flower_type != target.flower_type
                and self._available(flower, owned, busy)
            ]
            donors.sort(key=lambda flower: self._donor_pool_sort_key(
                flower, owned, busy
            ))
            for recipient in recipients[:4]:
                for donor in donors[:8]:
                    route = Route(target, "color_transfer", (donor, recipient))
                    if self._route_allowed_for_season(route, slot):
                        candidates.append(route)
        else:
            solid = Flower(target.flower_type, target.color, "Solid")
            if self._available(solid, owned, busy):
                if self.flower_types[target.flower_type].default_pattern == target.pattern:
                    route = Route(target, "fertilize_pattern", (solid,))
                    if self._route_allowed_for_season(route, slot):
                        candidates.append(route)
                donors = [
                    flower for flower in self._pattern_order_by_color.get(
                        (target.pattern, target.color), ()
                    )
                    if flower in owned
                    and flower.flower_type != target.flower_type
                    and self._available(flower, owned, busy)
                ]
                donors.sort(key=lambda flower: self._pattern_donor_pool_sort_key(
                    flower, owned, busy
                ))
                for donor in donors[:12]:
                    route = Route(target, "pattern_transfer", (donor, solid))
                    if self._route_allowed_for_season(route, slot):
                        candidates.append(route)

        candidates = list(dict.fromkeys(candidates))
        method_rank = {
            "color_mix": 0,
            "color_transfer": 1,
            "fertilize_ombre": 2,
            "fertilize_pattern": 2,
            "pattern_transfer": 3,
        }

        def rank(route: Route) -> tuple:
            probability, _eligible, _copies = self._daily_probability(
                route, slot, owned, busy
            )
            free = tuple(self._free_capacity(parent, owned, busy)
                         for parent in route.parents)
            return (
                probability,
                min(free) if free else 0,
                sum(free),
                -method_rank.get(route.method, 99),
                tuple(parent.label() for parent in route.parents),
            )

        candidates.sort(key=rank, reverse=True)
        return candidates[:max(0, int(limit))]

    def _greenhouse_fanout_partner(
        self,
        route: Route,
        slot: PlotSlot,
        owned: set[Flower],
        in_progress: set[Flower],
        busy: Counter[Flower],
        type_load: Counter[str],
        ready_by_priority: dict[int, set[Flower]],
        strategy: str,
        occupied_parent_cells: set[tuple[int, int]] | None = None,
        occupied_target_cells: set[tuple[int, int]] | None = None,
    ) -> tuple[Route, dict] | None:
        """Find a second ready Greenhouse-compatible recipient for a scarce donor.

        Fan-out is a live scheduling choice: it is considered only for the
        currently selected pattern-transfer route. Outdoor-eligible targets can
        use the same shared layout too; the location and route checks still
        apply. Donor scarcity and a paired finish-time comparison decide whether
        sharing starts both goals sooner than running them as separate jobs.
        """
        if (
            not slot.greenhouse
            or route.method != "pattern_transfer"
            or len(route.parents) != 2
        ):
            return None
        layout = pattern_transfer_fanout_layout(
            slot,
            occupied_parent_cells or (),
            occupied_target_cells or (),
        )
        if layout is None:
            return None

        donor, recipient = route.parents
        free_donor_copies = self._free_capacity(donor, owned, busy)
        if free_donor_copies <= 0:
            return None

        priority = self.target_priorities.get(route.target, 99)
        ready = ready_by_priority.get(priority, set())
        demand = self._pattern_transfer_demand_by_key.get(
            (route.target.pattern, route.target.color), ()
        )
        candidate_targets = [
            target for target in demand
            if target != route.target
            and target in ready
            and target not in owned
            and target not in in_progress
            and self.target_priorities.get(target, 99) == priority
            and self._hard_slot_allows(target, slot, owned)
        ]
        candidate_targets.sort(
            key=lambda target: self._target_order_rank.get(
                target, (priority, 10**9)
            )
        )
        if not fanout_reduces_donor_wait(
            len(candidate_targets) + 1, free_donor_copies
        ):
            return None

        selected_probability = self._greenhouse_single_route_probability(route, slot)
        selected_duration = 1.0 / selected_probability if selected_probability else math.inf
        shared_primary_cells = len(layout["primary"]["target_cells"])
        shared_primary_rate = BREED_PROBABILITY[route.method]
        shared_primary_probability = 1.0 - (1.0 - shared_primary_rate) ** shared_primary_cells

        candidates: list[tuple[float, str, Route]] = []
        compatible_count = 1
        for target in candidate_targets:
            candidate = self._ready_route(target, owned, busy, slot)
            if (
                candidate is None
                or candidate.method != "pattern_transfer"
                or len(candidate.parents) != 2
                or candidate.parents[0] != donor
                or candidate.parents[1] == recipient
            ):
                continue
            normal_probability = self._greenhouse_single_route_probability(
                candidate, slot
            )
            shared_secondary_cells = len(layout["secondary"]["target_cells"])
            shared_secondary_rate = BREED_PROBABILITY[candidate.method]
            shared_secondary_probability = (
                1.0 - (1.0 - shared_secondary_rate) ** shared_secondary_cells
            )
            normal_candidate_duration = (
                1.0 / normal_probability if normal_probability else math.inf
            )
            shared_finish = max(
                1.0 / shared_primary_probability
                if shared_primary_probability else math.inf,
                1.0 / shared_secondary_probability
                if shared_secondary_probability else math.inf,
            )
            separate_finish = selected_duration + normal_candidate_duration
            if not math.isfinite(separate_finish) or not math.isfinite(shared_finish):
                continue
            # Fan-out has a different payoff from ordinary extra attempts: it
            # deliberately shares a scarce donor while keeping both goals
            # active. Require a real reduction, but avoid using the generic
            # 2% attempt threshold, which would suppress small yet consistent
            # gains from converting two serial donor uses into concurrent work.
            if separate_finish - shared_finish <= max(0.005 * separate_finish, 0.05):
                continue
            compatible_count += 1
            score = self._job_score(
                candidate, slot, owned, busy, type_load, strategy
            )
            candidates.append((score, target.label(), candidate))
            # One extra route is enough to prove a one-copy bottleneck; stop
            # once the donor-overload threshold is crossed to keep the long
            # completion rollout bounded.
            if compatible_count > free_donor_copies:
                break

        if not fanout_reduces_donor_wait(compatible_count, free_donor_copies):
            return None
        if not candidates:
            return None
        partner = max(candidates, key=lambda item: (item[0], item[1]))[2]
        return partner, layout

    @staticmethod
    def _greenhouse_single_route_probability(route: Route, slot: PlotSlot) -> float:
        """Estimate one ordinary pair over all usable shared-grid spawn cells."""
        if len(route.parents) < 2:
            return 0.0
        usable = usable_cells(slot)
        best_cells = max(
            (
                len(
                    (neighboring_cells(pair[0], usable)
                     & neighboring_cells(pair[1], usable))
                    - set(pair)
                )
                for pair, _protected in isolated_pair_zones(slot, 24)
            ),
            default=0,
        )
        per_spawn = BREED_PROBABILITY[route.method]
        return 1.0 - (1.0 - per_spawn) ** best_cells if best_cells else 0.0

    def _daily_probability(
        self,
        route: Route,
        slot: PlotSlot,
        owned: set[Flower],
        busy: Counter[Flower],
    ) -> tuple[float, int, tuple[int, ...]]:
        remaining = tuple(max(0, self._capacity(parent, owned) - busy[parent]) for parent in route.parents)
        if route.method.startswith("fertilize_"):
            # Fertilizer acts on the planted solid itself. It needs a parent
            # flower cell, not an adjacent spawn cell or an isolated breeding
            # micro-zone. This applies outdoors as well as in the Greenhouse.
            eligible = min(remaining[0], slot.spots)
            copies = (eligible,)
            per_cell = BREED_PROBABILITY[route.method]
        else:
            if slot.greenhouse:
                placements = pair_placements(slot, 24, quick=self.quick)
                eligible = max(
                    (len(placement.protected_cells) for placement in placements),
                    default=0,
                )
                copies = (1, 1)
            else:
                pair_limit = min(remaining)
                if self.quick:
                    placements = pair_placements(slot, max(1, pair_limit), quick=True)[:pair_limit]
                    eligible = len(set().union(*(zone.protected_cells for zone in placements))) if placements else 0
                    copies = (len(placements), len(placements))
                else:
                    pairs, targets = isolated_pair_layout(slot, pair_limit)
                    eligible = len(targets)
                    copies = (len(pairs), len(pairs))
            spawn = 1.0 if slot.greenhouse else self.settings["outdoor_spawn_probability_fertilized"]
            per_spawn = BREED_PROBABILITY[route.method]
            # Pattern transfer is unusually favorable outdoors when the donor
            # is a patterned flower from a past/inactive event: 2% per new
            # spawn rather than the ordinary 1%. In the Greenhouse it remains
            # 1% per spawn.
            if (
                route.method == "pattern_transfer"
                and not slot.greenhouse
                and self._uses_inactive_event_patterned_parent(route)
            ):
                per_spawn = 0.02
            per_cell = per_spawn * spawn
        probability = 1.0 - (1.0 - per_cell) ** eligible if eligible else 0.0
        return probability, eligible, copies

    def _strategic_unlocks(self, target: Flower, owned: set[Flower]) -> dict[str, int]:
        """Cheap marginal reusable-resource value for one successful target.

        The full rollout handles dynamic unlock timing. This score uses the
        starting donor-pool baseline so candidate comparison stays fast enough
        for whole-farm scheduling.
        """
        if target.pattern != "Solid":
            color_profile = self._color_donor_coverage(target)
            color_gain = len(
                set(color_profile["covered_types"])
                - set(self._initial_color_pool_coverage.get(target.color, ()))
            )
            key = (target.pattern, target.color)
            pattern_profile = self._pattern_donor_coverage(target)
            pattern_gain = len(
                set(pattern_profile["covered_types"])
                - set(self._initial_pattern_pool_coverage.get(key, ()))
            )
            color_pressure = max(
                0,
                len(color_profile["covered_types"])
                - self._initial_color_pool_capacity.get(target.color, 0),
            )
            pattern_pressure = max(
                0,
                len(pattern_profile["covered_types"])
                - self._initial_pattern_pool_capacity.get(key, 0),
            )
            pool_pressure = min(4, color_pressure + pattern_pressure)
            solid_pattern_unlocks = 0
        else:
            color_gain = 0
            pattern_gain = 0
            pool_pressure = 0
            solid_pattern_unlocks = self._solid_pattern_unlock_potential.get(
                (target.flower_type, target.color), 0
            )
        return {
            "color_pool_gain": color_gain,
            "pattern_pool_gain": pattern_gain,
            "pool_capacity_pressure": pool_pressure,
            "solid_pattern_unlocks": solid_pattern_unlocks,
        }

    def _job_score(
        self,
        route: Route,
        slot: PlotSlot,
        owned: set[Flower],
        busy: Counter[Flower],
        type_load: Counter[str],
        strategy: str,
    ) -> float:
        probability, _, _ = self._daily_probability(route, slot, owned, busy)
        if probability <= 0:
            return 0.0
        duration = 1.0 / probability
        descendants = math.log1p(self.descendants.get(route.target, 0))
        critical = math.log1p(max(0.0, self.critical_tail.get(route.target, 0.0)))
        unlocks = self._strategic_unlocks(route.target, owned)
        pool_gain = (
            1.8 * unlocks["color_pool_gain"]
            + 1.8 * unlocks["pattern_pool_gain"]
            + 0.55 * unlocks["pool_capacity_pressure"]
            + 0.8 * unlocks["solid_pattern_unlocks"]
        )
        if (
            self._active_score_policy is not None
            and self.finish_time_config.applies(route.target, self.flower_types)
        ):
            policy = self._active_score_policy
            diversity = 1.0 + policy.type_diversity_weight * type_load[
                route.target.flower_type
            ]
            return probability * (
                1.0
                + policy.descendant_weight * descendants
                + policy.critical_tail_weight * critical
                + policy.donor_pool_weight * pool_gain
            ) / diversity
        diversity = 1.0 + 0.20 * type_load[route.target.flower_type]

        # v19 strategies are competing approximations to marginal makespan
        # reduction. The scheduler runs multiple rollouts and keeps the one with
        # the lowest simulated collection finish date, so no single handcrafted
        # formula is treated as truth.
        if strategy == "earliest_finish":
            return probability / diversity
        if strategy == "pool_unlock":
            return probability * (1.0 + pool_gain + 0.20 * descendants) / diversity
        if strategy == "critical_path":
            return probability * (1.0 + critical + 0.25 * descendants) / diversity
        if strategy == "balanced":
            return probability * (
                1.0 + 0.45 * descendants + 0.35 * critical + 0.75 * pool_gain
            ) / diversity
        # projected_finish: default rollout. Favor short jobs, but pay extra for
        # jobs that create reusable color/pattern coverage or unlock many
        # downstream targets. This is a marginal completion-time proxy, not a
        # fixed target tier.
        return probability * (
            1.0 + 0.55 * descendants + 0.30 * critical + pool_gain
        ) / diversity

    def _native_extreme_type_for_slot(self, slot: PlotSlot) -> str | None:
        return self._extreme_type_by_region.get(slot.region)

    def _hard_slot_allows(self, target: Flower, slot: PlotSlot, owned: set[Flower]) -> bool:
        """Only true hard scheduling rule besides target-scope exclusions.

        A native extreme-region plot is reserved for that extremophile's missing
        solids while any remain. Once its solids are complete, the plot can be
        used normally for other compatible work.
        """
        extreme_type = self._native_extreme_type_for_slot(slot)
        if extreme_type is None:
            return True
        missing_extreme_solids = any(
            flower not in owned
            for flower in self._extreme_solids_by_type.get(extreme_type, ())
        )
        if not missing_extreme_solids:
            return True
        return target.flower_type == extreme_type and target.pattern == "Solid"

    def _background_assignment(
        self,
        route: Route,
        probability: float,
        eligible: int,
    ) -> dict:
        target = route.target
        return {
            "slot": "BACKGROUND",
            "plot": "Background fertilization",
            "region": "No breeding slot",
            "plot_spots": eligible,
            "eligible_cells": eligible,
            "target": target.label(),
            "target_type": target.flower_type,
            "target_color": target.color,
            "target_pattern": target.pattern,
            "target_secondary_color": target.secondary_color,
            "method": route.method,
            "parents": [parent.label() for parent in route.parents],
            "parent_flowers": [
                {
                    "flower_type": parent.flower_type,
                    "color": parent.color,
                    "pattern": parent.pattern,
                    "secondary_color": parent.secondary_color,
                }
                for parent in route.parents
            ],
            "parent_patterns": [parent.pattern for parent in route.parents],
            "parent_copies": [eligible],
            "daily_probability": probability,
            "expected_days": 1.0 / probability if probability else float("inf"),
            "event_only": self._is_event_only(target),
            "stock_goal": 1,
            "stock_goal_reason": "first successful copy",
            "farm_state": "background_recommended",
            "locked": False,
            "background": True,
        }

    def _select_job(
        self,
        slot: PlotSlot,
        owned: set[Flower],
        in_progress: set[Flower],
        busy: Counter[Flower],
        type_load: Counter[str],
        strategy: str,
        ready_by_priority: dict[int, set[Flower]] | None = None,
        blocked_targets: set[Flower] | None = None,
        ready_queues: dict[tuple[int, str], deque[Flower]] | None = None,
        greenhouse_ready_queues: dict[int, deque[Flower]] | None = None,
        allow_ready_fallback: bool = True,
        candidate_scan_limit: int | None = None,
        candidate_feasible_limit: int | None = None,
    ) -> Route | None:
        blocked_targets = blocked_targets or set()

        def greenhouse_exclusive_options(candidates) -> list[tuple[float, str, Route]]:
            """Ready work that loses its only breeding venue outside Greenhouse.

            This is resource-scarcity priority, not a new arbitrary target tier:
            an inactive event flower that needs a new spawn has exactly one venue,
            while ordinary targets can use many outdoor regions. Give the scarce
            Greenhouse resource to those jobs first whenever one is currently
            feasible.
            """
            if not slot.greenhouse:
                return []
            options: list[tuple[float, str, Route]] = []
            for target in candidates:
                if (
                    target in owned
                    or target in in_progress
                    or target in blocked_targets
                    or not self._requires_greenhouse_spawn(target)
                    or not self._hard_slot_allows(target, slot, owned)
                ):
                    continue
                route = (self._ready_route(target, owned, busy, slot) if allow_ready_fallback
                             else self._ready_route_legacy(target, owned, busy, slot))
                if route is None:
                    continue
                score = self._job_score(route, slot, owned, busy, type_load, strategy)
                if score > 0:
                    options.append((score, target.label(), route))
            return options

        if ready_by_priority is not None:
            if slot.greenhouse:
                for priority in sorted(ready_by_priority):
                    ready = ready_by_priority[priority]
                    if not ready:
                        continue
                    queue = (
                        greenhouse_ready_queues[priority]
                        if greenhouse_ready_queues is not None
                        else deque(
                            sorted(
                                ready & self._greenhouse_exclusive_targets,
                                key=lambda target: target.label(),
                            )
                        )
                    )
                    exclusive: list[tuple[float, str, Route]] = []
                    inspected = 0
                    feasible = 0
                    # Compare several alternatives in the visible first wave.
                    # During the long-range simulation, stop after the first
                    # feasible Greenhouse-only job; that preserves the scarce-
                    # resource rule without rescoring thousands of event targets
                    # after every completion.
                    scan_limit = min(len(queue), 96)
                    feasible_limit = 16 if allow_ready_fallback else 1
                    while inspected < scan_limit and queue:
                        target = queue.popleft()
                        inspected += 1
                        if target not in ready or target in owned or target in in_progress:
                            continue
                        queue.append(target)
                        if (
                            target in blocked_targets
                            or target not in self._greenhouse_exclusive_targets
                            or not self._hard_slot_allows(target, slot, owned)
                        ):
                            continue
                        route = (self._ready_route(target, owned, busy, slot) if allow_ready_fallback
                             else self._ready_route_legacy(target, owned, busy, slot))
                        if route is None:
                            continue
                        score = self._job_score(
                            route, slot, owned, busy, type_load, strategy
                        )
                        if score > 0:
                            exclusive.append((score, target.label(), route))
                            feasible += 1
                            if feasible >= feasible_limit:
                                break
                    if exclusive:
                        return max(exclusive, key=lambda item: (item[0], item[1]))[2]

            # All ordinary targets share one scheduling bucket in v19. Sample a
            # bounded number of feasible candidates and compare their actual
            # marginal scores instead of taking the first dependency-ranked row.
            for priority in sorted(ready_by_priority):
                ready = ready_by_priority[priority]
                if not ready:
                    continue

                extreme_type = self._native_extreme_type_for_slot(slot)
                if extreme_type and any(
                    flower not in owned
                    for flower in self._extreme_solids_by_type.get(extreme_type, ())
                ):
                    candidate_targets = sorted(
                        (
                            target for target in ready
                            if self._hard_slot_allows(target, slot, owned)
                            and target not in blocked_targets
                            and target not in owned
                            and target not in in_progress
                        ),
                        key=lambda target: (
                            self.distance.get(target, math.inf), target.label()
                        ),
                    )
                    options: list[tuple[float, str, Route]] = []
                    for target in candidate_targets:
                        route = (self._ready_route(target, owned, busy, slot) if allow_ready_fallback
                             else self._ready_route_legacy(target, owned, busy, slot))
                        if route is None:
                            continue
                        score = self._job_score(route, slot, owned, busy, type_load, strategy)
                        if score > 0:
                            options.append((score, target.label(), route))
                    return max(options, key=lambda item: (item[0], item[1]))[2] if options else None

                queue = (
                    ready_queues[(priority, slot.region)]
                    if ready_queues is not None
                    else deque(sorted(ready, key=lambda t: t.label()))
                )
                options: list[tuple[float, str, Route]] = []
                inspected = 0
                feasible = 0
                # The first wave deserves a broad comparison because it is the
                # recommendation the user will actually plant. The long-horizon
                # simulation is only an estimate, so use a much smaller rolling
                # sample after day 0; the shared deque naturally rotates through
                # the remaining ready candidates over subsequent fills.
                default_scan_limit = 96 if allow_ready_fallback else 1
                default_feasible_limit = 16 if allow_ready_fallback else 1
                scan_limit = min(
                    len(queue), candidate_scan_limit or default_scan_limit
                )
                feasible_limit = candidate_feasible_limit or default_feasible_limit
                while inspected < scan_limit and queue:
                    target = queue.popleft()
                    inspected += 1
                    if target not in ready or target in owned or target in in_progress:
                        continue
                    # Keep it in circulation unless selected; ready.discard on
                    # assignment makes stale queue entries harmless.
                    queue.append(target)
                    if target in blocked_targets or not self._hard_slot_allows(target, slot, owned):
                        continue
                    route = (self._ready_route(target, owned, busy, slot) if allow_ready_fallback
                             else self._ready_route_legacy(target, owned, busy, slot))
                    if route is None:
                        continue
                    score = self._job_score(route, slot, owned, busy, type_load, strategy)
                    if score > 0:
                        options.append((score, target.label(), route))
                        feasible += 1
                        if feasible >= feasible_limit:
                            break
                if options:
                    return max(options, key=lambda item: (item[0], item[1]))[2]

            if not allow_ready_fallback:
                return None

            # The bounded regional queue is an optimization, not an authority.
            # If it finds nothing, scan the *ready set* rather than all ~10k
            # collection targets. add_ready_targets keeps this set current using
            # every valid parent relationship, so this preserves v22's small-plot
            # correctness without turning every idle-slot check into a full target
            # universe scan.
            live_options: list[tuple[float, str, Route]] = []
            ready_has_candidates = any(ready_by_priority.values())
            fallback_pools = (
                ready_by_priority
                if ready_has_candidates
                else self._targets_by_priority
            )
            for priority in sorted(fallback_pools):
                for target in fallback_pools[priority]:
                    if target in owned or target in in_progress:
                        continue
                    if target in blocked_targets or not self._hard_slot_allows(target, slot, owned):
                        continue
                    route = (self._ready_route(target, owned, busy, slot) if allow_ready_fallback
                             else self._ready_route_legacy(target, owned, busy, slot))
                    if route is None:
                        continue
                    score = self._job_score(route, slot, owned, busy, type_load, strategy)
                    if score > 0:
                        live_options.append((score, target.label(), route))
                if live_options:
                    # Priority buckets are scope/constraint buckets; once a
                    # feasible option exists in the earliest bucket, later buckets
                    # cannot improve a hard-priority decision.
                    break
            return max(live_options, key=lambda item: (item[0], item[1]))[2] if live_options else None

        # Cheap one-plot / supplemental path. Target categories are scope only;
        # compare a bounded set of feasible targets directly.
        if slot.greenhouse:
            exclusive = greenhouse_exclusive_options(
                target
                for pool in self._targets_by_priority.values()
                for target in pool
                if target in self._greenhouse_exclusive_targets
            )
            if exclusive:
                return max(exclusive, key=lambda item: (item[0], item[1]))[2]

        options: list[tuple[float, str, Route]] = []
        for pool in self._targets_by_priority.values():
            for target in pool:
                if target in owned or target in in_progress:
                    continue
                # Immediate feasibility is authoritative here. A target can be
                # breedable through a valid alternate route even if the long-range
                # dependency graph did not select a nominal best route for it.
                if not self._hard_slot_allows(target, slot, owned):
                    continue
                route = (self._ready_route(target, owned, busy, slot) if allow_ready_fallback
                             else self._ready_route_legacy(target, owned, busy, slot))
                if route is None:
                    continue
                score = self._job_score(route, slot, owned, busy, type_load, strategy)
                if score > 0:
                    options.append((score, target.label(), route))
                    if len(options) >= 24:
                        break
            if len(options) >= 24:
                break
        return max(options, key=lambda item: (item[0], item[1]))[2] if options else None

    def schedule(
        self,
        strategy: str = "projected_finish",
        score_policy: SchedulerScorePolicy | dict | None = None,
        busy_seed: Counter[Flower] | None = None,
    ) -> dict:
        """Simulate filling plots and completing targets; see schedule_run.py."""
        from .schedule_run import ScheduleRun

        if isinstance(score_policy, dict):
            score_policy = SchedulerScorePolicy(**score_policy)
        self._active_score_policy = score_policy
        return ScheduleRun(self, all_slots(), strategy, score_policy, busy_seed).run()

    @staticmethod
    def _zone_layout(zones) -> dict:
        return {
            "parent_a_cells": [list(pair[0]) for pair, _targets in zones],
            "parent_b_cells": [list(pair[1]) for pair, _targets in zones],
            "target_cells": [
                list(cell)
                for _pair, targets in zones
                for cell in sorted(targets)
            ],
        }

    @staticmethod
    def _job_layout_cells(job: dict) -> tuple[set[tuple[int, int]], set[tuple[int, int]]]:
        layout = job.get("layout")
        if not isinstance(layout, dict):
            return set(), set()
        parents = {
            (int(row), int(col))
            for key in ("parent_a_cells", "parent_b_cells", "shared_parent_a_cells")
            for row, col in layout.get(key, [])
        }
        # Fertilizer does not produce an offspring in any marked target cell.
        # Ignore legacy target halos if an older saved layout still has them.
        targets = set()
        if not str(job.get("method", "")).startswith("fertilize_"):
            targets = {
                (int(row), int(col)) for row, col in layout.get("target_cells", [])
            }
        return parents, targets

    def _available_outdoor_zones(
        self,
        slot: PlotSlot,
        zones,
        jobs: list[dict],
        claimed_zones: set[tuple],
    ) -> list[tuple]:
        """Return pair placements that preserve existing plant and spawn cells.

        Open offspring cells may be shared across goals; the cell evaluator
        accounts for that competition instead of rejecting the whole pair zone.
        Fertilizer remains a planted cell and cannot occupy an existing parent
        or offspring cell.
        """
        usable = usable_cells(slot)
        parent_cells: set[tuple[int, int]] = set()
        target_cells: set[tuple[int, int]] = set()
        for job in jobs:
            parents, targets = self._job_layout_cells(job)
            parent_cells.update(parents)
            target_cells.update(targets)
        available = []
        for zone in zones:
            pair, targets = zone
            signature = tuple(pair)
            if signature in claimed_zones:
                continue
            pair_cells = set(pair)
            target_set = set(targets)
            # Parent plants cannot occupy another job's parents or its open
            # offspring cells. Spawn cells, however, may be shared: the joint
            # cell evaluator divides their one physical chance across all goals
            # that can use them.
            if pair_cells & (parent_cells | target_cells):
                continue
            if target_set & parent_cells:
                continue
            # Any target cell not physically occupied by another parent's plant
            # is valid, including a shared/ambiguous offspring cell.
            safe_targets = target_set - parent_cells
            if safe_targets:
                available.append(zone)
        return available

    def _choose_fertilizer_parent_cells(
        self,
        slot: PlotSlot,
        count: int,
        jobs: list[dict] | None = None,
    ) -> list[tuple[int, int]]:
        """Place fertilizer plants while preserving as many breeding zones as possible."""
        usable = usable_cells(slot)
        jobs = jobs or []
        blocked: set[tuple[int, int]] = set()
        protected_targets: set[tuple[int, int]] = set()
        existing_parent_cells: set[tuple[int, int]] = set()
        for job in jobs:
            parents, targets = self._job_layout_cells(job)
            blocked.update(parents)
            blocked.update(targets)
            existing_parent_cells.update(parents)
            protected_targets.update(targets)
        for target in protected_targets:
            blocked.update(neighboring_cells(target, usable))

        zones = isolated_pair_zones(slot, 999)
        selected: list[tuple[int, int]] = []
        while len(selected) < max(0, int(count)):
            candidates = usable - blocked
            if not candidates:
                break
            def retained_zone_count(cell: tuple[int, int]) -> int:
                candidate_job = {
                    "method": "fertilize_pattern",
                    "layout": {
                        "parent_a_cells": [list(item) for item in selected + [cell]],
                        "parent_b_cells": [],
                        "target_cells": [],
                    },
                }
                return len(self._available_outdoor_zones(
                    slot, zones, jobs + [candidate_job], set()
                ))

            planted_before = existing_parent_cells | set(selected)

            def placement_key(cell: tuple[int, int]) -> tuple:
                # Preserve the greatest number of safe breeding zones first.
                # When several cells tie, prefer a balanced, spread-out layout
                # instead of the old row-major bias toward the upper-left edge.
                retained = retained_zone_count(cell)
                nearest_parent_distance = min((
                    abs(cell[0] - parent[0]) + abs(cell[1] - parent[1])
                    for parent in planted_before
                ), default=0)
                next_count = len(planted_before) + 1
                row_delta = (
                    2 * (sum(row for row, _col in planted_before) + cell[0])
                    - (slot.rows - 1) * next_count
                )
                col_delta = (
                    2 * (sum(col for _row, col in planted_before) + cell[1])
                    - (slot.cols - 1) * next_count
                )
                center_error = row_delta * row_delta + col_delta * col_delta
                return (-retained, -nearest_parent_distance, center_error, cell)

            chosen = min(candidates, key=placement_key)
            selected.append(chosen)
            blocked.add(chosen)
        return selected

    def _pack_outdoor_first_wave(
        self,
        first_wave: list[dict],
        preserved: dict[str, list[dict]] | None = None,
        slots_to_repack: set[str] | None = None,
        candidate_order: list[Flower] | None = None,
        busy_seed: Counter[Flower] | None = None,
        in_progress_seed: set[Flower] | None = None,
        preserve_scheduled_layouts: bool = False,
    ) -> dict[str, list[dict]]:
        """Pack outdoor plots across distinct ready goals before adding copies.

        Unlocked recommendations initially reserve one pair for their primary
        goal. Remaining safe zones are offered one at a time to other ready
        goals. Once no new goal can use a zone, extra pairs are distributed to
        active goals using parent capacity and projected marginal finish-time
        benefit. Locked/manual work is never resized.
        """
        from .first_wave_packing import FirstWavePacker

        return FirstWavePacker(
            self, all_slots(), first_wave, preserved, slots_to_repack,
            candidate_order, busy_seed, in_progress_seed, preserve_scheduled_layouts,
        ).pack()

    def _expand_outdoor_target_cells(
        self,
        slot: PlotSlot,
        jobs: list[dict],
    ) -> None:
        """Expand every cell opportunity and split shared-cell spawn chances."""
        if slot.greenhouse or not jobs:
            return
        evaluation_jobs: list[dict] = []
        for job in jobs:
            method = str(job.get("method", ""))
            if method.startswith("fertilize_"):
                if isinstance(job.get("layout"), dict):
                    job["layout"]["target_cells"] = []
                    job["layout"]["shared_target_cells"] = []
                continue
            if method == "propagate_solid":
                cell_probability = self.settings["outdoor_spawn_probability_fertilized"]
            else:
                per_spawn = BREED_PROBABILITY[method]
                if method == "pattern_transfer":
                    target = Flower(
                        job["target_type"], job["target_color"],
                        job["target_pattern"], job.get("target_secondary_color"),
                    )
                    parents = tuple(
                        Flower(
                            parent["flower_type"], parent["color"],
                            parent["pattern"], parent.get("secondary_color"),
                        )
                        for parent in job.get("parent_flowers", [])
                    )
                    if self._uses_inactive_event_patterned_parent(
                        Route(target, method, parents)
                    ):
                        per_spawn = 0.02
                cell_probability = (
                    per_spawn * self.settings["outdoor_spawn_probability_fertilized"]
                )
            job["cell_probability"] = cell_probability
            evaluation_jobs.append(job)

        evaluation = evaluate_cell_outcomes(slot, evaluation_jobs)
        for job in evaluation_jobs:
            goal = (
                str(job["target_type"]), str(job["target_color"]),
                str(job["target_pattern"]), job.get("target_secondary_color"),
            )
            layout = job.setdefault("layout", {})
            unique_cells = evaluation["unique_cells"].get(goal, [])
            shared_cells = evaluation["shared_cells"].get(goal, [])
            layout["target_cells"] = [list(cell) for cell in sorted(set(unique_cells) | set(shared_cells))]
            layout["shared_target_cells"] = [list(cell) for cell in sorted(set(shared_cells))]
            eligible = evaluation["eligible_cells"].get(goal, 0)
            probability = evaluation["probabilities"].get(goal, 0.0)
            job["eligible_cells"] = eligible
            job["shared_eligible_cells"] = len(shared_cells)
            job["daily_probability"] = probability
            job["expected_days"] = (1.0 / probability) if probability > 0 else math.inf

    def _assignment(
        self,
        slot: PlotSlot,
        route: Route,
        probability: float,
        eligible: int,
        duration: float,
        copies: tuple[int, ...],
    ) -> dict:
        # Breeding jobs stop after the first successful copy. v30 no longer
        # reserves downstream working stock here; a separate propagation job is
        # created later only if live copy capacity is actually blocking a ready
        # exact-parent consumer.
        propagation_goal, propagation_reason = self._stock_goal(route.target)
        return {
            "slot": slot.slot,
            "plot": slot.plot,
            "region": slot.region,
            "plot_spots": slot.spots,
            "eligible_cells": eligible,
            "target": route.target.label(),
            "target_type": route.target.flower_type,
            "target_color": route.target.color,
            "target_pattern": route.target.pattern,
            "target_secondary_color": route.target.secondary_color,
            "method": route.method,
            "parents": [parent.label() for parent in route.parents],
            "parent_flowers": [
                {
                    "flower_type": parent.flower_type,
                    "color": parent.color,
                    "pattern": parent.pattern,
                    "secondary_color": parent.secondary_color,
                }
                for parent in route.parents
            ],
            "parent_patterns": [parent.pattern for parent in route.parents],
            "parent_copies": list(copies),
            "daily_probability": probability,
            "expected_days": duration,
            "event_only": self._is_event_only(route.target),
            "stock_goal": 1,
            "stock_goal_reason": "first successful copy",
            "propagation_goal": propagation_goal,
            "propagation_goal_reason": propagation_reason,
            "farm_state": "recommended",
            "locked": False,
        }


    def propagation_assignment_for_target(
        self,
        target: Flower,
        slot: PlotSlot,
        busy: Counter[Flower] | None = None,
        goal: int | None = None,
        in_progress: set[Flower] | None = None,
    ) -> dict | None:
        """Build a cloning/propagation assignment for an already-owned solid.

        A single isolated solid can only clone itself, so once a newly bred
        color exists this is usually a cleaner way to build working stock than
        keeping the original breeding parents in place. Outdoor clone parents
        use the same isolation lattice as breeding jobs so spare zones can
        still be packed with other targets.
        """
        if target.pattern != "Solid" or target not in self.initial_owned:
            return None
        if not self._route_allowed_for_season(
            Route(target, "propagate_solid", (target,)), slot
        ):
            return None
        reserved = Counter(busy or {})
        available = max(0, self._capacity(target, set(self.initial_owned)) - reserved[target])
        if available <= 0:
            return None
        current = self.inventory.physical_count(target)
        if goal is None:
            need = self._on_demand_propagation_need(
                target, set(self.initial_owned), reserved, in_progress or set()
            )
            if need is None:
                return None
            desired_goal, desired_reason, demand_regions = need
        else:
            # Explicit callers may preserve a physically planted incremental
            # propagation job, but v30 still limits a new recommendation to one
            # additional copy at a time.
            desired_goal = min(max(current + 1, int(goal)), current + 1)
            desired_reason = "explicit incremental propagation goal"
            demand_regions = ()
        if current >= desired_goal:
            return None

        if slot.greenhouse:
            if not slot.parent_cells:
                return None
            parent_cells = [list(slot.parent_cells[0])]
            candidate_targets = [slot.parent_cells[1], *slot.target_cells]
            target_cells = [list(cell) for cell in candidate_targets]
            parent_count = 1
            eligible = len(target_cells)
            probability = 1.0 if eligible else 0.0
            zone_count = 1
        else:
            zones = isolated_pair_zones(slot, 999)
            if not zones:
                return None
            # One fresh copy is enough to start propagation. If several free
            # copies already exist, use a few isolated clone parents to speed
            # the build without consuming every plot cell.
            needed = max(1, desired_goal - current)
            parent_count = min(available, needed, len(zones))
            chosen = zones[:parent_count]
            parent_coords = [pair[0] for pair, _targets in chosen]
            parent_set = set(parent_coords)
            usable = usable_cells(slot)
            clone_targets: set[tuple[int, int]] = set()
            for parent in parent_coords:
                clone_targets.update(neighboring_cells(parent, usable) - parent_set)
            parent_cells = [list(cell) for cell in parent_coords]
            target_cells = [list(cell) for cell in sorted(clone_targets)]
            eligible = len(target_cells)
            per_cell = self.settings["outdoor_spawn_probability_fertilized"]
            probability = 1.0 - (1.0 - per_cell) ** eligible if eligible else 0.0
            zone_count = parent_count

        if probability <= 0:
            return None
        return {
            "slot": slot.slot,
            "plot": slot.plot,
            "region": slot.region,
            "plot_spots": slot.spots,
            "eligible_cells": eligible,
            "target": target.label(),
            "target_type": target.flower_type,
            "target_color": target.color,
            "target_pattern": target.pattern,
            "target_secondary_color": target.secondary_color,
            "method": "propagate_solid",
            "parents": [target.label()],
            "parent_flowers": [{
                "flower_type": target.flower_type,
                "color": target.color,
                "pattern": target.pattern,
                "secondary_color": target.secondary_color,
            }],
            "parent_patterns": [target.pattern],
            "parent_copies": [parent_count],
            "daily_probability": probability,
            "expected_days": 1.0 / probability,
            "event_only": self._is_event_only(target),
            "stock_goal": desired_goal,
            "stock_goal_reason": desired_reason,
            "propagation_goal": desired_goal,
            "propagation_goal_reason": desired_reason,
            "propagation": True,
            "propagation_zone_count": zone_count,
            "propagation_demand_regions": list(demand_regions),
            "farm_state": "recommended",
            "locked": False,
            "layout": {
                "parent_a_cells": parent_cells,
                "parent_b_cells": [],
                "target_cells": target_cells,
            },
        }

    def assignment_for_target(
        self,
        target: Flower,
        slot: PlotSlot,
        busy: Counter[Flower] | None = None,
    ) -> dict | None:
        """Build the best immediately plantable assignment for one target and plot."""
        owned = set(self.initial_owned)
        reserved = Counter(busy or {})
        route = self._ready_route(target, owned, reserved, slot)
        if route is None:
            return None
        probability, eligible, copies = self._daily_probability(
            route, slot, owned, reserved
        )
        if probability <= 0:
            return None
        return self._assignment(
            slot,
            route,
            probability,
            eligible,
            1.0 / probability,
            copies,
        )
