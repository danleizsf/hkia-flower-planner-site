from __future__ import annotations

import json
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path

from .models import Flower
from .rules import GAME_COLOR_ORDER


@dataclass
class Inventory:
    solids: set[Flower]
    ombres: set[Flower]
    other_patterned: set[Flower]
    counts: dict[Flower, int]
    explicit_counts: set[Flower]
    flower_order: tuple[str, ...]
    visible_colors: tuple[str, ...]
    uncollected: set[Flower] = field(default_factory=set)

    @classmethod
    def load(cls, path: Path, donor_path: Path | None = None) -> "Inventory":
        data = json.loads(path.read_text(encoding="utf-8"))
        flower_order = tuple(data["flower_order"])
        # Saved inventories may carry an older color order. Keep the current
        # game order for known colors and retain any custom/unknown colors at
        # the end in their saved order.
        visible_colors = tuple(dict.fromkeys((*GAME_COLOR_ORDER, *data["visible_color_order"])))
        solids: set[Flower] = set()
        ombres: set[Flower] = set()
        other_patterned: set[Flower] = set()
        uncollected: set[Flower] = set()
        for key in data.get("uncollected_variants", []):
            parts = str(key).split("|")
            if len(parts) not in {3, 4}:
                raise ValueError(f"Bad uncollected variant key: {key}")
            flower_type, color, pattern = parts[:3]
            secondary_color = parts[3] if len(parts) == 4 else None
            uncollected.add(Flower(flower_type, color, pattern, secondary_color))

        for color, bits in data["solid_rows"].items():
            if len(bits) != len(flower_order):
                raise ValueError(f"Bad solid row width for {color}")
            solids.update(
                Flower(name, color, "Solid")
                for name, bit in zip(flower_order, bits, strict=True)
                if bit == "1"
            )

        for color, bits in data["ombre_rows"].items():
            if len(bits) != len(flower_order):
                raise ValueError(f"Bad Ombre row width for {color}")
            ombres.update(
                Flower(name, color, "Ombre")
                for name, bit in zip(flower_order, bits, strict=True)
                if bit == "1"
            )

        confirmed_other: set[Flower] = set()
        for row in data.get("other_patterned_variants", []):
            flower = Flower(
                row["flower_type"], row["color"], row["pattern"], row.get("secondary_color")
            )
            if flower.pattern in {"Solid", "Ombre"}:
                raise ValueError(f"Other-pattern record has standard pattern: {flower.label()}")
            confirmed_other.add(flower)
            other_patterned.add(flower)

        for row in data.get("hybrid_patterned_variants", []):
            flower = Flower(
                row["flower_type"], row["color"], row["pattern"], row["secondary_color"]
            )
            if flower.pattern == "Solid":
                raise ValueError(f"Hybrid record cannot be solid: {flower.label()}")
            if flower.pattern == "Ombre":
                ombres.add(flower)
            else:
                other_patterned.add(flower)

        # Explicitly uncollected variants override every ownership source,
        # including legacy screenshot rows and assumed patterned donors.
        solids.difference_update(uncollected)
        ombres.difference_update(uncollected)
        other_patterned.difference_update(uncollected)

        # A collected flower without a recorded count has no copies to plant.
        counts = {flower: 0 for flower in solids | ombres | other_patterned}
        explicit_counts: set[Flower] = set()
        for key, count in data.get("variant_counts", {}).items():
            try:
                parts = key.split("|")
                if len(parts) not in {3, 4}:
                    raise ValueError
                flower_type, color, pattern = parts[:3]
                secondary_color = parts[3] if len(parts) == 4 else None
            except ValueError as error:
                raise ValueError(f"Bad variant count key: {key}") from error
            flower = Flower(flower_type, color, pattern, secondary_color)
            if flower in uncollected:
                continue
            if flower not in solids | ombres | other_patterned:
                raise ValueError(f"Count specified for unowned flower: {flower.label()}")
            parsed_count = int(count)
            if parsed_count < 0:
                raise ValueError(f"Bad count for {flower.label()}: {parsed_count}")
            counts[flower] = parsed_count
            explicit_counts.add(flower)
        if donor_path and donor_path.exists():
            donor_data = json.loads(donor_path.read_text(encoding="utf-8"))
            for row in donor_data.get("donors", []):
                flower = Flower(
                    row["flower_type"], row["color"], row["pattern"], row.get("secondary_color")
                )
                if flower in uncollected:
                    continue
                other_patterned.add(flower)
                if flower not in confirmed_other:
                    counts[flower] = int(row.get("count", 0))

        return cls(
            solids,
            ombres,
            other_patterned,
            counts,
            explicit_counts,
            flower_order,
            visible_colors,
            uncollected,
        )

    @cached_property
    def all(self) -> frozenset[Flower]:
        # Inventory instances are immutable snapshots loaded from disk. Cache
        # the combined sets because UI/state generation checks membership many
        # thousands of times per request.
        return frozenset(self.solids | self.ombres | self.other_patterned)

    @cached_property
    def all_patterned(self) -> frozenset[Flower]:
        return frozenset(self.ombres | self.other_patterned)

    def has(
        self, flower_type: str, color: str, pattern: str, secondary_color: str | None = None
    ) -> bool:
        return Flower(flower_type, color, pattern, secondary_color) in self.all

    def colors_for(self, flower_type: str, pattern: str) -> set[str]:
        source = self.solids if pattern == "Solid" else self.ombres
        return {f.color for f in source if f.flower_type == flower_type}

    def any_parent_for_type(self, flower_type: str) -> bool:
        return any(f.flower_type == flower_type for f in self.all)

    def physical_count(self, flower: Flower) -> int:
        """Total physical copies recorded, before plot reservations."""
        return self.counts.get(flower, 0)

    def capacity(self, flower: Flower, abundant_colors: set[str] | None = None) -> int:
        """Copies owned: the recorded count, like ``physical_count``. A common
        color no longer counts as 50 when untracked (``abundant_colors`` is
        ignored; see copies.py)."""
        return self.counts.get(flower, 0) if flower in self.all else 0
