"""Reconcile individual Actual routes with edited physical parent inventory."""
from collections import Counter
from .models import Flower
from .plot_status import record_cell_counts


def retained_route(previous: dict, record: dict, alternative: dict | None) -> dict | None:
    """Retain intent across moves/copy reductions, or use a supported alternative.

    Coordinates deliberately do not identify a goal. This checks parent support,
    not adjacency, success probability, or a newly optimized planting layout.
    """
    if previous.get("method") == "manual":
        return alternative
    counts = record_cell_counts(record)
    parents = [Flower(p['flower_type'], p['color'], p['pattern'],
                      p.get('secondary_color')) for p in previous.get('parent_flowers', [])]
    required = Counter(parents)
    if not parents or any(counts[p] < n for p, n in required.items()):
        return alternative
    return {
        **previous,
        'parent_copies': [max(1, counts[p] // required[p]) for p in parents],
    }
