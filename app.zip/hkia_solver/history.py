from __future__ import annotations

import json
import os
import shutil
from collections import OrderedDict
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

from .paths import farm_data_path


HISTORY_SCHEMA = 1
SNAPSHOT_RETENTION_PER_SOURCE = 20
LEGACY_SNAPSHOT_SOURCES = (
    "inventory.json",
    "plot_status.json",
    "ui_map_layouts.json",
    "settings.json",
    "latest_plan.json",
    "other_patterned_donors.json",
)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def game_day(moment: datetime) -> date:
    """The in-game day ``moment`` falls in: days start at the daily reset, not at midnight."""
    from .plot_checks import RESET_UTC_HOUR

    return (moment.astimezone(timezone.utc) - timedelta(hours=RESET_UTC_HOUR)).date()


def _event_day(event: dict) -> date | None:
    """An event's game day, from its timestamp (older events stored the UTC date)."""
    try:
        return game_day(datetime.fromisoformat(str(event.get("timestamp", "")).replace("Z", "+00:00")))
    except ValueError:
        pass
    try:
        return date.fromisoformat(str(event.get("date", "")))
    except ValueError:
        return None


def _snapshot_source_key(path: Path) -> str:
    """Group current and legacy snapshot names by the file they copied."""
    if "__" in path.name:
        return path.name.rsplit("__", 1)[-1]
    for source_name in LEGACY_SNAPSHOT_SOURCES:
        if path.name.endswith("_" + source_name):
            return source_name
    # Unknown legacy formats are preserved individually rather than guessed.
    return "unclassified:" + path.relative_to(path.parents[2]).as_posix()


def prune_history_snapshots(
    root: Path,
    keep_per_source: int = SNAPSHOT_RETENTION_PER_SOURCE,
    *,
    apply: bool = False,
    source_file: str | None = None,
) -> dict:
    """Preview or remove old snapshots, keeping the newest N per source file."""
    keep = int(keep_per_source)
    if keep < 1:
        raise ValueError("At least one snapshot per source file must be retained.")

    snapshots_dir = farm_data_path(root, "history") / "snapshots"
    if not snapshots_dir.is_dir():
        return {
            "scanned": 0,
            "remove_count": 0,
            "bytes_to_free": 0,
            "remaining": 0,
            "applied": apply,
            "removed": [],
        }

    grouped: dict[str, list[Path]] = {}
    snapshots = [path for path in snapshots_dir.rglob("*") if path.is_file()]
    if source_file is not None:
        snapshots = [
            path for path in snapshots
            if _snapshot_source_key(path) == source_file
        ]
    for path in snapshots:
        grouped.setdefault(_snapshot_source_key(path), []).append(path)

    remove: list[Path] = []
    for paths in grouped.values():
        ordered = sorted(paths, key=lambda path: (path.parent.name, path.name))
        remove.extend(ordered[:-keep])

    bytes_to_free = sum(path.stat().st_size for path in remove)
    if apply:
        for path in remove:
            path.unlink()
        for directory in sorted(snapshots_dir.rglob("*"), key=lambda path: len(path.parts), reverse=True):
            if directory.is_dir():
                try:
                    directory.rmdir()
                except OSError:
                    pass

    return {
        "scanned": len(snapshots),
        "remove_count": len(remove),
        "bytes_to_free": bytes_to_free,
        "remaining": len(snapshots) - len(remove),
        "applied": apply,
        "removed": [path.relative_to(root).as_posix() for path in remove] if apply else [],
    }


def backup_before_mutation(root: Path, path: Path, action: str) -> str | None:
    """Keep a bounded rolling set of pre-change copies for the source file."""
    if not path.is_file():
        return None
    now = utc_now()
    safe_action = "".join(char if char.isalnum() or char in "-_" else "-" for char in action)
    directory = farm_data_path(root, "history") / "snapshots" / now.date().isoformat()
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / f"{now.strftime('%H%M%S-%f')}__{safe_action}__{path.name}"
    shutil.copy2(path, destination)
    history_dir = farm_data_path(root, "history")
    retention_marker = history_dir / "snapshot-retention-v1.json"
    if not retention_marker.exists():
        # One initial sweep brings older installations under the same cap.
        prune_history_snapshots(root, apply=True)
        history_dir.mkdir(parents=True, exist_ok=True)
        retention_marker.write_text(
            json.dumps({
                "schema_version": 1,
                "keep_per_source": SNAPSHOT_RETENTION_PER_SOURCE,
            }) + "\n",
            encoding="utf-8",
        )
    else:
        # Routine edits only inspect the file family they just backed up.
        prune_history_snapshots(root, apply=True, source_file=path.name)
    return destination.relative_to(root).as_posix()


def append_history_event(
    root: Path,
    category: str,
    action: str,
    details: dict,
    metrics: dict,
    backups: list[str] | None = None,
) -> dict:
    now = utc_now()
    event = {
        "schema_version": HISTORY_SCHEMA,
        "timestamp": now.isoformat(timespec="seconds").replace("+00:00", "Z"),
        "date": game_day(now).isoformat(),
        "category": category,
        "action": action,
        "details": details,
        "metrics": metrics,
        "backups": list(backups or []),
    }
    path = farm_data_path(root, "history") / "events.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())
    return event


def load_history_events(root: Path, limit: int = 500) -> list[dict]:
    path = farm_data_path(root, "history") / "events.jsonl"
    if not path.is_file():
        return []
    events: list[dict] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            event = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(event, dict):
            events.append(event)
    events = events[-limit:]
    # Checking backups on disk is slow, so only do it for the events returned.
    for event in events:
        backups = event.get("backups")
        if isinstance(backups, list):
            retained = [
                backup for backup in backups
                if isinstance(backup, str) and (root / backup).is_file()
            ]
            event["available_backups"] = retained
            event["unavailable_backups"] = max(0, len(backups) - len(retained))
    return events


def load_daily_history_events(root: Path, days: int = 120) -> list[dict]:
    """Stream the full journal into a bounded set of daily chart checkpoints.

    The activity table intentionally uses a recent-event limit. The chart must
    not share that limit: a busy farm can append hundreds of edits in a short
    period and otherwise make older days disappear from the chart. Keep only
    the latest metric snapshot for each date in the chart window plus the last
    checkpoint before the window, which is enough for daily carry-forward.
    """
    path = farm_data_path(root, "history") / "events.jsonl"
    if not path.is_file():
        return []

    today = game_day(utc_now())
    window_start = today - timedelta(days=max(1, int(days)) - 1)
    recent_by_date: dict[date, dict] = {}
    prior_checkpoint: dict | None = None
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict) or not isinstance(event.get("metrics"), dict):
                continue
            event_date = _event_day(event)
            if event_date is None:
                continue
            checkpoint = {
                "date": event_date.isoformat(),
                "metrics": event["metrics"],
            }
            if event_date > today:
                continue
            if event_date < window_start:
                if prior_checkpoint is None or event_date >= date.fromisoformat(prior_checkpoint["date"]):
                    prior_checkpoint = checkpoint
            else:
                # Append order determines the final checkpoint on a given day.
                recent_by_date[event_date] = checkpoint

    checkpoints = sorted(recent_by_date.values(), key=lambda item: item["date"])
    if prior_checkpoint is not None:
        checkpoints.insert(0, prior_checkpoint)
    return checkpoints


def _first_copies(event: dict) -> list[str]:
    """Flowers an event took from 0 copies to at least 1."""
    details = event.get("details") or {}
    action = event.get("action")
    if action == "found_target":
        return [details["flower"]] if details.get("flower") and details.get("total") == details.get("added") else []
    if action in ("add_inventory", "set_inventory"):
        previous, new = details.get("previous_total"), details.get("new_total")
        return [details["flower"]] if details.get("flower") and previous == 0 and (new or 0) > 0 else []
    if action == "record_spawns":
        return [
            change["flower"] for change in details.get("changes") or []
            if isinstance(change, dict) and change.get("flower")
            and change.get("before") == 0 and (change.get("after") or 0) > 0
        ]
    if action == "plant_changed":
        # The event doesn't record the old count; the acquired check below
        # decides whether this was a first copy.
        return [details["to"]] if details.get("to") else []
    return []


def new_flowers(root: Path, days: int = 120) -> list[dict]:
    """First copies of goal flowers from the journal, oldest first.

    An event counts only when the collected-goals metric rose with it, which
    leaves out flowers that aren't goals. A flower later marked uncollected
    is dropped again.
    """
    path = farm_data_path(root, "history") / "events.jsonl"
    if not path.is_file():
        return []
    window_start = game_day(utc_now()) - timedelta(days=max(1, int(days)) - 1)
    found: list[dict] = []
    previous_acquired = None
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            acquired = (event.get("metrics") or {}).get("acquired")
            rose = previous_acquired is None or acquired is None or acquired > previous_acquired
            if acquired is not None:
                previous_acquired = acquired
            if event.get("action") == "mark_uncollected":
                flower = (event.get("details") or {}).get("flower")
                for index in range(len(found) - 1, -1, -1):
                    if found[index]["flower"] == flower:
                        del found[index]
                        break
                continue
            day = _event_day(event)
            if not rose or day is None or day < window_start:
                continue
            details = event.get("details") or {}
            # Where it appeared: a find can be filed under a plot's target but come from elsewhere.
            where = details.get("found_in", details.get("slot"))
            for flower in _first_copies(event):
                found.append({
                    "timestamp": event.get("timestamp"),
                    "day": day.isoformat(),            # the game day, as the chart counts it
                    "flower": flower,
                    "action": event.get("action"),
                    "slot": None if where == "inventory" else where,
                    "spotted_in_inventory": where == "inventory",
                })
    return found


def load_metric_anchors(root: Path) -> list[dict]:
    """Past "breeding_flowers" / "breeding" counts recovered from old farm
    copies (e.g. optimizer-run snapshots), from history/metric_anchors.json:
    [{"date": "YYYY-MM-DD", "breeding": 369, "breeding_flowers": 365}]."""
    path = farm_data_path(root, "history") / "metric_anchors.json"
    if not path.is_file():
        return []
    try:
        anchors = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return []
    return [
        anchor for anchor in anchors if isinstance(anchor, dict)
        and isinstance(anchor.get("date"), str)
        and (anchor.get("breeding") or 0) > 0 and anchor.get("breeding_flowers") is not None
    ]


def _estimate_breeding_flowers(rows: list[dict], anchors: list[dict]) -> None:
    """Fill "breeding_flowers" on days saved before it was recorded.

    Each estimate is that day's job count times the flowers-per-job ratio,
    interpolated by date between the nearest known ratios (recorded days and
    anchors). Estimated rows get "breeding_flowers_estimated": True.
    """
    ratios = {
        anchor["date"]: anchor["breeding_flowers"] / anchor["breeding"] for anchor in anchors
    }
    ratios.update({
        row["date"]: row["breeding_flowers"] / row["breeding"]
        for row in rows if row.get("breeding_flowers") is not None and row.get("breeding")
    })
    if not ratios:
        return
    known = sorted((date.fromisoformat(day), ratio) for day, ratio in ratios.items())
    for row in rows:
        if row.get("breeding_flowers") is not None or row.get("breeding") is None:
            continue
        day = date.fromisoformat(row["date"])
        before = [item for item in known if item[0] <= day]
        after = [item for item in known if item[0] >= day]
        if before and after and after[0][0] != before[-1][0]:
            (start, low), (end, high) = before[-1], after[0]
            ratio = low + (high - low) * (day - start).days / (end - start).days
        else:
            ratio = (before[-1] if before else after[0])[1]
        row["breeding_flowers"] = round(row["breeding"] * ratio)
        row["breeding_flowers_estimated"] = True


def daily_history(events: list[dict], current_metrics: dict, anchors: list[dict] | None = None) -> list[dict]:
    """Return a continuous daily series, carrying state across quiet days."""
    by_date: OrderedDict[str, dict] = OrderedDict()
    for event in events:
        metrics = event.get("metrics")
        event_date = event.get("date")
        if isinstance(event_date, str) and isinstance(metrics, dict):
            by_date[event_date] = {"date": event_date, **metrics}
    today = game_day(utc_now()).isoformat()
    by_date[today] = {"date": today, **current_metrics}
    if not by_date:
        return []
    parsed = sorted((date.fromisoformat(day), values) for day, values in by_date.items())
    start = max(parsed[0][0], date.fromisoformat(today) - timedelta(days=119))
    known = {day: values for day, values in parsed}
    current: dict | None = None
    # Seed a truncated window with the latest state preceding it.
    for day, values in parsed:
        if day <= start:
            current = values
        else:
            break
    rows: list[dict] = []
    day = start
    end = date.fromisoformat(today)
    while day <= end:
        current = known.get(day, current)
        if current is not None:
            # A metric added later is missing from older days; leave it out
            # rather than charting a false 0.
            rows.append({"date": day.isoformat(), **{
                key: int(current[key])
                for key in ("acquired", "breeding", "breeding_flowers", "blocked")
                if current.get(key) is not None
            }})
        day += timedelta(days=1)
    _estimate_breeding_flowers(rows, anchors or [])
    return rows
