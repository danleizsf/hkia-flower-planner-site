"""Live parent availability for the collection checklist; no schedule rollout."""
import json
from collections import defaultdict

from .models import Flower
from .optimizer import Route
from .plots import all_slots
from .rules import parents_for_mix


class CollectionAvailability:
    def __init__(self, optimizer, reserved):
        self.optimizer = optimizer
        self.reserved = reserved
        self.slots = list({(s.region, s.greenhouse): s for s in all_slots()}.values())
        self.legal = {}
        # Stock is fixed for one availability pass, and ~10k missing targets
        # ask about the same parents hundreds of thousands of times.
        self._capacity = {}
        # When set, every parent whose stock describe() looks at is added
        # here; AvailabilityCache uses it to know what a result depends on.
        self.touched = None

    def capacity(self, flower):
        if self.touched is not None:
            self.touched.add(flower)
        if flower not in self._capacity:
            self._capacity[flower] = self.optimizer.inventory.capacity(flower, self.optimizer.abundant_colors)
        return self._capacity[flower]

    def free(self, flower):
        if self.touched is not None:
            self.touched.add(flower)
        return max(0, self.capacity(flower) - self.reserved[flower])

    def routes(self, target):
        opt = self.optimizer
        if target.pattern == 'Solid':
            for a, b in parents_for_mix(target.color):
                yield Route(target, 'color_mix', (Flower(target.flower_type, a, 'Solid'), Flower(target.flower_type, b, 'Solid')))
            recipients = [p for p in opt._solid_order_by_type[target.flower_type] if p != target]
            # All same-species solid recipients have identical venue rules.
            if recipients:
                recipient = min(recipients, key=lambda p: (self.free(p) == 0, self.capacity(p) == 0, -self.free(p), p.label()))
                for donor in opt._patterned_order_by_color.get(target.color, ()):
                    if donor.flower_type != target.flower_type:
                        yield Route(target, 'color_transfer', (donor, recipient))
        else:
            solid = Flower(target.flower_type, target.color, 'Solid')
            if opt.flower_types[target.flower_type].default_pattern == target.pattern:
                yield Route(target, 'fertilize_pattern', (solid,))
            for donor in opt._pattern_order_by_color.get((target.pattern, target.color), ()):
                if donor.flower_type != target.flower_type:
                    yield Route(target, 'pattern_transfer', (donor, solid))

    def describe(self, target):
        alternatives = []
        for route in self.routes(target):
            key = (target.flower_type, target.pattern, route.method, tuple(p.flower_type for p in route.parents))
            if key not in self.legal:
                self.legal[key] = any(self.optimizer._route_allowed_for_season(route, slot) for slot in self.slots)
            if not self.legal[key]:
                continue
            blockers = []
            # Same result as Counter(route.parents) for these 1-2 parent routes, minus its overhead.
            parents = route.parents
            counts = ((parents[0], 2),) if len(parents) == 2 and parents[0] == parents[1] else ((p, 1) for p in parents)
            for parent, needed in counts:
                free = self.free(parent)
                if free < needed:
                    blockers.append({'label': parent.label(), 'needed': needed, 'free': free,
                                     'total': self.capacity(parent),
                                     'reason': 'missing copies' if self.capacity(parent) < needed else 'copies already planted'})
            if not blockers:
                return {'blocked': False, 'blocking_routes': []}
            alternatives.append({'method': route.method, 'parents': [p.label() for p in route.parents], 'blocking_parents': blockers})
        alternatives.sort(key=lambda r: (sum(p['total'] < p['needed'] for p in r['blocking_parents']), len(r['blocking_parents']), tuple(r['parents'])))
        # Avoid repeated explanations for many donors that all wait on the
        # same missing recipient. Show up to three distinct ways to unblock.
        distinct, seen = [], set()
        for route in alternatives:
            signature = tuple(sorted((p['label'], p['needed']) for p in route['blocking_parents']))
            if signature not in seen:
                seen.add(signature)
                distinct.append(route)
            if len(distinct) == 3:
                break
        return {'blocked': True, 'blocking_routes': distinct,
                'blocking_reason': ('No free parent combination is currently available.' if alternatives else 'No compatible parent route is available under the current flower and location rules.')}


class AvailabilityCache:
    """describe() results kept across dashboard loads.

    Recording a spawn or editing inventory changes a few parents' stock, but
    used to redo all ~10k blocked-flower explanations (about 2 s). A result
    depends only on the stock and reservations of the parents it looked at
    (CollectionAvailability.touched) plus the farm's structure: settings,
    abundant colors and which patterned flowers exist. So each pass re-checks
    the parents seen before and redoes only targets that read a changed one.
    The final sort in describe() makes results independent of route order.
    """

    def __init__(self):
        self._reset(None)

    def _reset(self, structure):
        self.structure = structure
        self.results = {}  # target -> describe() result
        self.deps = {}  # target -> parents its result read
        self.dependents = defaultdict(set)  # parent -> targets that read it
        self.seen = {}  # parent -> (capacity, free) when last read
        self.legal = {}  # CollectionAvailability.legal, settings-only

    @staticmethod
    def structure_of(optimizer, settings: dict):
        return (
            json.dumps(settings, sort_keys=True),
            frozenset(optimizer.abundant_colors),
            frozenset(flower for flowers in optimizer._patterned_by_color.values() for flower in flowers),
        )

    def _forget(self, target):
        self.results.pop(target, None)
        for parent in self.deps.pop(target, ()):
            self.dependents[parent].discard(target)

    def update(self, structure, availability: CollectionAvailability, targets) -> dict:
        """Results for ``targets``, recomputing only what changed."""
        if structure != self.structure:
            self._reset(structure)
        availability.legal = self.legal
        for parent, before in list(self.seen.items()):
            now = (availability.capacity(parent), availability.free(parent))
            if now != before:
                self.seen[parent] = now
                for target in list(self.dependents[parent]):
                    self._forget(target)
        results = {}
        for target in targets:
            if target not in self.results:
                availability.touched = set()
                self.results[target] = availability.describe(target)
                touched, availability.touched = availability.touched, None
                self.deps[target] = touched
                for parent in touched:
                    self.dependents[parent].add(target)
                    if parent not in self.seen:
                        self.seen[parent] = (availability.capacity(parent), availability.free(parent))
            results[target] = self.results[target]
        return results