from __future__ import annotations

import hashlib
import inspect
import json
import os
import threading
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class PlotSlot:
    slot: str
    plot: str
    region: str
    spots: int
    greenhouse: bool
    eligible_cells: int
    rows: int
    cols: int
    disabled_cells: tuple[tuple[int, int], ...] = ()
    parent_cells: tuple[tuple[int, int], ...] = ()
    target_cells: tuple[tuple[int, int], ...] = ()


PREFIX_REGIONS = {
    "sr": "Seaside Resort",
    "ss": "Spooky Swamp",
    "gm": "Gemstone Mountain",
    "rr": "Rainbow Reef",
    "mh": "Mount Hothead",
    "mm": "Merry Meadow",
    "ci": "Cloud Island",
    "ww": "Wheatflour Wonderland",
    "ct": "City Town",
    "ip": "Icy Peak",
    "cc": "Crystal Caves",
    "tm": "The Moon",
}


PLOT_LAYOUTS_PATH = Path(__file__).resolve().parents[1] / "data" / "plot_layouts.json"

# Areas in the order the game opens them (HKIA wiki, Nov 2026): the start;
# "Power Up the Gate" opens Spooky Swamp, and through it Gemstone Mountain and
# Mount Hothead (Crystal Caves and Caldera are inside those two); Flippers
# ("Finding Flippers", right after the gate) Rainbow Reef; "A Challenging
# Rescue" Icy Peak; "Stargazing" (after the rescue) Cloud Island; "Curious
# Caverns" (My Melody level 11) Merry Meadow; "This Tall to Ride" (late in the
# story) The Moon. The DLC areas come last. Setup screens list areas this way.
AREA_ORDER = (
    "Seaside Resort", "Spooky Swamp", "Rainbow Reef", "Gemstone Mountain", "Crystal Caves",
    "Mount Hothead", "Caldera", "Icy Peak", "Cloud Island", "Merry Meadow", "The Moon",
    "Wheatflour Wonderland", "City Town",
)

# Greenhouse (rows, cols) by upgrade level: 0 = not unlocked yet, 1-5 the
# material upgrades, 6 = 10 x 10, 7 = the Extreme upgrade (10 x 11, and
# extremophiles may grow there). HKIA wiki, Greenhouse (Nov 2026).
GREENHOUSE_SIZES = {0: None, 1: (2, 3), 2: (3, 4), 3: (5, 5), 4: (9, 5), 5: (9, 9), 6: (10, 10), 7: (10, 11)}
FULL_GREENHOUSE_LEVEL = 6
EXTREME_GREENHOUSE_LEVEL = 7

# The plots this farm has unlocked, from its settings: "unlocked_plots"
# (outdoor plot ids; missing = all) and "greenhouse_level" (missing = 10 x 10).
# A process plans one farm at a time (the dashboard, Generate plan, the
# forecast), so the plot list is set when the farm's settings load
# (configure_farm_plots) and every reader of all_slots() sees that farm.
_farm_plots: dict = {"unlocked": None, "greenhouse_level": FULL_GREENHOUSE_LEVEL}


def configure_farm_plots(settings: dict | None) -> None:
    settings = settings or {}
    unlocked = settings.get("unlocked_plots")
    level = settings.get("greenhouse_level", FULL_GREENHOUSE_LEVEL)
    if level not in GREENHOUSE_SIZES:
        raise ValueError(f"greenhouse_level must be 0-7, not {level!r}")
    _farm_plots["unlocked"] = None if unlocked is None else frozenset(str(s).upper() for s in unlocked)
    _farm_plots["greenhouse_level"] = level


def farm_plots_key() -> tuple:
    """Changes whenever the farm's plot list does (for caches built on it)."""
    unlocked = _farm_plots["unlocked"]
    return (None if unlocked is None else tuple(sorted(unlocked)), _farm_plots["greenhouse_level"])


def greenhouse_level() -> int:
    return _farm_plots["greenhouse_level"]


def extreme_gardening_mode(settings: dict | None) -> str:
    """FLOW's extreme_gardening for this farm: "now", "auto" or "never".

    The Extreme upgrade is the Greenhouse's last: unlocked at level 7; at
    10 x 10 FLOW may forecast unlocking it (or the farm's flow setting says);
    with a smaller Greenhouse, or none, it is out of reach for now.
    """
    settings = settings or {}
    level = settings.get("greenhouse_level", FULL_GREENHOUSE_LEVEL)
    if level == EXTREME_GREENHOUSE_LEVEL:
        return "now"
    if level == FULL_GREENHOUSE_LEVEL:
        return (settings.get("flow") or {}).get("extreme_gardening", "auto")
    return "never"


def every_outdoor_slot() -> list[PlotSlot]:
    """Every outdoor plot in the game, unlocked or not (for setup screens)."""
    return list(_outdoor_slots(PLOT_LAYOUTS_PATH.stat().st_mtime_ns))


def outdoor_slots() -> list[PlotSlot]:
    """The farm's unlocked outdoor plots."""
    # Called hundreds of times per dashboard load; parse the file once per edit.
    slots = _outdoor_slots(PLOT_LAYOUTS_PATH.stat().st_mtime_ns)
    unlocked = _farm_plots["unlocked"]
    return list(slots) if unlocked is None else [s for s in slots if s.slot in unlocked]


@lru_cache(maxsize=2)
def _outdoor_slots(_mtime_ns: int) -> tuple[PlotSlot, ...]:
    layouts = json.loads(PLOT_LAYOUTS_PATH.read_text(encoding="utf-8"))
    slots: list[PlotSlot] = []
    for layout_id, layout in layouts.items():
        prefix = layout_id[:2]
        rows = int(layout["rows"])
        cols = int(layout["cols"])
        disabled = tuple((int(cell["row"]), int(cell["col"])) for cell in layout["disabledCells"])
        spots = rows * cols - len(disabled)
        slots.append(PlotSlot(
            slot=layout_id.upper(),
            plot=layout["name"],
            region=layout.get("region", PREFIX_REGIONS[prefix]),
            spots=spots,
            greenhouse=False,
            eligible_cells=max(2, int(spots * 0.45)),
            rows=rows,
            cols=cols,
            disabled_cells=disabled,
        ))
    return tuple(sorted(slots, key=lambda item: (-item.spots, item.slot)))


def greenhouse_slots() -> list[PlotSlot]:
    """Return the one physical Greenhouse plot at the farm's size (none before it is unlocked).

    Pair placements are generated over this shared grid by the layout
    optimizer. The former GH01-GH12 slots were artificial scheduler lanes;
    they let independently planned subplots contend for the same physical
    cells and prevented the optimizer from packing all work together.
    """
    size = GREENHOUSE_SIZES[_farm_plots["greenhouse_level"]]
    if size is None:
        return []
    return [_greenhouse_slot(*size)]


def _greenhouse_slot(rows: int, cols: int) -> PlotSlot:
    return PlotSlot(
        slot="GH",
        plot="Greenhouse",
        region="Greenhouse",
        spots=rows * cols,
        greenhouse=True,
        eligible_cells=0,
        rows=rows,
        cols=cols,
    )


def all_slots() -> list[PlotSlot]:
    return greenhouse_slots() + outdoor_slots()


def usable_cells(slot: PlotSlot) -> set[tuple[int, int]]:
    disabled = set(slot.disabled_cells)
    return {
        (row, col)
        for row in range(slot.rows)
        for col in range(slot.cols)
        if (row, col) not in disabled
    }


def neighboring_cells(
    cell: tuple[int, int],
    usable: set[tuple[int, int]],
) -> set[tuple[int, int]]:
    row, col = cell
    return {
        (row + dr, col + dc)
        for dr in (-1, 0, 1)
        for dc in (-1, 0, 1)
        if (dr or dc) and (row + dr, col + dc) in usable
    }


def isolated_pair_zones(
    slot: PlotSlot,
    pair_limit: int,
) -> tuple[tuple[tuple[tuple[int, int], tuple[int, int]], frozenset[tuple[int, int]]], ...]:
    """Return up to ``pair_limit`` zones from one cached maximum packing.

    Plot geometry is static. Older versions solved the same conflict graph again
    for every requested pair limit (1 pair, 2 pairs, 3 pairs, ...), which made
    whole-farm planning spend most of its time recomputing identical geometry.
    v24 solves each physical plot once, caches the densest deterministic packing,
    and slices that result for smaller parent-copy limits.
    """
    if pair_limit <= 0:
        return ()
    return _maximum_isolated_pair_zones(slot)[:pair_limit]


ZONE_CACHE_PATH = Path(__file__).resolve().parents[1] / ".cache" / "pair_zones.json"
# Every plot's packing, computed when the browser version is built (browser/build.py):
# the browser can't keep .cache/ between visits, and packing takes 5+ s there.
BUNDLED_ZONE_CACHE_PATH = Path(__file__).resolve().parent / "pair_zones.json"
_zone_cache_lock = threading.Lock()


@lru_cache(maxsize=None)
def _zone_code_hash() -> str:
    # Editing the packing rules invalidates the cache; other edits here don't.
    source = "".join(inspect.getsource(function) for function in (
        usable_cells, neighboring_cells, _compute_isolated_pair_zones,
    ))
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


@lru_cache(maxsize=None)
def _disk_zone_cache() -> dict:
    zones = {}
    for path in (BUNDLED_ZONE_CACHE_PATH, ZONE_CACHE_PATH):     # the local cache wins
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if data.get("code") == _zone_code_hash():
            zones.update(data.get("zones", {}))
    return zones


def write_zone_cache(path: Path) -> int:
    """Save the packing of every outdoor plot and every Greenhouse size to ``path``."""
    slots = every_outdoor_slot() + [_greenhouse_slot(*size) for size in GREENHOUSE_SIZES.values() if size]
    zones = {repr(slot): [[list(pair), sorted(targets)] for pair, targets in _maximum_isolated_pair_zones(slot)]
             for slot in slots}
    path.write_text(json.dumps({"code": _zone_code_hash(), "zones": zones}), encoding="utf-8")
    return len(zones)


@lru_cache(maxsize=None)
def _maximum_isolated_pair_zones(
    slot: PlotSlot,
) -> tuple[tuple[tuple[tuple[int, int], tuple[int, int]], frozenset[tuple[int, int]]], ...]:
    """The packing below, kept on disk across restarts.

    Packing all 55 plots takes several seconds, which made the first dashboard
    load after every server start slow. Plot geometry never changes, so the
    result is saved under ``.cache/`` keyed by the slot and this module's code.
    """
    key = repr(slot)
    cache = _disk_zone_cache()
    stored = cache.get(key)
    if stored is not None:
        return tuple(((tuple(a), tuple(b)), frozenset(map(tuple, targets))) for (a, b), targets in stored)
    zones = _compute_isolated_pair_zones(slot)
    with _zone_cache_lock:
        cache[key] = [[list(pair), sorted(targets)] for pair, targets in zones]
        try:
            ZONE_CACHE_PATH.parent.mkdir(exist_ok=True)
            temporary = ZONE_CACHE_PATH.with_suffix(f".{os.getpid()}.tmp")
            temporary.write_text(json.dumps({"code": _zone_code_hash(), "zones": cache}), encoding="utf-8")
            os.replace(temporary, ZONE_CACHE_PATH)
        except OSError:
            pass  # caching is an optimization only
    return zones


def _compute_isolated_pair_zones(
    slot: PlotSlot,
) -> tuple[tuple[tuple[tuple[int, int], tuple[int, int]], frozenset[tuple[int, int]]], ...]:
    """Compute the maximum deterministic micro-zone packing for one plot mask."""
    usable = usable_cells(slot)
    candidates: list[
        tuple[tuple[tuple[int, int], tuple[int, int]], frozenset[tuple[int, int]]]
    ] = []

    for first in sorted(usable):
        for dr, dc in ((0, 1), (1, 0)):
            second = (first[0] + dr, first[1] + dc)
            if second not in usable:
                continue
            shared = (
                neighboring_cells(first, usable)
                & neighboring_cells(second, usable)
            ) - {first, second}

            if dr == 0:  # horizontal parents; spawn row above or below
                variants = (
                    ((first[0] - 1, first[1]), (first[0] - 1, second[1])),
                    ((first[0] + 1, first[1]), (first[0] + 1, second[1])),
                )
            else:  # vertical parents; spawn column left or right
                variants = (
                    ((first[0], first[1] - 1), (second[0], first[1] - 1)),
                    ((first[0], first[1] + 1), (second[0], first[1] + 1)),
                )

            for target_pair in variants:
                targets = frozenset(target_pair)
                if len(targets) == 2 and targets <= shared:
                    candidates.append(((first, second), targets))
            # Prefer a two-cell spawn edge, but also expose safe one-cell
            # variants. The allocator can use those when they let another
            # distinct target fit into geometry that the old all-or-nothing
            # rule left unused. Final layout expansion adds every additional
            # unambiguous spawn cell around the pair.
            for target in sorted(shared):
                candidates.append(((first, second), frozenset({target})))

    if not candidates:
        return ()

    parent_sets = [set(pair) for pair, _targets in candidates]
    target_sets = [set(targets) for _pair, targets in candidates]

    conflicts: list[set[int]] = [set() for _ in candidates]
    occupants_by_cell: dict[tuple[int, int], list[int]] = {}
    parents_by_cell: dict[tuple[int, int], list[int]] = {}
    for index, (parents, targets) in enumerate(zip(parent_sets, target_sets)):
        for cell in parents | targets:
            occupants_by_cell.setdefault(cell, []).append(index)
        for cell in parents:
            parents_by_cell.setdefault(cell, []).append(index)

    # Build the conflict graph from the sparse cell index instead of comparing
    # every candidate with every other candidate. Large plots have hundreds of
    # one-cell variants, while each zone touches only a small neighborhood.
    for indices in occupants_by_cell.values():
        for offset, left in enumerate(indices):
            for right in indices[offset + 1:]:
                conflicts[left].add(right)
                conflicts[right].add(left)
    for index, targets in enumerate(target_sets):
        for target in targets:
            for neighbor in neighboring_cells(target, usable):
                for other in parents_by_cell.get(neighbor, ()):
                    if other != index:
                        conflicts[index].add(other)
                        conflicts[other].add(index)

    # Maximum independent set is NP-hard. These masks are small, and several
    # deterministic minimum-conflict greedy passes recover dense packings.
    # Prefer more distinct safe pairs first, then the packing whose parent
    # positions support the greatest number of unambiguous target cells. The
    # latter breaks the old tie where an arbitrary maximum packing left useful
    # spawn cells stranded elsewhere in the same plot.
    best: list[int] = []
    best_score = (-1, -1)

    def packing_score(indices: list[int]) -> tuple[int, int]:
        parent_owner: dict[tuple[int, int], tuple[int, str]] = {}
        for owner, index in enumerate(indices):
            pair = candidates[index][0]
            parent_owner[pair[0]] = (owner, "A")
            parent_owner[pair[1]] = (owner, "B")
        active_cells = len(parent_owner)
        for cell in usable - set(parent_owner):
            owners = [
                parent_owner[neighbor]
                for neighbor in neighboring_cells(cell, usable)
                if neighbor in parent_owner
            ]
            if (
                len({owner for owner, _role in owners}) == 1
                and {role for _owner, role in owners} >= {"A", "B"}
            ):
                active_cells += 1
        return len(indices), active_cells

    for mode in range(8):
        remaining = set(range(len(candidates)))
        selected: list[int] = []
        while remaining:
            if mode == 0:
                chosen = min(
                    remaining,
                    key=lambda index: (len(conflicts[index] & remaining), index),
                )
            else:
                chosen = min(
                    remaining,
                    key=lambda index: (
                        len(conflicts[index] & remaining),
                        ((index * 2654435761 + mode * 7919) & 0xFFFF),
                        index,
                    ),
                )
            selected.append(chosen)
            remaining.remove(chosen)
            remaining.difference_update(conflicts[chosen])
        score = packing_score(selected)
        if score > best_score:
            best = selected
            best_score = score

    return tuple(candidates[index] for index in best)


@lru_cache(maxsize=None)
def isolated_pair_layout(
    slot: PlotSlot,
    pair_limit: int,
) -> tuple[tuple[tuple[tuple[int, int], tuple[int, int]], ...], frozenset[tuple[int, int]]]:
    zones = isolated_pair_zones(slot, pair_limit)
    pairs = tuple(pair for pair, _targets in zones)
    targets = frozenset(cell for _pair, cells in zones for cell in cells)
    return pairs, targets
