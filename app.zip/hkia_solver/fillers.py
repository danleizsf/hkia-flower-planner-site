"""Filler flowers for the free cells next to an outdoor plot's spawn cells.

Outdoors, an empty cell's daily spawn chance is 10% per fertilized flower
touching it, capped at 80% (the wiki rule ``flow/`` already uses). A planned
spawn cell usually touches only its pair, so it sits at 20-30%. A *filler* is
a fertilized flower in a free neighboring cell that can't breed with anything
around the spawn cells it touches: it raises their spawn chance without adding
an unplanned pair, so every extra spawn is still the planned attempt.
"""
from __future__ import annotations

from collections import Counter

from .copies import Copies, cell_flower
from .flow.packing import compatible
from .models import Flower
from .plots import PlotSlot, usable_cells
from .rules import BREED_PROBABILITY
from .zones import flower_allowed

Cell = tuple[int, int]
CAP = 0.80


def _ring(cell: Cell) -> set[Cell]:
    r, c = cell
    return {(r + dr, c + dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc}


def spawn_targets(record: dict, usable: set[Cell], planted: set[Cell]) -> dict[Cell, float]:
    """Empty planned spawn cells -> best per-spawn breeding chance among their jobs.

    A spawn cell several recipients touch is in ``shared_target_cells`` only
    (FLOW hubs), so both lists count.
    """
    targets: dict[Cell, float] = {}
    for job in [record.get("assignment") or {}, *record.get("jobs", [])]:
        per = BREED_PROBABILITY.get(str(job.get("method", "")))
        if per is None or str(job.get("method")).startswith("fertilize_"):
            continue
        layout = job.get("layout") or {}
        for row, col in [*layout.get("target_cells", []), *layout.get("shared_target_cells", [])]:
            cell = (int(row), int(col))
            if cell in usable and cell not in planted:
                targets[cell] = max(targets.get(cell, 0.0), per)
    return targets


def daily_finds(targets: dict[Cell, float], plants: set[Cell]) -> float:
    """Expected targeted finds a day: spawn chance x breeding chance per cell."""
    return sum(per * min(CAP, 0.10 * len(_ring(cell) & plants)) for cell, per in targets.items())


def suggest_fillers(slot: PlotSlot, record: dict, spare: dict[Flower, int],
                    keep: list[dict] = ()) -> dict:
    """Pick filler flowers for one planted outdoor plot.

    ``record`` is the plot's plot_status entry; ``spare`` the copies of each
    flower not planted anywhere. Fillers in the record are ignored; ``keep``
    lists fillers already in the ground, and each one that still sits on a
    free cell next to a spawn cell, breeds with nothing there and has a spare
    copy stays put, so a partial update doesn't shuffle them. New fillers
    reuse a flower the plot already has before starting another, where it
    breeds with nothing nearby (two copies of one flower breed, so fillers
    sharing an empty cell still differ). Only solids are
    considered: a patterned filler is compatible with every patterned donor.
    """
    if slot.greenhouse:
        raise ValueError("The Greenhouse already spawns in every empty cell; fillers only help outdoors.")
    usable = usable_cells(slot)
    cells = [cell for cell in record.get("cells", []) if not cell.get("filler")]
    plants = {(int(c["row"]), int(c["col"])): cell_flower(c) for c in cells}
    targets = spawn_targets(record, usable, set(plants))
    if not targets:
        raise ValueError(f"{slot.slot} has no planned spawn cells to fill around.")
    before = daily_finds(targets, set(plants))

    left = Counter({f: n for f, n in spare.items()
                    if n > 0 and f.pattern == "Solid" and flower_allowed(f, slot)})
    # Free cells touching the most still-uncapped spawn cells first.
    def touching(cell: Cell) -> list[Cell]:
        return [t for t in _ring(cell) & set(targets) if len(_ring(t) & set(plants)) < 8]

    def neighbors(cell: Cell) -> set[Flower]:
        # Check every empty cell it touches, spawn cells (capped ones too) and
        # free ones alike: a compatible pair at any of them breeds there.
        return {plants[n] for e in _ring(cell) & usable if e not in plants
                for n in _ring(e) if n in plants}

    fillers: list[dict] = []
    # Flowers the plot already has as fillers come first, dug-up ones too, so
    # a moved filler is replanted rather than swapped for another flower.
    used: Counter = Counter(cell_flower(c) for c in keep)

    def place(cell: Cell, flower: Flower) -> None:
        left[flower] -= 1
        used[flower] += 1
        plants[cell] = flower
        fillers.append({"row": cell[0], "col": cell[1], "flower_type": flower.flower_type,
                        "color": flower.color, "pattern": flower.pattern,
                        "secondary_color": None, "filler": True})

    for old in keep:
        cell, flower = (int(old["row"]), int(old["col"])), cell_flower(old)
        if (cell in usable and cell not in plants and cell not in targets
                and _ring(cell) & set(targets) and left[flower] > 0
                and not any(compatible(flower, n) for n in neighbors(cell))):
            place(cell, flower)

    free = sorted((c for t in targets for c in _ring(t) & usable
                   if c not in plants and c not in targets),
                  key=lambda c: (-len(touching(c)), c))
    for cell in dict.fromkeys(free):
        if not touching(cell):
            continue
        near = neighbors(cell)
        # A flower this plot already uses first, then most spare copies;
        # most_common() still lists used-up flowers.
        ranked = sorted(left.most_common(), key=lambda item: -used[item[0]])
        choice = next((f for f, copies in ranked
                       if copies > 0 and not any(compatible(f, n) for n in near)), None)
        if choice is not None:
            place(cell, choice)
    for filler in fillers:
        spare[cell_flower(filler)] = spare.get(cell_flower(filler), 0) - 1
    return {
        "slot": slot.slot,
        "fillers": fillers,
        "spawn_cells": len(targets),
        "finds_per_day_before": round(before, 4),
        "finds_per_day_after": round(daily_finds(targets, set(plants)), 4),
    }


def _physical(cells: list[dict]) -> set[tuple]:
    return {(int(c["row"]), int(c["col"]), c.get("flower_type"), c.get("color"),
             c.get("pattern"), c.get("secondary_color")) for c in cells if not c.get("filler")}


def farm_fillers(slots: dict[str, PlotSlot], recommended: dict[str, tuple[list[dict], list[dict]]],
                 status_data: dict, owned: dict[Flower, int], release=(),
                 fillers: bool = True) -> tuple[dict[str, list[dict]], Copies]:
    """Every plot's Recommendation in the farm's copies, plus its fillers.

    ``recommended`` maps a slot to (its recommended jobs, their plant cells);
    ``owned`` is each flower's copies (``copies.owned_counts``) and
    ``release`` the plots a batch replants (see ``copies.Copies``). Fillers
    count like any other plant: every plot's planned plants take their copies
    first, then each plot's fillers come from what that plot can plant.
    A plot whose recorded fillers sit around the same plants keeps them, so
    the suggestion doesn't move every time inventory changes; when its plants
    change, each recorded filler that still works stays where it is.

    Returns (fillers per plot, the farm's copies with all of it planted: its
    moves and shortages).
    """
    records = status_data.get("plots", {})
    copies = Copies.from_status(owned, status_data, release)
    kept: dict[str, list[dict]] = {}
    plans: dict[str, list[Flower]] = {}
    for slot_id, (jobs, cells) in recommended.items():
        slot = slots.get(slot_id)
        if slot is None:
            continue
        record = records.get(slot_id) or {}
        recorded = [c for c in record.get("cells", []) if c.get("filler")]
        spawn = set(spawn_targets({"assignment": (jobs or [{}])[0], "jobs": jobs[1:]},
                                  usable_cells(slot), set())) if jobs else set()
        # A recorded filler sitting on a spawn cell (e.g. one placed before
        # shared spawn cells counted) sends the plot back through the search.
        if (fillers and recorded and _physical(cells) == _physical(record.get("cells", []))
                and not any((int(c["row"]), int(c["col"])) in spawn for c in recorded)):
            kept[slot_id] = recorded
        plans[slot_id] = [cell_flower(c) for c in cells + kept.get(slot_id, [])]
    copies.plant_all(plans)
    if not fillers:
        return {}, copies
    result = dict(kept)
    solids = sorted((f for f in owned if f.pattern == "Solid"), key=Flower.label)
    for slot_id, (jobs, cells) in sorted(recommended.items()):
        slot = slots.get(slot_id)
        if slot is None or slot_id in kept or slot.greenhouse or not jobs:
            continue
        # Its recorded fillers are still in its ground: this plot may replant
        # them, other plots only in a batch (as a move).
        keep = [c for c in (records.get(slot_id) or {}).get("cells", []) if c.get("filler")]
        with copies.at(slot_id):
            spare = {f: copies[f] for f in solids}
        try:
            found = suggest_fillers(slot, {"cells": cells, "assignment": jobs[0], "jobs": jobs[1:]},
                                    spare, keep=keep)
        except ValueError:
            continue
        copies.plant(slot_id, (cell_flower(c) for c in found["fillers"]))
        if found["fillers"]:
            result[slot_id] = found["fillers"]
    return result, copies
