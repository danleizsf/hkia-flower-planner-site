"""Filler flowers for the free cells next to an outdoor plot's spawn cells.

Outdoors, an empty cell's daily spawn chance is 10% per fertilized flower
touching it, capped at 80% (the wiki rule ``flow/`` already uses). A planned
spawn cell usually touches only its pair, so it sits at 20-30%. A *filler* is
a fertilized flower in a free neighboring cell that can't breed with anything
around the spawn cells it touches: it raises their spawn chance without adding
an unplanned pair, so every extra spawn is still the planned attempt.
"""
from __future__ import annotations

from collections import Counter

from .flow.packing import compatible
from .models import Flower
from .plots import PlotSlot, usable_cells
from .rules import BREED_PROBABILITY
from .zones import flower_allowed

Cell = tuple[int, int]
CAP = 0.80


def _ring(cell: Cell) -> set[Cell]:
    r, c = cell
    return {(r + dr, c + dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc}


def cell_flower(cell: dict) -> Flower:
    return Flower(cell["flower_type"], cell["color"], cell["pattern"], cell.get("secondary_color"))


def spawn_targets(record: dict, usable: set[Cell], planted: set[Cell]) -> dict[Cell, float]:
    """Empty planned spawn cells -> best per-spawn breeding chance among their jobs."""
    targets: dict[Cell, float] = {}
    for job in [record.get("assignment") or {}, *record.get("jobs", [])]:
        per = BREED_PROBABILITY.get(str(job.get("method", "")))
        if per is None or str(job.get("method")).startswith("fertilize_"):
            continue
        for row, col in (job.get("layout") or {}).get("target_cells", []):
            cell = (int(row), int(col))
            if cell in usable and cell not in planted:
                targets[cell] = max(targets.get(cell, 0.0), per)
    return targets


def daily_finds(targets: dict[Cell, float], plants: set[Cell]) -> float:
    """Expected targeted finds a day: spawn chance x breeding chance per cell."""
    return sum(per * min(CAP, 0.10 * len(_ring(cell) & plants)) for cell, per in targets.items())


def suggest_fillers(slot: PlotSlot, record: dict, spare: dict[Flower, int]) -> dict:
    """Pick filler flowers for one planted outdoor plot.

    ``record`` is the plot's plot_status entry; ``spare`` the copies of each
    flower not planted anywhere. Earlier fillers in the record are ignored, so
    asking again redoes the whole set. Only solids are considered: a patterned
    filler is compatible with every patterned donor.
    """
    if slot.greenhouse:
        raise ValueError("The Greenhouse already spawns in every empty cell; fillers only help outdoors.")
    usable = usable_cells(slot)
    cells = [cell for cell in record.get("cells", []) if not cell.get("filler")]
    plants = {(int(c["row"]), int(c["col"])): cell_flower(c) for c in cells}
    targets = spawn_targets(record, usable, set(plants))
    if not targets:
        raise ValueError(f"{slot.slot} has no planned spawn cells to fill around.")
    before = daily_finds(targets, set(plants))

    left = Counter({f: n for f, n in spare.items()
                    if n > 0 and f.pattern == "Solid" and flower_allowed(f, slot)})
    # Free cells touching the most still-uncapped spawn cells first.
    def touching(cell: Cell) -> list[Cell]:
        return [t for t in _ring(cell) & set(targets) if len(_ring(t) & set(plants)) < 8]

    free = sorted((c for t in targets for c in _ring(t) & usable
                   if c not in plants and c not in targets),
                  key=lambda c: (-len(touching(c)), c))
    fillers: list[dict] = []
    for cell in dict.fromkeys(free):
        near = touching(cell)
        if not near:
            continue
        # Check every empty cell it touches, spawn cells (capped ones too) and
        # free ones alike: a compatible pair at any of them breeds there.
        neighbors = {plants[n] for e in _ring(cell) & usable if e not in plants
                     for n in _ring(e) if n in plants}
        # Most spare copies first; most_common() still lists used-up flowers.
        choice = next((f for f, copies in left.most_common()
                       if copies > 0 and not any(compatible(f, n) for n in neighbors)), None)
        if choice is None:
            continue
        left[choice] -= 1
        plants[cell] = choice
        fillers.append({"row": cell[0], "col": cell[1], "flower_type": choice.flower_type,
                        "color": choice.color, "pattern": choice.pattern,
                        "secondary_color": None, "filler": True})
    for filler in fillers:
        spare[cell_flower(filler)] = spare.get(cell_flower(filler), 0) - 1
    return {
        "slot": slot.slot,
        "fillers": fillers,
        "spawn_cells": len(targets),
        "finds_per_day_before": round(before, 4),
        "finds_per_day_after": round(daily_finds(targets, set(plants)), 4),
    }


def _physical(cells: list[dict]) -> set[tuple]:
    return {(int(c["row"]), int(c["col"]), c.get("flower_type"), c.get("color"),
             c.get("pattern"), c.get("secondary_color")) for c in cells if not c.get("filler")}


def farm_fillers(slots: dict[str, PlotSlot], recommended: dict[str, tuple[list[dict], list[dict]]],
                 status_data: dict, counts: dict[Flower, int]) -> dict[str, list[dict]]:
    """Filler cells for every outdoor plot's Recommendation, sharing spare copies.

    ``recommended`` maps a slot to (its recommended jobs, their parent cells);
    ``counts`` is each flower's physical copies. Copies the Recommendation
    plants (or that stay planted where nothing is recommended) aren't spare.
    A plot whose recorded fillers sit around the same plants keeps them, so
    the suggestion doesn't move every time inventory changes.
    """
    records = status_data.get("plots", {})
    used: Counter = Counter()
    kept: dict[str, list[dict]] = {}
    for slot_id in slots:
        record = records.get(slot_id) or {}
        recorded = [c for c in record.get("cells", []) if c.get("filler")]
        if slot_id in recommended:
            cells = recommended[slot_id][1]
            if recorded and _physical(cells) == _physical(record.get("cells", [])):
                kept[slot_id] = recorded
                cells = cells + recorded
        else:
            cells = record.get("cells", [])
        used.update(cell_flower(c) for c in cells)
    spare = {flower: n - used[flower] for flower, n in counts.items()}
    result = dict(kept)
    for slot_id, (jobs, cells) in sorted(recommended.items()):
        slot = slots.get(slot_id)
        if slot is None or slot.greenhouse or slot_id in kept or not jobs:
            continue
        try:
            found = suggest_fillers(slot, {"cells": cells, "assignment": jobs[0], "jobs": jobs[1:]}, spare)
        except ValueError:
            continue
        if found["fillers"]:
            result[slot_id] = found["fillers"]
    return result
