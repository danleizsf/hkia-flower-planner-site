from __future__ import annotations


from .models import Flower
from .plots import PlotSlot, isolated_pair_layout, usable_cells
from .greenhouse_layout_optimizer import single_job_layout


def _flower(data: dict) -> Flower:
    return Flower(
        data["flower_type"], data["color"], data["pattern"], data.get("secondary_color")
    )


def _fitted_layout(layout: dict, usable: set[tuple[int, int]]) -> dict:
    """Drop cells a game patch removed from the plot since the layout was planned."""
    keys = ("parent_a_cells", "shared_parent_a_cells", "parent_b_cells", "target_cells")
    return {
        **layout,
        **{
            key: [cell for cell in layout[key] if (int(cell[0]), int(cell[1])) in usable]
            for key in keys if key in layout
        },
    }


def _outdoor_matrix(planner, slot: PlotSlot, assignment: dict) -> tuple[list[list[str]], dict]:
    usable = usable_cells(slot)
    grid = [
        ["#" if (row, col) not in usable else "x" for col in range(slot.cols)]
        for row in range(slot.rows)
    ]
    parents = [_flower(data) for data in assignment["parent_flowers"]]
    method = assignment["method"]
    layout = assignment.get("layout")
    if isinstance(layout, dict):
        layout = _fitted_layout(layout, usable)
        for row, col in layout.get("parent_a_cells", []):
            grid[int(row)][int(col)] = "A"
        for row, col in layout.get("shared_parent_a_cells", []):
            grid[int(row)][int(col)] = "A"
        for row, col in layout.get("parent_b_cells", []):
            grid[int(row)][int(col)] = "B"
        if not method.startswith("fertilize_"):
            for row, col in layout.get("target_cells", []):
                if grid[int(row)][int(col)] == "x":
                    grid[int(row)][int(col)] = "·"
        pairs = min(
            len(layout.get("parent_a_cells", [])),
            len(layout.get("parent_b_cells", [])),
        )
        return grid, {
            "plants": len(layout.get("parent_a_cells", [])) + len(layout.get("parent_b_cells", [])),
            "pairs": pairs,
            "targets": (
                0 if method.startswith("fertilize_")
                else len(layout.get("target_cells", []))
            ),
        }

    if method.startswith("fertilize_"):
        count = min(assignment["parent_copies"][0], len(usable))
        for row, col in sorted(usable)[:count]:
            grid[row][col] = "A"
        return grid, {"plants": count, "pairs": 0, "targets": 0}

    pair_limit = min(assignment["parent_copies"])
    pairs, targets = isolated_pair_layout(slot, pair_limit)
    for first, second in pairs:
        grid[first[0]][first[1]] = "A"
        grid[second[0]][second[1]] = "B"
    for row, col in targets:
        if grid[row][col] == "x":
            grid[row][col] = "·"
    return grid, {"plants": 2 * len(pairs), "pairs": len(pairs), "targets": len(targets)}


def assignment_matrix(slot: PlotSlot, assignment: dict | None) -> list[list[str]]:
    """Return a compact exact-cell matrix for the UI and markdown renderer."""
    if assignment is None:
        usable = usable_cells(slot)
        return [
            ["#" if (row, col) not in usable else "x" for col in range(slot.cols)]
            for row in range(slot.rows)
        ]
    if not slot.greenhouse:
        grid, _ = _outdoor_matrix(None, slot, assignment)
        return grid
    grid = [["--" for _ in range(slot.cols)] for _ in range(slot.rows)]
    layout = assignment.get("layout")
    if isinstance(layout, dict):
        # Cells recorded for a bigger Greenhouse than the farm now has (its
        # level was lowered) are left out rather than drawn off the grid.
        def put(cells, mark, only_empty=False):
            for row, col in cells:
                row, col = int(row), int(col)
                if row < slot.rows and col < slot.cols and (not only_empty or grid[row][col] == "--"):
                    grid[row][col] = mark

        put(layout.get("parent_a_cells", []), "A")
        put(layout.get("shared_parent_a_cells", []), "A")
        put(layout.get("parent_b_cells", []), "B")
        if not str(assignment.get("method", "")).startswith("fertilize_"):
            put(layout.get("target_cells", []), "·", only_empty=True)
        return grid
    if str(assignment.get("method", "")).startswith("fertilize_"):
        positions = tuple(slot.parent_cells) + tuple(slot.target_cells)
        if not positions:
            fallback = single_job_layout(slot, fertilizer=True)
            positions = tuple(tuple(cell) for cell in (fallback or {}).get("parent_a_cells", []))
        for row, col in positions[: int(assignment["parent_copies"][0])]:
            grid[row][col] = "A"
        return grid
    if not slot.parent_cells:
        fallback = single_job_layout(slot)
        if fallback is None:
            return grid
        for row, col in fallback["parent_a_cells"]:
            grid[row][col] = "A"
        for row, col in fallback["parent_b_cells"]:
            grid[row][col] = "B"
        for row, col in fallback["target_cells"]:
            grid[row][col] = "·"
        return grid
    first, second = slot.parent_cells
    grid[first[0]][first[1]] = "A"
    grid[second[0]][second[1]] = "B"
    for row, col in slot.target_cells:
        grid[row][col] = "·"
    return grid


def assignment_cell_records(slot: PlotSlot, assignment: dict | None) -> list[dict]:
    """Expand a recommendation into exact persisted parent-plant cells."""
    if assignment is None:
        return []
    grid = assignment_matrix(slot, assignment)
    parents = assignment.get("parent_flowers", [])
    shared_parent_cells = {
        (int(row), int(col))
        for row, col in (assignment.get("layout") or {}).get(
            "shared_parent_a_cells", []
        )
    }
    cells: list[dict] = []
    for row, values in enumerate(grid):
        for col, marker in enumerate(values):
            if (row, col) in shared_parent_cells:
                # The donor is one physical plant already recorded by the
                # primary job. Do not count it a second time for inventory.
                continue
            index = 0 if marker == "A" else 1 if marker == "B" else None
            if index is None or index >= len(parents):
                continue
            parent = parents[index]
            cells.append({
                "row": row,
                "col": col,
                "parent_role": marker,
                "flower_type": parent["flower_type"],
                "color": parent["color"],
                "pattern": parent["pattern"],
                "secondary_color": parent.get("secondary_color"),
                **({"job_id": assignment["job_id"]} if assignment.get("job_id") else {}),
            })
    return cells


def assignments_matrix(slot: PlotSlot, assignments: list[dict]) -> list[list[str]]:
    """Overlay isolated jobs belonging to one physical plot."""
    if not assignments:
        return assignment_matrix(slot, None)
    base = assignment_matrix(slot, None)
    for assignment in assignments:
        job_grid = assignment_matrix(slot, assignment)
        for row, values in enumerate(job_grid):
            for col, marker in enumerate(values):
                if marker in {"A", "B", "·"} and base[row][col] in {"x", "--"}:
                    base[row][col] = marker
    return base


def assignments_cell_records(slot: PlotSlot, assignments: list[dict]) -> list[dict]:
    cells: list[dict] = []
    occupied: set[tuple[int, int]] = set()
    for assignment in assignments:
        for cell in assignment_cell_records(slot, assignment):
            coordinate = (int(cell["row"]), int(cell["col"]))
            if coordinate in occupied:
                raise ValueError(
                    f"Overlapping multi-target parent cell in {slot.slot}: "
                    f"R{coordinate[0] + 1} C{coordinate[1] + 1}"
                )
            occupied.add(coordinate)
            cells.append(cell)
    return sorted(cells, key=lambda cell: (cell["row"], cell["col"]))


