from __future__ import annotations

from .models import FlowerType


COLORS = (
    "Black", "Gray", "White", "Red", "Warm Pink", "Coral", "Blush",
    "Orange", "Peach", "Yellow", "Cream", "Lime", "Pistachio", "Green",
    "Mint", "Teal", "Seafoam", "Sky", "Cloud", "Blue", "Ice", "Indigo",
    "Periwinkle", "Violet", "Lilac", "Magenta", "Cool Pink", "Hot Pink",
    "Pink", "Brown",
)

# User-facing inventory order from the in-game color picker. Keep this separate
# from COLORS because COLORS also controls stable planner target iteration.
GAME_COLOR_ORDER = (
    "White", "Black", "Gray", "Red", "Warm Pink", "Coral", "Blush",
    "Brown", "Orange", "Peach", "Yellow", "Cream", "Lime", "Pistachio", "Green",
    "Mint", "Teal", "Seafoam", "Sky", "Cloud", "Blue", "Ice", "Indigo",
    "Periwinkle", "Violet", "Lilac", "Magenta", "Cool Pink", "Hot Pink", "Pink",
)


def _pair(a: str, b: str) -> frozenset[str]:
    return frozenset((a, b))


COLOR_MIXES = {
    _pair("Red", "Orange"): "Coral",
    _pair("Red", "Yellow"): "Orange",
    _pair("Yellow", "Green"): "Lime",
    _pair("Blue", "Yellow"): "Green",
    _pair("Green", "Sky"): "Teal",
    _pair("Violet", "Blue"): "Indigo",
    _pair("Red", "Blue"): "Violet",
    _pair("Violet", "Hot Pink"): "Magenta",
    _pair("White", "Red"): "Warm Pink",
    _pair("White", "Coral"): "Blush",
    _pair("White", "Orange"): "Peach",
    _pair("White", "Yellow"): "Cream",
    _pair("White", "Lime"): "Pistachio",
    _pair("White", "Green"): "Mint",
    _pair("White", "Teal"): "Seafoam",
    _pair("White", "Sky"): "Cloud",
    _pair("White", "Blue"): "Ice",
    _pair("White", "Indigo"): "Periwinkle",
    _pair("White", "Violet"): "Lilac",
    _pair("White", "Magenta"): "Cool Pink",
    _pair("White", "Hot Pink"): "Pink",
    _pair("White", "Black"): "Gray",
    _pair("Orange", "Black"): "Brown",
}


BREED_PROBABILITY = {
    "color_mix": 0.30,
    "color_transfer": 0.10,
    "pattern_transfer": 0.01,
    "fertilize_ombre": 0.01,
    "fertilize_pattern": 0.01,
}


FLOWER_TYPES = {
    "Anemone": FlowerType("Anemone", ("Lime", "Magenta"), "Ombre", "Rainbow Reef"),
    "Bellbutton": FlowerType("Bellbutton", ("Yellow", "Blue", "White"), "Ombre", "Merry Meadow"),
    "Bowblossom": FlowerType("Bowblossom", ("Warm Pink", "Seafoam", "Lilac"), "Iridescent", "Seaside Resort", "Hello Kitty's Birthday"),
    "Dandelily": FlowerType("Dandelily", ("Red", "Yellow", "White"), "Ombre", "Merry Meadow"),
    "Dreampuff": FlowerType("Dreampuff", ("Mint", "Cloud", "Periwinkle", "Cool Pink"), "Ombre", "Cloud Island"),
    "Eggwort": FlowerType("Eggwort", ("Sky", "White"), "Speckled", "Seaside Resort", "Month of Meh"),
    "Ghostgleam": FlowerType("Ghostgleam", ("White",), "Ombre", "Spooky Swamp"),
    "Glowbal": FlowerType("Glowbal", ("Yellow", "Sky", "Hot Pink"), "Glow", "Seaside Resort", "Lighttime Jubilee"),
    "Happadil": FlowerType("Happadil", ("Yellow", "Hot Pink"), "Confetti", "Seaside Resort", "Happy Haven"),
    "Heavy Nettle": FlowerType("Heavy Nettle", ("Orange",), "Ombre", "Mount Hothead"),
    "Hibiscus": FlowerType("Hibiscus", ("Hot Pink",), "Ombre", "Seaside Resort"),
    "Marigold": FlowerType("Marigold", ("Orange",), "Trim", "Seaside Resort", "Colorblaze Carnival"),
    "Penstemum": FlowerType("Penstemum", ("Green", "Sky", "White"), "Ombre", "Merry Meadow"),
    "Petunia": FlowerType("Petunia", ("Magenta",), "Striped", "Merry Meadow", "Jam Jamboree"),
    "Pinwheel": FlowerType("Pinwheel", ("Coral", "Lime", "Indigo"), "Alternate", "Merry Meadow", "Paper Parade"),
    "Poinsettia": FlowerType("Poinsettia", ("Red", "White"), "Patch", "Merry Meadow", "Give and Gather"),
    "Rose": FlowerType("Rose", ("Red", "Yellow", "White", "Pink"), "Ring", "Merry Meadow", "Hugs and Hearts"),
    "Sunburst": FlowerType("Sunburst", ("Orange",), "Sunbeam", "City Town"),
    "Thistle": FlowerType("Thistle", ("Violet",), "Ombre", "Gemstone Mountain"),
    "Tulia": FlowerType("Tulia", ("Red", "Yellow", "Violet"), "Ombre", "Merry Meadow"),
    "Wheatflower": FlowerType("Wheatflower", ("Cream",), "Glitter", "Wheatflour Wonderland"),
    "Blazebulb": FlowerType("Blazebulb", ("Coral", "Blush", "Peach", "Cream"), "Molten", "Caldera", extreme=True),
    "Bubbaluna": FlowerType("Bubbaluna", ("Indigo", "Pink"), "Cosmic", "The Moon", extreme=True),
    "Crystalia": FlowerType("Crystalia", ("Teal", "Pistachio", "Pink"), "Crystal", "Crystal Caves", extreme=True),
    "Frostfeather": FlowerType("Frostfeather", ("Ice",), "Frost", "Icy Peak", extreme=True),
}


PLOT_NAMES = {
    "mm1": "Meadow Fields Mini",
    "mm2": "Meadow Fields West",
    "mm3": "Meadow Fields East",
    "mm4": "Meadow Overlook Greenhouse Front",
    "mm5": "Meadow Overlook Puzzle Front",
    "mm6": "Meadow Plaza Garden",
    "mm7": "Meadow Temple Corner",
    "mm8": "Meadow Gazebo North",
    "mm9": "Meadow Gazebo Path West",
    "mm10": "Meadow Gazebo Path East",
    "mm11": "Meadow Corral",
    "rr1": "Reef Club South",
    "rr2": "Reef Club East",
    "ss1": "Swamp Ghost Ride",
    "ss2": "Swamp Nature Reserve",
    "ci1": "Cloud Outer Cabin",
    "ct1": "City West Park",
    "ww1": "Wheatflour Upper Left",
    "ww2": "Wheatflour Upper Right",
    "ww3": "Wheatflour Lower Left",
    "ww4": "Wheatflour Lower Right",
}


def mix_result(color_a: str, color_b: str) -> str | None:
    return COLOR_MIXES.get(_pair(color_a, color_b))


def parents_for_mix(result: str) -> list[tuple[str, str]]:
    return [tuple(sorted(pair)) for pair, output in COLOR_MIXES.items() if output == result]


def daily_probability(per_cell: float, eligible_cells: int) -> float:
    return 1.0 - (1.0 - per_cell) ** eligible_cells


def expected_days(per_cell: float, eligible_cells: int) -> float:
    return 1.0 / daily_probability(per_cell, eligible_cells)
