from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
from collections import Counter
from datetime import date, datetime, timezone
from pathlib import Path

from .history import (
    append_history_event,
    backup_before_mutation,
    daily_history,
    load_daily_history_events,
    load_metric_anchors,
    load_history_events,
)
from .inventory_updates import (
    COLORED_PATTERNS,
    EFFECT_PATTERNS,
    VALID_PATTERNS,
    apply_updates,
    increment_update,
    load_inventory_data,
    mark_uncollected,
    normalize_update,
    recorded_count,
    save_inventory_atomic,
)
from .collection_status import AvailabilityCache, CollectionAvailability
from .flow.integrate import cogimyun_setting
from .flow.scheduler import events_on, game_today, spawn_events
from .models import Flower
from .paths import PROGRAM_ROOT, farm_data_path, tool_data_path
from .map_layout import (
    load_map_layout,
    plot_display_name,
    plot_location,
    plot_position,
    region_sort_key,
)
from .planner import CollectionPlanner
from .optimizer import Route
from .fillers import farm_fillers
from .planting import (
    assignment_cell_records,
    assignment_matrix,
    assignments_cell_records,
    assignments_matrix,
)
from .copies import owned_counts, planted_by_plot, planted_counts, recording_shortfalls
from .plot_status import (
    actual_assignments,
    actual_jobs_by_slot,
    assignment_from_record,
    assignment_parent_counts,
    assignment_snapshot,
    effective_stock_goal,
    propagation_goal,
    clear_status,
    first_wave_by_slot,
    first_wave_jobs_by_slot,
    load_plot_status,
    mark_goal_reached,
    record_planted,
    record_parent_counts,
    save_plot_status,
)
from .plot_checks import set_plots_checked
from .plots import (AREA_ORDER, FULL_GREENHOUSE_LEVEL, GREENHOUSE_SIZES, PREFIX_REGIONS, all_slots, configure_farm_plots,
                    every_outdoor_slot, extreme_gardening_mode,
                    isolated_pair_zones, usable_cells)
from .greenhouse_layout_optimizer import single_job_layout
from .rules import BREED_PROBABILITY, FLOWER_TYPES
from .targeting import (
    TARGET_CATEGORY_LABELS,
    TARGET_CATEGORY_ORDER,
    normalized_target_categories,
)
from .rules import mix_result
from .zones import flower_type_allowed, flower_zones, route_allowed

# First-time setup steps (web/onboarding.js), recorded in settings["onboarding"];
# "guide" ("hidden") and "backup" (date of the last backup) belong to the guide after it.
SETUP_STEPS = ("island", "collection", "planted", "guide", "backup")
# Getting-started checklist items done by a farm action, as the history records it.
GUIDE_EVENTS = {
    "recorded": ("plot_status", "edit_plot_cells"),       # recorded what's planted (the "keep" choice)
    "applied": ("plot_status", "apply_recommendations"),
    "spawns": ("inventory", "record_spawns"),
    "found": ("inventory", "found_target"),
}


def _plot_utilization(slot, jobs: list[dict], grid: list[list[str]] | None) -> dict | None:
    if not grid or not jobs:
        return None
    active_cells = sum(
        1 for row in grid for marker in row if marker in {"A", "B", "·"}
    )
    parent_cells = sum(
        1 for row in grid for marker in row if marker in {"A", "B"}
    )
    target_cells = sum(1 for row in grid for marker in row if marker == "·")
    result = {
        "active_cells": active_cells,
        "parent_cells": parent_cells,
        "target_cells": target_cells,
        "plantable_cells": int(slot.spots),
        "empty_cells": max(0, int(slot.spots) - active_cells),
        "cell_utilization": (active_cells / slot.spots) if slot.spots else 0.0,
    }
    total_zones = len(isolated_pair_zones(slot, 999))
    used_zones = 0
    for job in jobs:
        layout = job.get("layout") if isinstance(job, dict) else None
        if isinstance(layout, dict):
            a_count = len(layout.get("parent_a_cells", []))
            b_count = len(layout.get("parent_b_cells", []))
            used_zones += a_count if job.get("method") == "propagate_solid" else min(a_count, b_count)
        elif job.get("method") == "propagate_solid":
            used_zones += int(job.get("propagation_zone_count", job.get("parent_copies", [0])[0]))
        else:
            copies = [int(value) for value in job.get("parent_copies", [])]
            used_zones += min(copies) if copies else 0
    result.update({
        "safe_zones_used": used_zones,
        "safe_zones_total": total_zones,
        "safe_zone_utilization": (used_zones / total_zones) if total_zones else 0.0,
    })
    return result

def _canonical_cells(cells: list[dict]) -> tuple[tuple, ...]:
    return tuple(sorted(
        (
            int(cell["row"]),
            int(cell["col"]),
            cell["flower_type"],
            cell["color"],
            cell["pattern"],
            cell.get("secondary_color"),
        )
        for cell in cells if not cell.get("filler")
    ))


def _cell_grid(slot, cells: list[dict]) -> list[list[dict | None]]:
    grid: list[list[dict | None]] = [[None for _ in range(slot.cols)] for _ in range(slot.rows)]
    for cell in cells:
        flower = Flower(
            cell["flower_type"], cell["color"], cell["pattern"], cell.get("secondary_color")
        )
        grid[int(cell["row"])][int(cell["col"])] = {
            **cell,
            "label": flower.label(),
        }
    return grid


def _remove_cells_outside_plot(status_data: dict) -> bool:
    """Discard saved plants in coordinates that are not real cells on that plot."""
    slots = {slot.slot: slot for slot in all_slots()}
    changed = False
    for slot_id, record in status_data.get("plots", {}).items():
        slot = slots.get(slot_id.upper())
        cells = record.get("cells")
        if slot is None or not isinstance(cells, list):
            continue
        available = usable_cells(slot)
        valid_cells = [
            cell for cell in cells
            if (int(cell["row"]), int(cell["col"])) in available
        ]
        if len(valid_cells) != len(cells):
            record["cells"] = valid_cells
            changed = True
    return changed


def _actual_base_grid(slot, assignment: dict | None) -> list[list[str]]:
    if not slot.greenhouse:
        return assignment_matrix(slot, None)
    grid = [["--" for _ in range(slot.cols)] for _ in range(slot.rows)]
    for row, col in slot.parent_cells:
        grid[row][col] = "x"
    if assignment:
        for row, col in slot.target_cells:
            grid[row][col] = "·"
    return grid


class _PlotRowContext:
    """Inputs shared by every plot row that FarmUIService.state() builds."""

    def __init__(
        self, planner, plan, status_data, map_layout,
        actual, actual_job_groups, recommended, recommended_job_groups,
        actual_work_states, recommended_work_states,
    ):
        self.planner = planner
        self.plan = plan
        self.status_data = status_data
        self.map_layout = map_layout
        self.actual = actual
        self.actual_job_groups = actual_job_groups
        self.recommended = recommended
        self.recommended_job_groups = recommended_job_groups
        self.actual_work_states = actual_work_states
        self.recommended_work_states = recommended_work_states
        self.fillers: dict[str, list[dict]] = {}    # slot -> filler cells for its Recommendation
        self.copy_moves: list[dict] = []            # a batch's plants taken from another plot (copies.py)
        self.copy_shortages: dict[str, Counter] = {}   # slot -> copies its Recommendation lacks


def _flower_row(flower: Flower) -> dict:
    return {"flower_type": flower.flower_type, "color": flower.color, "pattern": flower.pattern,
            "secondary_color": flower.secondary_color, "label": flower.label()}


def _move_row(move: dict, other_slot: str) -> dict:
    return {**_flower_row(move["flower"]), "slot": other_slot, "count": move["count"]}


def _shortfall_message(short: dict[Flower, tuple[int, int]], status_data: dict, recording: list[str]) -> str:
    """Why a recording is refused: which flowers, and which other plots still hold them."""
    by_plot = planted_by_plot(status_data)
    lines, first = [], []
    for flower, (needed, owned) in sorted(short.items(), key=lambda item: item[0].label()):
        holders = sorted(slot for slot, counts in by_plot.items() if counts[flower] and slot not in recording)
        where = f" ({', '.join(f'{by_plot[s][flower]} in {s}' for s in holders)})" if holders else ""
        lines.append(f"{flower.label()}: this would have {needed} in the ground, but you have {owned}{where}.")
        first += [s for s in holders if s not in first]
    hint = (f"Record {', '.join(first)} first: the plants this takes are still there." if first
            else "Update your inventory count, or generate a new plan.")
    return "Not enough copies to record this. " + " ".join(lines) + " " + hint


def _manual_layout_actual_assignment(
    record: dict, actual_assignment: dict | None,
    recommended_assignment: dict | None, recommended_jobs: list[dict],
) -> dict | None:
    """The assignment a manually edited plot's Actual view describes."""
    if record.get("target_management_locked"):
        # The target manager explicitly pins the Actual goal list
        # to this physical planting, independently of today's plan.
        return actual_assignment
    if actual_assignment and actual_assignment.get("manual_target"):
        # v28: keep the target attached to the physical manual layout even
        # when the optimizer recommends different parents or a different plot.
        return actual_assignment
    recommended_parent_counts: Counter[Flower] = Counter()
    for job in recommended_jobs:
        recommended_parent_counts.update(assignment_parent_counts(job))
    if recommended_assignment and record_parent_counts(record) == recommended_parent_counts:
        return recommended_assignment
    return None


def _annotate_actual_jobs(
    slot_id: str, jobs: list[dict], work_states: dict,
) -> tuple[list[dict], list[dict]]:
    """Copies of the Actual jobs with their work state, plus the work states."""
    shown_jobs, semantic = [], []
    for index, job in enumerate(jobs):
        shown = dict(job)
        shown["stock_goal"] = effective_stock_goal(job)
        shown["propagation_goal"] = propagation_goal(job)
        work = work_states.get((slot_id, index), {
            "state": "keep",
            "label": "Keep",
            "reason": "This unfinished goal is still active.",
            "planned_recommendation_slots": [],
            "matched_recommendation_slots": [],
        })
        shown.update({
            "work_state": work["state"],
            "work_label": work["label"],
            "work_reason": work["reason"],
            "planned_recommendation_slots": work.get(
                "planned_recommendation_slots",
                work.get("matched_recommendation_slots", []),
            ),
            "matched_recommendation_slots": work.get("matched_recommendation_slots", []),
            "semantic_required_goal": work.get("required_goal", effective_stock_goal(job)),
        })
        shown_jobs.append(shown)
        semantic.append(work)
    return shown_jobs, semantic


def _annotate_recommended_jobs(
    slot_id: str, jobs: list[dict], work_states: dict,
) -> tuple[list[dict], list[dict]]:
    """Copies of the recommended jobs with their work state, plus the work states."""
    shown_jobs, semantic = [], []
    for index, job in enumerate(jobs):
        shown = dict(job)
        work = work_states.get((slot_id, index), {
            "state": "new_work",
            "label": "New work",
            "reason": "The plan works on this goal here.",
        })
        shown.update({
            "work_state": work["state"],
            "work_label": work["label"],
            "work_reason": work["reason"],
        })
        shown_jobs.append(shown)
        semantic.append(work)
    return shown_jobs, semantic


def _plot_action(
    has_actual: bool, actual_jobs: list[dict], actual_states: list[str],
    recommended_states: list[str],
) -> tuple[str, str, str]:
    """A plot's (action_state, label, note), before any partial-update layout."""
    new_recommendations = sum(state == "new_work" for state in recommended_states)
    if has_actual and not actual_jobs:
        return "manual", "Manual", (
            "This plot has a manually recorded layout without a tracked breeding goal. "
            "The planner cannot safely decide whether it should be replaced."
        )
    if actual_states:
        if "review" in actual_states:
            note = (
                "At least one unfinished Actual goal is no longer part of the active plan. "
                "Review it before clearing or replacing this plot."
            )
            if new_recommendations:
                note += (
                    " Any new work for this plot is deferred while the recorded Actual plants "
                    "remain; the Recommendation view is not safe to plant over them."
                )
            elif recommended_states and all(
                state == "already_complete" for state in recommended_states
            ):
                note += " Inventory already satisfies every listed recommendation goal."
            return "review", "Review", note
        if "keep" in actual_states and "goal_reached" in actual_states:
            return "partial_update", "Partial update", (
                "Some goals here are complete, but other goals are still in progress. "
                "Keep the unfinished work; only the completed zones need replacement."
            )
        if "keep" in actual_states:
            note = (
                "Keep the current planting. Its unfinished goal(s) are still needed. "
                "Recommendation rows are proposed placements, not records of what is currently "
                "planted. Changing route, parent count, layout, or plot does not require "
                "replanting."
            )
            if new_recommendations:
                note += (
                    " New work suggested for this plot is deferred until the current goal "
                    "finishes. Recommendation is hidden while every Actual target is Keep; "
                    "use Replant plot to inspect it."
                )
            return "keep", "Keep", note
        return "goal_reached", "Goal reached", (
            "All tracked Actual goals on this plot are complete. "
            "This space is ready to clear or reuse."
        )
    if recommended_states:
        if new_recommendations:
            return "new_work", "Plant", "Plant this plot's recommended layout."
        return "already_complete", "Already complete", (
            "This saved recommendation is already satisfied by inventory. "
            "Replant this plot or regenerate the plan before planting it."
        )
    return "no_work", "No work", "No Actual planting or current recommendation is attached to this plot."


def _with_job_tags(cells: list[dict], jobs: list[dict], record: dict | None = None,
                   slot_id: str | None = None) -> list[dict]:
    """Copies of ``cells`` with each cell's job tag (1A / 1B / 2F / 3P).

    Jobs recorded without cell positions (a layout edited by hand before
    tags existed) get their positions inferred from the planted flowers.
    """
    from .job_tags import cell_tags

    if record is not None and slot_id and any(
            not ((job.get("layout") or {}).get("parent_a_cells")
                 or (job.get("layout") or {}).get("shared_parent_a_cells")) for job in jobs):
        from .flow.plan_today import _infer_layouts

        inferred = _infer_layouts({"plots": {slot_id: record}})["plots"][slot_id]
        jobs = [inferred.get("assignment") or {}] + list(inferred.get("jobs") or [])
    tags = cell_tags([job for job in jobs if job])
    return [{**cell, "tag": tags.get((int(cell["row"]), int(cell["col"])))} for cell in cells]


def _physical_cells(cells: list[dict]) -> set[tuple]:
    """What is physically planted, ignoring job IDs and parent roles."""
    return {
        (int(cell["row"]), int(cell["col"]),
         cell.get("flower_type"), cell.get("color"),
         cell.get("pattern"), cell.get("secondary_color"))
        for cell in cells
    }


def _planted_locations(plot_rows: list[dict]) -> dict[Flower, list[dict]]:
    """Where each flower is physically planted, from the recorded Actual cells.

    Inventory reservations answer how many copies are planted; this index
    answers the separate question of *where* those copies physically are.
    """
    locations: dict[Flower, list[dict]] = {}
    for plot in plot_rows:
        counts: Counter[Flower] = Counter()
        for cell in plot["actual_cells"]:
            counts[Flower(
                cell["flower_type"],
                cell["color"],
                cell["pattern"],
                cell.get("secondary_color"),
            )] += 1
        for flower, count in counts.items():
            locations.setdefault(flower, []).append({
                "slot": plot["slot"],
                "name": plot["name"],
                "location": plot["location"],
                "region": plot["region"],
                "count": count,
            })
    return locations


def _current_targets(plot_rows: list[dict]) -> list[dict]:
    """Targets being worked on now (planted, or new first-wave work)."""
    current_targets = []
    for row in plot_rows:
        source = "planted" if row["actual_jobs"] else "recommended"
        jobs = row["actual_jobs"] if row["actual_jobs"] else [
            job for job in row["recommended_jobs"]
            if job.get("work_state") == "new_work"
        ]
        for assignment in jobs:
            current_targets.append({
                "target": assignment["target"],
                "target_type": assignment["target_type"],
                "target_color": assignment["target_color"],
                "target_pattern": assignment["target_pattern"],
                "target_secondary_color": assignment.get("target_secondary_color"),
                "slot": row["slot"],
                "job_id": assignment.get("job_id"),
                "plot": row["name"],
                "region": row["region"],
                "method": assignment["method"],
                "parents": assignment["parents"],
                "daily_probability": assignment["daily_probability"],
                "manual_target": bool(assignment.get("manual_target")),
                "manual_target_source": assignment.get("manual_target_source"),
                "stock_goal": assignment.get("semantic_required_goal", assignment.get("stock_goal", 1)),
                "status": assignment.get("work_state", row["action_state"]),
                "source": source,
            })
    return current_targets


def _solver_env() -> dict:
    """Environment for planner subprocesses: a fixed hash seed.

    The planner breaks ties between equally good options in set order, which
    follows Python's per-process hash seed. Fixing it makes every Generate
    plan choose the same way, so regenerating with no news changes nothing.
    """
    return {**os.environ, "PYTHONHASHSEED": "0"}


class FarmUIService:
    def __init__(self, root: Path):
        self.root = root
        self.inventory_path = farm_data_path(root, "inventory.json")
        self.status_path = farm_data_path(root, "plot_status.json")
        self.settings_path = farm_data_path(root, "settings.json")
        self.plan_path = root / "output" / "latest_plan.json"
        # The plan generator lives with the program, not in the data folder.
        self.solver_script = PROGRAM_ROOT / "run_solver.py"
        self.colors_path = tool_data_path("flower_colors.json")
        self._plan_process: subprocess.Popen[str] | None = None
        self._plan_process_lock = threading.Lock()
        self._plan_cancel_requested = False
        self._generation_lock = threading.Lock()
        self._generation_status = {"state": "idle", "message": "No generation running."}
        self._availability_cache_lock = threading.Lock()
        self._availability_cache = AvailabilityCache()
        self._availability_results = None
        self._optimizer_cache = (None, None)

    def _optimizer_inputs_key(self) -> tuple:
        key = []
        for name in ("settings.json", "inventory.json", "other_patterned_donors.json"):
            try:
                stat = farm_data_path(self.root, name).stat()
                key.append((name, stat.st_mtime_ns, stat.st_size))
            except OSError:
                key.append((name, None, None))
        key.append(spawn_events(game_today()))  # season changes with the date
        return tuple(key)

    def _state_optimizer(self, planner, key: tuple):
        """planner.immediate_optimizer(), reused while its inputs are unchanged.

        It takes ~0.3 s to build and depends only on settings and inventory,
        so plot edits, checks and history writes can skip rebuilding it.
        ``key`` must be read before ``planner`` loaded those files, so a write
        in between leaves a stale key that the next load rebuilds.
        """
        cached_key, optimizer = self._optimizer_cache
        if cached_key != key or optimizer is None:
            optimizer = planner.immediate_optimizer()
            self._optimizer_cache = (key, optimizer)
        return optimizer

    def _history_metrics(self, status_data: dict | None = None, planner=None) -> dict:
        planner = planner or CollectionPlanner(self.root)
        status = status_data if status_data is not None else planner.plot_status
        breeding_jobs = 0
        breeding_flowers = set()
        for record in status.get("plots", {}).values():
            record_state = record.get("state", record.get("status", "planted"))
            if record_state not in {"planted", "goal_reached"}:
                continue
            if record_state == "goal_reached":
                continue
            primary = assignment_from_record(record)
            jobs = ([primary] if primary else []) + [
                job for job in record.get("jobs", []) if isinstance(job, dict)
            ]
            job_states = record.get("job_states", {})
            for index, job in enumerate(jobs):
                key = self._job_record_key(job, index)
                if job_states.get(key, {}).get("state") == "goal_reached":
                    continue
                target = self._target(job)
                if planner.inventory.physical_count(target) >= effective_stock_goal(job):
                    continue
                breeding_jobs += 1
                breeding_flowers.add(target)
        # "breeding" counts jobs (a flower worked on in several plots counts
        # once per plot); "breeding_flowers" counts the distinct targets.
        return {
            "acquired": len(planner.owned_targets),
            "breeding": breeding_jobs,
            "breeding_flowers": len(breeding_flowers),
            "blocked": len(planner.missing_targets - planner.reachable_missing),
        }

    def _record_history(
        self,
        category: str,
        action: str,
        details: dict,
        backups: list[str | None],
        status_data: dict | None = None,
    ) -> None:
        append_history_event(
            self.root,
            category,
            action,
            details,
            self._history_metrics(status_data),
            [path for path in backups if path],
        )

    def load_plan(self) -> dict:
        if not self.plan_path.exists():
            raise ValueError("No generated plan found. Generate a plan first.")
        return json.loads(self.plan_path.read_text(encoding="utf-8"))

    @staticmethod
    def _target(assignment: dict) -> Flower:
        return Flower(
            assignment["target_type"],
            assignment["target_color"],
            assignment["target_pattern"],
            assignment.get("target_secondary_color"),
        )

    @staticmethod
    def _goal_kind(assignment: dict) -> str:
        """Return the semantic goal class for an assignment.

        Physical route details are intentionally excluded. A color mix and a
        color transfer that both produce the first copy of the same variant are
        the same farm goal. Propagation is kept separate because it is a stock
        goal rather than a collection-acquisition goal.
        """
        if assignment.get("method") == "propagate_solid" or assignment.get("propagation"):
            return "propagation"
        return "acquire"

    @classmethod
    def _goal_key(cls, assignment: dict) -> tuple[str, str, str, str | None, str]:
        return (
            assignment["target_type"],
            assignment["target_color"],
            assignment["target_pattern"],
            assignment.get("target_secondary_color"),
            cls._goal_kind(assignment),
        )

    @staticmethod
    def _assignment_currently_valid(
        planner: CollectionPlanner,
        slot_id: str,
        assignment: dict,
    ) -> tuple[bool, str | None]:
        """Check the hard physical/event rules for recorded Actual work.

        Semantic goal reconciliation intentionally ignores donor choice, parent
        counts, and location *when the existing setup is still valid*. v29 adds
        the important seasonal exception: an inactive event species cannot be
        the new spawn outdoors, even if its plants can physically grow there.
        """
        slot = {item.slot: item for item in all_slots()}.get(slot_id.upper())
        if slot is None:
            return False, "This recorded plot no longer maps to a known farm slot."
        target_type = assignment.get("target_type")
        flower_type = planner.active_types.get(target_type)
        if flower_type is None:
            return False, "This target flower type is outside the current planner scope."
        method = str(assignment.get("method") or "")
        if (
            flower_type.event
            and not planner.event_active(flower_type.event)
            and not slot.greenhouse
            and not method.startswith("fertilize_")
        ):
            return (
                False,
                f"{target_type} is out of season, so a new {target_type} can only "
                "spawn in the Greenhouse. Keep outdoor plants only as donors or "
                "for default-pattern fertilization.",
            )
        return True, None

    @staticmethod
    def _job_record_key(job: dict, index: int) -> str:
        return str(job.get("job_id") or ("primary" if index == 0 else f"job-{index + 1}"))

    def _semantic_work_state(
        self,
        planner: CollectionPlanner,
        plan: dict,
        status_data: dict,
        actual_job_groups: dict[str, list[dict]],
        recommended_job_groups: dict[str, list[dict]],
    ) -> tuple[dict[tuple[str, int], dict], dict[tuple[str, int], dict]]:
        """Compare Actual and Recommendation by goal across the whole farm.

        v27 deliberately ignores plot, route, donor choice, parent count, and
        cell layout when deciding whether in-progress work should be kept. The
        question is whether the physical farm is already working toward the
        same unfinished target. This prevents optimizer reshuffles from turning
        into unnecessary replanting instructions.
        """
        planned_goal_rows: dict[tuple, list[tuple[str, int]]] = {}
        recommended_goal_values: dict[tuple, int] = {}
        for slot, jobs in recommended_job_groups.items():
            for index, job in enumerate(jobs):
                key = self._goal_key(job)
                planned_goal_rows.setdefault(key, []).append((slot, index))
                recommended_goal_values[key] = max(
                    recommended_goal_values.get(key, 1), effective_stock_goal(job)
                )

        # Propagation is an optimization goal rather than a collection target.
        # Keep an existing propagation setup only when the current generated plan
        # still asks for that stock somewhere in its simulated schedule.
        planned_propagation_keys: set[tuple] = set()
        for job in plan.get("first_wave", []):
            if self._goal_kind(job) == "propagation":
                planned_propagation_keys.add(self._goal_key(job))
        for jobs in plan.get("plot_jobs", {}).values():
            for job in jobs:
                if self._goal_kind(job) == "propagation":
                    planned_propagation_keys.add(self._goal_key(job))
        for job in plan.get("completion_schedule", []):
            if self._goal_kind(job) == "propagation":
                planned_propagation_keys.add(self._goal_key(job))
                key = self._goal_key(job)
                recommended_goal_values[key] = max(
                    recommended_goal_values.get(key, 1), effective_stock_goal(job)
                )

        actual_states: dict[tuple[str, int], dict] = {}
        active_actual_by_goal: dict[tuple, list[str]] = {}
        for slot, jobs in actual_job_groups.items():
            record = status_data.get("plots", {}).get(slot, {})
            job_states = record.get("job_states", {})
            for index, job in enumerate(jobs):
                key = self._goal_key(job)
                target = self._target(job)
                job_key = self._job_record_key(job, index)
                required_goal = effective_stock_goal(job)
                if self._goal_kind(job) == "propagation":
                    required_goal = max(
                        required_goal, recommended_goal_values.get(key, required_goal)
                    )
                current_total = planner.inventory.physical_count(target)
                reached = current_total >= required_goal
                if not reached and job_states.get(job_key, {}).get("state") == "goal_reached":
                    # The persisted flag can lag behind a higher v27 semantic
                    # propagation goal. Current inventory remains authoritative.
                    reached = current_total >= required_goal

                planned_recommendation_slots = sorted({
                    planned_slot
                    for planned_slot, _planned_index in planned_goal_rows.get(key, [])
                })
                valid, invalid_reason = self._assignment_currently_valid(
                    planner, slot, job
                )
                if reached:
                    state = "goal_reached"
                    label = "Goal reached"
                    reason = "This target has reached its current goal and its space can be reused."
                elif not valid:
                    state = "review"
                    label = "Review"
                    reason = invalid_reason or "This recorded setup is no longer a valid route."
                elif self._goal_kind(job) == "acquire" and target in planner.targets:
                    state = "keep"
                    label = "Keep"
                    reason = "This unfinished collection goal is still in scope."
                    active_actual_by_goal.setdefault(key, []).append(slot)
                elif self._goal_kind(job) == "propagation" and key in planned_propagation_keys:
                    state = "keep"
                    label = "Keep"
                    reason = (
                        "The current plan still needs additional stock of this variant. "
                        "Keep the existing propagation setup even if the planner placed it elsewhere."
                    )
                    active_actual_by_goal.setdefault(key, []).append(slot)
                else:
                    state = "review"
                    label = "Review"
                    reason = (
                        "This unfinished goal is no longer part of the active collection/stock plan. "
                        "It can be cleared or replaced when convenient."
                    )

                actual_states[(slot, index)] = {
                    "state": state,
                    "label": label,
                    "reason": reason,
                    "goal_kind": self._goal_kind(job),
                    "current_total": current_total,
                    "required_goal": required_goal,
                    # These are generated-plan destinations, not claims about
                    # what those plots currently record as Actual.
                    "planned_recommendation_slots": planned_recommendation_slots,
                    "matched_recommendation_slots": planned_recommendation_slots,
                }

        recommended_states: dict[tuple[str, int], dict] = {}
        for slot, jobs in recommended_job_groups.items():
            for index, job in enumerate(jobs):
                key = self._goal_key(job)
                target = self._target(job)
                required_goal = effective_stock_goal(job)
                current_total = planner.inventory.physical_count(target)
                # FLOW plans the whole farm, so a goal that is also worked on
                # elsewhere is deliberate parallel work, not a duplicate.
                if current_total >= required_goal:
                    state = "already_complete"
                    label = "Already complete"
                    reason = "Inventory already satisfies this recommendation; do not replant it."
                else:
                    state = "new_work"
                    label = "New work"
                    reason = "The plan works on this goal here."
                recommended_states[(slot, index)] = {
                    "state": state,
                    "label": label,
                    "reason": reason,
                    "goal_kind": self._goal_kind(job),
                    "current_total": current_total,
                    "required_goal": required_goal,
                }

        # Explain Keep from the plan's destinations for the same goal. A
        # destination is not evidence of what that plot has planted.
        for (slot, index), work in actual_states.items():
            if work.get("state") != "keep" or work.get("goal_kind") != "acquire":
                continue
            job = actual_job_groups[slot][index]
            key = self._goal_key(job)
            active_elsewhere = sorted(
                set(active_actual_by_goal.get(key, [])) - {slot}
            )
            if active_elsewhere:
                work["reason"] = (
                    "The same unfinished goal is currently recorded as Actual at "
                    f"{', '.join(active_elsewhere)}. Keep this setup; route and "
                    "parent-count differences do not change the goal."
                )
                continue

            rows = planned_goal_rows.get(key, [])
            other_slots = sorted({row[0] for row in rows if row[0] != slot})
            clauses = []
            if any(row[0] == slot for row in rows):
                clauses.append(f"The plan keeps this goal at {slot}.")
            if other_slots:
                clauses.append(
                    f"The plan also works on this goal at {', '.join(other_slots)}."
                )
            if not clauses:
                clauses.append("This unfinished collection goal is still in scope.")
            work["reason"] = (
                f"This unfinished goal is active as Actual at {slot}. "
                + " ".join(clauses)
                + " Keep this setup; changing route, parent count, or plot is not required."
            )

        return actual_states, recommended_states

    def _reconcile_goal_states(self, status_data: dict, inventory_data: dict) -> bool:
        """Make planted goal state a projection of the current inventory.

        A Found action used to persist ``goal_reached`` in plot_status.json. If
        that inventory entry was later corrected downward or explicitly marked
        uncollected, the persisted flag could survive and make the planner think
        the target was still complete. Recompute every planted job from current
        counts so inventory is the source of truth in both directions.
        """
        changed = False
        now = datetime.now(timezone.utc).isoformat(timespec="seconds").replace(
            "+00:00", "Z"
        )
        for slot, jobs in actual_jobs_by_slot(status_data).items():
            record = status_data.get("plots", {}).get(slot)
            if not record or not jobs:
                continue
            had_job_states = "job_states" in record
            job_states = record.setdefault("job_states", {})
            all_reached = True
            for index, job in enumerate(jobs):
                update = normalize_update(
                    inventory_data,
                    job["target_type"],
                    job["target_color"],
                    job["target_pattern"],
                    secondary_color=job.get("target_secondary_color"),
                )[0]
                reached = recorded_count(inventory_data, update) >= effective_stock_goal(job)
                # Jobs without an id (hand-edited layouts) each need their own key;
                # sharing "primary" made a reached and an unreached job overwrite
                # each other, re-stamping goal_reached_at and rewriting
                # plot_status.json on every dashboard load.
                key = self._job_record_key(job, index)
                existing = job_states.get(key, {})
                if reached:
                    if existing.get("state") != "goal_reached":
                        job_states[key] = {
                            "state": "goal_reached",
                            "goal_reached_at": now,
                        }
                        changed = True
                else:
                    all_reached = False
                    if existing.get("state") == "goal_reached":
                        job_states.pop(key, None)
                        changed = True

            if not job_states:
                record.pop("job_states", None)
                # Only a change if the saved record had one; the setdefault
                # above adds an empty dict to every record.
                if had_job_states:
                    changed = True

            current_state = record.get("state", record.get("status", "planted"))
            if current_state in {"planted", "goal_reached"}:
                desired_state = "goal_reached" if all_reached else "planted"
                if current_state != desired_state:
                    record["state"] = desired_state
                    changed = True
                if desired_state == "goal_reached":
                    if not record.get("goal_reached_at"):
                        record["goal_reached_at"] = now
                        changed = True
                elif "goal_reached_at" in record:
                    record.pop("goal_reached_at", None)
                    changed = True
        return changed

    def _other_plot_commitments(
        self,
        plan: dict,
        status_data: dict,
        selected_slot: str,
    ) -> tuple[Counter[Flower], set[Flower]]:
        """Return authoritative parent reservations and targets outside one plot.

        A recorded farm layout is the source of truth for that physical plot.
        Recommendations reserve inventory only for plots that are not currently
        recorded as planted. This is the same model used by a one-plot refresh:
        the selected plot is released, while every other physical commitment
        remains unavailable to the new recommendation.
        """
        selected_slot = selected_slot.upper()
        busy: Counter[Flower] = Counter()
        in_progress: set[Flower] = set()
        actual_jobs = actual_jobs_by_slot(status_data)
        recorded_slots: set[str] = set()

        for other_slot, record in status_data.get("plots", {}).items():
            slot_id = other_slot.upper()
            if slot_id == selected_slot:
                continue
            state = record.get("state", record.get("status", "planted"))
            if state not in {"planted", "goal_reached"}:
                continue
            recorded_slots.add(slot_id)
            busy.update(planted_counts({"plots": {other_slot: record}}))
            for assignment in actual_jobs.get(slot_id, []):
                in_progress.add(self._target(assignment))

        for other_slot, jobs in first_wave_jobs_by_slot(plan).items():
            if other_slot == selected_slot or other_slot in recorded_slots:
                continue
            for assignment in jobs:
                busy.update(assignment_parent_counts(assignment))
                in_progress.add(self._target(assignment))

        return busy, in_progress

    def _reservation_warnings(self, status_data: dict, planner: CollectionPlanner) -> list[dict]:
        by_plot = planted_by_plot(status_data)
        reserved: Counter[Flower] = Counter()
        for plot_counts in by_plot.values():
            reserved.update(plot_counts)
        warnings = []
        abundant = planner.abundant_colors()
        for flower, count in sorted(reserved.items()):
            total = planner.inventory.capacity(flower, abundant)
            if count > total:
                sources = [
                    {"slot": slot, "count": counts[flower]}
                    for slot, counts in sorted(by_plot.items())
                    if counts[flower]
                ]
                source_text = ", ".join(
                    f"{source['slot']} ({source['count']})" for source in sources
                )
                warnings.append({
                    "flower_type": flower.flower_type,
                    "color": flower.color,
                    "pattern": flower.pattern,
                    "flower": flower.label(),
                    "planted": count,
                    "inventory": total,
                    "shortage": count - total,
                    "plots": sources,
                    "message": (
                        f"{flower.label()}: {count} planted across {source_text}, "
                        f"but inventory records {total}."
                    ),
                })
        return warnings

    @staticmethod
    def _detach_stale_assignment(record: dict) -> None:
        for key in (
            "assignment",
            "target",
            "method",
            "parents",
            "parent_copies",
            "plan_signature",
            "goal_reached_at",
            "jobs",
            "job_states",
        ):
            record.pop(key, None)

    def _manual_target_candidates(
        self, slot_id: str, record: dict, planner: CollectionPlanner
    ) -> list[dict]:
        """Infer collection targets that the recorded plants can produce.

        Manual layouts do not record A/B job boundaries, so inference is deliberately
        conservative. Two-parent breeding routes are preferred over background
        fertilization because a solid used in a color mix can also be fertilized for
        its native pattern; treating that side effect as the intended target would
        make many obvious color mixes ambiguous.
        """
        slots = {item.slot: item for item in all_slots()}
        slot = slots.get(slot_id.upper())
        if slot is None:
            return []
        counts = record_parent_counts(record)
        flowers = sorted(counts)
        solids = [flower for flower in flowers if flower.pattern == "Solid"]
        patterned = [flower for flower in flowers if flower.pattern != "Solid"]
        routes: dict[Flower, list[dict]] = {}

        def add(target: Flower, method: str, parents: tuple[Flower, ...]) -> None:
            if target not in planner.targets:
                return
            if any(counts[parent] < 1 for parent in parents):
                return
            if not route_allowed(target, parents, slot):
                return
            flower_type = planner.active_types.get(target.flower_type)
            if (
                flower_type
                and flower_type.event
                and not planner.event_active(flower_type.event)
                and not slot.greenhouse
                and not method.startswith("fertilize_")
            ):
                # The plants can still physically grow outdoors, but a new
                # out-of-season event flower cannot spawn there. Do not call an
                # impossible manual setup "auto-recognized"/verified.
                return
            route = {
                "target": target.label(),
                "target_type": target.flower_type,
                "target_color": target.color,
                "target_pattern": target.pattern,
                "target_secondary_color": target.secondary_color,
                "method": method,
                "parents": [parent.label() for parent in parents],
                "parent_flowers": [
                    {
                        "flower_type": parent.flower_type,
                        "color": parent.color,
                        "pattern": parent.pattern,
                        "secondary_color": parent.secondary_color,
                    }
                    for parent in parents
                ],
                "parent_copies": [int(counts[parent]) for parent in parents],
                "missing": target not in planner.inventory.all,
            }
            routes.setdefault(target, []).append(route)

        # Same-species solid color mixing.
        for index, first in enumerate(solids):
            for second in solids[index + 1 :]:
                if first.flower_type != second.flower_type:
                    continue
                result = mix_result(first.color, second.color)
                if result:
                    add(
                        Flower(first.flower_type, result, "Solid"),
                        "color_mix",
                        (first, second),
                    )

        # Cross-species color and pattern transfer.
        for donor in patterned:
            for recipient in solids:
                if donor.flower_type == recipient.flower_type:
                    continue
                if donor.color != recipient.color:
                    add(
                        Flower(recipient.flower_type, donor.color, "Solid"),
                        "color_transfer",
                        (donor, recipient),
                    )
                elif donor.secondary_color is None:
                    add(
                        Flower(recipient.flower_type, donor.color, donor.pattern),
                        "pattern_transfer",
                        (donor, recipient),
                    )

        # Native pattern/effect fertilization is a fallback inference only.
        for solid in solids:
            flower_type = planner.active_types.get(solid.flower_type)
            if flower_type:
                add(
                    Flower(solid.flower_type, solid.color, flower_type.default_pattern),
                    "fertilize_pattern",
                    (solid,),
                )

        method_rank = {
            "color_mix": 0,
            "color_transfer": 1,
            "pattern_transfer": 2,
            "fertilize_pattern": 3,
        }
        result = []
        for target, target_routes in routes.items():
            best = min(
                target_routes,
                key=lambda route: (
                    method_rank.get(route["method"], 99),
                    -min(route["parent_copies"] or [0]),
                    route["parents"],
                ),
            )
            result.append(best)
        return sorted(
            result,
            key=lambda route: (
                0 if route["missing"] else 1,
                method_rank.get(route["method"], 99),
                route["target"],
            ),
        )

    @staticmethod
    def _automatic_manual_candidate(candidates: list[dict]) -> dict | None:
        """Return a target only when inference is sufficiently unambiguous."""
        two_parent = [
            row for row in candidates if row["method"] != "fertilize_pattern"
        ]
        missing_two_parent = [row for row in two_parent if row.get("missing")]
        pool = missing_two_parent or two_parent
        if len(pool) == 1:
            return pool[0]
        # A lone solid could mean native-pattern fertilization, propagation, or
        # simply a reserved flower. Show that as a suggestion, but never attach
        # a background-fertilization target automatically.
        return None

    def _manual_assignment(
        self,
        slot_id: str,
        record: dict,
        target: Flower,
        candidate: dict | None,
        source: str,
    ) -> dict:
        slot = {item.slot: item for item in all_slots()}[slot_id.upper()]
        counts = record_parent_counts(record)
        if candidate:
            parent_flowers = candidate["parent_flowers"]
            parent_copies = candidate["parent_copies"]
            parents = candidate["parents"]
            method = candidate["method"]
            verified = True
        else:
            physical = sorted(counts)
            parent_flowers = [
                {
                    "flower_type": parent.flower_type,
                    "color": parent.color,
                    "pattern": parent.pattern,
                    "secondary_color": parent.secondary_color,
                }
                for parent in physical
            ]
            parent_copies = [int(counts[parent]) for parent in physical]
            parents = [parent.label() for parent in physical]
            method = "manual"
            verified = False
        return {
            "slot": slot.slot,
            "plot": slot.plot,
            "region": slot.region,
            "plot_spots": slot.spots,
            "eligible_cells": 0,
            "target": target.label(),
            "target_type": target.flower_type,
            "target_color": target.color,
            "target_pattern": target.pattern,
            "target_secondary_color": target.secondary_color,
            "method": method,
            "parents": parents,
            "parent_flowers": parent_flowers,
            "parent_patterns": [parent["pattern"] for parent in parent_flowers],
            "parent_copies": parent_copies,
            "daily_probability": 0.0,
            "expected_days": 0.0,
            "event_only": False,
            "stock_goal": 1,
            "stock_goal_reason": "manual planted target",
            "propagation_goal": 1,
            "propagation_goal_reason": "manual planted target",
            "propagation": False,
            "job_id": "manual-primary",
            "supplemental": False,
            "manual_target": True,
            "manual_target_source": source,
            "manual_target_verified": verified,
        }

    def _set_manual_target(
        self, record: dict, assignment: dict, *, inferred: bool = False
    ) -> None:
        self._detach_stale_assignment(record)
        record["assignment"] = assignment_snapshot(assignment)
        record["target"] = assignment["target"]
        record["method"] = assignment["method"]
        record["parents"] = assignment["parents"]
        record["parent_copies"] = assignment["parent_copies"]
        record["manual_layout"] = True
        record["layout_edited"] = True
        record["state"] = "planted"
        record["status"] = "planted"
        if inferred:
            record["target_inferred_at"] = datetime.now(timezone.utc).isoformat(
                timespec="seconds"
            ).replace("+00:00", "Z")
        else:
            record.pop("target_inferred_at", None)

    def _upsert_manual_target(
        self, record: dict, assignment: dict, *, inferred: bool = False
    ) -> str:
        """Add or update one goal on a manually recorded multi-job plot."""
        target = self._target(assignment)
        existing_primary = assignment_from_record(record)
        existing_jobs = list(record.get("jobs", []))
        existing = ([existing_primary] if existing_primary else []) + [
            job for job in existing_jobs if isinstance(job, dict)
        ]
        match = next((job for job in existing if self._target(job) == target), None)

        if not existing_primary or not existing_primary.get("manual_target"):
            assignment["job_id"] = "manual-primary"
            self._set_manual_target(record, assignment, inferred=inferred)
            return "attached"

        if match is not None:
            assignment["job_id"] = match.get("job_id", "manual-primary")
            if match is existing_primary:
                record["assignment"] = assignment_snapshot(assignment)
                record.update({
                    "target": assignment["target"],
                    "method": assignment["method"],
                    "parents": assignment["parents"],
                    "parent_copies": assignment["parent_copies"],
                })
            else:
                record["jobs"] = [
                    assignment_snapshot(assignment)
                    if job is match else job
                    for job in existing_jobs
                ]
            record.pop("plan_signature", None)
            record.pop("goal_reached_at", None)
            record["manual_layout"] = True
            record["layout_edited"] = True
            record["state"] = record["status"] = "planted"
            if inferred:
                record["target_inferred_at"] = datetime.now(timezone.utc).isoformat(
                    timespec="seconds"
                ).replace("+00:00", "Z")
            else:
                record.pop("target_inferred_at", None)
            return "updated"

        assignment["job_id"] = (
            f"manual-{target.flower_type}-{target.color}-{target.pattern}"
        )
        record.setdefault("jobs", []).append(assignment_snapshot(assignment))
        record["manual_layout"] = True
        record["layout_edited"] = True
        record["state"] = record["status"] = "planted"
        record.pop("plan_signature", None)
        record.pop("goal_reached_at", None)
        return "attached"

    def _infer_untracked_manual_targets(
        self, status_data: dict, planner: CollectionPlanner
    ) -> list[str]:
        linked: list[str] = []
        for slot_id, record in status_data.get("plots", {}).items():
            if record.get("target_management_locked"):
                continue
            if not (record.get("manual_layout") or record.get("layout_edited")):
                continue
            if assignment_from_record(record) is not None:
                continue
            candidate = self._automatic_manual_candidate(
                self._manual_target_candidates(slot_id, record, planner)
            )
            if not candidate:
                continue
            target = Flower(
                candidate["target_type"],
                candidate["target_color"],
                candidate["target_pattern"],
                candidate.get("target_secondary_color"),
            )
            assignment = self._manual_assignment(
                slot_id, record, target, candidate, "inferred"
            )
            self._set_manual_target(record, assignment, inferred=True)
            linked.append(slot_id.upper())
        return linked

    def _reconcile_manual_assignments(self, plan: dict, status_data: dict) -> dict:
        """Attach current target metadata only when a manual layout uses its parents."""
        recommended = first_wave_by_slot(plan)
        job_groups = first_wave_jobs_by_slot(plan)
        linked: list[str] = []
        detached: list[str] = []
        for slot, record in list(status_data.get("plots", {}).items()):
            slot_id = slot.upper()
            if record.get("target_management_locked"):
                # The user explicitly edited the goal list for this recorded
                # layout. Keep those Actual goals even when Generate Plan picks
                # a different route or target for the same physical cells.
                continue
            if not (record.get("manual_layout") or record.get("layout_edited")):
                continue
            existing_assignment = assignment_from_record(record)
            if existing_assignment and existing_assignment.get("manual_target"):
                # A user/inference-attached Actual goal belongs to the physical farm,
                # not to the current optimizer layout. Generate Plan must not erase it.
                continue
            assignment = recommended.get(slot_id)
            expected: Counter[Flower] = Counter()
            for job in job_groups.get(slot_id, []):
                expected.update(assignment_parent_counts(job))
            if assignment and record_parent_counts(record) == expected:
                cells = json.loads(json.dumps(record.get("cells", [])))
                planted_at = record.get("planted_at")
                edited_at = record.get("edited_at")
                record_planted(
                    status_data,
                    [assignment],
                    planted_at=planted_at,
                    cells_by_slot={slot_id: cells},
                )
                updated = status_data["plots"][slot_id]
                updated["jobs"] = [
                    assignment_snapshot(job)
                    for job in job_groups.get(slot_id, [])[1:]
                ]
                updated["manual_layout"] = True
                updated["layout_edited"] = False
                if edited_at:
                    updated["edited_at"] = edited_at
                linked.append(slot_id)
            else:
                self._detach_stale_assignment(record)
                record["manual_layout"] = True
                record["layout_edited"] = True
                detached.append(slot_id)
        return {"linked": linked, "detached": detached}

    def state(self, include_inventory: bool = True) -> dict:
        """The dashboard's state. Without the inventory (most of its size and,
        on a cold start, most of its time) the farm map can show first; the page
        then loads ``inventory_view`` in the background."""
        plan = self.load_plan()
        legacy_greenhouse_records = self._has_legacy_greenhouse_records()
        optimizer_key = self._optimizer_inputs_key()
        planner = CollectionPlanner(self.root)
        status_data = planner.plot_status
        self._repair_greenhouse_plan_layouts(plan, status_data)
        invalid_cells_removed = _remove_cells_outside_plot(status_data)
        inferred_manual_slots = self._infer_untracked_manual_targets(status_data, planner)
        inventory_data = load_inventory_data(self.inventory_path)
        goals_changed = self._reconcile_goal_states(status_data, inventory_data)
        if (
            legacy_greenhouse_records or invalid_cells_removed
            or inferred_manual_slots or goals_changed
        ):
            save_plot_status(self.status_path, status_data)
        actual = actual_assignments(status_data)
        actual_job_groups = actual_jobs_by_slot(status_data)
        recommended = first_wave_by_slot(plan)
        recommended_job_groups = first_wave_jobs_by_slot(plan)
        actual_work_states, recommended_work_states = self._semantic_work_state(
            planner, plan, status_data, actual_job_groups, recommended_job_groups
        )
        reserved = planted_counts(status_data)
        abundant = planner.abundant_colors()
        reservation_warnings = self._reservation_warnings(status_data, planner)
        slots = {slot.slot: slot for slot in all_slots()}
        map_layout = load_map_layout(self.root)
        context = _PlotRowContext(
            planner, plan, status_data, map_layout,
            actual, actual_job_groups, recommended, recommended_job_groups,
            actual_work_states, recommended_work_states,
        )
        fillers_on = (planner.settings.get("flow") or {}).get("outdoor_model") == "wiki_fillers"
        recommended_cells = {slot_id: (jobs, assignments_cell_records(slots[slot_id], jobs))
                             for slot_id, jobs in recommended_job_groups.items() if slot_id in slots}
        # Every Recommendation (fillers too) in the farm's copies, the one count
        # (copies.py). Replant the whole farm is one batch: a plot may take a
        # plant another one drops (a move); otherwise plants stay in their plot.
        release = set(recommended_cells) if (plan.get("flow") or {}).get("replant_all") else ()
        context.fillers, copies = farm_fillers(slots, recommended_cells, status_data, owned_counts(planner.inventory),
                                               release=release, fillers=fillers_on)
        context.copy_moves = copies.move_list()
        context.copy_shortages = copies.shortages()
        plot_rows = [
            self._plot_row(slot_id, slot, context)
            for slot_id, slot in sorted(
                slots.items(),
                key=lambda item: (*region_sort_key(map_layout, item[1].region), item[0]),
            )
        ]
        inventory_rows = self._inventory_rows(
            planner, reserved, abundant, _planted_locations(plot_rows),
            self._state_optimizer(planner, optimizer_key),
        ) if include_inventory else None
        action_statuses = Counter(row["action_state"] for row in plot_rows)
        current_targets = _current_targets(plot_rows)
        history_events = load_history_events(self.root, limit=200)
        history_daily_events = load_daily_history_events(self.root)
        history_metrics = self._history_metrics(status_data, planner)
        return {
            "summary": {
                **plan["summary"],
                "recorded_slots": len(status_data.get("plots", {})),
                "reserved_copies": sum(reserved.values()),
                "keep_slots": action_statuses["keep"],
                "partial_update_slots": action_statuses["partial_update"],
                "goal_reached_slots": action_statuses["goal_reached"],
                "new_work_slots": action_statuses["new_work"],
                "review_slots": action_statuses["review"],
                "reservation_warning_count": len(reservation_warnings),
                "fillers": fillers_on,
                "cogimyun": cogimyun_setting(planner.settings.get("flow") or {}),
            },
            "reservation_warnings": reservation_warnings,
            "plots": plot_rows,
            "locked_plots": self._locked_plots(slots, map_layout),
            "targets": {
                "current": current_targets,
                "summary": {
                    "current_jobs": len(current_targets),
                    "planted_jobs": sum(row["source"] == "planted" for row in current_targets),
                    "blocked_targets": plan["summary"]["blocked_targets"],
                },
            },
            "history": {
                "events": list(reversed(history_events)),
                "daily": daily_history(history_daily_events, history_metrics, load_metric_anchors(self.root)),
                "current": history_metrics,
            },
            "options": self._state_options(planner, map_layout, slots),
        } | ({"inventory": inventory_rows} if include_inventory else {"inventory_pending": True})

    def inventory_view(self) -> dict:
        """The inventory rows on their own, for a page that loaded the state without them."""
        return {"inventory": self.state()["inventory"]}

    def _has_legacy_greenhouse_records(self) -> bool:
        """Whether plot_status.json still has pre-shared-grid GH1, GH2… records."""
        if not self.status_path.exists():
            return False
        try:
            raw_status = json.loads(self.status_path.read_text(encoding="utf-8"))
            raw_plots = raw_status.get("plots", {})
            return isinstance(raw_plots, dict) and any(
                str(slot).upper() != "GH"
                and str(slot).upper().startswith("GH")
                and str(slot)[2:].isdigit()
                for slot in raw_plots
            )
        except (OSError, json.JSONDecodeError, AttributeError):
            return False

    def _repair_greenhouse_plan_layouts(self, plan: dict, status_data: dict) -> None:
        """Give coordinates to GH recommendations saved without a layout.

        Recovers plans written by older fast-refresh paths that saved a GH
        recommendation before assigning coordinates on the shared grid.
        """
        greenhouse = next((item for item in all_slots() if item.slot == "GH"), None)
        if greenhouse is None:
            return
        gh_record = status_data.get("plots", {}).get("GH", {})
        gh_cells = gh_record.get("cells", []) if isinstance(gh_record, dict) else []
        occupied_parents = {
            (int(cell["row"]), int(cell["col"]))
            for cell in gh_cells
            if isinstance(cell, dict) and "row" in cell and "col" in cell
        }
        occupied_targets = {
            tuple(map(int, cell))
            for job in actual_jobs_by_slot(status_data).get("GH", [])
            for cell in (job.get("layout") or {}).get("target_cells", [])
        }
        repaired = False
        for assignment in plan.get("first_wave", []):
            if str(assignment.get("slot", "")).upper() != "GH" or isinstance(assignment.get("layout"), dict):
                continue
            fertilizer = str(assignment.get("method", "")).startswith("fertilize_")
            layout = single_job_layout(
                greenhouse, occupied_parents, occupied_targets,
                fertilizer=fertilizer,
            )
            if layout is None:
                continue
            assignment["layout"] = layout
            if not fertilizer and len(assignment.get("parent_copies", [])) >= 2:
                assignment["parent_copies"] = [1, 1]
                assignment["eligible_cells"] = len(layout.get("target_cells", []))
            repaired = True
            occupied_parents.update(
                tuple(cell)
                for key in ("parent_a_cells", "parent_b_cells")
                for cell in layout.get(key, [])
            )
            occupied_targets.update(tuple(cell) for cell in layout.get("target_cells", []))
        if repaired:
            save_plot_status(self.plan_path, plan, compact=True)

    def _plot_row(self, slot_id: str, slot, context: _PlotRowContext) -> dict:
        """Everything the dashboard shows for one plot: Actual, Recommendation, and the action."""
        planner = context.planner
        map_layout = context.map_layout
        actual_assignment = context.actual.get(slot_id)
        recommended_assignment = context.recommended.get(slot_id)
        actual_jobs = context.actual_job_groups.get(slot_id, [])
        recommended_jobs = context.recommended_job_groups.get(slot_id, [])
        record = context.status_data.get("plots", {}).get(slot_id)
        recommended_cells = assignments_cell_records(slot, recommended_jobs)
        if record and isinstance(record.get("cells"), list):
            actual_cells = record["cells"]
        elif actual_assignment:
            actual_cells = assignments_cell_records(slot, actual_jobs)
        else:
            actual_cells = []
        manual_record = bool(
            record and (record.get("manual_layout") or record.get("layout_edited"))
        )
        if manual_record:
            actual_assignment = _manual_layout_actual_assignment(
                record, actual_assignment, recommended_assignment, recommended_jobs
            )
        actual_state = record.get("state", "planted") if record else "unplanted"
        has_actual = record is not None
        actual_grid = (
            _actual_base_grid(slot, actual_assignment)
            if has_actual and manual_record
            else assignments_matrix(slot, actual_jobs)
            if has_actual and actual_jobs
            else _actual_base_grid(slot, actual_assignment) if has_actual else None
        )
        recommended_grid = (
            assignments_matrix(slot, recommended_jobs)
            if recommended_assignment
            else None
        )
        if recommended_grid and context.fillers.get(slot_id):
            # Fillers (X): fertilized flowers that raise the spawn cells' chance.
            recommended_cells = sorted(recommended_cells + context.fillers[slot_id],
                                       key=lambda cell: (int(cell["row"]), int(cell["col"])))
            for cell in context.fillers[slot_id]:
                recommended_grid[int(cell["row"])][int(cell["col"])] = "X"
        display_actual_jobs, actual_semantic = _annotate_actual_jobs(
            slot_id, actual_jobs, context.actual_work_states
        )
        display_recommended_jobs, recommended_semantic = _annotate_recommended_jobs(
            slot_id, recommended_jobs, context.recommended_work_states
        )
        display_actual_assignment = display_actual_jobs[0] if display_actual_jobs else actual_assignment
        display_recommended_assignment = (
            display_recommended_jobs[0] if display_recommended_jobs else recommended_assignment
        )
        target_total = 0
        stock_goal = None
        if actual_assignment:
            target_total = planner.inventory.physical_count(self._target(actual_assignment))
            stock_goal = (
                actual_semantic[0].get("required_goal", effective_stock_goal(actual_assignment))
                if actual_semantic else effective_stock_goal(actual_assignment)
            )

        actual_states = [item["state"] for item in actual_semantic]
        recommended_states = [item["state"] for item in recommended_semantic]
        action_state, action_label, action_note = _plot_action(
            has_actual, actual_jobs, actual_states, recommended_states
        )

        # A FLOW recommendation is already the plot's whole layout: every hub
        # still working stays in its planted cells. Whether the plot needs
        # work is simply whether its plants change.
        partial_layout_jobs = None
        if not manual_record and has_actual and display_recommended_jobs:
            if _physical_cells(recommended_cells) != _physical_cells(actual_cells):
                partial_layout_jobs = display_recommended_jobs
                action_state, action_label = "partial_update", "Partial update"
                if context.plan.get("flow", {}).get("replant_all"):
                    action_note = (
                        "Farm-wide replant: groups whose work is still wanted stay where they are. "
                        "Clear and replant only the cells that change."
                    )
                elif slot_id in set(context.plan.get("flow", {}).get("replanted_plots", [])):
                    action_note = (
                        "Refreshed after a find: planted groups stay unless higher-priority work is "
                        "waiting. Clear and replant only the cells that change."
                    )
                else:
                    action_note = (
                        "FLOW keeps every planted hub that is still working. Plant only the cells "
                        "that change; finished recipients and new copies make room for more work."
                    )
            else:
                action_state, action_label = "keep", "Keep"
                action_note = "Nothing to replant here: every plant in this plot is still working in the FLOW plan."

        partial_update_ready = bool(partial_layout_jobs)
        can_apply_recommendation = bool(
            not manual_record
            and display_recommended_jobs
            and (
                partial_update_ready
                or (
                    all(item["state"] == "new_work" for item in recommended_semantic)
                    and (not actual_states or all(state == "goal_reached" for state in actual_states))
                )
            )
        )
        # A plot with only unfinished Actual work has nothing actionable to
        # change yet. Hide its future recommendation grid even when the
        # generated plan has new jobs for this slot; completed goals or
        # review states keep the recommendation view available.
        only_kept_actual = bool(actual_states) and all(
            state == "keep" for state in actual_states
        )
        show_recommendation_view = bool(display_recommended_jobs) and not only_kept_actual
        manual_target_candidates = (
            self._manual_target_candidates(slot_id, record, planner)
            if manual_record and not actual_jobs
            else []
        )

        return {
            "slot": slot_id,
            "name": plot_display_name(map_layout, slot.region, slot_id, slot.plot),
            "location": plot_location(map_layout, slot.region, slot_id),
            "region": slot.region,
            "greenhouse": slot.greenhouse,
            "rows": slot.rows,
            "cols": slot.cols,
            "spots": slot.spots,
            "actual_state": actual_state,
            "layout_edited": bool(record and record.get("layout_edited")),
            "manual_layout": bool(record and record.get("manual_layout")),
            "manual_target_candidates": manual_target_candidates,
            "job_states": record.get("job_states", {}) if record else {},
            "action_state": action_state,
            "action_label": action_label,
            "action_note": action_note,
            "action_required": action_state in {"partial_update", "goal_reached", "new_work", "review"},
            "can_apply_recommendation": can_apply_recommendation,
            "show_recommendation_view": show_recommendation_view,
            "partial_update_ready": partial_update_ready,
            "partial_update_has_completed": any(
                state == "goal_reached" for state in actual_states
            ),
            "actual": display_actual_assignment,
            "recommended": display_recommended_assignment,
            "actual_jobs": display_actual_jobs,
            "recommended_jobs": display_recommended_jobs,
            "preserved_actual_jobs": self._preserved_actual_jobs(
                display_actual_jobs, display_recommended_jobs
            ),
            "display_mode": "actual" if has_actual else "recommended",
            "grid": actual_grid if has_actual else recommended_grid or assignment_matrix(slot, None),
            "actual_grid": actual_grid,
            "recommended_grid": recommended_grid,
            "actual_utilization": _plot_utilization(slot, actual_jobs, actual_grid),
            "recommended_utilization": _plot_utilization(
                slot, display_recommended_jobs, recommended_grid
            ),
            "actual_cells": _with_job_tags(actual_cells, actual_jobs, record, slot_id) if has_actual else actual_cells,
            "recommended_cells": _with_job_tags(recommended_cells, recommended_jobs),
            "actual_cell_grid": _cell_grid(slot, actual_cells) if has_actual else None,
            "recommended_cell_grid": _cell_grid(slot, recommended_cells),
            "display_cell_grid": (
                _cell_grid(slot, actual_cells)
                if has_actual
                else _cell_grid(slot, recommended_cells)
            ),
            "editable_cells": [
                {"row": row, "col": col}
                for row, col in sorted(usable_cells(slot))
            ],
            "target_total": target_total,
            "stock_goal": stock_goal,
            # Plants this Recommendation takes from / gives to another plot in a
            # whole-farm replant (dig them up there first), and copies it lacks.
            "copy_moves_in": [_move_row(move, move["from"]) for move in context.copy_moves
                              if move["to"] == slot_id],
            "copy_moves_out": [_move_row(move, move["to"]) for move in context.copy_moves
                               if move["from"] == slot_id],
            "copy_shortages": [{**_flower_row(flower), "count": n}
                               for flower, n in sorted(context.copy_shortages.get(slot_id, {}).items(),
                                                       key=lambda item: item[0].label())],
            "map_position": plot_position(map_layout, slot.region, slot_id),
            "map_locked": bool(
                map_layout.get("regions", {}).get(slot.region, {})
                .get("locked_positions", {})
                .get(slot_id, False)
            ),
        }

    def _preserved_actual_jobs(
        self, display_actual_jobs: list[dict], display_recommended_jobs: list[dict],
    ) -> list[dict]:
        """Kept Actual goals that the plot's Recommendation layout leaves out.

        Manual layouts (and partial layouts that cannot be composed safely)
        leave the generated layout untouched, which used to hide kept Actual
        targets missing from this plot's first-wave jobs. Surface them
        separately without implying they are part of the generated grid or
        safe to plant over.
        """
        recommended_goal_keys = {self._goal_key(job) for job in display_recommended_jobs}
        preserved_jobs = []
        for job in display_actual_jobs:
            if job.get("work_state") != "keep":
                continue
            if self._goal_key(job) in recommended_goal_keys:
                continue
            preserved = dict(job)
            preserved["work_label"] = "Kept from Actual"
            preserved["work_reason"] = (
                str(job.get("work_reason") or "This unfinished Actual goal is still needed.")
                + " It remains tracked as Actual and is not part of this plot's generated recommendation layout."
            )
            preserved["preserved_actual_only"] = True
            preserved_jobs.append(preserved)
        return preserved_jobs

    @staticmethod
    def _collection_waits(planner, today=None) -> dict:
        """Why each missing collection goal waits, when it is not being bred.

        Structural reasons only (the checklist shows 🌱 for goals in a plot):
        a breed not owned at all, an event flower out of season (outdoors it
        only spawns during its event; the Greenhouse is shared), an
        extremophile before Extreme Gardening (only its small native plot),
        or no breeding route from what is owned.
        """
        import datetime as dt
        from .flow.scheduler import EVENT_WINDOWS, FlowConfig, _spawn_window
        from .rules import COLORS

        today = today or game_today()
        owned_types = {f.flower_type for f, n in owned_counts(planner.inventory).items() if n > 0}
        needed = FlowConfig.extreme_colors_needed
        eg_setting = extreme_gardening_mode(planner.settings if isinstance(planner.settings, dict) else {})
        extremes = [name for name, ft in FLOWER_TYPES.items() if ft.extreme]
        eg_unlocked = eg_setting == "now" or all(
            sum(1 for c in COLORS if planner.inventory.counts.get(Flower(n, c, "Solid"), 0) > 0) >= needed
            for n in extremes)

        def next_start(window):
            (sm, sd), _ = window
            start = dt.date(today.year, sm, sd)
            return start if start >= today else dt.date(today.year + 1, sm, sd)

        def end_of(window):
            (sm, sd), (em, ed) = window
            end = dt.date(today.year, em, ed)
            return end if end >= today else dt.date(today.year + 1, em, ed)

        reachable = planner.reachable_missing
        # Flower types no unlocked plot (Greenhouse included) can grow: the
        # player needs to unlock one of their areas first.
        slots = all_slots()
        zones = flower_zones()
        unplantable = {name: sorted(zones.get(name, ())) for name in FLOWER_TYPES
                       if not any(flower_type_allowed(name, slot) for slot in slots)}
        waits = {}
        for flower in planner.missing_targets:
            ft = FLOWER_TYPES[flower.flower_type]
            # Compact (one entry per missing variant): the checklist words it.
            if flower.flower_type in unplantable:
                waits[flower] = {"kind": "needs_area", "areas": unplantable[flower.flower_type]}
            elif flower.flower_type not in owned_types:
                waits[flower] = {"kind": "no_breed", "starters": list(ft.default_colors), "event": ft.event or None}
            elif ft.extreme and not eg_unlocked:
                # Extreme Gardening is a Greenhouse upgrade: only worth naming with one.
                waits[flower] = {"kind": "extreme", "needed": needed,
                                 "greenhouse": any(slot.greenhouse for slot in slots)}
            elif ft.event and ft.event in EVENT_WINDOWS:
                window = EVENT_WINDOWS[ft.event]
                if _spawn_window(today, window):
                    waits[flower] = {"kind": "event_now", "event": ft.event, "date": end_of(window).isoformat()}
                else:
                    waits[flower] = {"kind": "event", "event": ft.event, "date": next_start(window).isoformat()}
            elif flower not in reachable:
                waits[flower] = {"kind": "no_route"}
        return waits

    def _inventory_rows(
        self, planner, reserved: Counter, abundant, planted_locations: dict, optimizer,
    ) -> list[dict]:
        """One row per known flower variant: stock, reservations, location, and blockers."""
        variants = set(planner.targets) | planner.inventory.all | planner.inventory.uncollected
        type_index = {name: index for index, name in enumerate(planner.inventory.flower_order)}
        color_index = {name: index for index, name in enumerate(planner.inventory.visible_colors)}
        # Blocked-flower explanations are kept between loads and only the ones
        # whose parents' stock changed are redone (see AvailabilityCache).
        with self._availability_cache_lock:
            availability_results = self._availability_cache.update(
                AvailabilityCache.structure_of(optimizer, planner.settings),
                CollectionAvailability(optimizer, reserved),
                planner.missing_targets,
            )
            self._availability_results = availability_results
        waits = self._collection_waits(planner)
        rows = []
        for flower in sorted(
            variants,
            key=lambda item: (
                type_index.get(item.flower_type, 999),
                color_index.get(item.color, 999),
                0 if item.pattern == "Solid" else 1,
                item.pattern if item.pattern != "Solid" else "",
                item.secondary_color or "",
            ),
        ):
            total = planner.inventory.capacity(flower, abundant)
            planted = reserved[flower]
            explicit = flower in planner.inventory.explicit_counts
            rows.append({
                "flower_type": flower.flower_type,
                "color": flower.color,
                "pattern": flower.pattern,
                "secondary_color": flower.secondary_color,
                "label": flower.label(),
                "collected": flower in planner.inventory.all,
                "total": total,
                "total_label": f"{total}+" if total >= 50 and not explicit else str(total),
                "planted": planted,
                "free": max(0, total - planted),
                "over_reserved": max(0, planted - total),
                "planted_locations": planted_locations.get(flower, []),
                "abundant": total >= 50 and not explicit,
                # Why a flower is blocked (routes and reason) is most of the
                # payload; the checklist fetches it via collection_blocking_routes().
                "blocked": bool(flower in planner.missing_targets and availability_results[flower]["blocked"]),
                "in_scope": flower in planner.targets,
                "extremophile": bool(FLOWER_TYPES[flower.flower_type].extreme),
                "wait": waits.get(flower),
            })
        return rows

    def collection_blocking_routes(self) -> dict:
        """Ways to unblock each blocked collection goal, as left out of state()."""
        with self._availability_cache_lock:
            ready = self._availability_results is not None
        if not ready:
            self.state()
        with self._availability_cache_lock:
            results = list(self._availability_results.items())
        return {"routes": [
            {
                "flower_type": flower.flower_type, "color": flower.color,
                "pattern": flower.pattern, "secondary_color": flower.secondary_color,
                "blocking_reason": result.get("blocking_reason"),
                "blocking_routes": result["blocking_routes"],
            }
            for flower, result in results if result.get("blocked")
        ]}

    def _state_options(self, planner, map_layout: dict, slots: dict) -> dict:
        """Choices the dashboard's filters and edit dialogs offer."""
        return {
            "flower_types": list(planner.inventory.flower_order),
            "colors": list(planner.inventory.visible_colors),
            "patterns": list(VALID_PATTERNS),
            "colored_patterns": sorted(COLORED_PATTERNS),
            "effect_patterns": sorted(EFFECT_PATTERNS),
            "target_flower_types": list(planner.active_types),
            "extremophile_flower_types": [
                name for name, flower_type in FLOWER_TYPES.items()
                if flower_type.extreme
            ],
            "flower_patterns": {
                name: list(patterns)
                for name, patterns in planner.compatible_patterns.items()
            },
            # The pattern fertilizer turns each species' solids into.
            "default_patterns": {
                name: flower_type.default_pattern for name, flower_type in FLOWER_TYPES.items()
            },
            "target_colors": list(planner.active_colors),
            "target_patterns": sorted(
                {flower.pattern for flower in planner.targets},
                key=lambda pattern: (pattern != "Solid", pattern),
            ),
            "target_categories": [
                {
                    "key": key,
                    "label": TARGET_CATEGORY_LABELS[key],
                    "priority": index + 1,
                    "enabled": planner.target_categories[key],
                    "supported": key != "non_default_secondary_patterns",
                }
                for index, key in enumerate(TARGET_CATEGORY_ORDER)
            ],
            "regions": [
                region for region in map_layout["region_order"]
                if any(slot.region == region for slot in [*slots.values(), *every_outdoor_slot()])
            ],
            "region_maps": map_layout["regions"],
            "flower_colors": json.loads(self.colors_path.read_text(encoding="utf-8"))["colors"],
        }

    def update_plot_map_details(
        self,
        slot: str,
        name: str,
        location: str,
        column: int,
        row: int,
        span: int,
    ) -> dict:
        slot = slot.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot not in slots:
            raise ValueError(f"Unknown plot slot: {slot}")
        plot = slots[slot]
        name = name.strip()
        location = location.strip()
        if not name:
            raise ValueError("Plot name cannot be empty")
        if len(name) > 80 or len(location) > 160:
            raise ValueError("Plot name or location note is too long")
        if row < 1:
            raise ValueError("Map row must be at least 1")
        if not 1 <= column <= 12 or not 1 <= span <= 12:
            raise ValueError("Map column and width must be between 1 and 12")
        if column + span - 1 > 12:
            raise ValueError("Map card extends past column 12")

        layout = load_map_layout(self.root)
        region_data = layout["regions"][plot.region]
        current_position = tuple(
            map(int, region_data.get("positions", {}).get(slot, [1, 1, 4]))
        )
        if (
            bool(region_data.get("locked_positions", {}).get(slot, False))
            and current_position != (column, row, span)
        ):
            raise ValueError(f"{slot} is locked; unlock it before changing its position")
        requested_columns = set(range(column, column + span))
        conflicts = []
        for other_slot, values in region_data.get("positions", {}).items():
            if other_slot == slot:
                continue
            other_column, other_row, other_span = map(int, values)
            other_columns = set(range(other_column, other_column + other_span))
            if other_row == row and requested_columns & other_columns:
                conflicts.append(other_slot)
        if conflicts:
            raise ValueError(
                f"That map position overlaps {', '.join(sorted(conflicts))}; move one plot to a free row or column first"
            )

        region_data.setdefault("plot_names", {})[slot] = name
        locations = region_data.setdefault("plot_locations", {})
        if location:
            locations[slot] = location
        else:
            locations.pop(slot, None)
        region_data.setdefault("positions", {})[slot] = [column, row, span]
        region_data["map_rows"] = max(
            1,
            *(int(values[1]) for values in region_data["positions"].values()),
        )
        map_path = farm_data_path(self.root, "ui_map_layouts.json")
        backup = backup_before_mutation(self.root, map_path, "update-plot-map-details")
        save_plot_status(map_path, layout)
        self._record_history(
            "plot_map", "update_plot_details",
            {"slot": slot, "name": name, "location": location, "position": [column, row, span]},
            [backup],
        )
        return {
            "message": f"Updated map details for {slot}.",
            "slot": slot,
            "name": name,
            "location": location,
            "position": {"column": column, "row": row, "span": span},
        }

    def move_plot_map_card(self, slot: str, column: int, row: int) -> dict:
        """Move an unlocked plot card, swapping with one unlocked conflict when possible."""
        slot = slot.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot not in slots:
            raise ValueError(f"Unknown plot slot: {slot}")
        if row < 1 or row > 99:
            raise ValueError("Map row must be between 1 and 99")

        plot = slots[slot]
        layout = load_map_layout(self.root)
        region_data = layout["regions"][plot.region]
        positions = region_data.setdefault("positions", {})
        source_column, source_row, span = map(int, positions.get(slot, [1, 1, 4]))
        if column < 1 or column + span - 1 > 12:
            raise ValueError("Map card extends past the 12-column region map")
        if column == source_column and row == source_row:
            return {
                "message": f"{slot} is already in that map position.",
                "slot": slot,
                "position": {"column": column, "row": row, "span": span},
            }

        requested_columns = set(range(column, column + span))
        conflicts = []
        for other_slot, values in positions.items():
            if other_slot == slot:
                continue
            other_column, other_row, other_span = map(int, values)
            if other_row != row:
                continue
            other_columns = set(range(other_column, other_column + other_span))
            if requested_columns & other_columns:
                conflicts.append(other_slot)

        swapped = None
        if conflicts:
            if len(conflicts) != 1:
                raise ValueError(
                    f"That position overlaps {', '.join(sorted(conflicts))}; choose a clearer space"
                )
            swapped = conflicts[0]
            other_column, other_row, other_span = map(int, positions[swapped])
            if source_column + other_span - 1 > 12:
                raise ValueError(f"{swapped} is too wide to swap into {slot}'s old position")
            swap_columns = set(range(source_column, source_column + other_span))
            blockers = []
            for third_slot, values in positions.items():
                if third_slot in {slot, swapped}:
                    continue
                third_column, third_row, third_span = map(int, values)
                third_columns = set(range(third_column, third_column + third_span))
                if third_row == source_row and swap_columns & third_columns:
                    blockers.append(third_slot)
            if blockers:
                raise ValueError(
                    f"Cannot swap because {swapped} would overlap {', '.join(sorted(blockers))}"
                )
            positions[swapped] = [source_column, source_row, other_span]

        positions[slot] = [column, row, span]
        region_data["map_rows"] = max(
            1,
            *(int(values[1]) for values in positions.values()),
        )
        map_path = farm_data_path(self.root, "ui_map_layouts.json")
        backup = backup_before_mutation(self.root, map_path, "move-plot-map-card")
        save_plot_status(map_path, layout)
        self._record_history(
            "plot_map", "move_plot",
            {"slot": slot, "position": [column, row, span], "swapped": swapped},
            [backup],
        )
        message = f"Moved {slot}."
        if swapped:
            message = f"Moved {slot} and swapped it with {swapped}."
        return {
            "message": message,
            "slot": slot,
            "swapped": swapped,
            "position": {"column": column, "row": row, "span": span},
        }

    def set_plot_map_lock(self, slot: str, locked: bool) -> dict:
        slot = slot.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot not in slots:
            raise ValueError(f"Unknown plot slot: {slot}")
        plot = slots[slot]
        layout = load_map_layout(self.root)
        region_data = layout["regions"][plot.region]
        lock_data = region_data.setdefault("locked_positions", {})
        if locked:
            lock_data[slot] = True
        else:
            lock_data.pop(slot, None)
        map_path = farm_data_path(self.root, "ui_map_layouts.json")
        backup = backup_before_mutation(self.root, map_path, "set-plot-map-lock")
        save_plot_status(map_path, layout)
        self._record_history(
            "plot_map", "set_plot_lock", {"slot": slot, "locked": locked}, [backup]
        )
        return {
            "message": f"{slot} map position {'locked' if locked else 'unlocked'}.",
            "slot": slot,
            "locked": locked,
        }

    @staticmethod
    def _locked_plots(unlocked: dict, map_layout: dict) -> list[dict]:
        """Outdoor plots the farm hasn't unlocked yet: the map shows them greyed out."""
        return [
            {
                "slot": slot.slot,
                "name": plot_display_name(map_layout, slot.region, slot.slot, slot.plot),
                "region": slot.region,
                "spots": slot.spots,
                "map_position": plot_position(map_layout, slot.region, slot.slot),
            }
            for slot in every_outdoor_slot() if slot.slot not in unlocked
        ]

    def setup_status(self) -> dict:
        """First-time setup (web/onboarding.js): a farm with no plan yet gets the setup screens;
        a farm set up that way also gets the getting-started guide (``guide``)."""
        settings = self._read_settings()
        onboarding = settings.get("onboarding", {})
        return {
            "needs_setup": not self.plan_path.exists(),
            "steps": {key: value for key, value in onboarding.items() if key in SETUP_STEPS},
            "guide": self._guide(settings) if onboarding and self.plan_path.exists() else None,
        }

    def _guide(self, settings: dict) -> dict:
        """Getting-started checklist progress, from the farm's history.

        A ticked item is kept in settings (the history is read from its
        recent end only, and an item must not untick as it grows).
        """
        onboarding = settings["onboarding"]
        done = dict(onboarding.get("guide_done", {}))
        events = load_history_events(self.root, limit=500)
        plan_time = datetime.fromtimestamp(self.plan_path.stat().st_mtime, timezone.utc)

        def when(event: dict) -> datetime | None:
            try:
                return datetime.fromisoformat(str(event.get("timestamp", "")).replace("Z", "+00:00"))
            except ValueError:
                return None

        for item, (category, action) in GUIDE_EVENTS.items():
            if item not in done:
                first = next((e for e in events if (e.get("category"), e.get("action")) == (category, action)), None)
                if first is not None:
                    done[item] = first.get("timestamp")
        found_at = when({"timestamp": done.get("found")}) if done.get("found") else None
        if "replanned" not in done and found_at and plan_time > found_at:
            done["replanned"] = plan_time.isoformat(timespec="seconds")
        if done != onboarding.get("guide_done", {}):
            onboarding["guide_done"] = done
            save_inventory_atomic(self.settings_path, settings)
        finds_since_plan = sum(
            1 for e in events
            if (e.get("category"), e.get("action")) == ("inventory", "found_target") and (when(e) or plan_time) > plan_time
        )
        return {
            "done": {item: item in done for item in (*GUIDE_EVENTS, "replanned")},
            "planted": onboarding.get("planted"),
            "collection": onboarding.get("collection"),     # "skipped" in setup, "later" once added
            "hidden": onboarding.get("guide") == "hidden",
            "backup": onboarding.get("backup"),
            "hints_seen": onboarding.get("hints", []),
            "finds_since_plan": finds_since_plan,
        }

    def mark_setup_step(self, step: str, value=True) -> dict:
        """Record a setup step (or a value for it, e.g. planted: "keep")."""
        if step not in SETUP_STEPS:
            raise ValueError(f"Unknown setup step: {step}")
        if not isinstance(value, (bool, str)):
            raise ValueError("A setup step's value is true/false or a short text")
        settings = self._read_settings()
        settings.setdefault("onboarding", {})[step] = value
        save_inventory_atomic(self.settings_path, settings)
        return self.setup_status()

    def set_fillers(self, enabled: bool) -> dict:
        """Fillers (X) in outdoor Recommendations, and odds that count them.

        Stored as the FLOW outdoor model, so Generate plan and the forecast
        both see it (and a finished forecast goes out of date).
        """
        settings = self._read_settings()
        settings.setdefault("flow", {})["outdoor_model"] = "wiki_fillers" if enabled else "wiki"
        save_inventory_atomic(self.settings_path, settings)
        return {"message": ("Fillers on: outdoor plots show X cells. Press Generate plan to update the odds."
                            if enabled else "Fillers off.")}

    def set_cogimyun(self, enabled: bool) -> dict:
        """Cogimyun's ability used when fertilizing: a 5% daily default-pattern
        chance for fertilized solids (not 1%), in every region. Replaces the
        older Wheatflour Wonderland-only keys."""
        settings = self._read_settings()
        flow = settings.setdefault("flow", {})
        flow.pop("cogimyun_wheatflour", None)
        flow.pop("cogimyun_everywhere", None)
        flow["cogimyun"] = enabled
        save_inventory_atomic(self.settings_path, settings)
        return {"message": "Cogimyun on." if enabled else "Cogimyun off."}

    def mark_hint_seen(self, hint: str) -> dict:
        """A one-time hint the player has dismissed ("Got it")."""
        if not hint or len(hint) > 40:
            raise ValueError("Unknown hint")
        settings = self._read_settings()
        seen = settings.setdefault("onboarding", {}).setdefault("hints", [])
        if hint not in seen:
            seen.append(hint)
            save_inventory_atomic(self.settings_path, settings)
        return {"hints_seen": seen}

    def _plan_made(self) -> tuple:
        """(game day, whole farm?) of the current plan, cached on its mtime.

        The plan file is large, and the banner asks on every farm load.
        """
        try:
            mtime = self.plan_path.stat().st_mtime_ns
        except OSError:
            return None, False
        cached = getattr(self, "_plan_made_cache", None)
        if cached and cached[0] == mtime:
            return cached[1]
        made = game_today(datetime.fromtimestamp(mtime / 1e9, timezone.utc))
        whole = False
        try:
            flow = self.load_plan().get("flow") or {}
            made = date.fromisoformat(flow["as_of"]) if flow.get("as_of") else made
            whole = bool(flow.get("replant_all"))
        except (OSError, ValueError):
            pass
        self._plan_made_cache = (mtime, (made, whole))
        return made, whole

    def current_events(self, today=None) -> dict:
        """Events with event flowers for the Farm map's banner: on now, or ended this past week.

        Each with its dates and flowers, whether the current plan was made
        before it started (so a new plan would use the event's outdoor window),
        and, from its last day on, whether the farm still needs a whole-farm
        plan: plans made on the last day already leave its flowers out
        outdoors, since that night's reset rolls after the event.
        """
        import datetime as dt
        from .flow.scheduler import EVENT_WINDOWS, _in_window
        from .plot_checks import next_reset

        today = today or game_today()
        plan_day, whole_farm = self._plan_made()
        active = []
        for event, window in EVENT_WINDOWS.items():
            flowers = [name for name, ft in FLOWER_TYPES.items() if ft.event == event]
            ended = next((today - dt.timedelta(days=back) for back in range(1, 8)
                          if _in_window(today - dt.timedelta(days=back), window)), None)
            if not flowers or not (_in_window(today, window) or ended):
                continue
            end = today if _in_window(today, window) else ended
            while _in_window(end + dt.timedelta(days=1), window):
                end += dt.timedelta(days=1)
            start = end
            while _in_window(start - dt.timedelta(days=1), window):
                start -= dt.timedelta(days=1)
            last_day_or_after = today >= end
            active.append({
                "event": event, "flowers": flowers, "start": start.isoformat(), "end": end.isoformat(),
                "ended": today > end,
                "plan_before_event": not last_day_or_after and plan_day is not None and plan_day < start,
                "replant_after_event": last_day_or_after and not (
                    whole_farm and plan_day is not None and plan_day >= end),
            })
        return {"active": active, "today": today.isoformat(), "resets_at": next_reset().isoformat()}

    def collection_setup(self) -> dict:
        """Everything collectable and what is collected, for the setup's collection step.

        Variants are "Type|Color|Pattern" keys: each flower type in every
        color, Solid and each of its patterns (the collection goals; patterns
        with a second color are left out, as in the goals).
        """
        planner = CollectionPlanner(self.root)
        palette = json.loads(self.colors_path.read_text(encoding="utf-8"))["colors"]
        return {
            "flower_types": [
                {
                    "name": name, "default_colors": list(ft.default_colors),
                    "default_pattern": ft.default_pattern, "event": ft.event, "extreme": ft.extreme,
                    # Its own pattern first after Solid, then the transferable ones.
                    "patterns": ["Solid", ft.default_pattern, *(p for p in planner.compatible_patterns.get(name, ())
                                                                if p != ft.default_pattern)],
                }
                for name, ft in planner.active_types.items()
            ],
            "colors": [{"name": color, "hex": palette.get(color, "#cccccc")} for color in planner.active_colors],
            "collected": sorted(
                f"{f.flower_type}|{f.color}|{f.pattern}" for f in planner.inventory.all if not f.secondary_color
            ),
            # Plantable copies of each collected flower (a collected flower counts 1 until counted).
            "counts": {
                f"{f.flower_type}|{f.color}|{f.pattern}": planner.inventory.physical_count(f)
                for f in planner.inventory.all if not f.secondary_color
            },
            "total": len(planner.targets),
        }

    def set_collection(self, collect: list[dict], uncollect: list[dict]) -> dict:
        """Mark many flowers collected or not collected, in one save.

        A collect row may carry "count" (plantable copies, 0 or more); without
        one a newly collected flower is recorded with 1 copy (an untracked
        flower would have none, see copies.py) and a counted one keeps its count.
        """
        data = load_inventory_data(self.inventory_path)
        counted = set(data.get("variant_counts", {}))

        def updates(rows, collecting=False):
            out = []
            for row in rows:
                count = row.get("count")
                if count is not None and (not isinstance(count, int) or isinstance(count, bool) or count < 0):
                    raise ValueError(f"Copies must be a whole number of 0 or more, not {count!r}")
                update = normalize_update(data, row["flower_type"], row["color"], row["pattern"], count=count)[0]
                if collecting and count is None and update.count_key() not in counted:
                    update = normalize_update(data, row["flower_type"], row["color"], row["pattern"], count=1)[0]
                out.append(update)
            return out

        to_collect, to_drop = updates(collect, collecting=True), updates(uncollect)
        planted = planted_counts(load_plot_status(self.status_path))
        for update in to_drop:
            flower = Flower(update.flower_type, update.color, update.pattern)
            if planted[flower]:
                raise ValueError(f"{flower.label()} is planted; it can't be marked not collected")
        data, collected = apply_updates(data, to_collect)
        dropped = 0
        for update in to_drop:
            data.get("variant_counts", {}).pop(update.count_key(), None)
            data, changed = mark_uncollected(data, update)
            dropped += changed
        if not collected and not dropped:
            return {"message": "No changes.", "collected": 0, "uncollected": 0}
        backup = backup_before_mutation(self.root, self.inventory_path, "set-collection")
        save_inventory_atomic(self.inventory_path, data)
        self._record_history("inventory", "set_collection",
                             {"collected": len(collected), "uncollected": dropped}, [backup])
        changes = len(collected) + dropped
        return {"message": f"Saved {changes} change{'' if changes == 1 else 's'} to your collection.",
                "collected": len(collected), "uncollected": dropped}

    def _read_settings(self) -> dict:
        return json.loads(self.settings_path.read_text(encoding="utf-8")) if self.settings_path.exists() else {}

    def farm_plots(self) -> dict:
        """Every flower patch in the game by area, marked unlocked or not, and the Greenhouse size.

        For the setup screens; the planner itself only ever sees unlocked plots.
        """
        settings = self._read_settings()
        unlocked = settings.get("unlocked_plots")
        unlocked = None if unlocked is None else {str(slot).upper() for slot in unlocked}
        prefixes = list(PREFIX_REGIONS)
        areas: dict[str, list[dict]] = {}

        def area_rank(region: str) -> int:
            return AREA_ORDER.index(region) if region in AREA_ORDER else len(AREA_ORDER)

        for slot in sorted(every_outdoor_slot(), key=lambda s: (
                area_rank(s.region), prefixes.index(s.slot[:2].lower()), int(s.slot[2:]))):
            areas.setdefault(slot.region, []).append({
                "slot": slot.slot, "name": slot.plot, "spots": slot.spots,
                "unlocked": unlocked is None or slot.slot in unlocked,
            })
        return {
            "areas": [{"region": region, "plots": plots} for region, plots in areas.items()],
            "greenhouse_level": settings.get("greenhouse_level", FULL_GREENHOUSE_LEVEL),
            "greenhouse_sizes": [
                {"level": level, "rows": size[0], "cols": size[1], "plots": size[0] * size[1]} if size
                else {"level": level, "rows": 0, "cols": 0, "plots": 0}
                for level, size in GREENHOUSE_SIZES.items()
            ],
        }

    def set_farm_plots(self, unlocked_plots: list[str] | None = None, greenhouse_level: int | None = None) -> dict:
        """Save which outdoor plots are unlocked and the Greenhouse level (None leaves either as is).

        Listing every plot stores "all" (no list), so plots added to the game
        later start unlocked. Takes effect at the next Generate plan (the
        current plan stays as it is).
        """
        settings = self._read_settings()
        if unlocked_plots is not None:
            known = {slot.slot for slot in every_outdoor_slot()}
            chosen = sorted({str(slot).upper() for slot in unlocked_plots})
            unknown = [slot for slot in chosen if slot not in known]
            if unknown:
                raise ValueError("Unknown plots: " + ", ".join(unknown))
            if set(chosen) == known:
                settings.pop("unlocked_plots", None)     # everything: same as never set
            else:
                settings["unlocked_plots"] = chosen
        if greenhouse_level is not None:
            if greenhouse_level not in GREENHOUSE_SIZES:
                raise ValueError("Greenhouse level must be 0-7")
            settings["greenhouse_level"] = greenhouse_level
        configure_farm_plots(settings)                   # validates before anything is saved
        backup = backup_before_mutation(self.root, self.settings_path, "update-farm-plots")
        save_inventory_atomic(self.settings_path, settings)
        unlocked = settings.get("unlocked_plots")
        details = {"unlocked_plots": unlocked, "greenhouse_level": settings.get("greenhouse_level")}
        self._record_history("settings", "update_farm_plots", details, [backup])
        count = len(every_outdoor_slot()) if unlocked is None else len(unlocked)
        return {"message": f"Saved: {count} outdoor plots unlocked. Generate plan to plan for them.",
                **self.farm_plots()}

    def set_region_map_collapsed(self, region: str, collapsed: bool) -> dict:
        layout = load_map_layout(self.root)
        if region not in layout["regions"]:
            raise ValueError(f"Unknown map region: {region}")
        layout["regions"][region]["collapsed"] = collapsed
        map_path = farm_data_path(self.root, "ui_map_layouts.json")
        backup = backup_before_mutation(self.root, map_path, "collapse-region-map")
        save_plot_status(map_path, layout)
        self._record_history(
            "plot_map", "set_region_collapsed",
            {"region": region, "collapsed": collapsed}, [backup]
        )
        return {
            "message": f"{region} {'collapsed' if collapsed else 'expanded'}.",
            "region": region,
            "collapsed": collapsed,
        }

    def set_region_map_columns(self, region: str, cards_per_row: int) -> dict:
        """Reflow a region to the supported three- or four-card grid."""
        if cards_per_row not in {3, 4}:
            raise ValueError("Region maps support either 3 or 4 cards per row")
        layout = load_map_layout(self.root)
        if region not in layout["regions"]:
            raise ValueError(f"Unknown map region: {region}")
        region_data = layout["regions"][region]
        current = int(region_data.get("cards_per_row", 3))
        if current == cards_per_row:
            return {
                "message": f"{region} is already set to {cards_per_row} cards across.",
                "region": region,
                "cards_per_row": cards_per_row,
            }

        positions = region_data.setdefault("positions", {})
        rows: dict[int, list[tuple[str, int]]] = {}
        for slot, values in positions.items():
            column, row, _span = map(int, values)
            rows.setdefault(row, []).append((slot, column))

        span = 12 // cards_per_row
        next_row = 1
        reflowed: dict[str, list[int]] = {}
        for original_row in sorted(rows):
            ordered = [slot for slot, _column in sorted(rows[original_row], key=lambda item: (item[1], item[0]))]
            for offset in range(0, len(ordered), cards_per_row):
                for index, slot in enumerate(ordered[offset : offset + cards_per_row]):
                    reflowed[slot] = [1 + index * span, next_row, span]
                next_row += 1

        region_data["positions"] = reflowed
        region_data["map_rows"] = max(1, next_row - 1)
        region_data["cards_per_row"] = cards_per_row
        map_path = farm_data_path(self.root, "ui_map_layouts.json")
        backup = backup_before_mutation(self.root, map_path, "reflow-region-map")
        save_plot_status(map_path, layout)
        self._record_history(
            "plot_map", "set_region_columns",
            {"region": region, "cards_per_row": cards_per_row}, [backup]
        )
        return {
            "message": f"Reflowed {region} to {cards_per_row} cards across.",
            "region": region,
            "cards_per_row": cards_per_row,
        }

    def preview_manual_plot_target(
        self,
        slot: str,
        flower_type: str,
        color: str,
        pattern: str,
    ) -> dict:
        slot = slot.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot not in slots:
            raise ValueError(f"Unknown plot slot: {slot}")
        status_data = load_plot_status(self.status_path)
        record = status_data.get("plots", {}).get(slot)
        if not record or not isinstance(record.get("cells"), list) or not record.get("cells"):
            raise ValueError(f"{slot} has no manually recorded planted layout")
        planner = CollectionPlanner(self.root)
        if flower_type not in planner.active_types:
            raise ValueError(f"{flower_type} is outside the current target scope")
        if color not in planner.active_colors:
            raise ValueError(f"{color} is outside the current target scope")
        compatible = {"Solid", *planner.compatible_patterns[flower_type]}
        if pattern not in compatible:
            raise ValueError(
                f"{pattern} is not compatible with {flower_type}; choose one of "
                + ", ".join(sorted(compatible))
            )
        target = Flower(flower_type, color, pattern)
        if target not in planner.targets:
            raise ValueError(f"{target.label()} is outside the enabled collection scope")
        if not flower_type_allowed(flower_type, slots[slot]):
            raise ValueError(f"{flower_type} cannot grow in {slots[slot].region} ({slot})")

        candidates = self._manual_target_candidates(slot, record, planner)
        attached_jobs = actual_jobs_by_slot(status_data).get(slot, [])
        attached_targets = [job["target"] for job in attached_jobs]
        candidate = next(
            (row for row in candidates if (
                row["target_type"], row["target_color"], row["target_pattern"],
                row.get("target_secondary_color")
            ) == (target.flower_type, target.color, target.pattern, target.secondary_color)),
            None,
        )
        assignment = self._manual_assignment(slot, record, target, candidate, "user")
        warnings: list[str] = []
        if candidate is None:
            warnings.append(
                "The planner cannot verify this target from the recorded plants. "
                "You can still attach it as the intended goal; it will be marked manually specified."
            )
        target_type = planner.active_types[target.flower_type]
        if (
            target_type.event
            and not planner.event_active(target_type.event)
            and not slots[slot].greenhouse
            and (
                target.pattern == "Solid"
                or target.pattern != target_type.default_pattern
            )
        ):
            warnings.append(
                f"{target.flower_type} is out of season. New {target.flower_type} "
                "offspring cannot spawn on this outdoor plot; use the Greenhouse."
            )
        if target in planner.inventory.all:
            warnings.append(
                f"{target.label()} is already collected, so this Actual goal may immediately show Goal reached."
            )
        return {
            "slot": slot,
            "target": target.label(),
            "assignment": assignment,
            "verified": candidate is not None,
            "already_attached": target.label() in attached_targets,
            "attached_targets": attached_targets,
            "warnings": warnings,
            "candidates": candidates[:12],
        }

    @staticmethod
    def _target_job_index(jobs: list[dict], job_id: str | None) -> int | None:
        if job_id is None:
            return None
        wanted = str(job_id)
        for index, job in enumerate(jobs):
            current = str(job.get("job_id") or ("primary" if index == 0 else f"job-{index + 1}"))
            if current == wanted:
                return index
        return None

    def _managed_recommendation_preview(
        self,
        slot_id: str,
        flower_type: str,
        color: str,
        pattern: str,
        action: str,
        job_id: str | None,
    ) -> dict:
        slot_id = slot_id.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot_id not in slots:
            raise ValueError(f"Unknown plot slot: {slot_id}")
        slot = slots[slot_id]
        plan = self.load_plan()
        all_jobs = list(first_wave_jobs_by_slot(plan).get(slot_id, []))
        edit_index = self._target_job_index(all_jobs, job_id) if action == "edit" else None
        if action == "edit" and edit_index is None:
            raise ValueError(f"The selected recommendation target is no longer on {slot_id}")
        siblings = [job for index, job in enumerate(all_jobs) if index != edit_index]

        target = Flower(flower_type, color, pattern)
        duplicate = next((job for job in siblings if self._target(job) == target), None)
        if duplicate:
            raise ValueError(f"{target.label()} is already a separate recommendation on {slot_id}")

        previous = all_jobs[edit_index] if edit_index is not None else None
        if previous and self._target(previous) == target:
            # Editing a target to the same goal is a no-op. Keep its existing
            # route and exact cell layout; rebuilding it as a fresh target can
            # fail on a full plot even though the selected job already owns a
            # safe zone there.
            base = self.preview_plot_target(slot_id, flower_type, color, pattern)
            assignment = json.loads(json.dumps(previous))
            warnings = [
                warning for warning in base["warnings"]
                if "already the recommended target" not in warning
            ]
            return {
                **base,
                "assignment": assignment,
                "grid": assignments_matrix(slot, all_jobs),
                "cells": assignments_cell_records(slot, all_jobs),
                "warnings": warnings,
                "action": action,
                "scope": "recommendation",
                "job_id": job_id,
            }

        base = self.preview_plot_target(slot_id, flower_type, color, pattern)
        planner = CollectionPlanner(self.root)
        optimizer = planner.immediate_optimizer()
        busy, _assigned_elsewhere = self._other_plot_commitments(
            plan, planner.plot_status, slot_id
        )
        for sibling in siblings:
            busy.update(assignment_parent_counts(sibling))
        assignment = optimizer.assignment_for_target(target, slot, busy)
        if assignment is None:
            raise ValueError(
                f"No immediately breedable route for {target.label()} remains after reserving the other targets on {slot_id}."
            )

        # Target management is intentionally additive: every sibling keeps its
        # saved cells, and a new route gets a fresh safe zone or as many
        # fertilizer plants as fit the free inventory and unoccupied cells.
        method = str(assignment.get("method", ""))
        if method.startswith("fertilize_"):
            requested_copies = max(
                1,
                min(
                    slot.spots,
                    int((assignment.get("parent_copies") or [1])[0]),
                ),
            )
            parent_cells = optimizer._choose_fertilizer_parent_cells(
                slot, requested_copies, siblings
            )
            if not parent_cells:
                raise ValueError(f"No open plant cell remains on {slot_id} for {target.label()}.")
            assignment["parent_copies"] = [len(parent_cells)]
            assignment["eligible_cells"] = len(parent_cells)
            assignment["layout"] = {
                "parent_a_cells": [list(cell) for cell in parent_cells],
                "parent_b_cells": [],
                "target_cells": [],
            }
        else:
            zones = isolated_pair_zones(slot, 999)
            available = optimizer._available_outdoor_zones(slot, zones, siblings, set())
            if not available:
                raise ValueError(
                    f"No unoccupied safe parent pair remains on {slot_id} for another target."
                )
            pair, spawn_cells = available[0]
            assignment["parent_copies"] = [1 for _ in assignment.get("parent_flowers", [])]
            assignment["layout"] = {
                "parent_a_cells": [list(pair[0])],
                "parent_b_cells": [list(pair[1])],
                "target_cells": [list(cell) for cell in sorted(spawn_cells)],
            }
            assignment["eligible_cells"] = len(spawn_cells)

        parents = tuple(
            Flower(
                row["flower_type"], row["color"], row["pattern"],
                row.get("secondary_color"),
            )
            for row in assignment.get("parent_flowers", [])
        )
        route = Route(target, method, parents)
        if method.startswith("fertilize_"):
            per_cell = BREED_PROBABILITY[method]
        else:
            per_spawn = BREED_PROBABILITY[method]
            if (
                method == "pattern_transfer"
                and optimizer._uses_inactive_event_patterned_parent(route)
            ):
                per_spawn = 0.02
            per_cell = per_spawn * (
                planner.settings["outdoor_spawn_probability_fertilized"]
                if not slot.greenhouse else 1.0
            )
        eligible = max(1, int(assignment.get("eligible_cells", 1)))
        probability = 1.0 - (1.0 - per_cell) ** eligible
        assignment["daily_probability"] = probability
        assignment["expected_days"] = 1.0 / probability if probability > 0 else float("inf")
        assignment["custom_target"] = True
        assignment["fast_refresh"] = True
        previous = all_jobs[edit_index] if edit_index is not None else None
        assignment["job_id"] = (
            previous.get("job_id") if previous
            else f"{slot_id}.M{len(all_jobs) + 1:02d}"
        )
        assignment["supplemental"] = bool(siblings)
        assignment["previous_target"] = previous.get("target") if previous else None
        combined = siblings + [assignment]
        cells = assignments_cell_records(slot, combined)
        return {
            **base,
            "assignment": assignment,
            "grid": assignments_matrix(slot, combined),
            "cells": cells,
            "warnings": [
                warning for warning in base["warnings"]
                if not (
                    previous
                    and self._target(previous) == target
                    and "already the recommended target" in warning
                )
            ],
            "action": action,
            "scope": "recommendation",
            "job_id": job_id,
        }

    def preview_managed_target(
        self,
        slot: str,
        scope: str,
        action: str,
        flower_type: str,
        color: str,
        pattern: str,
        job_id: str | None = None,
    ) -> dict:
        if action not in {"add", "edit"}:
            raise ValueError("Choose Add or Edit before previewing a target")
        if scope == "recommendation":
            return self._managed_recommendation_preview(
                slot, flower_type, color, pattern, action, job_id
            )
        if scope != "actual":
            raise ValueError("Target scope must be Actual or Recommendation")

        preview = self.preview_manual_plot_target(slot, flower_type, color, pattern)
        jobs = actual_jobs_by_slot(load_plot_status(self.status_path)).get(slot.upper(), [])
        edit_index = self._target_job_index(jobs, job_id) if action == "edit" else None
        if action == "edit" and edit_index is None:
            raise ValueError(f"The selected Actual target is no longer on {slot.upper()}")
        duplicate = next(
            (job for index, job in enumerate(jobs)
             if index != edit_index and self._target(job) == self._target(preview["assignment"])),
            None,
        )
        if duplicate:
            raise ValueError(
                f"{preview['target']} is already tracked as another Actual target on {slot.upper()}"
            )
        preview.update({"action": action, "scope": "actual", "job_id": job_id})
        return preview

    @staticmethod
    def _write_actual_primary(record: dict, assignment: dict) -> None:
        snapshot = assignment_snapshot(assignment)
        record["assignment"] = snapshot
        for key in ("target", "method", "parents", "parent_copies"):
            if key in snapshot:
                record[key] = snapshot[key]
        record.pop("plan_signature", None)

    def _remove_managed_actual_target(
        self, status_data: dict, slot_id: str, job_id: str
    ) -> dict:
        record = status_data.get("plots", {}).get(slot_id)
        if not record:
            raise ValueError(f"{slot_id} has no recorded Actual planting")
        jobs = actual_jobs_by_slot(status_data).get(slot_id, [])
        index = self._target_job_index(jobs, job_id)
        if index is None:
            raise ValueError(f"The selected Actual target is no longer on {slot_id}")
        removed = jobs.pop(index)
        if index == 0:
            if jobs:
                self._write_actual_primary(record, jobs.pop(0))
            else:
                for key in ("assignment", "target", "method", "parents", "parent_copies", "plan_signature"):
                    record.pop(key, None)
        record["jobs"] = [assignment_snapshot(job) for job in jobs]
        if not record["jobs"]:
            record.pop("jobs", None)
        record.setdefault("job_states", {}).pop(str(removed.get("job_id") or "primary"), None)
        if not record.get("job_states"):
            record.pop("job_states", None)
        record["target_management_locked"] = True
        record["target_tracking_explicit"] = True
        record["manual_layout"] = True
        record["layout_edited"] = True
        record["state"] = record["status"] = "planted"
        record.pop("goal_reached_at", None)
        return removed

    def manage_plot_target(
        self,
        slot: str,
        scope: str,
        action: str,
        job_id: str | None = None,
        flower_type: str | None = None,
        color: str | None = None,
        pattern: str | None = None,
        confirmed: bool = False,
    ) -> dict:
        slot_id = slot.upper()
        if scope not in {"actual", "recommendation"}:
            raise ValueError("Target scope must be Actual or Recommendation")
        if action not in {"add", "edit", "remove"}:
            raise ValueError("Target action must be Add, Edit, or Remove")
        if action == "remove":
            if not job_id:
                raise ValueError("Select a target to remove")
            if scope == "actual":
                status_data = load_plot_status(self.status_path)
                removed = self._remove_managed_actual_target(status_data, slot_id, job_id)
                backup = backup_before_mutation(self.root, self.status_path, "remove-actual-target")
                save_plot_status(self.status_path, status_data)
                self._record_history(
                    "plot_status", "remove_actual_target",
                    {"slot": slot_id, "job_id": job_id, "target": removed.get("target")},
                    [backup], status_data,
                )
                return {"message": f"Stopped tracking {removed.get('target')} as Actual on {slot_id}. The recorded plants were left in place."}

            plan = self.load_plan()
            current = list(first_wave_jobs_by_slot(plan).get(slot_id, []))
            index = self._target_job_index(current, job_id)
            if index is None:
                raise ValueError(f"The selected recommendation target is no longer on {slot_id}")
            removed = current.pop(index)
            self._save_managed_recommendation_jobs(plan, slot_id, current)
            self._refresh_managed_recommendation_cells(plan, slot_id)
            backup = backup_before_mutation(self.root, self.plan_path, "remove-recommendation-target")
            save_plot_status(self.plan_path, plan, compact=True)
            self._record_history(
                "recommendation", "remove_recommendation_target",
                {"slot": slot_id, "job_id": job_id, "target": removed.get("target")},
                [backup],
            )
            return {"message": f"Removed {removed.get('target')} from the {slot_id} recommendation. Other targets were left unchanged."}

        if not all((flower_type, color, pattern)):
            raise ValueError("Choose a flower type, color, and pattern")
        preview = self.preview_managed_target(
            slot_id, scope, action, str(flower_type), str(color), str(pattern), job_id
        )
        if preview.get("warnings") and not confirmed:
            raise ValueError("Review and confirm the target warnings before saving it")

        if scope == "actual":
            status_data = load_plot_status(self.status_path)
            record = status_data.get("plots", {}).get(slot_id)
            if not record or not isinstance(record.get("cells"), list) or not record["cells"]:
                raise ValueError(f"{slot_id} has no recorded planted cells")
            jobs = actual_jobs_by_slot(status_data).get(slot_id, [])
            index = self._target_job_index(jobs, job_id) if action == "edit" else None
            assignment = dict(preview["assignment"])
            if index is not None:
                assignment["job_id"] = jobs[index].get("job_id", "primary")
                if index == 0:
                    self._write_actual_primary(record, assignment)
                else:
                    saved = list(record.get("jobs", []))
                    extra_index = index - 1
                    saved[extra_index] = assignment_snapshot(assignment)
                    record["jobs"] = saved
                record.setdefault("job_states", {}).pop(str(assignment["job_id"]), None)
            else:
                used_ids = {str(job.get("job_id")) for job in jobs}
                next_id = 1
                while f"actual-goal-{next_id}" in used_ids:
                    next_id += 1
                assignment["job_id"] = f"actual-goal-{next_id}"
                if jobs:
                    record.setdefault("jobs", []).append(assignment_snapshot(assignment))
                else:
                    self._write_actual_primary(record, assignment)
            record["target_management_locked"] = True
            record["target_tracking_explicit"] = True
            record["manual_layout"] = True
            record["layout_edited"] = True
            record["state"] = record["status"] = "planted"
            record.pop("goal_reached_at", None)
            self._reconcile_goal_states(status_data, load_inventory_data(self.inventory_path))
            backup = backup_before_mutation(self.root, self.status_path, "manage-actual-target")
            save_plot_status(self.status_path, status_data)
            self._record_history(
                "plot_status", f"{action}_actual_target",
                {"slot": slot_id, "job_id": assignment.get("job_id"), "target": assignment["target"]},
                [backup], status_data,
            )
            return {"message": f"{action.capitalize()}ed {assignment['target']} as an Actual target on {slot_id}. The recorded cells were left unchanged."}

        plan = self.load_plan()
        current = list(first_wave_jobs_by_slot(plan).get(slot_id, []))
        index = self._target_job_index(current, job_id) if action == "edit" else None
        assignment = dict(preview["assignment"])
        if index is not None:
            current[index] = assignment
        else:
            current.append(assignment)
        self._save_managed_recommendation_jobs(plan, slot_id, current)
        self._refresh_managed_recommendation_cells(plan, slot_id)
        backup = backup_before_mutation(self.root, self.plan_path, "manage-recommendation-target")
        save_plot_status(self.plan_path, plan, compact=True)
        self._record_history(
            "recommendation", f"{action}_recommendation_target",
            {"slot": slot_id, "job_id": assignment.get("job_id"), "target": assignment["target"]},
            [backup],
        )
        return {"message": f"{action.capitalize()}ed {assignment['target']} in the {slot_id} recommendation. Other targets were left unchanged."}

    @staticmethod
    def _save_managed_recommendation_jobs(plan: dict, slot_id: str, jobs: list[dict]) -> None:
        normalized = []
        for index, job in enumerate(jobs):
            item = dict(job)
            item["slot"] = slot_id
            item["supplemental"] = index > 0
            if index == 0:
                item.pop("supplemental", None)
            normalized.append(item)
        old_first_wave = list(plan.get("first_wave", []))
        first_wave = []
        inserted = False
        for job in old_first_wave:
            if str(job.get("slot", "")).upper() == slot_id:
                if normalized and not inserted:
                    first_wave.append(normalized[0])
                    inserted = True
            else:
                first_wave.append(job)
        if normalized and not inserted:
            first_wave.append(normalized[0])
        plot_jobs = {
            key: list(value)
            for key, value in plan.get("plot_jobs", {}).items()
            if str(key).upper() != slot_id and value
        }
        if len(normalized) > 1:
            plot_jobs[slot_id] = normalized[1:]
        plan["first_wave"] = first_wave
        plan["plot_jobs"] = plot_jobs
        supplemental = [job for values in plot_jobs.values() for job in values]
        plan.setdefault("method_counts", {})["first_wave"] = dict(sorted(
            Counter(row["method"] for row in first_wave + supplemental).items()
        ))
        plan.setdefault("summary", {})["first_wave_job_count"] = len(first_wave) + len(supplemental)

    def _refresh_managed_recommendation_cells(self, plan: dict, slot_id: str) -> None:
        """Recompute shared-cell chances after one plot's target list changes."""
        slot = next((item for item in all_slots() if item.slot == slot_id.upper()), None)
        if slot is None or slot.greenhouse:
            return
        jobs = first_wave_jobs_by_slot(plan).get(slot.slot, [])
        if not jobs:
            return
        planner = CollectionPlanner(self.root)
        planner.immediate_optimizer()._expand_outdoor_target_cells(slot, jobs)

    def attach_manual_plot_target(
        self,
        slot: str,
        flower_type: str,
        color: str,
        pattern: str,
        confirmed: bool = False,
    ) -> dict:
        preview = self.preview_manual_plot_target(slot, flower_type, color, pattern)
        if preview["warnings"] and not confirmed:
            raise ValueError("Review and confirm the manual-target warnings before attaching it")
        status_data = load_plot_status(self.status_path)
        record = status_data["plots"][preview["slot"]]
        planted_at = record.get("planted_at")
        edited_at = record.get("edited_at")
        action = self._upsert_manual_target(
            record, preview["assignment"], inferred=False
        )
        if planted_at:
            record["planted_at"] = planted_at
        if edited_at:
            record["edited_at"] = edited_at
        self._reconcile_goal_states(status_data, load_inventory_data(self.inventory_path))
        backup = backup_before_mutation(self.root, self.status_path, "attach-manual-target")
        save_plot_status(self.status_path, status_data)
        self._record_history(
            "plot_status",
            "attach_manual_target",
            {
                "slot": preview["slot"],
                "target": preview["target"],
                "verified": preview["verified"],
                "action": action,
            },
            [backup],
            status_data,
        )
        qualifier = "recognized from the recorded parents" if preview["verified"] else "manually specified"
        verb = "Updated" if action == "updated" else "Attached"
        attached_targets = list(preview["attached_targets"])
        if preview["target"] not in attached_targets:
            attached_targets.append(preview["target"])
        return {
            **preview,
            "already_attached": True,
            "attached_targets": attached_targets,
            "message": f"{verb} {preview['target']} on {preview['slot']} ({qualifier}).",
        }

    def preview_plot_target(
        self,
        slot: str,
        flower_type: str,
        color: str,
        pattern: str,
    ) -> dict:
        slot = slot.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot not in slots:
            raise ValueError(f"Unknown plot slot: {slot}")
        plot = slots[slot]
        planner = CollectionPlanner(self.root)
        if flower_type not in planner.active_types:
            raise ValueError(f"{flower_type} is outside the current target scope")
        if color not in planner.active_colors:
            raise ValueError(f"{color} is not available in the current platform target scope")
        compatible = {"Solid", *planner.compatible_patterns[flower_type]}
        if pattern not in compatible:
            raise ValueError(
                f"{pattern} is not compatible with {flower_type}; choose one of "
                + ", ".join(sorted(compatible))
            )
        target = Flower(flower_type, color, pattern)
        if target not in planner.targets:
            raise ValueError(
                f"{target.label()} is outside the currently enabled target categories"
            )
        if not flower_type_allowed(flower_type, plot):
            raise ValueError(
                f"{flower_type} cannot be planted in {plot.region} ({slot})"
            )

        plan = self.load_plan()
        recommended = first_wave_by_slot(plan)
        recommended_jobs = first_wave_jobs_by_slot(plan)
        actual = actual_assignments(planner.plot_status)
        actual_jobs = actual_jobs_by_slot(planner.plot_status)
        warnings: list[str] = []
        if target in planner.inventory.all:
            count = planner.inventory.physical_count(target)
            warnings.append(
                f"{target.label()} is already recorded in inventory"
                + (f" with {count} physical cop{'y' if count == 1 else 'ies'}" if count else ", but no physical copies remain")
                + "."
            )

        selected_actual = actual.get(slot)
        selected_recommended = recommended.get(slot)
        if selected_actual:
            current = self._target(selected_actual)
            if current == target:
                warnings.append(f"{target.label()} is already the planted target for {slot}.")
            else:
                warnings.append(
                    f"{slot} is currently planted for {current.label()}; changing the recommendation does not change the recorded farm until you mark the new layout Planted."
                )
        if selected_recommended and self._target(selected_recommended) == target:
            warnings.append(f"{target.label()} is already the recommended target for {slot}.")

        duplicate_slots = sorted({
            other_slot
            for assignments in (actual_jobs, recommended_jobs)
            for other_slot, jobs in assignments.items()
            if other_slot != slot and any(self._target(job) == target for job in jobs)
        })
        if duplicate_slots:
            warnings.append(
                f"{target.label()} is already targeted in: {', '.join(duplicate_slots)}."
            )

        # Model the proposed first wave, not only the farm as currently planted.
        # The selected plot is released; every other physical/planned commitment
        # stays reserved through the same authoritative context used by repacking.
        busy, _in_progress = self._other_plot_commitments(
            plan, planner.plot_status, slot
        )

        optimizer = planner.immediate_optimizer()
        assignment = optimizer.assignment_for_target(target, plot, busy)
        if assignment is None:
            without_reservations = optimizer.assignment_for_target(target, plot, Counter())
            if without_reservations is not None:
                raise ValueError(
                    f"{target.label()} has a compatible breeding route in {slot}, but its required parent copies are reserved in other planted plots."
                )
            raise ValueError(
                f"No immediately breedable route for {target.label()} in {slot} uses parents currently available in inventory and compatible with {plot.region}."
            )

        assignment["custom_target"] = True
        assignment["previous_target"] = (
            selected_recommended["target"] if selected_recommended else None
        )
        return {
            "slot": slot,
            "target": target.label(),
            "assignment": assignment,
            "warnings": warnings,
            "grid": assignment_matrix(plot, assignment),
            "cells": assignment_cell_records(plot, assignment),
        }

    def change_plot_target(
        self,
        slot: str,
        flower_type: str,
        color: str,
        pattern: str,
        confirmed: bool = False,
    ) -> dict:
        preview = self.preview_plot_target(slot, flower_type, color, pattern)
        if preview["warnings"] and not confirmed:
            raise ValueError("Review and confirm the target warnings before changing this plot")

        plan = self.load_plan()
        assignment = preview["assignment"]
        replaced = False
        first_wave = []
        for existing in plan["first_wave"]:
            if existing["slot"].upper() == preview["slot"]:
                first_wave.append(assignment)
                replaced = True
            else:
                first_wave.append(existing)
        if not replaced:
            first_wave.append(assignment)
        plan["first_wave"] = first_wave
        planner = CollectionPlanner(self.root)
        optimizer = planner.immediate_optimizer()
        busy, assigned_elsewhere = self._other_plot_commitments(
            plan, planner.plot_status, preview["slot"]
        )
        preserved_plot_jobs = {
            other_slot: jobs
            for other_slot, jobs in plan.get("plot_jobs", {}).items()
            if other_slot != preview["slot"]
        }
        custom_target = self._target(assignment)
        repack_order: list[Flower] = []
        repack_seen: set[Flower] = {custom_target}
        for candidate in plan.get("completion_schedule", []):
            try:
                target = self._target(candidate)
            except KeyError:
                continue
            if target not in repack_seen:
                repack_seen.add(target)
                repack_order.append(target)
        for target in sorted(
            planner.missing_targets,
            key=lambda flower: (planner.target_priority(flower), flower.label()),
        ):
            if target not in repack_seen:
                repack_seen.add(target)
                repack_order.append(target)
        plan["plot_jobs"] = optimizer._pack_outdoor_first_wave(
            first_wave,
            preserved_plot_jobs,
            slots_to_repack={preview["slot"]},
            candidate_order=repack_order,
            busy_seed=busy,
            in_progress_seed=assigned_elsewhere,
        )
        supplemental_jobs = [
            job for jobs in plan.get("plot_jobs", {}).values() for job in jobs
        ]
        plan.setdefault("method_counts", {})["first_wave"] = dict(sorted(
            Counter(row["method"] for row in first_wave + supplemental_jobs).items()
        ))
        plan["summary"]["first_wave_job_count"] = len(first_wave) + len(supplemental_jobs)
        # The plan can exceed several MB. Compact JSON is materially faster to
        # serialize during interactive one-plot edits and remains fully readable
        # by the app; a full Generate Plan run may still emit pretty JSON.
        save_plot_status(self.plan_path, plan, compact=True)

        status_data = load_plot_status(self.status_path)
        return {
            "message": f"Changed {preview['slot']} recommendation to {preview['target']}.",
            **preview,
        }

    def apply_plots(self, slots: list[str], confirmed: bool = False) -> dict:
        plan = self.load_plan()
        recommended = first_wave_by_slot(plan)
        recommended_jobs = first_wave_jobs_by_slot(plan)
        normalized = [slot.upper() for slot in slots]
        known_slots = {item.slot for item in all_slots()}
        unknown = [slot for slot in normalized if slot not in known_slots]
        if unknown:
            raise ValueError(f"Unknown plot slot(s): {', '.join(unknown)}")
        missing_recommendations = [slot for slot in normalized if slot not in recommended]
        if missing_recommendations:
            raise ValueError(
                f"No current recommendation for plot(s): {', '.join(missing_recommendations)}"
            )
        status_data = load_plot_status(self.status_path)
        proposed = json.loads(json.dumps(status_data))
        state_by_slot = {
            row["slot"]: row for row in self.state()["plots"]
        }
        manual_slots = [
            slot
            for slot in normalized
            if not confirmed
            if (
                proposed.get("plots", {}).get(slot, {}).get("layout_edited")
                or proposed.get("plots", {}).get(slot, {}).get("manual_layout")
            )
        ]
        applied_slots = [slot for slot in normalized if slot not in manual_slots]
        unsafe_slots = [
            slot for slot in applied_slots
            if not confirmed
            and not state_by_slot[slot].get("can_apply_recommendation")
        ]
        if unsafe_slots:
            raise ValueError(
                "Confirmation is required to replace or duplicate Actual work for plot(s): "
                + ", ".join(unsafe_slots)
            )
        slot_map = {item.slot: item for item in all_slots()}
        jobs_to_apply = {}
        for slot in applied_slots:
            slot_state = state_by_slot[slot]
            if slot_state.get("partial_update_ready"):
                jobs_to_apply[slot] = slot_state["recommended_jobs"]
            elif confirmed:
                jobs_to_apply[slot] = (
                    slot_state.get("recommended_jobs") or recommended_jobs[slot]
                )
            else:
                jobs_to_apply[slot] = recommended_jobs[slot]
        assignments_to_apply = {
            slot: jobs_to_apply[slot][0]
            for slot in applied_slots
        }
        cells_by_slot = {
            slot: sorted(
                assignments_cell_records(slot_map[slot], jobs_to_apply[slot])
                + [{key: value for key, value in cell.items() if key != "tag"}
                   for cell in state_by_slot[slot].get("recommended_cells", []) if cell.get("filler")],
                key=lambda cell: (int(cell["row"]), int(cell["col"])),
            )
            for slot in applied_slots
        }
        if applied_slots:
            record_planted(
                proposed,
                [assignments_to_apply[slot] for slot in applied_slots],
                cells_by_slot=cells_by_slot,
            )
            for slot in applied_slots:
                proposed["plots"][slot]["jobs"] = [
                    assignment_snapshot(job)
                    for job in jobs_to_apply[slot][1:]
                ]
        planner = CollectionPlanner(self.root)
        # The same count as everywhere (copies.py): a plot can't be recorded
        # with a plant that is still in another plot's ground.
        short = recording_shortfalls(owned_counts(planner.inventory), status_data, proposed)
        if short:
            raise ValueError(_shortfall_message(short, status_data, applied_slots))
        warnings = self._reservation_warnings(proposed, planner)
        backup = backup_before_mutation(self.root, self.status_path, "apply-plots")
        save_plot_status(self.status_path, proposed)
        self._record_history(
            "plot_status",
            "apply_recommendations",
            {"slots": applied_slots, "manual_slots_preserved": manual_slots},
            [backup],
            proposed,
        )
        if applied_slots:
            # Recording a replant means the plot was visited today.
            set_plots_checked(self.root, applied_slots, True)
        messages = []
        if applied_slots:
            messages.append(f"Recorded {len(applied_slots)} plot assignment(s) as planted.")
        if manual_slots:
            messages.append(
                f"Preserved the saved Actual layout for {', '.join(manual_slots)}."
            )
        message = " ".join(messages)
        if warnings:
            message += f" Inventory mismatch warning: {len(warnings)} parent variant(s)."
        return {
            "message": message,
            "warnings": warnings,
            "applied_slots": applied_slots,
            "manual_slots_preserved": manual_slots,
        }

    def update_plot_cells(self, slot: str, cells: list[dict]) -> dict:
        slot = slot.upper()
        slots = {item.slot: item for item in all_slots()}
        if slot not in slots:
            raise ValueError(f"Unknown plot slot: {slot}")
        plot = slots[slot]
        if not isinstance(cells, list):
            raise ValueError("Plot cells must be a list")
        # The same cells the editor offers (state()'s editable_cells). The shared
        # 10 × 10 Greenhouse has no fixed parent_cells, so checking against those
        # rejected every greenhouse save.
        editable = usable_cells(plot)
        planner = CollectionPlanner(self.root)
        normalized: list[dict] = []
        seen: set[tuple[int, int]] = set()
        tags: dict[tuple[int, int], str] = {}
        for cell in cells:
            row, col = int(cell["row"]), int(cell["col"])
            coordinate = (row, col)
            if cell.get("tag"):
                tags[coordinate] = str(cell["tag"]).upper()
            if coordinate not in editable:
                raise ValueError(f"Cell R{row + 1} C{col + 1} is not editable in {slot}")
            if coordinate in seen:
                raise ValueError(f"Cell R{row + 1} C{col + 1} is listed twice")
            flower = Flower(
                str(cell["flower_type"]),
                str(cell["color"]),
                str(cell["pattern"]),
                str(cell["secondary_color"]) if cell.get("secondary_color") else None,
            )
            if flower not in planner.inventory.all:
                raise ValueError(f"{flower.label()} is not recorded in inventory")
            seen.add(coordinate)
            normalized.append({
                "row": row,
                "col": col,
                "flower_type": flower.flower_type,
                "color": flower.color,
                "pattern": flower.pattern,
                "secondary_color": flower.secondary_color,
            })
        normalized.sort(key=lambda item: (item["row"], item["col"]))

        status_data = load_plot_status(self.status_path)
        proposed = json.loads(json.dumps(status_data))
        # A filler spot stays a filler (even swapped for another flower) unless
        # it's tagged as a parent; losing the tag made the next Recommendation
        # count the plot's fillers as spare and replan them.
        filler_spots = {
            (int(c["row"]), int(c["col"]))
            for c in (status_data.get("plots", {}).get(slot) or {}).get("cells", []) if c.get("filler")
        } | {(int(c["row"]), int(c["col"])) for c in cells if c.get("filler")}
        for cell in normalized:
            if (cell["row"], cell["col"]) in filler_spots and (cell["row"], cell["col"]) not in tags:
                cell["filler"] = True
        tagged_jobs = self._jobs_from_cell_tags(plot, normalized, tags, proposed) if normalized and tags else None
        if not normalized:
            proposed.setdefault("plots", {}).pop(slot, None)
        elif tagged_jobs:
            # Tagged cells give every job its real cells: the plot is recorded
            # exactly like a recommendation recorded as planted.
            record = proposed.get("plots", {}).get(slot, {})
            keep_planted_at = record.get("planted_at")
            job_states = dict(record.get("job_states", {}))
            record_planted(proposed, [tagged_jobs[0]], cells_by_slot={slot: normalized})
            updated = proposed["plots"][slot]
            updated["jobs"] = [assignment_snapshot(job) for job in tagged_jobs[1:]]
            if keep_planted_at:
                updated["planted_at"] = keep_planted_at
            updated["edited_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
            ids = {job["job_id"] for job in tagged_jobs}
            updated["job_states"] = {key: value for key, value in job_states.items() if key in ids}
            if not updated["job_states"]:
                updated.pop("job_states")
        else:
            current_plan = self.load_plan()
            recommendation = first_wave_by_slot(current_plan).get(slot)
            jobs = first_wave_jobs_by_slot(current_plan).get(slot, [])
            recommended_cells = assignments_cell_records(plot, jobs)
            saved_manual_jobs = actual_jobs_by_slot(proposed).get(slot, [])
            if (
                recommendation
                and not saved_manual_jobs
                and _canonical_cells(normalized) == _canonical_cells(recommended_cells)
            ):
                record_planted(
                    proposed,
                    [recommendation],
                    cells_by_slot={slot: normalized},
                )
                proposed["plots"][slot]["jobs"] = [
                    assignment_snapshot(job) for job in jobs[1:]
                ]
            else:
                timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds").replace(
                    "+00:00", "Z"
                )
                record = proposed.setdefault("plots", {}).setdefault(slot, {})
                previous_manual_jobs = [
                    job for job in actual_jobs_by_slot(proposed).get(slot, [])
                ]
                previous_job_states = dict(record.get("job_states", {}))
                self._detach_stale_assignment(record)
                record.update({
                    "state": "planted",
                    "status": "planted",
                    "planted_at": record.get("planted_at", timestamp),
                    "edited_at": timestamp,
                    "cells": normalized,
                    "manual_layout": True,
                    "layout_edited": True,
                })
                if previous_manual_jobs:
                    candidates = self._manual_target_candidates(slot, record, planner)
                    for previous_index, previous_manual in enumerate(previous_manual_jobs):
                        previous_target = self._target(previous_manual)
                        candidate = next(
                            (row for row in candidates if (
                                row["target_type"], row["target_color"], row["target_pattern"],
                                row.get("target_secondary_color")
                            ) == (
                                previous_target.flower_type, previous_target.color,
                                previous_target.pattern, previous_target.secondary_color
                            )),
                            None,
                        )
                        # Parent positions are presentation, not goal identity.
                        # Keep the original route while at least one copy of each
                        # parent remains; fewer copies only reduce parallel attempts.
                        from .actual_target_reconciliation import retained_route
                        candidate = retained_route(previous_manual, record, candidate)
                        source = previous_manual.get("manual_target_source", "inferred")
                        if candidate is None and source != "user":
                            continue
                        assignment = self._manual_assignment(
                            slot, record, previous_target, candidate, source
                        )
                        assignment["job_id"] = previous_manual.get("job_id") or ("primary" if previous_index == 0 else f"actual-{previous_index}")
                        assignment["supplemental"] = bool(record.get("assignment"))
                        for key in ("stock_goal", "stock_goal_reason", "propagation_goal",
                                    "propagation_goal_reason", "propagation"):
                            if key in previous_manual:
                                assignment[key] = previous_manual[key]
                        snapshot = assignment_snapshot(assignment)
                        if not record.get("assignment"):
                            record["assignment"] = snapshot
                            for key in ("target", "method", "parents", "parent_copies"):
                                record[key] = snapshot[key]
                        else:
                            record.setdefault("jobs", []).append(snapshot)
                    valid_ids = {
                        job.get("job_id", "primary")
                        for job in actual_jobs_by_slot({"plots": {slot: record}}).get(slot, [])
                    }
                    record["job_states"] = {
                        key: value for key, value in previous_job_states.items()
                        if key in valid_ids
                    }
        warnings = self._reservation_warnings(proposed, planner)
        backup = backup_before_mutation(self.root, self.status_path, "edit-plot-cells")
        save_plot_status(self.status_path, proposed)
        self._record_history(
            "plot_status",
            "edit_plot_cells",
            {"slot": slot, "planted_cells": len(normalized)},
            [backup],
            proposed,
        )
        message = f"Saved {len(normalized)} planted flower(s) in {slot}."
        if warnings:
            message += f" Inventory mismatch warning: {len(warnings)} parent variant(s)."
        return {
            "message": message,
            "planted_cells": len(normalized),
            "warnings": warnings,
        }

    def _jobs_from_cell_tags(self, plot, cells: list[dict], tags: dict[tuple[int, int], str],
                             status_data: dict) -> list[dict] | None:
        """Jobs with cell layouts built from the editor's job tags (None: no tagged job)."""
        from .job_tags import jobs_from_tags

        slot = plot.slot
        previous = []
        for index, job in enumerate(actual_jobs_by_slot(status_data).get(slot, [])):
            previous.append({**job, "job_id": self._job_record_key(job, index)})
        flowers = {
            (int(c["row"]), int(c["col"])): Flower(c["flower_type"], c["color"], c["pattern"], c.get("secondary_color"))
            for c in cells
        }
        meta = {"slot": slot, "plot": plot.plot, "region": plot.region, "plot_spots": plot.spots}
        jobs, problems = jobs_from_tags(meta, flowers, tags, set(usable_cells(plot)), previous)
        if problems:
            raise ValueError("Job tags: " + "; ".join(problems))
        if not jobs:
            return None
        used = {job.get("job_id") for job in jobs if job.get("job_id")}
        number = 1
        for job in jobs:
            if not job.get("job_id"):
                while f"tag-{number}" in used:
                    number += 1
                job["job_id"] = f"tag-{number}"
                used.add(job["job_id"])
            job["supplemental"] = job is not jobs[0]
        return jobs

    def clear_plots(self, slots: list[str]) -> dict:
        status_data = load_plot_status(self.status_path)
        normalized = [slot.upper() for slot in slots]
        records = status_data.get("plots", {})
        unknown = [slot for slot in normalized if slot not in records]
        if unknown:
            raise ValueError(f"Plot(s) are not recorded as planted: {', '.join(unknown)}")
        removed = clear_status(status_data, normalized)
        backup = backup_before_mutation(self.root, self.status_path, "clear-plots")
        save_plot_status(self.status_path, status_data)
        self._record_history(
            "plot_status",
            "clear_plots",
            {"slots": normalized, "removed": removed},
            [backup],
            status_data,
        )
        return {"message": f"Cleared {removed} planted assignment(s)."}

    @staticmethod
    def _cannot_appear_in(assignment: dict, slot: str, fertilized: bool) -> str | None:
        """Why this target can't have appeared in ``slot`` today, or None if it can.

        Catches a find filed under the wrong plot, e.g. a Greenhouse find
        recorded with an outdoor plot's Found button because that plot had the
        same target.
        """
        plot = next((s for s in all_slots() if s.slot == slot), None)
        flower_type = FLOWER_TYPES.get(assignment.get("target_type", ""))
        if plot is None or flower_type is None:
            return None
        target = assignment.get("target", "This flower")
        if not plot.greenhouse and flower_type.event and flower_type.event not in events_on(game_today()):
            # Fertilizer still turns a planted event flower into its own default pattern.
            if not (fertilized and assignment.get("target_pattern") == flower_type.default_pattern):
                return (f"{target} can't have appeared in {slot} today: outside {flower_type.event}, "
                        f"new {flower_type.name} only appear in the Greenhouse.")
        if not fertilized and not flower_type_allowed(flower_type.name, plot):
            return f"{target} can't have appeared in {slot}: {flower_type.name} doesn't grow in {plot.region}."
        return None

    def found(self, slot: str, count: int = 1, job_id: str | None = None,
              cell: list[int] | None = None, dug_up: bool = False, replaced: bool = False,
              found_in: str | None = None) -> dict:
        """Record ``count`` new copies of a planted job's target.

        A fertilizer find changes a planted solid into its native pattern in
        place: the solid's count drops, the patterned flower's rises, and the
        plot records the new flower in that cell (``cell``, or the first bed
        cell still holding the solid), or nothing there when ``dug_up``. When
        ``replaced``, the find was dug up and a spare solid planted in its
        place, so the cell and bed stay as they were.

        ``found_in`` is where it actually appeared when that isn't this plot:
        another plot's slot (e.g. "GH") or "inventory" (spotted while going
        through the inventory). The copy is added and the target's goal
        updated, but this plot's plants are left as they are.
        """
        if count < 1:
            raise ValueError("Count must be at least 1")
        slot = slot.upper()
        found_in = (found_in or slot).strip()
        found_in = "inventory" if found_in.lower() == "inventory" else found_in.upper()
        elsewhere = found_in != slot
        status_data = load_plot_status(self.status_path)
        jobs = actual_jobs_by_slot(status_data).get(slot, [])
        if not jobs:
            raise ValueError(f"{slot} has no recorded planted assignment")
        assignment_index = 0
        if job_id:
            matches = [
                index for index, job in enumerate(jobs)
                if self._job_record_key(job, index) == job_id
            ]
            if not matches:
                raise ValueError(f"{slot} has no planted breeding job {job_id}")
            assignment_index = matches[0]
        assignment = jobs[assignment_index]
        selected_job_id = self._job_record_key(assignment, assignment_index)
        fertilized = str(assignment.get("method", "")).startswith("fertilize_") and assignment.get("parent_flowers")
        if not elsewhere:
            reason = self._cannot_appear_in(assignment, slot, bool(fertilized))
            if reason:
                raise ValueError(f"{reason} If you found it somewhere else, use \"Found it somewhere else?\".")
        inventory_data = load_inventory_data(self.inventory_path)
        update = normalize_update(
            inventory_data,
            assignment["target_type"],
            assignment["target_color"],
            assignment["target_pattern"],
            secondary_color=assignment.get("target_secondary_color"),
        )[0]
        incremented = increment_update(inventory_data, update, count)
        updated, _ = apply_updates(inventory_data, [incremented])
        total = recorded_count(updated, incremented)
        changed_cells: list[tuple[int, int]] = []
        if fertilized and not elsewhere:
            solid = assignment["parent_flowers"][0]
            solid_update = normalize_update(
                updated, solid["flower_type"], solid["color"], solid["pattern"],
                secondary_color=solid.get("secondary_color"),
            )[0]
            if replaced:
                spare = recorded_count(updated, solid_update) - planted_counts(status_data)[Flower(
                    solid["flower_type"], solid["color"], solid["pattern"], solid.get("secondary_color"))]
                if spare < count:
                    raise ValueError(f"No spare {assignment['parents'][0]} in inventory to replant in its place")
            left = max(0, recorded_count(updated, solid_update) - count)
            updated, _ = apply_updates(updated, [normalize_update(
                updated, solid["flower_type"], solid["color"], solid["pattern"], count=left,
                secondary_color=solid.get("secondary_color"),
            )[0]])
            changed_cells = self._fertilized_in_plot(
                status_data["plots"][slot], assignment_index, solid, assignment, count, cell, dug_up, replaced
            )
        goal = effective_stock_goal(assignment)
        reached = total >= goal
        record = status_data["plots"][slot]
        if reached:
            record.setdefault("job_states", {})[selected_job_id] = {
                "state": "goal_reached",
                "goal_reached_at": datetime.now(timezone.utc).isoformat(
                    timespec="seconds"
                ).replace("+00:00", "Z"),
            }
            all_reached = True
            for job in jobs:
                job_update = normalize_update(
                    updated,
                    job["target_type"],
                    job["target_color"],
                    job["target_pattern"],
                    secondary_color=job.get("target_secondary_color"),
                )[0]
                if recorded_count(updated, job_update) < effective_stock_goal(job):
                    all_reached = False
                    break
            if all_reached:
                mark_goal_reached(status_data, slot)
        inventory_backup = backup_before_mutation(
            self.root, self.inventory_path, "record-found-target"
        )
        status_backup = (
            backup_before_mutation(self.root, self.status_path, "mark-goal-reached")
            if reached or changed_cells
            else None
        )
        save_inventory_atomic(self.inventory_path, updated)
        if reached or changed_cells:
            save_plot_status(self.status_path, status_data)
        self._record_history(
            "inventory",
            "found_target",
            {
                "slot": slot,
                "job_id": selected_job_id,
                "found_in": found_in,        # where it appeared: this plot, another one, or "inventory"
                "flower": assignment["target"],
                "added": count,
                "total": total,
                "goal": goal,
                "goal_reached": reached,
            },
            [inventory_backup, status_backup],
            status_data,
        )
        message = f"Added {count} × {assignment['target']}."
        if elsewhere:
            message += f" {slot}'s plants are unchanged."
        elif fertilized:
            where = ", ".join(f"R{r + 1}·C{c + 1}" for r, c in changed_cells)
            message += (f" Removed {count} × {assignment['parents'][0]} from inventory"
                        + (f"; {where} " + (f"replanted with {assignment['parents'][0]}." if replaced
                                             else "dug up." if dug_up else "now holds the new flower.")
                           if where else "."))
        return {
            "message": message,
            "total": total,
            "goal": goal,
            "goal_reached": reached,
            "job_id": selected_job_id,
        }

    @staticmethod
    def _fertilized_in_plot(record: dict, job_index: int, solid: dict, assignment: dict, count: int,
                            cell: list[int] | None, dug_up: bool,
                            replaced: bool = False) -> list[tuple[int, int]]:
        """Turn fertilized bed plants into the target (or clear them when dug up).

        Replaced plants are left alone: a spare solid now stands in their spot.
        """
        key = lambda c: (c.get("flower_type"), c.get("color"), c.get("pattern"), c.get("secondary_color"))
        solid_key = key(solid)
        stored = record.get("assignment") if job_index == 0 else (record.get("jobs") or [None] * job_index)[job_index - 1]
        layout = (stored or {}).get("layout") or {}
        bed = [(int(c[0]), int(c[1])) for c in layout.get("parent_a_cells") or []]
        cells = {(int(c["row"]), int(c["col"])): c for c in record.get("cells", [])}
        candidates = [c for c in bed if c in cells and key(cells[c]) == solid_key]
        candidates += [c for c in sorted(cells) if key(cells[c]) == solid_key and c not in candidates]
        if cell is not None and (int(cell[0]), int(cell[1])) in candidates:
            chosen = (int(cell[0]), int(cell[1]))
            candidates.remove(chosen)
            candidates.insert(0, chosen)
        changed = candidates[:count]
        if replaced:
            return changed
        for coordinate in changed:
            if dug_up:
                record["cells"] = [c for c in record["cells"]
                                   if (int(c["row"]), int(c["col"])) != coordinate]
            else:
                cells[coordinate].update({
                    "flower_type": assignment["target_type"],
                    "color": assignment["target_color"],
                    "pattern": assignment["target_pattern"],
                    "secondary_color": assignment.get("target_secondary_color"),
                })
            if coordinate in bed:
                layout["parent_a_cells"] = [c for c in layout["parent_a_cells"]
                                            if (int(c[0]), int(c[1])) != coordinate]
                copies = list(stored.get("parent_copies") or [len(bed)])
                copies[0] = max(0, int(copies[0]) - 1)
                stored["parent_copies"] = copies
        return changed

    def plant_changed(
        self, slot: str, row: int, col: int, pattern: str, dug_up: bool = False, replaced: bool = False,
    ) -> dict:
        """A planted flower changed pattern by accident, e.g. stray fertilizer.

        Like a fertilizer find, but for any planted cell: the old flower's
        count drops by one, the new one's rises by one, and the cell holds the
        new flower (or is emptied when it was dug up, or keeps the original
        flower when a spare copy was planted in its place).
        """
        slot = slot.upper()
        status_data = load_plot_status(self.status_path)
        record = status_data.get("plots", {}).get(slot)
        if not isinstance(record, dict):
            raise ValueError(f"{slot} has no recorded planted layout")
        cell = next((c for c in record.get("cells", [])
                     if int(c["row"]) == int(row) and int(c["col"]) == int(col)), None)
        if cell is None:
            raise ValueError(f"Nothing is planted at R{int(row) + 1}·C{int(col) + 1} in {slot}")
        if pattern == cell["pattern"]:
            raise ValueError(f"That plant is already {pattern}")
        old_flower = Flower(cell["flower_type"], cell["color"], cell["pattern"], cell.get("secondary_color"))
        old_label = old_flower.label()
        inventory_data = load_inventory_data(self.inventory_path)
        if replaced:
            recorded = recorded_count(inventory_data, normalize_update(
                inventory_data, cell["flower_type"], cell["color"], cell["pattern"],
                secondary_color=cell.get("secondary_color"),
            )[0])
            if recorded - planted_counts(status_data)[old_flower] < 1:
                raise ValueError(f"No spare {old_label} in inventory to replant in its place")
        new_update = normalize_update(inventory_data, cell["flower_type"], cell["color"], pattern)[0]
        updated, _ = apply_updates(inventory_data, [increment_update(inventory_data, new_update, 1)])
        old_update = normalize_update(
            updated, cell["flower_type"], cell["color"], cell["pattern"],
            secondary_color=cell.get("secondary_color"),
        )[0]
        left = max(0, recorded_count(updated, old_update) - 1)
        updated, _ = apply_updates(updated, [normalize_update(
            updated, cell["flower_type"], cell["color"], cell["pattern"], count=left,
            secondary_color=cell.get("secondary_color"),
        )[0]])
        new_label = Flower(cell["flower_type"], cell["color"], pattern, new_update.secondary_color).label()
        was_parent = bool(cell.get("parent_role"))
        if replaced:
            was_parent = False
        elif dug_up:
            record["cells"] = [c for c in record["cells"] if c is not cell]
        else:
            cell.update({"pattern": pattern, "secondary_color": new_update.secondary_color})
            cell.pop("parent_role", None)
        inventory_backup = backup_before_mutation(self.root, self.inventory_path, "plant-changed")
        status_backup = backup_before_mutation(self.root, self.status_path, "plant-changed")
        save_inventory_atomic(self.inventory_path, updated)
        save_plot_status(self.status_path, status_data)
        self._record_history(
            "inventory", "plant_changed",
            {"slot": slot, "cell": [int(row), int(col)], "from": old_label, "to": new_label, "dug_up": dug_up,
             "replaced": replaced},
            [inventory_backup, status_backup], status_data,
        )
        where = f"{slot} R{int(row) + 1}·C{int(col) + 1}"
        message = f"{old_label} at {where} became {new_label}" + (
            f" and was replaced with another {old_label}." if replaced
            else " and was dug up." if dug_up else ".")
        message += f" Inventory: {old_label} −1, {new_label} +1."
        if was_parent:
            message += " It was a parent, so replant the plot to update its jobs."
        return {"message": message, "was_parent": was_parent}

    def record_spawns(self, entries: list[dict], slot: str | None = None, abundance_limit: int = 30) -> dict:
        """Commit a spawn review as one inventory mutation and history entry.

        Counts are *actual* counts for scarce flowers; abundant entries are
        optionally skipped, never silently clamped in the underlying inventory.
        """
        if not isinstance(entries, list) or not 1 <= len(entries) <= 150:
            raise ValueError("Choose between 1 and 150 spawn entries")
        if not isinstance(abundance_limit, int) or not 10 <= abundance_limit <= 1000:
            raise ValueError("Invalid abundance threshold")
        data = load_inventory_data(self.inventory_path)
        planner = CollectionPlanner(self.root)
        increments = Counter()
        omitted = []
        for row in entries:
            if not isinstance(row, dict):
                raise ValueError("Invalid spawn entry")
            amount = row.get("count")
            if type(amount) is not int or not 1 <= amount <= 999:
                raise ValueError("Spawn quantities must be between 1 and 999")
            update = normalize_update(
                data, row["flower_type"], row["color"], row["pattern"],
                secondary_color=row.get("secondary_color"),
            )[0]
            increments[update] += amount
        if slot:
            # Spawns filed under a plot that can't have produced them (an
            # out-of-season event flower outdoors, a type outside the region).
            # A planted flower fertilized into its default pattern still can.
            problems = []
            for update in increments:
                flower_type = FLOWER_TYPES.get(update.flower_type)
                reason = self._cannot_appear_in(
                    {"target": update.label(), "target_type": update.flower_type,
                     "target_pattern": update.pattern},
                    str(slot).upper(),
                    bool(flower_type and update.pattern == flower_type.default_pattern),
                )
                if reason:
                    problems.append(reason)
            if problems:
                raise ValueError(" ".join(problems) + " Choose the plot it came from, or All plots.")
        updates = []
        changes = []
        for update, amount in increments.items():
            flower = Flower(update.flower_type, update.color, update.pattern, update.secondary_color)
            before = planner.inventory.physical_count(flower)
            if before >= abundance_limit and update.pattern == "Solid" and flower in planner.inventory.all:
                omitted.append(update.label())
                continue
            new_count = before + amount
            updates.append(type(update)(update.flower_type, update.color, update.pattern, new_count, update.secondary_color))
            changes.append({"flower": update.label(), "added": amount, "before": before, "after": new_count})
        if not updates:
            return {"message": "All selected plants were already abundant; no counts changed.", "skipped": omitted}
        updated, _ = apply_updates(data, updates)
        status_data = load_plot_status(self.status_path)
        changed = self._reconcile_goal_states(status_data, updated)
        backup = backup_before_mutation(self.root, self.inventory_path, "record-spawns")
        status_backup = backup_before_mutation(self.root, self.status_path, "reconcile-spawns") if changed else None
        save_inventory_atomic(self.inventory_path, updated)
        if changed:
            save_plot_status(self.status_path, status_data)
        self._record_history(
            "inventory", "record_spawns",
            {"slot": slot, "changes": changes, "skipped_abundant": omitted},
            [backup, status_backup], status_data,
        )
        return {"message": f"Recorded {sum(x['added'] for x in changes)} new plants across {len(changes)} variants." + (f" Skipped {len(omitted)} abundant variants." if omitted else ""), "changes": changes, "skipped": omitted}

    def update_inventory(
        self,
        action: str,
        flower_type: str,
        color: str,
        pattern: str,
        count: int,
        secondary_color: str | None = None,
    ) -> dict:
        if action not in {"set", "add", "uncollect"}:
            raise ValueError("Inventory action must be 'set', 'add', or 'uncollect'")
        if count < 0 or (action == "add" and count < 1):
            raise ValueError("Invalid inventory count")
        data = load_inventory_data(self.inventory_path)
        update = normalize_update(
            data, flower_type, color, pattern, secondary_color=secondary_color
        )[0]
        flower = Flower(
            update.flower_type, update.color, update.pattern, update.secondary_color
        )
        planner = CollectionPlanner(self.root)
        if action == "uncollect":
            if flower not in planner.inventory.all:
                return {"message": f"{flower.label()} is already uncollected.", "total": 0}
            current = planner.inventory.physical_count(flower)
            planted = planted_counts(load_plot_status(self.status_path))[flower]
            if current != 0:
                raise ValueError(
                    f"Set {flower.label()} total to 0 before marking it uncollected"
                )
            if planted:
                raise ValueError(
                    f"Cannot mark {flower.label()} uncollected; {planted} copies are planted"
                )
            updated, changed = mark_uncollected(data, update)
            if not changed:
                return {"message": f"{flower.label()} is already uncollected.", "total": 0}
            backup = backup_before_mutation(
                self.root, self.inventory_path, "mark-uncollected"
            )
            status_data = load_plot_status(self.status_path)
            status_changed = self._reconcile_goal_states(status_data, updated)
            status_backup = (
                backup_before_mutation(self.root, self.status_path, "reconcile-goals")
                if status_changed
                else None
            )
            save_inventory_atomic(self.inventory_path, updated)
            if status_changed:
                save_plot_status(self.status_path, status_data)
            self._record_history(
                "inventory",
                "mark_uncollected",
                {"flower": flower.label(), "previous_total": 0, "new_total": 0},
                [backup, status_backup],
                status_data,
            )
            return {"message": f"{flower.label()} marked uncollected.", "total": 0}

        if action == "add":
            current = planner.inventory.physical_count(flower)
            update = type(update)(
                update.flower_type,
                update.color,
                update.pattern,
                current + count,
                update.secondary_color,
            )
        else:
            update = type(update)(
                update.flower_type,
                update.color,
                update.pattern,
                count,
                update.secondary_color,
            )
        planted = planted_counts(load_plot_status(self.status_path))[flower]
        if planted > int(update.count or 0):
            raise ValueError(
                f"Cannot set {flower.label()} to {update.count}; {planted} copies are planted"
            )
        updated, _ = apply_updates(data, [update])
        previous = planner.inventory.physical_count(flower)
        backup = backup_before_mutation(self.root, self.inventory_path, "update-inventory")
        status_data = load_plot_status(self.status_path)
        status_changed = self._reconcile_goal_states(status_data, updated)
        status_backup = (
            backup_before_mutation(self.root, self.status_path, "reconcile-goals")
            if status_changed
            else None
        )
        save_inventory_atomic(self.inventory_path, updated)
        if status_changed:
            save_plot_status(self.status_path, status_data)
        self._record_history(
            "inventory",
            f"{action}_inventory",
            {
                "flower": flower.label(),
                "previous_total": previous,
                "new_total": update.count,
            },
            [backup, status_backup],
            status_data,
        )
        return {
            "message": f"{flower.label()} total is now {update.count}.",
            "total": update.count,
            "inventory_item": {
                "flower_type": flower.flower_type, "color": flower.color,
                "pattern": flower.pattern, "secondary_color": flower.secondary_color,
                "label": flower.label(), "collected": True,
                "total": int(update.count), "total_label": str(update.count),
                "planted": planted_counts(status_data)[flower],
                "free": max(0, int(update.count) - planted_counts(status_data)[flower]),
                "over_reserved": 0, "abundant": False,
                "in_scope": flower in planner.targets,
                "extremophile": bool(FLOWER_TYPES[flower.flower_type].extreme),
                "blocked": False,
            },
            "collection_delta": int(flower in planner.targets and flower not in planner.inventory.all),
        }

    def plan_generation_status(self) -> dict:
        with self._generation_lock:
            status = dict(self._generation_status)
        if status.get("state") in ("starting", "running"):
            # run_solver.py reports how far it has got (hkia_solver/progress.py).
            try:
                status["progress"] = json.loads((self.root / "output" / "plan_progress.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                pass
        return status

    def start_plan_generation(self, **kwargs) -> dict:
        with self._generation_lock:
            if self._generation_status["state"] in ("starting", "running"):
                raise ValueError("Plan generation is already running")
            self._generation_status = {
                "state": "starting", "message": "Starting plan generation…",
                "started_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            }
            (self.root / "output" / "plan_progress.json").unlink(missing_ok=True)   # last run's

        def work():
            with self._generation_lock:
                self._generation_status.update(state="running", message="Calculating recommendations…")
            try:
                result = self.generate_plan(**kwargs)
            except Exception as error:
                with self._generation_lock:
                    cancelled = "cancel" in str(error).lower()
                    self._generation_status.update(
                        state="cancelled" if cancelled else "failed", message=str(error),
                        finished_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    )
            else:
                with self._generation_lock:
                    self._generation_status.update(
                        state="completed", message=result.get("message", "Plan generated."),
                        finished_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    )

        threading.Thread(target=work, daemon=True, name="hkia-plan-generation").start()
        return self.plan_generation_status()

    def _run_solver(self, args: list[str]) -> tuple[int, str, str, bool]:
        """Run run_solver.py in its own process: (returncode, stdout, stderr, cancelled).

        The browser build (no processes there) runs it in-process instead.
        """
        with self._plan_process_lock:
            process = subprocess.Popen(
                [sys.executable, str(self.solver_script), *args],
                cwd=PROGRAM_ROOT,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=_solver_env(),
            )
            self._plan_process = process
        try:
            stdout, stderr = process.communicate()
        finally:
            with self._plan_process_lock:
                cancelled = self._plan_cancel_requested
                if self._plan_process is process:
                    self._plan_process = None
                self._plan_cancel_requested = False
        return process.returncode, stdout, stderr, cancelled

    def generate_plan(
        self,
        target_categories: dict | None = None,
        replant_all: bool = False,
    ) -> dict:
        original_settings_text = (
            self.settings_path.read_text(encoding="utf-8")
            if self.settings_path.exists()
            else "{}\n"
        )
        original_settings = json.loads(original_settings_text)
        requested = dict(original_settings)
        if target_categories is not None:
            if not isinstance(target_categories, dict):
                raise ValueError("Target categories must be an object")
            unknown = set(target_categories) - set(TARGET_CATEGORY_ORDER)
            if unknown:
                raise ValueError(
                    "Unknown target categories: " + ", ".join(sorted(unknown))
                )
            current = normalized_target_categories(original_settings)
            requested["target_categories"] = {
                key: bool(target_categories.get(key, current[key]))
                for key in TARGET_CATEGORY_ORDER
            }
        normalized = normalized_target_categories(requested)
        if not any(
            normalized[key]
            for key in TARGET_CATEGORY_ORDER
            if key != "non_default_secondary_patterns"
        ):
            raise ValueError("Enable at least one supported target category")
        if target_categories is not None:
            requested["target_categories"] = normalized
        settings_changed = requested != original_settings
        settings_backup = None

        args = ["--quick", "--data-dir", str(self.root)]
        if replant_all:
            args.append("--replant-all")
        with self._plan_process_lock:
            if self._plan_process is not None and self._plan_process.poll() is None:
                raise ValueError("A recommendation update is already running")
            if settings_changed:
                settings_backup = backup_before_mutation(
                    self.root, self.settings_path, "update-target-categories"
                )
                save_inventory_atomic(self.settings_path, requested)
            self._plan_cancel_requested = False
        try:
            returncode, stdout, stderr, cancelled = self._run_solver(args)
        except Exception:
            if settings_changed:
                temporary = self.settings_path.with_name(
                    self.settings_path.name + ".restore.tmp"
                )
                temporary.write_text(original_settings_text, encoding="utf-8")
                temporary.replace(self.settings_path)
            raise
        if returncode:
            if settings_changed:
                temporary = self.settings_path.with_name(
                    self.settings_path.name + ".restore.tmp"
                )
                temporary.write_text(original_settings_text, encoding="utf-8")
                temporary.replace(self.settings_path)
            if cancelled:
                raise ValueError("Recommendation update cancelled")
            raise ValueError(stderr.strip() or stdout.strip() or "Plan generation failed")
        plan = self.load_plan()
        status_data = load_plot_status(self.status_path)
        reconciled = self._reconcile_manual_assignments(plan, status_data)
        if reconciled["linked"] or reconciled["detached"]:
            backup = backup_before_mutation(
                self.root, self.status_path, "reconcile-manual-plots"
            )
            save_plot_status(self.status_path, status_data)
            self._record_history(
                "plot_status",
                "reconcile_manual_assignments",
                reconciled,
                [backup],
                status_data,
            )
        message = "Plan generated."
        if reconciled["linked"]:
            message += (
                " Updated target metadata for manual layout(s): "
                + ", ".join(reconciled["linked"])
                + "."
            )
        if settings_changed:
            self._record_history(
                "settings",
                "update_target_categories",
                {key: normalized[key] for key in TARGET_CATEGORY_ORDER},
                [settings_backup],
                status_data,
            )
            message += " Target categories were saved."
        if self.auto_flow_forecast:
            try:
                # Re-apply a finished forecast whose inputs are unchanged; the
                # forecast itself only runs from the Roadmap tab's button.
                self.start_flow_forecast(reuse_only=True)
            except Exception as error:  # the plan itself is fine; report and continue
                message += f" The Roadmap forecast could not be re-applied: {error}"
        return {
            "message": message,
            "log": stdout.strip(),
            "reconciled": reconciled,
            "target_categories": normalized,
        }

    auto_flow_forecast = True  # Generate plan starts the Roadmap forecast (tests turn this off)
    _flow_forecast_processes: dict = {}
    _flow_forecast_lock = threading.Lock()

    def start_flow_forecast(self, force: bool = False, reuse_only: bool = False, full: bool = False) -> dict:
        """Run the FLOW roadmap forecast in the background.

        ``force`` (the Roadmap tab's button) always computes a fresh forecast,
        replacing a run for older inputs. ``reuse_only`` (after Generate plan)
        never computes and never disturbs a running forecast: it only
        re-applies a finished forecast whose inputs are unchanged.
        """
        from .flow.forecast import inputs_key

        root_key = str(self.root)
        inputs = inputs_key(self.root)
        with self._flow_forecast_lock:
            previous = self._flow_forecast_processes.get(root_key)
            if previous is not None and previous[0].poll() is None:
                if reuse_only or (previous[1] == inputs and not force):
                    return self.flow_roadmap()
                previous[0].terminate()
            log_dir = self.root / "output" / "flow"
            log_dir.mkdir(parents=True, exist_ok=True)
            command = [sys.executable, str(PROGRAM_ROOT / "run_flow_forecast.py"), "--data-dir", str(self.root)]
            if force:
                command.append("--force")
            if full:
                command.append("--full")
            elif reuse_only:
                command.append("--reuse-only")
            with open(log_dir / ("forecast.reuse.log" if reuse_only else "forecast.log"), "w",
                      encoding="utf-8") as log:
                process = subprocess.Popen(
                    command, cwd=PROGRAM_ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                    env=_solver_env(),
                )
            if not reuse_only:  # a quick re-apply is not "the forecast is running"
                self._flow_forecast_processes[root_key] = (process, inputs)
        return self.flow_roadmap()

    def flow_forecast_running(self) -> bool:
        entry = self._flow_forecast_processes.get(str(self.root))
        return entry is not None and entry[0].poll() is None

    def flow_roadmap(self) -> dict:
        from .flow.roadmap import roadmap_view
        return roadmap_view(self.root, running=self.flow_forecast_running())

    def update_plot_recommendation(self, slot: str) -> dict:
        """A fresh FLOW layout for one plot; every other plot stays as planned."""
        from .flow.integrate import refresh_plot

        slot = slot.upper()
        if slot not in {item.slot for item in all_slots()}:
            raise ValueError(f"Unknown plot slot: {slot}")
        plan = self.load_plan()
        if plan.get("summary", {}).get("planner") != "flow":
            raise ValueError("Generate a FLOW plan first; this plot can then be refreshed on its own.")
        jobs = refresh_plot(CollectionPlanner(self.root), plan, slot)
        plan["first_wave"] = [job for job in plan["first_wave"] if job["slot"].upper() != slot] + jobs[:1]
        plan.setdefault("plot_jobs", {}).pop(slot, None)
        if len(jobs) > 1:
            plan["plot_jobs"][slot] = jobs[1:]
        flow = plan.setdefault("flow", {})
        flow["replanted_plots"] = sorted(set(flow.get("replanted_plots", [])) | {slot})
        save_plot_status(self.plan_path, plan, compact=True)
        breeding = [job for job in jobs if job["method"] != "fertilize_pattern"]
        beds = len(jobs) - len(breeding)
        summary = (f"{len(breeding)} breeding job(s)" + (f" and {beds} fertilizer bed(s)" if beds else "")
                   if jobs else "nothing (no spare copies fit here right now)")
        return {
            "message": f"Replanned {slot} from scratch: {summary}. Other plot recommendations were left unchanged.",
            "slot": slot,
            "assignment": jobs[0] if jobs else None,
            "jobs": len(jobs),
        }

    def mark_plant_missing(
        self,
        slot: str,
        flower_type: str,
        color: str,
        pattern: str,
        secondary_color: str | None = None,
        free: int = 0,
    ) -> dict:
        """A recommended parent turned out to have fewer spare copies than recorded:
        set its total to planted + ``free``, then replan ``slot`` with that stock."""
        if free < 0:
            raise ValueError("Free copies can't be negative")
        # Check the replan can run before changing inventory, so a refusal changes nothing.
        if self.load_plan().get("summary", {}).get("planner") != "flow":
            raise ValueError("Generate a FLOW plan first; this plot can then be refreshed on its own.")
        flower = Flower(flower_type, color, pattern, secondary_color or None)
        planted = planted_counts(load_plot_status(self.status_path))[flower]
        self.update_inventory("set", flower_type, color, pattern, planted + free, secondary_color or None)
        replanned = self.update_plot_recommendation(slot)
        return {
            **replanned,
            "message": (
                f"{flower.label()} set to {planted + free} total ({free} free). "
                + replanned["message"]
            ),
        }

    def cancel_plan(self) -> dict:
        with self._plan_process_lock:
            process = self._plan_process
            if process is None or process.poll() is not None:
                return {"message": "No recommendation solver process is running."}
            self._plan_cancel_requested = True
            process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=5)
        return {"message": "Recommendation update cancelled."}
