"""Shape the FLOW forecast for the dashboard's Roadmap tab (kept small for phones)."""
from __future__ import annotations

import datetime as dt
import json
from collections import Counter
from pathlib import Path

from ..paths import farm_data_path
from .forecast import forecast_path, inputs_key, load_json, partial_path
from .integrate import cogimyun_setting
from .scheduler import game_today

UPCOMING_DAYS = 365
UPCOMING_LIMIT = 600


def roadmap_view(root: Path, *, running: bool, today: dt.date | None = None) -> dict:
    today = today or game_today()
    plan_key = None
    plan_path = root / "output" / "latest_plan.json"
    if plan_path.is_file():
        try:
            plan_key = json.loads(plan_path.read_text(encoding="utf-8")).get("summary", {}).get("planning_input_key")
        except ValueError:
            plan_key = None
    # The Cogimyun switch lives on this tab: it changes the forecast, not the day's plan.
    try:
        flow = (load_json(farm_data_path(root, "settings.json")) or {}).get("flow") or {}
    except Exception:
        flow = {}
    view = {"running": running, "available": False, "cogimyun": cogimyun_setting(flow)}
    # The last finished forecast stays on screen while a new one runs.
    final = load_json(forecast_path(root))
    partial = load_json(partial_path(root)) if running else None
    forecast = final or partial
    if forecast is None:
        return view
    if partial is not None:
        p_as_of = dt.date.fromisoformat(partial["as_of"])
        view["progress"] = {
            "as_of": partial["as_of"],
            "simulated_through": (p_as_of + dt.timedelta(days=partial.get("days_simulated") or 0)).isoformat(),
        }
    if forecast.get("inputs_key"):
        try:
            stale = forecast["inputs_key"] != inputs_key(root, today)
        except Exception:  # an unreadable inventory should not hide the roadmap
            stale = False
    else:
        stale = forecast.get("planning_input_key") != plan_key
    as_of = dt.date.fromisoformat(forecast["as_of"])
    offset = (today - as_of).days            # days since the forecast's own day 0
    rows = forecast.get("schedule", [])
    upcoming = [r for r in rows if offset <= r["finish_day"] <= offset + UPCOMING_DAYS][:UPCOMING_LIMIT]
    by_region = Counter(r["region"] or "Fertilizer bed" for r in upcoming)
    view.update({
        "available": True,
        "status": forecast.get("status"),
        "stale": stale,
        "showing_previous": final is not None and running,
        "as_of": forecast["as_of"],
        "generated_at": forecast.get("generated_at"),
        "days_simulated": forecast.get("days_simulated"),
        "simulated_through": (as_of + dt.timedelta(days=forecast.get("days_simulated") or 0)).isoformat(),
        "settings": forecast.get("settings", {}),
        "counts": forecast.get("counts", {}),
        "milestones": forecast.get("milestones", {}),
        "island": forecast.get("island"),
        "events": [e for e in forecast.get("events", []) if e["end"] >= today.isoformat()],
        "upcoming": [{k: r.get(k) for k in ("target", "target_type", "target_color", "target_pattern", "date",
                                             "finish_day", "slot", "plot", "region", "method", "parents", "phase")}
                     for r in upcoming],
        "upcoming_by_region": dict(by_region.most_common()),
        "horizon_days": forecast.get("horizon_days"),
        "engine": forecast.get("engine", "planner"),
    })
    return view
