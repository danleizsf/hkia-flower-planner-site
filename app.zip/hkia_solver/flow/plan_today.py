"""Turn FLOW's day-one decision into a physically valid, cell-level plan.

The simulator (``scheduler.FlowSimulator``) decides which hub works on which
front. For a forecast it may assume more recipient copies than exist and plans
from an empty farm. This module runs the same decision once, for today, with:

* every donor and recipient limited to its free physical copies;
* hubs already planted correctly kept in place (stickiness), so re-planning
  after you record spawns only refills seats that freed up;
* the result expanded to exact cells in the dashboard's plan format
  (``first_wave`` + ``plot_jobs``; one job per target, the donor shared through
  ``shared_parent_a_cells``) plus fertilizer-bed jobs for default patterns.
"""
from __future__ import annotations

import dataclasses
import datetime as dt
from collections import Counter, defaultdict
from dataclasses import dataclass

from .. import progress
from ..copies import Copies
from ..models import Flower
from ..plots import usable_cells
from ..rules import FLOWER_TYPES, mix_result
from .layouts import Hub
from .packing import Board
from .scheduler import Entry, FlowConfig, FlowSimulator, Job, spawn_events

Cell = tuple[int, int]
# Which planning round plan_today is on, and how many it may take (for progress reports).
_ROUND = [0, 1]


def _neighbors(cell: Cell) -> set[Cell]:
    r, c = cell
    return {(r + dr, c + dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc}


def _flower_dict(f: Flower) -> dict:
    return {"flower_type": f.flower_type, "color": f.color, "pattern": f.pattern,
            "secondary_color": f.secondary_color}


@dataclass
class PlannedHub:
    hub: Hub
    job: Job
    cells: dict[Flower, Cell]          # target -> recipient cell
    kept: set[Flower]                  # targets kept from what is already planted
    donors: tuple[Cell, ...] = ()      # a line group's other donor copies



class DayOnePlanner(FlowSimulator):
    """FlowSimulator whose day-one assignment respects physical copy counts."""

    def __init__(self, owned_counts, targets, cfg, *, required=None, priority=None):
        super().__init__(owned_counts, targets, cfg, required=required, priority=priority)
        self.free: Counter[Flower] = Counter({f: n for f, n in owned_counts.items() if n > 0})
        self._day_cache: dict = {}

    # A flower can be planted only while an unplanted physical copy remains.
    def ready(self, flower: Flower, day: int) -> bool:
        return super().ready(flower, day) and self.free[flower] > 0

    def donor_free(self, donor: Flower, day: int) -> bool:
        return self.ready(donor, day)

    def base_rank(self, flower: Flower) -> int:
        # Today's plan spends real copies: rank bases by spare copies.
        return self.free[flower]

    def candidate_entries(self, hub, donor, day, allow_dup):
        """Candidates for this donor, with today's spare copies applied.

        Which targets a donor can work on, and their weights, do not change
        within one plan, so they are cached per (region, donor). Spare copies
        do change as the plan is filled, so recipients are checked (and the
        color-transfer base chosen) on every call.
        """
        key = (hub.region, hub.greenhouse, donor, day)
        raw = self._day_cache.get(key)
        if raw is None:
            raw = self._raw_candidates(hub, donor, day)
            self._day_cache[key] = raw
        return self._spare(raw)

    def _spare(self, raw):
        # Lazy: pick_entries stops once a hub's seats are full, so entries
        # past that point are never built.
        free, remaining = self.free, self.remaining
        count = free.__getitem__                        # == base_rank, without the extra call
        most = self.cfg.base_most_copies
        for weight, target, rec, options, p in raw:
            if target not in remaining:
                continue
            if rec is None:
                # The first option with the most spare copies (or the first spare one).
                best = 0
                for f in options:
                    n = count(f)
                    if n > best:
                        rec, best = f, n
                        if not most:
                            break
                if rec is None:
                    continue
            elif free[rec] <= 0:
                continue
            yield weight, Entry(target, rec, p)

    def _raw_candidates(self, hub, donor, day):
        # Same rules as FlowSimulator.candidate_entries, before spare copies.
        ready = super().ready
        out = []
        is_event_donor = bool(self.types[donor.flower_type].event) and not self.in_season(donor.flower_type, day)
        p_pat = (self.cfg.p_pattern_event_donor_outdoor
                 if (is_event_donor and not hub.greenhouse) else self.cfg.p_pattern)
        for t in self.front_targets.get((donor.color, donor.pattern), ()):
            if t.flower_type == donor.flower_type:
                continue
            rec = self._solid_of[t]
            if not ready(rec, day) or not self.spawn_ok(t, hub.region, hub.greenhouse, day):
                continue
            out.append((self.value(t, hub, day) * p_pat, t, rec, None, p_pat))
        p = self.cfg.p_color_transfer
        for t in self.solid_targets_by_color.get(donor.color, ()):
            if t.flower_type == donor.flower_type or not self.spawn_ok(t, hub.region, hub.greenhouse, day):
                continue
            options = tuple(f for f in self._solids_of_type[t.flower_type] if f.color != t.color and ready(f, day))
            if options:
                out.append((self.value(t, hub, day) * p, t, None, options, p))
        out.sort(key=lambda x: -x[0])
        return out

    def pick_entries(self, hub, cands, taken_types, allow_dup=False):
        # candidate_entries already skips recipients without a spare copy.
        return super().pick_entries(hub, cands, taken_types, allow_dup)

    def assign(self, job: Job) -> None:
        super().assign(job)
        self.free[job.donor] -= 1
        for e in job.entries:
            self.free[e.recipient] -= 1

    def refill(self, job: Job, day: int, allow_dup: bool) -> None:
        before = len(job.entries)
        super().refill(job, day, allow_dup)
        for e in job.entries[before:]:
            self.free[e.recipient] -= 1


def _season(day: dt.date) -> tuple:
    return spawn_events(day)


def _actual_cells(plot_status: dict) -> dict[str, dict[Cell, Flower]]:
    out: dict[str, dict[Cell, Flower]] = {}
    for slot, record in (plot_status or {}).get("plots", {}).items():
        cells = {}
        for cell in record.get("cells", []):
            cells[(int(cell["row"]), int(cell["col"]))] = Flower(
                cell["flower_type"], cell["color"], cell["pattern"], cell.get("secondary_color"))
        out[slot.upper()] = cells
    return out


FLOW_BED = "FLOW fertilizer bed"   # stock_goal_reason marking FLOW's beds (survives recording)


def _actual_bed_cells(plot_status: dict, flow_only: bool = False) -> dict[str, set[Cell]]:
    """Cells recorded as fertilizer-bed plants (any planner's, or only FLOW's)."""
    beds: dict[str, set[Cell]] = defaultdict(set)
    for slot, record in (plot_status or {}).get("plots", {}).items():
        jobs = [record.get("assignment") or {}] + list(record.get("jobs") or [])
        for job in jobs:
            if str(job.get("method", "")).startswith("fertilize_") and (
                    not flow_only or job.get("stock_goal_reason") == FLOW_BED):
                for cell in (job.get("layout") or {}).get("parent_a_cells", []):
                    beds[slot.upper()].add((int(cell[0]), int(cell[1])))
    return beds


def _keep_existing(sim: DayOnePlanner, actual: dict[str, dict[Cell, Flower]], day: int,
                   skip=None, wanted=lambda slot, target: True) -> dict[int, PlannedHub]:
    """Keep hubs whose planted donor and recipients still serve missing targets."""
    kept: dict[int, PlannedHub] = {}
    for hub in sim.hubs:
        if skip is not None and skip(hub):
            continue
        sim.free.slot = hub.slot
        cells = actual.get(hub.slot, {})
        donor = cells.get(hub.donor)
        if donor is None or donor.secondary_color is not None:
            continue
        if donor.pattern == "Solid":
            # A planted color-mix pair: solid at the donor cell, a mixable
            # solid of the same type in one recipient cell.
            if sim.free[donor] <= 0 or not sim.type_ok(donor.flower_type, hub.region):
                continue
            for rcell in hub.recipients:
                rec = cells.get(rcell)
                if (rec is None or rec.pattern != "Solid" or rec.flower_type != donor.flower_type
                        or sim.free[rec] <= 0):
                    continue
                color = mix_result(donor.color, rec.color)
                target = Flower(donor.flower_type, color, "Solid") if color else None
                if (target is None or target not in sim.remaining or not wanted(hub.slot, target)
                        or not sim.spawn_ok(target, hub.region, hub.greenhouse, day)):
                    continue
                job = Job(hub, donor, [Entry(target, rec, sim.cfg.p_color_mix)], kind="mix")
                sim.assign(job)
                kept[id(hub)] = PlannedHub(hub, job, {target: rcell}, {target})
                break
            continue
        if sim.free[donor] <= 0 or not sim.type_ok(donor.flower_type, hub.region):
            continue
        entries, where = [], {}
        for rcell in hub.recipients:
            rec = cells.get(rcell)
            if rec is None or rec.pattern != "Solid" or sim.free[rec] <= 0:
                continue
            if rec.color == donor.color:      # pattern transfer onto a same-color solid
                target = Flower(rec.flower_type, donor.color, donor.pattern)
                prob = sim.cfg.p_pattern
            else:                             # color transfer onto another-color solid
                target = Flower(rec.flower_type, donor.color, "Solid")
                prob = sim.cfg.p_color_transfer
            if (target not in sim.remaining or rec.flower_type == donor.flower_type
                    or not wanted(hub.slot, target) or not sim.spawn_ok(target, hub.region, hub.greenhouse, day)
                    or any(e.target.flower_type == rec.flower_type for e in entries)):
                continue
            entries.append(Entry(target, rec, prob))
            where[target] = rcell
        if entries:
            job = Job(hub, donor, entries)
            sim.assign(job)
            kept[id(hub)] = PlannedHub(hub, job, dict(where), set(where))
    sim.free.slot = None
    return kept


def _place_recipients(hub: Hub, entries: list[Entry], fixed: dict[Flower, Cell]) -> dict[Flower, Cell]:
    """Give each entry a recipient cell, best-served cells to the highest-value entries."""
    where = dict(fixed)
    free_cells = [c for c in hub.recipients if c not in where.values()]
    spawn = set(hub.spawn_cells)
    for e in entries:
        if e.target in where or not free_cells:
            continue
        best = max(free_cells, key=lambda c: (len(_neighbors(c) & spawn), c))
        where[e.target] = best
        free_cells.remove(best)
    return where


def _hub_jobs(sim, ph: PlannedHub, slot_meta, today: dt.date, outdoor_model: str) -> list[dict]:
    hub, job = ph.hub, ph.job
    donors = [hub.donor, *ph.donors]
    occupied = {cell for cell in ph.cells.values()} | set(donors)
    spawn = set(hub.spawn_cells)
    rec_cells = set(ph.cells.values())
    if outdoor_model == "wiki_fillers" and not hub.greenhouse:
        # Optimistic: every free non-spawn neighbor holds a fertilized filler.
        from ..plots import all_slots, usable_cells
        slot = next(s for s in all_slots() if s.slot == hub.slot)
        occupied = usable_cells(slot) - spawn
    out = []
    for i, e in enumerate(e for e in job.entries if e.target in ph.cells):
        rcell = ph.cells[e.target]
        mine = sorted(c for c in spawn if rcell in _neighbors(c))
        exclusive = [c for c in mine if not (_neighbors(c) & (rec_cells - {rcell}))]
        shared = [c for c in mine if c not in exclusive]
        daily_miss = 1.0
        for c in mine:
            sharers = len(_neighbors(c) & rec_cells)
            plants = len(_neighbors(c) & occupied)
            chance = 1.0 if hub.greenhouse else (0.10 if outdoor_model == "flat" else min(0.8, 0.10 * plants))
            # This recipient's share of the compatible pairs here: one per donor
            # copy touching the cell, out of every donor x recipient pair plus
            # the donor x donor pairs (which only copy the donor).
            nd = max(1, len(_neighbors(c) & set(donors)))
            share = nd / (nd * max(1, sharers) + nd * (nd - 1) / 2)
            daily_miss *= 1 - chance * e.prob * share
        p_day = 1 - daily_miss
        method = ("color_mix" if job.kind == "mix" else
                  "pattern_transfer" if e.target.pattern != "Solid" else "color_transfer")
        layout = {"parent_a_cells": [list(c) for c in donors] if i == 0 else [],
                  "parent_b_cells": [list(rcell)],
                  "target_cells": [list(c) for c in exclusive],
                  "shared_target_cells": [list(c) for c in shared]}
        if i:
            layout["shared_parent_a_cells"] = [list(c) for c in donors]
        ft = FLOWER_TYPES[e.target.flower_type]
        out.append({
            **slot_meta,
            "eligible_cells": len(mine),
            "target": e.target.label(),
            "target_type": e.target.flower_type,
            "target_color": e.target.color,
            "target_pattern": e.target.pattern,
            "target_secondary_color": None,
            "method": method,
            "parents": [job.donor.label(), e.recipient.label()],
            "parent_flowers": [_flower_dict(job.donor), _flower_dict(e.recipient)],
            "parent_patterns": [job.donor.pattern, e.recipient.pattern],
            "parent_copies": [1, 1],
            "daily_probability": p_day,
            "expected_days": (1 / p_day) if p_day > 0 else None,
            "event_only": bool(ft.event) and not sim.in_season(e.target.flower_type, 0),
            "stock_goal": 1,
            "stock_goal_reason": "first successful copy",
            "propagation_goal": 1,
            "propagation_goal_reason": "one reusable collection copy",
            "farm_state": "recommended",
            "locked": False,
            "layout": layout,
            "layout_search": "flow_hub",
            "flow_hub": {"donor_cell": list(hub.donor), "line_donors": len(donors), "kept": e.target in ph.kept,
                         "secondary": bool(sim.priority) and e.target not in sim.priority},
        })
    return out


def _bed_job(meta: dict, t: Flower, cells: list[Cell], p: float) -> dict:
    solid = Flower(t.flower_type, t.color, "Solid")
    n = len(cells)
    p_day = 1 - (1 - p) ** n
    return {
                **meta,
                "eligible_cells": n,
                "target": t.label(), "target_type": t.flower_type, "target_color": t.color,
                "target_pattern": t.pattern, "target_secondary_color": None,
                "method": "fertilize_pattern",
                "parents": [solid.label()], "parent_flowers": [_flower_dict(solid)],
                "parent_patterns": ["Solid"], "parent_copies": [n],
                "daily_probability": p_day, "expected_days": 1 / p_day,
                "event_only": False, "stock_goal": 1, "stock_goal_reason": FLOW_BED,
                "propagation_goal": 1, "propagation_goal_reason": "one reusable collection copy",
                "farm_state": "recommended", "locked": False, "supplemental": True,
                "layout": {"parent_a_cells": [list(c) for c in cells], "parent_b_cells": [],
                           "target_cells": [], "shared_target_cells": []},
                "layout_search": "flow_fertilizer_bed",
    }


# --------------------------------------------------------------------------
# Cell-level packing (see packing.py)
# --------------------------------------------------------------------------
FILL_MISSES = 8           # jobs that may fail to fit on one plot before it counts as full
FILL_PARALLEL = 12        # parallel attempts per target when only filling idle space
FILL_BED_CAP = 80         # bed plants per native pattern when only filling idle space
TRANSFER_METHODS = {"pattern_transfer", "color_transfer", "color_mix"}
GREENHOUSE_FILL_COST = 8  # a Greenhouse cell takes ~8x an outdoor cell's time to fill (progress only)
BLOCKER_MARGIN = 20       # a solid is a blocker option only while this many copies are spare
BLOCKER_COLORS = 3        # blocker options per flower type: its most-copied colors
FLOW_BLOCKER = "FLOW blocker"   # stock_goal_reason marking blocker plants (survives recording)


def _blocker_options(sim, region: str, plot_cells: dict[Cell, Flower] | None = None) -> list[Flower]:
    """Solids a group in this region may plant as blockers.

    Every flower type is offered (a blocker must be incompatible with what is
    around it, so variety matters), in its most-copied colors, only while
    plenty are spare. Solids whose native pattern is still missing come first
    (as fertilized plants they roll it every day), then the most copied. Solids
    already standing in the plot come first of all, so replanting can keep them.
    """
    by_type: dict[str, list[tuple[int, Flower]]] = defaultdict(list)
    for f, n in sim.free.pool.items():
        if f.pattern == "Solid" and f.secondary_color is None and n >= BLOCKER_MARGIN and sim.type_ok(f.flower_type, region):
            by_type[f.flower_type].append((n, f))
    options = [f for rows in by_type.values() for _, f in sorted(rows, key=lambda r: -r[0])[:BLOCKER_COLORS]]
    standing = set((plot_cells or {}).values())
    native = lambda f: Flower(f.flower_type, f.color, FLOWER_TYPES[f.flower_type].default_pattern)
    return sorted(options, key=lambda f: (f not in standing, native(f) not in sim.remaining,
                                          -sim.free.pool[f], f.label()))
ROUND_PREP = 0.4          # share of a planning round's progress before plots are filled (progress only)


def _virtual_hub(board: Board, seats: int = 6, donor: Cell = (-1, -1), recips=(), spawn=()) -> Hub:
    recipients = tuple(recips) or tuple((-2, -2 - i) for i in range(seats))
    return Hub(slot=board.slot.slot, region=board.slot.region, greenhouse=board.slot.greenhouse,
               donor=donor, recipients=recipients, spawn_cells=tuple(sorted(spawn)),
               spawn_rate=float(len(spawn) or 1))


def _entry_prob(sim, method: str, donor: Flower, greenhouse: bool, day: int) -> float:
    if method == "color_mix":
        return sim.cfg.p_color_mix
    if method == "color_transfer":
        return sim.cfg.p_color_transfer
    event_donor = bool(FLOWER_TYPES[donor.flower_type].event) and not sim.in_season(donor.flower_type, day)
    return sim.cfg.p_pattern_event_donor_outdoor if (event_donor and not greenhouse) else sim.cfg.p_pattern


def _keep_recorded(sim: "DayOnePlanner", plot_status: dict, actual: dict[str, dict[Cell, Flower]],
                   boards: dict[str, Board], day: int,
                   wanted=lambda slot, target: True) -> list[tuple[Board, object, Job]]:
    """Keep recorded breeding groups whose plants are still in place and still useful."""
    kept = []
    for slot, record in sorted((plot_status or {}).get("plots", {}).items()):
        board = boards.get(slot.upper())
        if board is None:
            continue
        sim.free.slot = board.slot.slot
        cells = actual.get(slot.upper(), {})
        jobs, seen = [], set()
        for job in [record.get("assignment") or {}] + list(record.get("jobs") or []):
            key = (job.get("method"), job.get("target"), repr(job.get("layout")))
            if key not in seen:
                seen.add(key)
                jobs.append(job)
        groups: dict[Cell, list[dict]] = defaultdict(list)
        donor_copies: dict[Cell, set[Cell]] = defaultdict(set)    # a line group's other donor cells
        for job in jobs:
            if job.get("method") not in TRANSFER_METHODS:
                continue
            layout = job.get("layout") or {}
            a_cells = layout.get("parent_a_cells") or layout.get("shared_parent_a_cells") or [None]
            a, b = a_cells[0], (layout.get("parent_b_cells") or [None])[0]
            if a is None or b is None or len(job.get("parent_flowers") or []) < 2:
                continue
            key = (int(a[0]), int(a[1]))
            groups[key].append(job)
            donor_copies[key] |= {(int(c[0]), int(c[1])) for c in a_cells[1:]}
        for dcell, group_jobs in sorted(groups.items()):
            donor = cells.get(dcell)
            if donor is None or sim.free[donor] <= 0 or not sim.type_ok(donor.flower_type, board.slot.region):
                continue
            extra = tuple(sorted(c for c in donor_copies[dcell] if cells.get(c) == donor))
            extra = extra[:max(0, sim.free[donor] - 1)]
            mix = any(j["method"] == "color_mix" for j in group_jobs)
            entries, recips, types, spawn = [], {}, set(), set()
            for job in group_jobs:
                if (job["method"] == "color_mix") != mix:
                    continue
                pf = [Flower(f["flower_type"], f["color"], f["pattern"], f.get("secondary_color"))
                      for f in job["parent_flowers"][:2]]
                b = tuple(int(x) for x in job["layout"]["parent_b_cells"][0])
                rec = cells.get(b)
                target = Flower(job["target_type"], job["target_color"], job["target_pattern"],
                                job.get("target_secondary_color"))
                if (pf[0] != donor or rec != pf[1] or b in recips or rec.flower_type in types
                        or sim.free[rec] <= 0 or target not in sim.remaining
                        or not wanted(board.slot.slot, target)
                        or not sim.spawn_ok(target, board.slot.region, board.greenhouse, day)
                        or (mix and entries)):
                    continue
                entry = Entry(target, rec, _entry_prob(sim, job["method"], donor, board.greenhouse, day))
                entries.append(entry)
                recips[b] = (entry, rec)
                types.add(rec.flower_type)
                layout = job["layout"]
                spawn |= {(int(c[0]), int(c[1])) for c in layout.get("target_cells", []) + layout.get("shared_target_cells", [])}
            if not entries:
                continue
            # Already planted: keep its recorded spawn cells and, like the hub
            # layouts it may come from, protect only planned spawn cells.
            if not spawn:
                # No recorded spawn cells (a hand-drawn layout): only cells
                # that are empty in the plot, never one a planted bed holds.
                spawn = set(board.usable) - set(cells)
            group = board.add_fixed_group(dcell, donor, recips, spawn=spawn, tolerate_buffers=True,
                                          extra_donors=extra)
            if group is None:
                continue
            if not group.spawn:
                board.remove_group(group)
                continue
            job = Job(_virtual_hub(board, donor=dcell, recips=group.recipients, spawn=group.spawn),
                      donor, entries, kind="mix" if mix else "transfer")
            sim.assign(job)
            job.extra_donors = len(extra)
            sim.free[donor] -= len(extra)
            kept.append((board, group, job))
    sim.free.slot = None
    return kept


def _keep_blockers(sim: "DayOnePlanner", plot_status: dict, actual: dict[str, dict[Cell, Flower]],
                   boards: dict[str, Board], placed) -> dict[str, dict[Cell, Flower]]:
    """Recorded blockers still standing next to a kept group stay where they are."""
    near_kept: dict[str, set[Cell]] = defaultdict(set)
    for board, group, _job, _kept in placed:
        for cell in [*group.donor_cells, *group.recipients]:
            near_kept[board.slot.slot] |= {(cell[0] + dr, cell[1] + dc) for dr in range(-2, 3) for dc in range(-2, 3)}
    kept: dict[str, dict[Cell, Flower]] = defaultdict(dict)
    for slot, record in sorted((plot_status or {}).get("plots", {}).items()):
        board = boards.get(slot.upper())
        if board is None or board.greenhouse:
            continue
        sim.free.slot = board.slot.slot
        for job in [record.get("assignment") or {}] + list(record.get("jobs") or []):
            if job.get("stock_goal_reason") != FLOW_BLOCKER:
                continue
            for c in (job.get("layout") or {}).get("parent_a_cells") or []:
                cell = (int(c[0]), int(c[1]))
                plant = actual.get(slot.upper(), {}).get(cell)
                if (plant is None or cell not in near_kept[board.slot.slot] or sim.free[plant] <= 0
                        or not board.free(cell)):
                    continue
                board._put(cell, plant)
                if not board._around_ok(cell, spawn_only=True):
                    board._take(cell)
                    continue
                sim.free[plant] -= 1
                kept[board.slot.slot][cell] = plant
    sim.free.slot = None
    return kept


def _unassign(sim: "DayOnePlanner", job: Job, entries: list[Entry], whole: bool) -> None:
    for e in entries:
        job.entries.remove(e)
        sim.assigned[e.target] -= 1
        sim.free[e.recipient] += 1
    if whole:
        sim.jobs.pop(id(job.hub), None)
        if job.kind == "transfer":
            sim.donor_busy[job.donor] -= 1
        sim.free[job.donor] += 1 + job.extra_donors
        job.extra_donors = 0


def _move_copies(sim: "DayOnePlanner", job: Job, src: str, dst: str) -> bool:
    """Move a job's copies from plot ``src``'s view to ``dst``'s; False (nothing moved) if dst lacks them."""
    need = Counter([job.donor] + [e.recipient for e in job.entries])
    sim.free.slot = src
    for f, n in need.items():
        sim.free[f] += n
    sim.free.slot = dst
    ok = all(sim.free[f] >= n for f, n in need.items())
    if not ok:
        sim.free.slot = src
    for f, n in need.items():
        sim.free[f] -= n
    sim.free.slot = None
    return ok


def _place_job(sim: "DayOnePlanner", board: Board, job: Job, day: int, near: Cell | None = None,
               prefer: Cell | None = None):
    """Place an assigned job on a board; drop entries that do not fit. Returns the group or None."""
    vh = _virtual_hub(board)
    weight = lambda e: sim.value(e.target, vh, day) * e.prob
    entries = [(e, e.recipient, weight(e)) for e in job.entries]
    existing = None
    current = None
    if near is not None:
        current = next((g for g in board.groups.values() if g.donor_cell == near), None)
        existing = {rc: weight(e) for rc, e in (current.recipients.items() if current else ())}
    before = len(current.donors) if current else 0
    max_donors = 1
    lines = sim.cfg.line_groups
    if job.kind == "transfer" and (lines is True or (lines and board.slot.slot in lines)):
        # A line group: more copies of the donor, as many as are spare (capped).
        max_donors = min(sim.cfg.line_max_donors, 1 + before + max(0, sim.free[job.donor]))
    had = set(current.blockers) if current else set()
    group = board.place_group(job.donor, entries, near=near, existing=existing, prefer=prefer,
                              max_donors=max_donors)
    if group is not None:
        added = len(group.donors) - before
        sim.free[job.donor] -= added
        job.extra_donors += added
        for cell, flower in group.blockers.items():
            if cell not in had:
                sim.free[flower] -= 1
                if sim.free[flower] < BLOCKER_MARGIN and flower in board.blocker_options:
                    board.blocker_options.remove(flower)
    placed = set(id(e) for e in (group.recipients.values() if group else ()))
    dropped = [e for e in job.entries if id(e) not in placed]
    return group, dropped


def _sticky_beds(sim, boards: dict[str, Board], actual, bed_cells, cfg,
                 wanted=lambda slot, target: True) -> dict[tuple[str, Flower], list[Cell]]:
    """Keep planted bed plants whose pattern is still missing (repeat: neighbours decide validity)."""
    beds: dict[tuple[str, Flower], list[Cell]] = defaultdict(list)
    given: Counter[Flower] = Counter()
    cap = max(cfg.bed_cap_per_target, FILL_BED_CAP if cfg.idle_parallel else 0)
    pending = [(slot, cell) for slot, cells in sorted(bed_cells.items()) if slot in boards for cell in sorted(cells)]
    for _ in range(4):
        left = []
        for slot, cell in pending:
            board = boards[slot]
            sim.free.slot = slot
            plant = actual.get(slot, {}).get(cell)
            if plant is None or plant.pattern != "Solid":
                continue
            native = Flower(plant.flower_type, plant.color, FLOWER_TYPES[plant.flower_type].default_pattern)
            if not (native in sim.natives and native in sim.remaining and wanted(slot, native)
                    and sim.type_ok(plant.flower_type, board.slot.region)):
                continue
            if sim.free[plant] > 0 and given[native] < cap and board.add_bed(cell, plant, spawn_only=True):
                sim.free[plant] -= 1
                given[native] += 1
                beds[(slot, native)].append(cell)
            else:
                left.append((slot, cell))
        if len(left) == len(pending):
            break
        pending = left
    sim.free.slot = None
    return beds


def _new_beds(sim, boards: dict[str, Board], cfg, beds: dict[tuple[str, Flower], list[Cell]]) -> None:
    given: Counter[Flower] = Counter()
    for (_, t), cells in beds.items():
        given[t] += len(cells)
    natives = [t for t in sim.natives if t in sim.remaining]
    natives.sort(key=lambda t: (-(10 if sim.donor_count[(t.color, t.pattern)] == 0 else 1)
                                * (1 + len(sim.front_targets.get((t.color, t.pattern), ()))), t.label()))
    order = sorted(boards.values(), key=lambda b: b.slot.slot)
    # Whether a cell can take a bed plant depends on its neighbours, which
    # later placements can change, so repeat until nothing more fits.
    for _ in range(4):
        added = 0
        for board in order:
            sim.free.slot = board.slot.slot
            # Cells where a solid already stands come first, so it can stay put.
            for cell in sorted((c for c in board.usable if board.free(c)),
                               key=lambda c: (not (board.prior.get(c) and board.prior[c].pattern == "Solid"), c)):
                was = board.prior.get(cell)
                first = ([t for t in natives if was is not None and was.pattern == "Solid"
                          and t.flower_type == was.flower_type and t.color == was.color])
                for t in first + natives:
                    solid = Flower(t.flower_type, t.color, "Solid")
                    if (sim.free[solid] <= 0 or given[t] >= cfg.bed_cap_per_target
                            or not sim.type_ok(t.flower_type, board.slot.region)):
                        continue
                    if board.add_bed(cell, solid):
                        sim.free[solid] -= 1
                        given[t] += 1
                        beds[(board.slot.slot, t)].append(cell)
                        added += 1
                        break
        if not added:
            break
    sim.free.slot = None


PROPAGATE_BASE = 2        # copies of a solid that waiting patterns need, at most ...
PROPAGATE_BUSY = 3        # ... or this many when PROPAGATE_BUSY_AT+ patterns wait
PROPAGATE_BUSY_AT = 5


def _propagation_needs(sim) -> dict[Flower, int]:
    """Copies wanted of each owned solid, by how many patterns wait for it.

    A solid is the recipient of every still-missing pattern in its color (one
    job per copy at a time), so a scarce solid holds those jobs back. The
    target is min(patterns waiting, 2), or 3 when 5 or more wait. Only solids
    with at least one copy can propagate; extremophiles are left out (they
    only grow in their tiny native plots or the Greenhouse).
    """
    waiting: Counter[Flower] = Counter()
    for t in sim.remaining:
        if t.pattern == "Solid" or t.pattern == FLOWER_TYPES[t.flower_type].default_pattern:
            continue
        if sim.donor_count.get((t.color, t.pattern), 0) <= 0:
            continue
        waiting[Flower(t.flower_type, t.color, "Solid")] += 1
    needs = {}
    for solid, n in waiting.items():
        if FLOWER_TYPES[solid.flower_type].extreme or sim.copies.get(solid, 0) <= 0:
            continue
        target = min(n, PROPAGATE_BUSY if n >= PROPAGATE_BUSY_AT else PROPAGATE_BASE)
        if sim.copies[solid] < target:
            needs[solid] = target
    return needs


def farm_propagation_needs(owned: dict[Flower, int], required: set[Flower], aux: set[Flower],
                           cfg: FlowConfig, priority: set[Flower] | None = None) -> dict[Flower, int]:
    """Propagation needs judged from every owned copy, as Generate plan sees them.

    Replant plot plans one plot with only the copies the rest of the farm
    leaves spare; judged from those, a solid planted elsewhere looks scarce or
    its donors look missing, and its propagator would come and go.
    """
    return _propagation_needs(DayOnePlanner(owned, required | aux, cfg, required=required, priority=priority))


def _prop_job(meta: dict, solid: Flower, cell: Cell, spawn: list[Cell], p_day: float, goal: int,
              have: int) -> dict:
    return {
        **meta,
        "eligible_cells": len(spawn),
        "target": solid.label(), "target_type": solid.flower_type, "target_color": solid.color,
        "target_pattern": "Solid", "target_secondary_color": None,
        "method": "propagate_solid",
        "parents": [solid.label()], "parent_flowers": [_flower_dict(solid)],
        "parent_patterns": ["Solid"], "parent_copies": [1],
        "daily_probability": p_day, "expected_days": (1 / p_day) if p_day > 0 else None,
        "event_only": False, "stock_goal": goal,
        "stock_goal_reason": f"{goal} copies so its waiting patterns can run at once (have {have})",
        "propagation": True, "propagation_goal": goal,
        "propagation_goal_reason": f"{goal} copies so its waiting patterns can run at once (have {have})",
        "farm_state": "recommended", "locked": False, "supplemental": True,
        "layout": {"parent_a_cells": [list(cell)], "parent_b_cells": [],
                   "target_cells": [list(c) for c in spawn], "shared_target_cells": []},
        "layout_search": "flow_propagation",
    }


def _place_propagators(sim, boards: dict[str, "Board"], day: int, needs: dict[Flower, int],
                       props: dict[Flower, tuple], recorded: dict[Flower, list[tuple[str, Cell]]] | None,
                       wanted, actual: dict[str, dict[Cell, Flower]] | None = None) -> None:
    """One propagating plant per scarce solid, kept where it is if planted.

    With ``recorded`` only the planted propagators are placed (in their own
    cells); otherwise new ones go into space nothing else uses.
    """
    order = sorted(needs, key=lambda f: (-sum(1 for t in sim.remaining if t in (sim.priority or ())
                                              and t.flower_type == f.flower_type and t.color == f.color),
                                         f.label()))
    for solid in order:
        if solid in props:
            continue
        if recorded is not None:
            for slot, cell in recorded.get(solid, []):
                board = boards.get(slot)
                if (board is None or board.greenhouse or not wanted(slot, solid)
                        or not sim.spawn_ok(solid, board.slot.region, False, day)):
                    continue
                sim.free.slot = slot
                if sim.free[solid] > 0:
                    # Planted neighbours (placed later) are never its spawn cells.
                    group = board.add_propagator(cell, solid, min_spawn=1, spawn_only=True,
                                                 avoid=set((actual or {}).get(slot, {})))
                    if group is not None:
                        sim.free[solid] -= 1
                        props[solid] = (board, group)
                        break
            sim.free.slot = None
            continue
        for board in sorted(boards.values(), key=lambda b: (-b.idle_cells(), b.slot.slot)):
            if (board.greenhouse or not sim.type_ok(solid.flower_type, board.slot.region)
                    or not sim.spawn_ok(solid, board.slot.region, False, day)):
                continue
            sim.free.slot = board.slot.slot
            if sim.free[solid] <= 0:
                continue
            # The cell where the same flower already stands first, then the
            # cell with the most empty space around it.
            cells = sorted((c for c in board.usable if board.free(c)),
                           key=lambda c: (board.prior.get(c) != solid,
                                          -sum(1 for n in board.nb[c] if board.free(n)), c))
            for cell in cells[:40]:
                group = board.add_propagator(cell, solid)
                if group is not None:
                    sim.free[solid] -= 1
                    props[solid] = (board, group)
                    break
            if solid in props:
                break
        sim.free.slot = None


def _plots_with_finds(plot_status: dict | None) -> set[str]:
    """Plots where a find has been recorded since they were planted.

    Recording a find marks the job (``job_states``) or the whole plot
    (``state``) as goal_reached. Only that plot is replanted; other plots that
    were running a parallel attempt at the same target just refill the seat.
    """
    out = set()
    for slot, record in (plot_status or {}).get("plots", {}).items():
        states = [record.get("state")] + [s.get("state") for s in (record.get("job_states") or {}).values()
                                          if isinstance(s, dict)]
        if "goal_reached" in states:
            out.add(slot.upper())
    return out


def plan_today(owned: dict[Flower, int], required: set[Flower], aux: set[Flower],
               plot_status: dict | None, cfg: FlowConfig, priority: set[Flower] | None = None,
               only_slots: set[str] | None = None, busy_targets: dict[Flower, int] | None = None,
               replant: set[str] | None = None, full_refresh: bool = False,
               propagating: set[Flower] | None = None,
               propagation_needs: dict[Flower, int] | None = None) -> dict:
    """Return {first_wave, plot_jobs, stats} for today's FLOW plan.

    Plants already in place stay where they are. Plots in ``replant`` (the
    Replant plot button, or every plot for a farm-wide replant) and plots
    where a target has been found are refreshed for the best current work,
    with as little digging as possible:

    1. The refreshed plots are planned from scratch to see which work the
       farm should be doing now.
    2. The real plan keeps every planted group and bed in those plots whose
       work the plan still does (anywhere on the farm): moving it would only
       shuffle the same work around. Replanting takes effort, so other
       planted work also stays unless the fresh plan has higher-priority
       work for that plot (extremophiles, in-season event flowers, the
       preliminary target). Only ``full_refresh`` (Replant whole farm)
       replaces work of the same priority. The freed space is filled; new
       plants prefer the cells where the same flower already stands.

    ``only_slots`` plans just those plots (the rest of the farm is accounted
    for by the caller: ``owned`` then holds only the copies left over, and
    ``busy_targets`` counts attempts already running elsewhere,
    ``propagating`` the solids another plot already propagates, which get no
    second propagator here, and ``propagation_needs`` the farm-wide needs from
    ``farm_propagation_needs``).
    """
    extra = {"propagating": propagating, "propagation_needs": propagation_needs}
    refresh = {s.upper() for s in (replant or ())}
    if cfg.replant_found_plots:
        refresh |= _plots_with_finds(plot_status)
    recorded = {s.upper() for s in (plot_status or {}).get("plots", {})}
    refresh &= recorded
    if only_slots is not None:
        refresh &= {s.upper() for s in only_slots}
    if not refresh:
        _ROUND[:] = [0, 1]
        return _plan_once(owned, required, aux, plot_status, cfg, priority, only_slots, busy_targets, **extra)
    rest = {**plot_status, "plots": {s: r for s, r in plot_status["plots"].items() if s.upper() not in refresh}}
    _ROUND[:] = [0, 5]           # a fresh plan, then up to 4 rounds keeping what's planted (below)
    fresh = _plan_once(owned, required, aux, rest, cfg, priority, only_slots, busy_targets, **extra,
                       prior=_actual_cells({"plots": {s: r for s, r in plot_status["plots"].items()
                                                      if s.upper() in refresh}}))
    if not cfg.minimal_replant:
        fresh["stats"]["replanted_plots"] = sorted(refresh)
        return fresh
    def targets(plan: dict) -> set[Flower]:
        return {Flower(job["target_type"], job["target_color"], job["target_pattern"],
                       job.get("target_secondary_color"))
                for job in plan["first_wave"] + [j for js in plan["plot_jobs"].values() for j in js]}

    # The fresh plan is one of many near-equal plans: work it skipped can
    # still win a place in the real plan. Such work is kept where it already
    # stands rather than cleared and planted again a few cells away, so
    # re-plan until the kept set covers everything the plan does.
    wanted = targets(fresh)
    # Replanting takes effort: unless every plot is being replanted on
    # purpose (Replant whole farm), a planted group or bed in a refreshed
    # plot stays unless the fresh plan has higher-priority work for that plot.
    floor_from = None
    if not full_refresh:
        floor_from = defaultdict(set)
        for job in fresh["first_wave"] + [j for js in fresh["plot_jobs"].values() for j in js]:
            if job["slot"].upper() in refresh:
                floor_from[job["slot"].upper()].add(Flower(job["target_type"], job["target_color"],
                                                           job["target_pattern"], job.get("target_secondary_color")))
    # Replant whole farm is one batch: a plant one plot drops may go to another
    # (a recorded move); otherwise a plant stays with its plot until recorded.
    release = frozenset(refresh) if full_refresh else frozenset()
    for attempt in range(4):
        _ROUND[0] = attempt + 1
        result = _plan_once(owned, required, aux, plot_status, cfg, priority, only_slots, busy_targets,
                            keep_only={slot: wanted for slot in refresh}, keep_tier=floor_from, release=release,
                            **extra)
        more = targets(result) - wanted
        if not more:
            break
        wanted |= more
    result["stats"]["replanted_plots"] = sorted(refresh)
    result["stats"]["fresh_breeding_p"] = fresh["stats"].get("breeding_p")
    return result


def _job_flowers(job: dict) -> list[Flower]:
    return [Flower(f["flower_type"], f["color"], f["pattern"], f.get("secondary_color"))
            for f in job.get("parent_flowers") or []]


def _infer_layouts(plot_status: dict | None) -> dict | None:
    """Give jobs recorded without cell positions (a layout drawn by hand) their cells.

    Each breeding job takes a cell with its first parent and the nearest cell
    with its second that shares an empty neighbour with it; jobs sharing a
    donor flower share its cell. A fertilizer bed
    takes every remaining cell holding its solid. Without this such plants
    look unplanned, and a replant would dig them up only to put the same
    flowers back a few cells away.
    """
    if not plot_status:
        return plot_status
    plots = {}
    for slot, record in plot_status.get("plots", {}).items():
        jobs = [record.get("assignment") or {}] + list(record.get("jobs") or [])
        if all((j.get("layout") or {}).get("parent_a_cells") or (j.get("layout") or {}).get("shared_parent_a_cells")
               or not j for j in jobs):
            plots[slot] = record
            continue
        cells = {(int(c["row"]), int(c["col"])): Flower(c["flower_type"], c["color"], c["pattern"],
                                                        c.get("secondary_color"))
                 for c in record.get("cells", [])}
        used: set[Cell] = set()
        donor_at: dict[Flower, Cell] = {}
        out = []
        for job in jobs:
            layout = job.get("layout") or {}
            if not job or layout.get("parent_a_cells") or layout.get("shared_parent_a_cells"):
                for key in ("parent_a_cells", "shared_parent_a_cells", "parent_b_cells"):
                    used |= {(int(c[0]), int(c[1])) for c in layout.get(key) or []}
                out.append(job)
                continue
            parents = _job_flowers(job)
            new_layout = None
            if job.get("method") == "fertilize_pattern" and parents:
                bed = [c for c, f in sorted(cells.items()) if f == parents[0] and c not in used]
                if bed:
                    used |= set(bed)
                    new_layout = {"parent_a_cells": [list(c) for c in bed], "parent_b_cells": [],
                                  "target_cells": [], "shared_parent_a_cells": [], "shared_target_cells": []}
            elif len(parents) >= 2:
                a_flower, b_flower = parents[0], parents[1]
                options = ([donor_at[a_flower]] if a_flower in donor_at else []) + [
                    c for c, f in sorted(cells.items()) if f == a_flower and c not in used]
                for a in options:
                    # Parents breed into an empty cell touching both: the
                    # recipient may be up to two cells away (nearest first).
                    near = sorted((c for c, f in cells.items() if f == b_flower and c not in used
                                   and 0 < max(abs(c[0] - a[0]), abs(c[1] - a[1])) <= 2),
                                  key=lambda c: (max(abs(c[0] - a[0]), abs(c[1] - a[1])), c))
                    b = near[0] if near else None
                    if b is None:
                        continue
                    shared = donor_at.get(a_flower) == a
                    donor_at[a_flower] = a
                    used |= {a, b}
                    new_layout = {"parent_a_cells": [] if shared else [list(a)],
                                  "shared_parent_a_cells": [list(a)] if shared else [],
                                  "parent_b_cells": [list(b)], "target_cells": [], "shared_target_cells": []}
                    break
            out.append({**job, "layout": new_layout} if new_layout else job)
        plots[slot] = {**record, "assignment": out[0], "jobs": out[1:]}
    return {**plot_status, "plots": plots}


def _plan_once(owned, required, aux, plot_status, cfg, priority=None, only_slots=None, busy_targets=None,
               prior: dict | None = None, keep_only: dict[str, set[Flower]] | None = None,
               keep_tier: dict[str, set[Flower]] | None = None,
               propagating: set[Flower] | None = None,
               propagation_needs: dict[Flower, int] | None = None,
               release: frozenset[str] | set[str] = frozenset()) -> dict:
    progress.report("plots", _ROUND[0] / _ROUND[1], "Getting your plots ready")
    plot_status = _infer_layouts(plot_status)
    sim = DayOnePlanner(owned, required | aux, cfg, required=required, priority=priority)
    for target, count in (busy_targets or {}).items():
        sim.assigned[target] += count
    keep_only = keep_only or {}
    if keep_only:
        prior = _actual_cells({"plots": {s: r for s, r in plot_status["plots"].items() if s.upper() in keep_only}})

    floor: dict[str, tuple | None] = {}     # per refreshed plot, filled once the boards exist

    def wanted(slot: str, target: Flower) -> bool:
        slot = slot.upper()
        allowed = keep_only.get(slot)
        if allowed is None or target in allowed:
            return True
        if keep_tier is None or slot not in boards:
            return False
        # Kept unless the plot has higher-priority work waiting.
        if slot not in floor:
            vh = _virtual_hub(boards[slot])
            floor[slot] = max((sim.tier(t, vh, day) for t in keep_tier.get(slot, ())), default=None)
        return floor[slot] is None or sim.tier(target, _virtual_hub(boards[slot]), day) >= floor[slot]

    day = 0
    season = _season(cfg.start_date)
    sim._season_key = season
    actual = _actual_cells(plot_status)
    # A plant in the ground stays with its plot, except in a batch (see copies.py).
    sim.free = Copies.from_status(dict(sim.free), plot_status, release=release)
    boards = {l.slot.slot: Board(l.slot, cfg.outdoor_model) for l in sim.layouts
              if only_slots is None or l.slot.slot in only_slots}
    for slot, cells in (prior or {}).items():
        if slot in boards:
            boards[slot].prior = dict(cells)
    placed: list[tuple[Board, object, Job, bool]] = []      # (board, group, job, kept)

    # 1. Recorded breeding groups still in place stay where they are.
    for board, group, job in _keep_recorded(sim, plot_status, actual, boards, day, wanted):
        placed.append((board, group, job, True))
    # Their blockers stay with them; new groups may plant more.
    kept_blockers = _keep_blockers(sim, plot_status, actual, boards, placed) if cfg.blockers else {}
    if cfg.blockers:
        for slot, board in boards.items():
            if not board.greenhouse:
                board.blocker_options = _blocker_options(sim, board.slot.region, actual.get(slot))
    # Planted propagators of solids still short of copies stay too. A
    # scarce solid's spare copy is held for propagating before breeding jobs
    # take it: within a day or two it makes another copy, so more of its
    # waiting patterns can run.
    needs = ((_propagation_needs(sim) if propagation_needs is None else dict(propagation_needs))
             if cfg.propagate_scarce else {})
    # One propagator per solid farm-wide: none here for solids another plot propagates.
    needs = {f: n for f, n in needs.items() if f not in (propagating or ())}
    props: dict[Flower, tuple] = {}
    recorded_props: dict[Flower, list[tuple[str, Cell]]] = defaultdict(list)
    for slot, record in (plot_status or {}).get("plots", {}).items():
        for job in [record.get("assignment") or {}] + list(record.get("jobs") or []):
            if job.get("method") == "propagate_solid" and job.get("parent_flowers"):
                f = job["parent_flowers"][0]
                for c in (job.get("layout") or {}).get("parent_a_cells") or []:
                    recorded_props[Flower(f["flower_type"], f["color"], f["pattern"], f.get("secondary_color"))
                                   ].append((slot.upper(), (int(c[0]), int(c[1]))))
    # A planted propagator stays in its plot while its solid is still short,
    # even when that plot is replanted: dropping it only makes the next plan
    # start a new one in another plot (dig up, replant elsewhere). Only
    # Replant whole farm (keep_only without keep_tier) plans them afresh.
    full_refresh = bool(keep_only) and keep_tier is None
    _place_propagators(sim, boards, day, needs, props, recorded_props,
                       wanted if full_refresh else (lambda slot, target: True), actual)
    # A scarce solid standing in a fertilizer bed propagates where it is
    # instead: no digging, and it still gets fertilized like every plant.
    for slot, cells in _actual_bed_cells(plot_status).items():
        for cell in sorted(cells):
            plant = actual.get(slot, {}).get(cell)
            if plant in needs and plant not in props and slot in boards:
                recorded_props[plant].append((slot, cell))
    _place_propagators(sim, boards, day, needs, props, recorded_props, wanted, actual)
    held: Counter[Flower] = Counter()
    for solid in needs:
        if solid not in props and sim.free.pool[solid] > 0:
            sim.free.pool[solid] -= 1
            held[solid] += 1
    taken = {slot: set(b.plant) | set(b.reserved) for slot, b in boards.items()}

    bed_cells = _actual_bed_cells(plot_status)
    flow_bed_cells = _actual_bed_cells(plot_status, flow_only=True)

    def bed_still_working(slot: str, cell: Cell) -> bool:
        # Only FLOW's own beds hold a hub back. Other planners' beds (e.g. the
        # v72 plan being replaced) give way to hubs.
        if cell not in flow_bed_cells.get(slot, ()):
            return False
        plant = actual.get(slot, {}).get(cell)
        if plant is None or plant.pattern != "Solid":
            return False
        native = Flower(plant.flower_type, plant.color, FLOWER_TYPES[plant.flower_type].default_pattern)
        return native in sim.natives and native in sim.remaining and wanted(slot, native)

    def hub_blocked(hub: Hub) -> bool:
        if hub.slot not in boards:
            return True
        hub_cells = (hub.donor, *hub.recipients, *hub.spawn_cells)
        return (any(c in taken.get(hub.slot, ()) for c in hub_cells)
                or any(bed_still_working(hub.slot, c) for c in hub_cells))

    # 2. Hubs: keep unrecorded plantings that match a hub, then assign the rest.
    planned = _keep_existing(sim, actual, day, skip=hub_blocked, wanted=wanted)
    def prep(fraction: float, what: str) -> None:
        """Progress through this round's preparation (`fraction` 0-1), before plots are filled."""
        progress.report("plots", (_ROUND[0] + ROUND_PREP * fraction) / _ROUND[1],
                        what + (f" · round {_ROUND[0] + 1}" if _ROUND[0] else ""))

    for index, hub in enumerate(sim.hubs):
        prep(0.4 * index / len(sim.hubs), "Choosing work for each breeding spot")
        sim.free.slot = hub.slot
        ph = planned.get(id(hub))
        if ph is not None:
            sim.refill(ph.job, day, False)
            continue
        if hub_blocked(hub):
            continue
        job = sim.best_job(hub, day, False)
        if job is None and cfg.idle_parallel:
            job = sim.best_job(hub, day, True)
        if job is not None:
            sim.assign(job)
            planned[id(hub)] = PlannedHub(hub, job, {}, set())
    # Seats still empty take parallel attempts at targets already running elsewhere.
    if cfg.idle_parallel:
        for ph in planned.values():
            sim.free.slot = ph.hub.slot
            sim.refill(ph.job, day, True)
    sim.free.slot = None
    for ph in planned.values():
        ph.cells = _place_recipients(ph.hub, ph.job.entries, ph.cells)

    # 3. Transfer hubs keep their optimized geometry (only the seats in use
    #    reserve cells). A color-mix pair needs no hub (two solids of one type
    #    only breed with each other), so it is packed compactly in its hub's
    #    area instead, leaving the rest of that area for more work.
    mix_jobs: list[PlannedHub] = []
    compact_jobs: list[PlannedHub] = []
    hub_order = sorted(planned.values(), key=lambda p: (not p.hub.greenhouse, -len(p.cells)))
    for index, ph in enumerate(hub_order):
        prep(0.4 + 0.2 * index / max(len(hub_order), 1), "Laying out your plots")
        board = boards[ph.hub.slot]
        sim.free.slot = ph.hub.slot
        if ph.job.kind == "mix" and not ph.kept:
            mix_jobs.append(ph)
            continue
        if cfg.compact_hubs and not ph.kept:
            # Sized to its real recipients instead of the hub template's seats.
            compact_jobs.append(ph)
            continue
        recips = {cell: (e, e.recipient) for e in ph.job.entries
                  for t, cell in ph.cells.items() if t == e.target}
        group = board.add_fixed_group(ph.hub.donor, ph.job.donor, recips, spawn=set(ph.hub.spawn_cells),
                                      tolerate_buffers=True)
        if group is not None and group.spawn:
            seated = {id(e) for e in group.recipients.values()}
            _unassign(sim, ph.job, [e for e in ph.job.entries if id(e) not in seated], whole=False)
            placed.append((board, group, ph.job, bool(ph.kept)))
            continue
        if group is not None:
            board.remove_group(group)
        _unassign(sim, ph.job, list(ph.job.entries), whole=True)
        ph.job.entries.clear()

    # 4. Beds already planted and still working stay.
    beds = _sticky_beds(sim, boards, actual, bed_cells, cfg, wanted)

    # 5. Compact groups (largest first, Greenhouse first), then color-mix
    #    pairs: as close to their hub's area as possible.
    compact_jobs.sort(key=lambda p: (not p.hub.greenhouse, -len(p.job.entries)))
    for index, ph in enumerate(compact_jobs + mix_jobs):
        prep(0.6 + 0.2 * index / max(len(compact_jobs) + len(mix_jobs), 1), "Laying out your plots")
        home = boards[ph.hub.slot]
        others = sorted((b for b in boards.values() if b is not home and b.slot.region == home.slot.region
                         and b.greenhouse == home.greenhouse), key=lambda b: -b.idle_cells())
        for board in [home, *others]:
            if board is not home and not _move_copies(sim, ph.job, home.slot.slot, board.slot.slot):
                continue
            sim.free.slot = board.slot.slot
            group, dropped = _place_job(sim, board, ph.job, day, prefer=ph.hub.donor if board is home else None)
            if group is not None:
                _unassign(sim, ph.job, dropped, whole=False)
                placed.append((board, group, ph.job, False))
                break
            if board is not home:
                _move_copies(sim, ph.job, board.slot.slot, home.slot.slot)
        else:
            sim.free.slot = home.slot.slot
            _unassign(sim, ph.job, list(ph.job.entries), whole=True)
            ph.job.entries.clear()
    sim.free.slot = None

    # 5b. New propagators for the held copies (the rest go back to the pool).
    for solid, n in held.items():
        sim.free.pool[solid] += n
    _place_propagators(sim, boards, day, needs, props, None, wanted)

    # 6. Transfer groups take more recipients in the free seats around their donor.
    def extend(only_kept: bool, allow_dup: bool, report: bool = False) -> None:
        groups = list(placed)
        for index, (board, group, job, kept) in enumerate(groups):
            if report:            # only before plots are filled (prep's share of the round)
                prep(0.8 + 0.2 * index / max(len(groups), 1), "Adding more flowers around each parent")
            if job.kind != "transfer" or (only_kept and not kept):
                continue
            sim.free.slot = board.slot.slot
            vh = _virtual_hub(board)
            taken_types = {e.target.flower_type for e in job.entries}
            extra = [e for _, e in sim.pick_entries(vh, sim.candidate_entries(vh, job.donor, day, allow_dup),
                                                    taken_types, allow_dup) if sim.free[e.recipient] > 0]
            if not extra:
                continue
            for e in extra:
                job.entries.append(e)
                sim.assigned[e.target] += 1
                sim.free[e.recipient] -= 1
            more = Job(job.hub, job.donor, list(extra))
            added, dropped = _place_job(sim, board, more, day, near=group.donor_cell)
            job.extra_donors += more.extra_donors       # donor copies a line group grew by
            _unassign(sim, job, dropped if added is not None else extra, whole=False)
        sim.free.slot = None

    extend(only_kept=False, allow_dup=False, report=True)

    # 7. Fill the space that is left with more breeding work, then fertilizer
    #    beds. Color-mix pairs pack tightly among other flower types; a new
    #    transfer donor needs a clear patch, so it is tried after them.
    def mix_job(vh, allow_dup):
        found = sim.best_mix_job(vh, day, allow_dup)
        return found[1] if found else None

    def transfer_job(vh, allow_dup):
        sim.best_mix_job = lambda *args, **kwargs: None
        try:
            return sim.best_job(vh, day, allow_dup)
        finally:
            del sim.best_mix_job

    fills = 2 * (2 if cfg.idle_parallel else 1)          # fill() runs below for each (make, allow_dup)
    filled = [0]

    def fill(make, allow_dup):
        ordered = sorted(boards.values(), key=lambda b: (not b.greenhouse, -b.idle_cells()))
        # Progress by cells, not plots, with the Greenhouse counted at its cost: filled
        # first, its cells take far longer than an outdoor plot's (most work can go there).
        def weight(b):
            return len(b.usable) * (GREENHOUSE_FILL_COST if b.greenhouse else 1)

        total = sum(weight(b) for b in ordered) or 1
        before = 0

        def report(board, start_idle):
            filled_here = weight(board) * (1 - board.idle_cells() / start_idle) if start_idle else 0
            done = min(1.0, (filled[0] + (before + filled_here) / total) / fills)
            progress.report("plots", (_ROUND[0] + ROUND_PREP + (1 - ROUND_PREP) * done) / _ROUND[1],
                            f"{board.slot.plot}" + (f" · round {_ROUND[0] + 1}" if _ROUND[0] else ""))

        for board in ordered:
            start_idle = board.idle_cells()
            report(board, start_idle)
            # A job that does not fit is skipped (its first parent is hidden for
            # this plot) so the next-best job can still use the space.
            hidden: Counter[Flower] = Counter()
            misses = 0
            sim.free.slot = board.slot.slot
            try:
                while board.idle_cells() >= 3 and misses < FILL_MISSES:
                    job = make(_virtual_hub(board), allow_dup)
                    if job is None:
                        break
                    sim.assign(job)
                    group, dropped = _place_job(sim, board, job, day)
                    if group is None:
                        _unassign(sim, job, list(job.entries), whole=True)
                        hidden[job.donor] += sim.free[job.donor]
                        sim.free[job.donor] = 0
                        misses += 1
                        continue
                    _unassign(sim, job, dropped, whole=False)
                    placed.append((board, group, job, False))
                    report(board, start_idle)
            finally:
                for flower, n in hidden.items():
                    sim.free[flower] += n
                sim.free.slot = None
            before += weight(board)

    for make in (mix_job, transfer_job):
        for allow_dup in ((False, True) if cfg.idle_parallel else (False,)):
            fill(make, allow_dup)
            filled[0] += 1
    _new_beds(sim, boards, cfg, beds)
    # Space still idle: an empty cell earns nothing today, so loosen the caps
    # the forecast uses (parallel attempts per target, bed plants per pattern).
    if cfg.idle_parallel:
        sim.cfg = dataclasses.replace(cfg, tail_parallel=FILL_PARALLEL, bed_cap_per_target=FILL_BED_CAP)
        try:
            # Repeat until nothing more fits: each round can free the way for the next.
            for _ in range(3):
                before = len(placed), sum(len(g.recipients) for _, g, _, _ in placed)
                extend(only_kept=False, allow_dup=True)
                for make in (mix_job, transfer_job):
                    fill(make, True)
                if (len(placed), sum(len(g.recipients) for _, g, _, _ in placed)) == before:
                    break
            _new_beds(sim, boards, sim.cfg, beds)
        finally:
            sim.cfg = cfg

    # 8. Expand to the dashboard's job format.
    slot_meta_of = {
        l.slot.slot: {"slot": l.slot.slot, "plot": l.slot.plot, "region": l.slot.region,
                      "plot_spots": l.slot.spots}
        for l in sim.layouts}
    jobs_by_slot: dict[str, list[dict]] = defaultdict(list)
    placed.sort(key=lambda x: (x[0].slot.slot, x[1].donor_cell))
    for board, group, job, kept in placed:
        hub = Hub(slot=board.slot.slot, region=board.slot.region, greenhouse=board.greenhouse,
                  donor=group.donor_cell, recipients=tuple(sorted(group.recipients)),
                  spawn_cells=tuple(sorted(group.spawn)), spawn_rate=float(len(group.spawn)))
        cells = {e.target: rc for rc, e in group.recipients.items()}
        job.entries = [e for e in job.entries if e.target in cells]
        ph = PlannedHub(hub, job, cells, set(cells) if kept else set(), donors=tuple(sorted(group.donors)))
        jobs_by_slot[hub.slot].extend(_hub_jobs(sim, ph, slot_meta_of[hub.slot], cfg.start_date, cfg.outdoor_model))
    for solid, (board, group) in sorted(props.items(), key=lambda kv: (kv[1][0].slot.slot, kv[1][1].donor_cell)):
        spawn = sorted(group.spawn)
        miss = 1.0
        for c in spawn:
            miss *= 1 - board.chance(c)
        jobs_by_slot[board.slot.slot].append(_prop_job(slot_meta_of[board.slot.slot], solid, group.donor_cell,
                                                       spawn, 1 - miss, needs[solid], sim.copies.get(solid, 0)))
    for (slot, t), cells in sorted(beds.items(), key=lambda kv: (kv[0][0], kv[0][1].label())):
        p = cfg.p_fertilize_daily
        jobs_by_slot[slot].append(_bed_job(slot_meta_of[slot], t, sorted(cells), p))
    # Blockers: fertilized like bed plants (they roll their native pattern too).
    blockers: dict[tuple[str, Flower], list[Cell]] = defaultdict(list)
    for slot, cells in kept_blockers.items():
        for cell, flower in cells.items():
            blockers[(slot, flower)].append(cell)
    for board, group, _job, _kept in placed:
        for cell, flower in group.blockers.items():
            blockers[(board.slot.slot, flower)].append(cell)
    for (slot, flower), cells in sorted(blockers.items(), key=lambda kv: (kv[0][0], kv[0][1].label())):
        p = cfg.p_fertilize_daily
        native = Flower(flower.flower_type, flower.color, FLOWER_TYPES[flower.flower_type].default_pattern)
        job = _bed_job(slot_meta_of[slot], native, sorted(cells), p)
        job["stock_goal_reason"] = FLOW_BLOCKER
        job["layout_search"] = "flow_blocker"
        jobs_by_slot[slot].append(job)

    first_wave, plot_jobs = [], {}
    for slot, jobs in jobs_by_slot.items():
        first_wave.append(jobs[0])
        if len(jobs) > 1:
            plot_jobs[slot] = jobs[1:]
    over = {f.label(): -n for f, n in sim.free.items() if n < 0}
    usable = sum(len(b.usable) for b in boards.values())
    idle = sum(b.idle_cells() for b in boards.values())
    stats = {
        "hubs_used": sum(1 for ph in planned.values() if ph.job.entries and ph not in mix_jobs
                         and ph not in compact_jobs),
        "hubs_total": len(sim.hubs),
        "hubs_kept": sum(1 for _, _, _, kept in placed if kept),
        "compact_groups": sum(1 for _, g, _, _ in placed)
        - sum(1 for ph in planned.values() if ph.job.entries and ph not in mix_jobs
              and ph not in compact_jobs),
        "breeding_jobs": sum(len(g.recipients) for _, g, _, _ in placed),
        "line_groups": sum(1 for _, g, _, _ in placed if g.donors),
        "line_donor_copies": sum(len(g.donors) for _, g, _, _ in placed),
        "blockers": sum(len(c) for c in blockers.values()),
        "kept_jobs": sum(len(g.recipients) for _, g, _, kept in placed if kept),
        "fertilizer_jobs": len(beds),
        "fertilizer_plants": sum(len(c) for c in beds.values()),
        "propagation_jobs": len(props),
        "plots_used": len(jobs_by_slot),
        "cells_usable": usable,
        "cells_idle": idle,
        "violations": sum(len(b.violations()) for b in boards.values()),
        "stray_cells": sum(len(b.stray_cells()) for b in boards.values()),
        "season": list(season),
        "replanted_plots": [],
        "copy_overuse": over,
        "copy_moves": sum(m["count"] for m in sim.free.move_list()),
        "breeding_p": round(sum(j.get("daily_probability") or 0.0 for js in jobs_by_slot.values() for j in js
                                if j.get("method") not in ("fertilize_pattern", "propagate_solid")), 4),
    }
    return {"first_wave": first_wave, "plot_jobs": plot_jobs, "stats": stats}
