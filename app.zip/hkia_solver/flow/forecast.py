"""FLOW roadmap forecast: simulate from today's farm to the finish.

The forecast runs the real planner forward in time (``unified.py``): day 1
is today's plan, and every later re-plan is what Generate plan would do after
the expected finds. It runs in the background when started from the Roadmap
tab. Its inputs are fingerprinted (``inputs_key``: which flowers you have and
have collected, the settings, the date and this code), so Generate plan can
re-apply a finished forecast whose inputs are unchanged. A run writes
``forecast.partial.json`` as it goes and ``forecast.json`` only when finished,
so the last finished forecast stays visible meanwhile. A finished forecast
replaces the plan's ``completion_schedule`` (Targets tab and dashboard
headline) with FLOW's.

The forecast rolls each target's daily chance (one seeded run of luck): totals are a fair estimate, single dates less so; the order of targets is more dependable
than the exact dates.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import time
from collections import Counter, defaultdict
from pathlib import Path

from ..copies import owned_counts
from ..models import Flower
from ..plots import extreme_gardening_mode, greenhouse_level
from ..rules import FLOWER_TYPES
from .integrate import auxiliary_prerequisites, cogimyun_setting, is_extreme_transfer, line_groups_setting
from .scheduler import EVENT_WINDOWS, FlowConfig, _in_window, game_today

FORECAST_DIR = ("output", "flow")
FORECAST_FILE = "forecast.json"
PARTIAL_FILE = "forecast.partial.json"
FORECAST_VERSION = 6   # 6: daily dice rolls instead of expected waits; 5: the next FORECAST_DAYS only; 4: the island as it is (no Extreme Gardening assumed)
# How far ahead the forecast looks. The whole collection took hours for a big
# farm (each re-plan is a whole-farm plan), and two months is what most
# players plan around.
FORECAST_DAYS = 60
_CODE_FILES = ("forecast.py", "scheduler.py", "layouts.py", "integrate.py", "unified.py", "plan_today.py",
               "packing.py")


def forecast_path(root: Path) -> Path:
    return root.joinpath(*FORECAST_DIR, FORECAST_FILE)


def partial_path(root: Path) -> Path:
    return root.joinpath(*FORECAST_DIR, PARTIAL_FILE)


def inputs_key(root: Path, today: dt.date | None = None) -> str:
    """Fingerprint of what the forecast depends on.

    Which flowers are owned (at least one copy) and collected, the settings
    (except the planner switch), the date and the forecast code. Planting and
    exact copy counts are left out: they barely move the forecast, and
    including them would restart a 20-minute run on every recorded spawn.
    """
    from ..inventory import Inventory
    from ..paths import farm_data_path

    today = today or game_today()
    inv = Inventory.load(farm_data_path(root, "inventory.json"),
                         farm_data_path(root, "other_patterned_donors.json"))
    have = sorted((f.label(), f.secondary_color or "", inv.physical_count(f) > 0)
                  for f in inv.all)
    settings_path = farm_data_path(root, "settings.json")
    try:
        settings = json.loads(settings_path.read_text(encoding="utf-8")) if settings_path.is_file() else {}
    except ValueError:
        settings = {}
    settings.pop("onboarding", None)     # setup steps, tips seen, backup date: not forecast inputs
    digest = hashlib.sha256(json.dumps([FORECAST_VERSION, today.isoformat(), have, settings],
                                       sort_keys=True, default=str).encode())
    here = Path(__file__).resolve().parent
    for name in _CODE_FILES:
        digest.update((here / name).read_bytes())
    return digest.hexdigest()


def load_json(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None
    except (OSError, ValueError):
        return None


def _write_json_atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
    os.replace(tmp, path)


def post_extreme_gardening_viable(planner_cls, root: Path) -> set[Flower]:
    """Viable targets once extremophiles may also grow in the Greenhouse."""
    import hkia_solver.optimizer as optimizer_module
    import hkia_solver.zones as zones_module

    original = zones_module.flower_zones()
    patched = {k: (v | {"Greenhouse"} if FLOWER_TYPES[k].extreme else v) for k, v in original.items()}
    saved = (zones_module.flower_zones, optimizer_module.flower_zones)
    zones_module.flower_zones = optimizer_module.flower_zones = lambda: patched
    try:
        planner = planner_cls(root)
        return set(planner.missing_targets - planner.optimizer().unreachable_required)
    finally:
        zones_module.flower_zones, optimizer_module.flower_zones = saved


def _event_calendar(start: dt.date, rows: list[dict], blocked: dict[str, int] | None = None,
                    months: int = 15) -> list[dict]:
    """Upcoming event windows and the forecast work inside each."""
    end = start + dt.timedelta(days=int(months * 30.5))
    events = []
    for name, ft in FLOWER_TYPES.items():
        if not ft.event or ft.event not in EVENT_WINDOWS:
            continue
        window = EVENT_WINDOWS[ft.event]
        day = start
        while day <= end:
            if _in_window(day, window) and (day == start or not _in_window(day - dt.timedelta(days=1), window)):
                stop = day
                while _in_window(stop + dt.timedelta(days=1), window):
                    stop += dt.timedelta(days=1)
                done = [r for r in rows if r["target_type"] == name
                        and day.isoformat() <= r["date"] <= stop.isoformat()]
                events.append({"event": ft.event, "flower_type": name, "start": day.isoformat(),
                               "end": stop.isoformat(), "forecast_targets": len(done),
                               "examples": [r["target"] for r in done[:6]],
                               "unlocks_blocked": (blocked or {}).get(name, 0)})
                day = stop
            day += dt.timedelta(days=1)
    return sorted(events, key=lambda e: e["start"])


def build_forecast(root: Path, *, on_partial=None, today: dt.date | None = None,
                   max_days: int | None = FORECAST_DAYS, key: str | None = None, full: bool = False) -> dict:
    """Forecast the next ``max_days`` (``None``: to the finish; ``full``, the Full forecast button)."""
    from ..planner import CollectionPlanner
    from ..plots import all_slots

    started = time.time()
    planner = CollectionPlanner(root)
    options = planner.settings.get("flow", {}) or {}
    today = today or game_today()
    inv = planner.inventory
    owned = {f: n for f, n in owned_counts(inv).items() if n > 0}
    viable_now = set(planner.missing_targets - planner.optimizer().unreachable_required)
    # The island as it is: what its unlocked patches and Greenhouse can grow. No
    # upgrade is assumed (not even Extreme Gardening once its requirement is met).
    required = viable_now
    preliminary = {t for t in viable_now if not is_extreme_transfer(t)}
    priority = preliminary if options.get("preliminary_first", True) else None
    cfg = FlowConfig(outdoor_model=options.get("outdoor_model", "wiki"),
                     cogimyun=cogimyun_setting(options),
                     extreme_gardening=extreme_gardening_mode(planner.settings),
                     line_groups=line_groups_setting(options.get("line_groups", False)),
                     blockers=bool(options.get("blockers", False)),
                     start_date=today, **({"max_days": max_days} if max_days else {}))
    plan_key = None
    plan_path = root / "output" / "latest_plan.json"
    if plan_path.is_file():
        try:
            plan_key = json.loads(plan_path.read_text(encoding="utf-8")).get("summary", {}).get("planning_input_key")
        except ValueError:
            plan_key = None
    slot_info = {s.slot: (s.plot, s.region) for s in all_slots()}
    # Event flowers with no stock at all: their event is the only way in.
    blocked_targets = planner.missing_targets & planner.optimizer().unreachable_required
    stockless = {name for name, ft in FLOWER_TYPES.items()
                 if ft.event and not any(f.flower_type == name and n > 0 for f, n in owned.items())}
    blocked_by_type = {name: sum(1 for t in blocked_targets
                                 if t.flower_type == name or t.pattern == FLOWER_TYPES[name].default_pattern)
                       for name in stockless}

    def snapshot(sim, day: int, complete: bool) -> dict:
        rows = []
        for t, d in sorted(sim.completed_day.items(), key=lambda kv: (kv[1], kv[0].label())):
            if t not in sim.required:
                continue
            info = sim.completion_info.get(t, {})
            slot = info.get("slot", "")
            plot, region = slot_info.get(slot, ("", ""))
            date = today + dt.timedelta(days=d)
            rows.append({
                "target": t.label(), "target_type": t.flower_type, "target_color": t.color,
                "target_pattern": t.pattern, "target_secondary_color": None,
                "finish_day": d, "date": date.isoformat(),
                "slot": slot, "plot": plot, "region": region,
                "method": info.get("method", "fertilize_pattern" if t.pattern != "Solid" else "color_transfer"),
                "parents": info.get("parents", []),
                "daily_probability": info.get("daily_probability"),
                "expected_days": (1 / info["daily_probability"]) if info.get("daily_probability") else None,
                "stock_goal": 1,
                "phase": "preliminary" if t in preliminary else "secondary",
            })
        remaining = sim.remaining & sim.required
        by_phase = Counter("preliminary" if t in preliminary else "secondary" for t in remaining)
        prelim_day = sim.priority_done_day if priority is not None else (
            max((r["finish_day"] for r in rows if r["phase"] == "preliminary"), default=None)
            if not by_phase["preliminary"] else None)
        finish_day = (max((r["finish_day"] for r in rows), default=0) + 1) if complete and not remaining else None
        when = lambda d: (today + dt.timedelta(days=d)).isoformat() if d is not None else None
        return {
            "schema": 1,
            "status": ("complete" if complete and not remaining else "incomplete" if complete else "running"),
            "as_of": today.isoformat(),
            "generated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
            "planning_input_key": plan_key,
            "inputs_key": key,
            "engine": "full" if full else "planner",
            "replans": getattr(sim, "replans", None),
            "days_simulated": day,
            "horizon_days": max_days,
            "seconds": round(time.time() - started, 1),
            "settings": {"outdoor_model": cfg.outdoor_model, "cogimyun": cfg.cogimyun,
                         "preliminary_first": priority is not None},
            "counts": {"preliminary": len(preliminary), "secondary": len(required - preliminary),
                       "done": len(rows), "remaining_preliminary": by_phase["preliminary"],
                       "remaining_secondary": by_phase["secondary"]},
            # The island the forecast plans with (never upgraded during it).
            "island": {"outdoor_plots": sum(1 for s in all_slots() if not s.greenhouse),
                       "greenhouse": next((f"{s.rows} × {s.cols}" for s in all_slots() if s.greenhouse), None),
                       "greenhouse_level": greenhouse_level(), "extreme_gardening": sim.extreme_unlocked},
            "milestones": {
                # Unlocked already (day 0), or the day its requirement (14 solid colors of
                # each extremophile) would be met; the upgrade itself is not simulated.
                "extreme_gardening": ({"day": 0, "date": when(0), "status": "unlocked"} if extreme_from_start else
                                      {"day": sim.extreme_requirement_day, "date": when(sim.extreme_requirement_day),
                                       "status": "requirement"}),
                "preliminary": {"day": prelim_day, "date": when(prelim_day)},
                "everything": {"day": finish_day, "date": when(finish_day)},
            },
            "events": _event_calendar(today, rows, blocked_by_type),
            "schedule": rows,
        }

    # The full forecast is the same simulation (re-plans after finds), with no
    # horizon: it runs until everything is found (or nothing more spawns).
    from .unified import UnifiedForecast

    sim = UnifiedForecast(owned, required, cfg, priority=priority, plot_status=planner.plot_status,
                          assume_upgrades=False, **({"max_days": max_days} if max_days else {}))
    extreme_from_start = sim.extreme_unlocked
    if on_partial is not None:
        sim.on_progress = lambda s, day: on_partial(snapshot(s, day, False))
        if max_days is None:
            sim.progress_every = 30      # a run to the finish takes hours: show it filling in monthly
    result = sim.run()
    return snapshot(sim, result["days_simulated"], True)


def apply_to_plan(root: Path, forecast: dict, current_key: str | None = None) -> bool:
    """Replace the plan's completion schedule with FLOW's.

    Applies when the forecast was made from the plan's own inputs, or from
    the same forecast inputs as now (the plan was regenerated after planting
    or recording spare copies, which the forecast does not depend on).
    """
    plan_path = root / "output" / "latest_plan.json"
    plan = load_json(plan_path)
    if plan is None or plan.get("summary", {}).get("planner") != "flow":
        return False
    plan_key = plan.get("summary", {}).get("planning_input_key")
    same_plan = plan_key == forecast.get("planning_input_key")
    same_inputs = forecast.get("inputs_key") is not None and forecast.get("inputs_key") == current_key
    if not (same_plan or same_inputs):
        return False
    rows = [{k: v for k, v in row.items() if k not in ("date", "phase")} for row in forecast["schedule"]]
    # Past the forecast's horizon the plan's own estimates stay, no sooner than the horizon.
    horizon = forecast.get("days_simulated") or 0
    forecast_targets = {row["target"] for row in rows}
    later = [dict(row, finish_day=max(row.get("finish_day") or 0, horizon))
             for row in plan.get("completion_schedule", []) if row.get("target") not in forecast_targets]
    plan["completion_schedule"] = rows + sorted(later, key=lambda row: row["finish_day"])
    milestones = forecast["milestones"]
    summary = plan["summary"]
    summary["flow_forecast_as_of"] = forecast["as_of"]
    if milestones["everything"]["day"] is not None:
        summary["viable_finish_days"] = milestones["everything"]["day"]
    tmp = plan_path.with_name(plan_path.name + ".flow.tmp")
    tmp.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    os.replace(tmp, plan_path)
    forecast["planning_input_key"] = plan_key
    return True


def run(root: Path, force: bool = False, reuse_only: bool = False, full: bool = False) -> dict:
    """Make the forecast, or reuse the finished one when its inputs are unchanged.

    ``reuse_only`` (after Generate plan) never computes: it re-applies a
    finished forecast with unchanged inputs to the new plan, or does nothing.
    """
    key = inputs_key(root)
    final = forecast_path(root)
    existing = load_json(final)
    if (not force and existing is not None and existing.get("inputs_key") == key
            and existing.get("status") in ("complete", "incomplete")):
        existing["applied_to_plan"] = apply_to_plan(root, existing, current_key=key)
        _write_json_atomic(final, existing)
        existing["reused"] = True
        return existing
    if reuse_only:
        return {"skipped": True, "reason": "no finished forecast for the current inputs"}
    partial = partial_path(root)
    forecast = build_forecast(root, on_partial=lambda data: _write_json_atomic(partial, data), key=key,
                              **({"max_days": None, "full": True} if full else {}))
    forecast["applied_to_plan"] = apply_to_plan(root, forecast, current_key=inputs_key(root))
    _write_json_atomic(final, forecast)
    try:
        partial.unlink()
    except OSError:
        pass
    return forecast
