"""Forecast by running the real planner forward in time.

Day 1 is exactly today's plan (Generate plan). Each simulated day every target
in the current plan gets one roll at its daily chance (breeding pairs at their
cells' spawn chances, fertilizer beds, recipients' own native rolls), from a
fixed seed so the same farm gives the same forecast. Rolling, rather than
waiting until a target's chances add up to 1, keeps the many long shots: a
1%-a-day target turns up within 60 days almost half the time, which the old
"expected wait" count never credited. When a target spawns it is recorded as found, and the planner
re-plans with the current plan as the planted state, just like recording a
find and pressing Generate plan (which refreshes the plot where it was found,
keeping the groups whose work is still wanted). Re-plans happen after a batch of finds, at
least every ``replan_days``, at every event boundary and when Extreme
Gardening unlocks.
"""
from __future__ import annotations

import dataclasses
import datetime as dt
import math
import random
import time
from collections import defaultdict

from ..models import Flower
from ..rules import COLORS, FLOWER_TYPES
from .integrate import auxiliary_prerequisites
from .plan_today import plan_today
from .scheduler import EVENT_WINDOWS, FlowConfig, _in_window


def plan_to_status(plan: dict) -> dict:
    """The plan as if planted and recorded (the shape plot_status.json uses)."""
    by_slot: dict[str, list[dict]] = defaultdict(list)
    for job in plan["first_wave"]:
        by_slot[job["slot"]].append(job)
    for slot, jobs in plan["plot_jobs"].items():
        by_slot[slot].extend(jobs)
    plots = {}
    for slot, jobs in by_slot.items():
        cells = {}
        for job in jobs:
            layout, parents = job["layout"], job["parent_flowers"]
            for key, index, role in (("parent_a_cells", 0, "A"), ("shared_parent_a_cells", 0, "A"),
                                     ("parent_b_cells", 1, "B")):
                for c in layout.get(key, []):
                    f = parents[min(index, len(parents) - 1)]
                    cells[(c[0], c[1])] = {"row": c[0], "col": c[1], "parent_role": role,
                                           **{k: f.get(k) for k in ("flower_type", "color", "pattern",
                                                                     "secondary_color")}}
        plots[slot] = {"state": "planted", "assignment": jobs[0], "jobs": jobs[1:], "cells": list(cells.values())}
    return {"plots": plots}


def _season(day: dt.date) -> tuple:
    return tuple(sorted(n for n, w in EVENT_WINDOWS.items() if _in_window(day, w)))


@dataclasses.dataclass
class Contribution:
    target: Flower
    p: float
    slot: str
    method: str
    parents: tuple
    event: str | None        # outdoor event-flower work only counts in season
    greenhouse: bool


class UnifiedForecast:
    """State of the farm as the forecast moves day by day."""

    def __init__(self, owned: dict[Flower, int], required: set[Flower], cfg: FlowConfig,
                 priority: set[Flower] | None = None, plot_status: dict | None = None,
                 replan_after: int = 12, replan_days: int = 30, max_days: int = 40000,
                 assume_upgrades: bool = True, seed: int = 0):
        self.cfg = cfg
        # False (the Roadmap forecast): the island stays as it is. Extreme Gardening is
        # never applied mid-forecast; the day its requirement is met is still recorded.
        self.assume_upgrades = assume_upgrades
        self.extreme_requirement_day: int | None = None
        self.owned = dict(owned)
        self.required = set(required)
        self.remaining = set(required)
        self.aux: set[Flower] = set()        # prerequisites (zero-copy parents) the plan may breed
        self.priority = set(priority) if priority else None
        self.plot_status = plot_status
        self.replan_after = replan_after
        self.replan_days = replan_days
        self.max_days = max_days
        self.luck = random.Random(seed)      # the day's rolls: same farm, same forecast
        self.copy_hazard: dict[Flower, float] = defaultdict(float)
        self.completed_day: dict[Flower, int] = {}
        self.completion_info: dict[Flower, dict] = {}
        self.extreme_unlocked = cfg.extreme_gardening == "now"
        self.extreme_unlock_day: int | None = 0 if self.extreme_unlocked else None
        self.priority_done_day: int | None = None
        self.plan: dict | None = None
        self.day1_plan: dict | None = None
        self.contributions: list[Contribution] = []
        self.on_progress = None          # callable(state, day)
        self.progress_every = 250
        self.replans = 0
        self.replan_seconds = 0.0
        self._types = FLOWER_TYPES

    # ------------------------------------------------------------ planning
    def date(self, day: int) -> dt.date:
        return self.cfg.start_date + dt.timedelta(days=day)

    def _extreme_ready(self) -> bool:
        if self.cfg.extreme_gardening != "auto":
            return False
        extremes = [n for n, ft in self._types.items() if ft.extreme]
        return all(sum(1 for c in COLORS if self.owned.get(Flower(n, c, "Solid"), 0) > 0)
                   >= self.cfg.extreme_colors_needed for n in extremes)

    def replan(self, day: int) -> None:
        started = time.time()
        cfg = dataclasses.replace(self.cfg, start_date=self.date(day),
                                  extreme_gardening="now" if self.extreme_unlocked else self.cfg.extreme_gardening)
        remaining = self.remaining
        priority = (self.priority & remaining) if self.priority else None
        aux = auxiliary_prerequisites(remaining, self.owned)
        self.aux = set(aux)
        plan = plan_today(self.owned, remaining, aux, self.plot_status, cfg, priority=priority or None)
        self.plan = plan
        if self.day1_plan is None:
            self.day1_plan = plan
        self.plot_status = plan_to_status(plan)
        self._index(plan, cfg)
        self.replans += 1
        self.replan_seconds += time.time() - started

    def _index(self, plan: dict, cfg: FlowConfig) -> None:
        out = []
        jobs = list(plan["first_wave"]) + [j for js in plan["plot_jobs"].values() for j in js]
        for job in jobs:
            target = Flower(job["target_type"], job["target_color"], job["target_pattern"],
                            job.get("target_secondary_color"))
            ft = self._types[target.flower_type]
            greenhouse = job["region"] == "Greenhouse"
            parents = tuple(job.get("parents", []))
            out.append(Contribution(target, float(job.get("daily_probability") or 0.0), job["slot"],
                                    job["method"], parents, ft.event or None, greenhouse))
            # Fertilized recipients also roll their own native pattern every day.
            if cfg.fertilize_recipients and job["method"] != "fertilize_pattern" and len(job["parent_flowers"]) > 1:
                rec = job["parent_flowers"][1]
                if rec.get("pattern") == "Solid":
                    rt = self._types[rec["flower_type"]]
                    native = Flower(rec["flower_type"], rec["color"], rt.default_pattern)
                    p = (cfg.p_fertilize_cogimyun if cfg.cogimyun_ww and job["region"] == "Wheatflour Wonderland"
                         else cfg.p_fertilize)
                    out.append(Contribution(native, p, job["slot"], "fertilize_pattern",
                                            (f"{rec['color']} {rec['flower_type']}",), None, greenhouse))
        self.contributions = out

    # ---------------------------------------------------------------- run
    def run(self) -> dict:
        day = 0
        found_since = 0
        last_plan = 0
        season = _season(self.date(0))
        self.replan(0)
        stalled = 0
        while (self.remaining & self.required) and day < self.max_days:
            today_season = _season(self.date(day))
            if day > 0:
                ready = not self.extreme_unlocked and self._extreme_ready()
                if ready and self.extreme_requirement_day is None:
                    self.extreme_requirement_day = day
                unlock = ready and self.assume_upgrades
                if unlock:
                    self.extreme_unlocked = True
                    self.extreme_unlock_day = day
                if (unlock or today_season != season or found_since >= self.replan_after
                        or day - last_plan >= self.replan_days):
                    self.replan(day)
                    found_since, last_plan, season = 0, day, today_season
            daily: dict[Flower, float] = defaultdict(float)
            best: dict[Flower, Contribution] = {}
            for c in self.contributions:
                if c.method == "propagate_solid":
                    # A scarce solid copying itself: each expected copy is one
                    # more recipient for the next re-plan.
                    if not (c.event and not c.greenhouse and c.event not in today_season):
                        self.copy_hazard[c.target] += c.p
                        if self.copy_hazard[c.target] >= 1.0:
                            self.copy_hazard[c.target] -= 1.0
                            self.owned[c.target] = self.owned.get(c.target, 0) + 1
                    continue
                if c.target not in self.remaining and c.target not in self.aux:
                    continue
                if c.event and not c.greenhouse and c.event not in today_season:
                    continue
                daily[c.target] += c.p
                if c.target not in best or c.p > best[c.target].p:
                    best[c.target] = c
            # One roll per target at its combined daily chance (in a fixed order, so runs repeat).
            done = [t for t in sorted(daily, key=lambda f: f.sort_key())
                    if self.luck.random() < 1.0 - math.exp(-daily[t])]
            for t in done:
                src = best[t]
                # Recorded where it spawned, like the dashboard's "found": the
                # planner replants that plot at the next re-plan.
                record = (self.plot_status or {}).get("plots", {}).get(src.slot)
                if record is not None:
                    record.setdefault("job_states", {})[f"found-{t.label()}"] = {"state": "goal_reached"}
                self.owned[t] = self.owned.get(t, 0) + 1
                found_since += 1
                if t in self.aux:                # a prerequisite: owned now, not a collection target
                    self.aux.discard(t)
                    continue
                self.remaining.discard(t)
                self.completed_day[t] = day
                self.completion_info[t] = {"slot": src.slot, "method": src.method,
                                           "parents": list(src.parents),
                                           "daily_probability": round(min(1.0, daily[t]), 5)}
            if (self.priority is not None and self.priority_done_day is None
                    and not (self.remaining & self.priority)):
                self.priority_done_day = day
            stalled = 0 if done else stalled + 1
            if stalled > 1500:
                break
            if self.on_progress is not None and day and day % self.progress_every == 0:
                self.on_progress(self, day)
            day += 1
        left = self.remaining & self.required
        finish = (max((d for t, d in self.completed_day.items() if t in self.required), default=0) + 1
                  if not left else None)
        return {"finish_days": finish, "remaining": len(left), "days_simulated": day,
                "extreme_unlock_day": self.extreme_unlock_day, "replans": self.replans,
                "replan_seconds": round(self.replan_seconds, 1)}
