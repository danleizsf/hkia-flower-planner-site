"""Front-based throughput scheduler ("FLOW") for the HKIA collection.

Core ideas (see FLOW_ALGORITHM.md):

1. Every plot is pre-tiled into *donor hubs* (``layouts.py``): one patterned
   donor, several distinct-type recipients, and empty spawn cells that can only
   produce planned donor x recipient attempts. Cells left over are fertilizer
   beds.
2. Work is organised by *front* = (color, pattern). A front spreads across
   flower types; every finished target is a new donor for its own front.
3. Each day the scheduler keeps every hub busy. When a hub's slot frees up it
   is refilled from the same front; when the front is exhausted the hub is
   re-assigned to the front with the highest marginal value. Greenhouse hubs
   serve greenhouse-only work first; in-season event flowers get outdoor hubs
   first because their window is scarce.
4. Native patterns come from fertilizer beds (and, optionally, the fertilized
   recipients themselves).

The simulation is an expected-hazard rollout: each target accumulates its daily
success probability and completes when the total reaches its threshold (1.0 in
deterministic mode, an Exp(1) draw in Monte Carlo mode).
"""
from __future__ import annotations

import datetime as dt
import math
import random
from collections import defaultdict
from dataclasses import dataclass, field

from ..models import Flower
from ..rules import COLORS, FLOWER_TYPES, parents_for_mix
from ..zones import flower_zones
from .layouts import Hub, farm_layouts

# Annual event windows (month, day) inclusive. 2026 dates where published,
# otherwise the 2025 dates. Source: hellokittyislandadventure.wiki.gg/wiki/Event
EVENT_WINDOWS = {
    "Hugs and Hearts": ((2, 5), (2, 18)),
    "Colorblaze Carnival": ((3, 4), (3, 18)),
    "Happy Haven": ((3, 19), (3, 25)),
    "Month of Meh": ((4, 30), (5, 31)),
    "Paper Parade": ((6, 11), (7, 1)),
    "Jam Jamboree": ((8, 27), (9, 9)),
    "Interlude of Dreams": ((10, 19), (11, 2)),
    "Hello Kitty's Birthday": ((10, 30), (11, 12)),  # Bowblossom
    "Give and Gather": ((11, 20), (12, 29)),
    "Lighttime Jubilee": ((12, 18), (1, 15)),
}


@dataclass
class FlowConfig:
    outdoor_model: str = "wiki"          # "wiki" (stacking fertilizer) or "flat" (v72)
    use_event_windows: bool = True
    extreme_gardening: str = "auto"     # "never" | "auto" (unlock at 14 colors each) | "now"
    extreme_colors_needed: int = 14
    cogimyun: bool = False               # her ability used when fertilizing: 5% pattern chance, every region
    fertilize_recipients: bool = True    # recipients are fertilized daily: 1% native roll
    clone_patterned: bool = False        # patterned donors can be cloned into extra copies
    clone_lag_days: int = 2
    new_copy_lag_days: int = 1           # a bred flower is usable as a parent next day
    max_parallel_per_target: int = 1     # raised automatically in the tail
    tail_parallel: int = 4
    bed_cap_per_target: int = 25
    gh_priority: str = "offload_aware"  # "offload_aware" (extremophile > far-window event) | "event_first" (v1)
    window_parallel: int = 6            # parallel outdoor attempts per in-season event target
    idle_parallel: bool = True          # idle hubs may run parallel attempts (cap tail_parallel)
    secondary_weight: float = 0.02      # value multiplier for non-preliminary targets while preliminary work remains
    root_priority: bool = True          # boost solids/natives that start a front with no donor yet
    group_by_breeds: bool = True        # within a priority tier, prefer the donor serving the most breeds
    group_until_preliminary: bool = True   # stop grouping once the preliminary target is done (rare patterns otherwise pile up at the end)
    base_most_copies: bool = True       # color transfers use the base breed's most-copied color
    compact_hubs: bool = True           # place new transfer groups compactly, sized to their recipients
    line_groups: bool | tuple[str, ...] = False   # day plan: transfer groups may hold several donor
                                                   # copies (lines); True everywhere, or these plot ids
    line_max_donors: int = 6            # donor copies per line group, at most
    blockers: bool = False              # day plan: new groups may plug stray cells with blocker solids
    propagate_scarce: bool = True       # day plan: scarce solids copy themselves in unused space
    minimal_replant: bool = True        # a replant keeps planted groups whose work the fresh plan also does
    replant_found_plots: bool = True    # a recorded find replants its whole plot (else: refill freed space only)
    reassign_every_days: int = 30
    start_date: dt.date = dt.date(2026, 10, 10)
    max_days: int = 60000
    monte_carlo_seed: int | None = None  # None = deterministic threshold 1.0
    p_pattern: float = 0.01
    p_pattern_event_donor_outdoor: float = 0.02
    p_color_transfer: float = 0.10
    p_color_mix: float = 0.30
    p_fertilize: float = 0.01
    p_fertilize_cogimyun: float = 0.05

    @property
    def p_fertilize_daily(self) -> float:
        """Daily native-pattern chance of one fertilized solid (the same in every region)."""
        return self.p_fertilize_cogimyun if self.cogimyun else self.p_fertilize


@dataclass
class Entry:
    target: Flower
    recipient: Flower
    prob: float


@dataclass
class Job:
    hub: Hub
    donor: Flower
    entries: list[Entry] = field(default_factory=list)
    kind: str = "transfer"   # "transfer" or "mix"
    extra_donors: int = 0    # day plan: donor copies beyond the first (a line group)


def _in_window(day: dt.date, window) -> bool:
    (m1, d1), (m2, d2) = window
    key = (day.month, day.day)
    if (m1, d1) <= (m2, d2):
        return (m1, d1) <= key <= (m2, d2)
    return key >= (m1, d1) or key <= (m2, d2)


def events_on(day: dt.date) -> tuple[str, ...]:
    """Events running on ``day`` by the calendar (two can overlap in December)."""
    return tuple(sorted(name for name, window in EVENT_WINDOWS.items() if _in_window(day, window)))


def game_today(now: dt.datetime | None = None) -> dt.date:
    """Today's in-game day: it starts at the daily reset, not at midnight."""
    from ..plot_checks import game_day

    return game_day(now)


def _spawn_window(day: dt.date, window) -> bool:
    """Whether plants on game day ``day`` can spawn the event's flowers outdoors.

    They roll at the next reset, which starts ``day + 1``; on the event's
    last day that roll falls after the event, so it already counts as over.
    """
    return _in_window(day, window) and _in_window(day + dt.timedelta(days=1), window)


def spawn_events(day: dt.date) -> tuple[str, ...]:
    """Events whose flowers plants on game day ``day`` can spawn outdoors."""
    return tuple(sorted(name for name, window in EVENT_WINDOWS.items() if _spawn_window(day, window)))


def resolve_active_events(setting, day: dt.date | None = None) -> tuple[str, ...]:
    """The ``active_event`` setting as a tuple of event names.

    "auto" (the default, also when the key is missing) follows the calendar
    for ``day`` (today's game day) as FLOW does, leaving out an event on its
    last day; a name or list of names pins them; null means no event.
    """
    if setting == "auto":
        return spawn_events(day or game_today())
    if setting is None:
        return ()
    return (setting,) if isinstance(setting, str) else tuple(setting)


class FlowSimulator:
    def __init__(self, owned_counts: dict[Flower, int], targets: set[Flower], cfg: FlowConfig, progress: bool = False,
                 required: set[Flower] | None = None, priority: set[Flower] | None = None):
        self.cfg = cfg
        self.progress = progress
        self.completion_info: dict[Flower, dict] = {}
        self.on_progress = None          # callable(sim, day), every progress_every simulated days
        self.progress_every = 250
        # Auxiliary prerequisites (collected but zero physical copies) are bred
        # but do not count toward collection completion.
        self.required = set(targets if required is None else required)
        # Optional preliminary set: other targets are deprioritized until it is done.
        self.priority: set[Flower] | None = set(priority) if priority else None
        self.priority_done_day: int | None = None
        self.zones = flower_zones()
        self.types = FLOWER_TYPES
        self.extreme_unlocked = cfg.extreme_gardening == "now"
        self.extreme_unlock_day: int | None = 0 if self.extreme_unlocked else None
        self._install_layouts(farm_layouts(cfg.outdoor_model, self.extreme_unlocked))
        self.remaining: set[Flower] = set(targets)
        self.all_targets = frozenset(targets)
        self.owned_ready_day: dict[Flower, int] = {f: 0 for f, n in owned_counts.items() if n > 0}
        self.copies: dict[Flower, int] = {f: max(1, n) for f, n in owned_counts.items() if n > 0}
        self.hazard: dict[Flower, float] = defaultdict(float)
        rng = random.Random(cfg.monte_carlo_seed) if cfg.monte_carlo_seed is not None else None
        self.threshold = {t: (rng.expovariate(1.0) if rng else 1.0) for t in targets}
        self.completed_day: dict[Flower, int] = {}
        self.jobs: dict[int, Job] = {}
        self.assigned: dict[Flower, int] = defaultdict(int)
        self.donor_busy: dict[Flower, int] = defaultdict(int)
        self.trace: list[dict] = []
        # Index of missing pattern targets per (color, pattern).
        self.front_targets: dict[tuple[str, str], set[Flower]] = defaultdict(set)
        self.solid_targets_by_color: dict[str, set[Flower]] = defaultdict(set)
        for t in targets:
            if t.pattern == "Solid":
                self.solid_targets_by_color[t.color].add(t)
            elif t.pattern != self.types[t.flower_type].default_pattern:
                self.front_targets[(t.color, t.pattern)].add(t)
        self.natives = {t for t in targets if t.pattern != "Solid" and t.pattern == self.types[t.flower_type].default_pattern}
        self.donor_count: dict[tuple[str, str], int] = defaultdict(int)
        self.donors_by_front: dict[tuple[str, str], list[Flower]] = defaultdict(list)
        for f in self.owned_ready_day:
            if f.pattern != "Solid" and f.secondary_color is None:
                self.donor_count[(f.color, f.pattern)] += 1
                self.donors_by_front[(f.color, f.pattern)].append(f)
        self.missing_patterns_tc: dict[tuple[str, str], int] = defaultdict(int)
        for (c, p), ts in self.front_targets.items():
            for t in ts:
                self.missing_patterns_tc[(t.flower_type, c)] += 1
        self._season_day = -1
        self._season_cache: dict[str, bool] = {}
        self.version = 0
        self._cand_cache: dict = {}
        self._window_cache: dict = {}
        self._season_key: tuple = ()
        self.gh_usage: dict[str, float] = defaultdict(float)
        self._solid_of = {t: Flower(t.flower_type, t.color, "Solid") for t in targets}
        self._solids_of_type = {name: tuple(Flower(name, c, "Solid") for c in COLORS) for name in FLOWER_TYPES}
        self.no_job_version: dict[int, int] = {}
        # Every native target can also become a front root.

    def _install_layouts(self, layouts) -> None:
        self.layouts = layouts
        self.hubs = [hub for layout in self.layouts for hub in layout.hubs]
        # GH first, then highest-rate outdoor hubs.
        self.hubs.sort(key=lambda h: (not h.greenhouse, -h.spawn_rate))
        self.beds_by_slot = {layout.slot.slot: (layout.slot.region, len(layout.bed_cells)) for layout in self.layouts}
        self.hub_cells = {id(h): 1 + len(h.recipients) + len(h.spawn_cells) for h in self.hubs}

    def extreme_colors(self, flower_type: str) -> int:
        return sum(1 for c in COLORS if Flower(flower_type, c, "Solid") in self.owned_ready_day)

    def maybe_unlock_extreme(self, day: int) -> None:
        if self.extreme_unlocked or self.cfg.extreme_gardening != "auto":
            return
        extremes = [n for n, ft in self.types.items() if ft.extreme]
        if all(self.extreme_colors(n) >= self.cfg.extreme_colors_needed for n in extremes):
            for hub in list(self.hubs):
                self.release(hub)
            self.extreme_unlocked = True
            self.extreme_unlock_day = day
            self._cand_cache.clear()
            self.no_job_version.clear()
            self._install_layouts(farm_layouts(self.cfg.outdoor_model, True))

    # ------------------------------------------------------------------ rules
    def date(self, day: int) -> dt.date:
        return self.cfg.start_date + dt.timedelta(days=day)

    def in_season(self, flower_type: str, day: int) -> bool:
        if day != self._season_day:
            self._season_day, self._season_cache = day, {}
        hit = self._season_cache.get(flower_type)
        if hit is None:
            hit = self._season_cache[flower_type] = self._in_season(flower_type, day)
        return hit

    def _in_season(self, flower_type: str, day: int) -> bool:
        event = self.types[flower_type].event
        if not event:
            return True
        if not self.cfg.use_event_windows:
            return False
        window = EVENT_WINDOWS.get(event)
        return bool(window and _spawn_window(self.date(day), window))

    def days_to_window(self, flower_type: str, day: int) -> int:
        """Days until this event flower's next in-season window (0 if in season)."""
        key = (flower_type, day)
        hit = self._window_cache.get(key)
        if hit is not None:
            return hit
        event = self.types[flower_type].event
        window = EVENT_WINDOWS.get(event) if event else None
        result = 10**6
        if window and self.cfg.use_event_windows:
            for d in range(0, 370):
                if _spawn_window(self.date(day + d), window):
                    result = d
                    break
        if len(self._window_cache) > 100000:
            self._window_cache.clear()
        self._window_cache[key] = result
        return result

    def type_ok(self, flower_type: str, region: str) -> bool:
        if region == "Greenhouse" and self.types[flower_type].extreme:
            return self.extreme_unlocked
        return region in self.zones.get(flower_type, ())

    def spawn_ok(self, target: Flower, region: str, greenhouse: bool, day: int) -> bool:
        if not self.type_ok(target.flower_type, region):
            return False
        if greenhouse:
            return True
        return self.in_season(target.flower_type, day)

    def ready(self, flower: Flower, day: int) -> bool:
        ready_day = self.owned_ready_day.get(flower)
        return ready_day is not None and ready_day <= day

    def donor_free(self, donor: Flower, day: int) -> bool:
        if not self.ready(donor, day):
            return False
        if self.cfg.clone_patterned and day >= self.owned_ready_day[donor] + self.cfg.clone_lag_days:
            return True
        return self.donor_busy[donor] < self.copies.get(donor, 1)

    # ------------------------------------------------------------ priorities
    def front_pressure(self, color: str, pattern: str, day: int) -> float:
        return len(self.front_targets[(color, pattern)]) / max(1, self.donor_count[(color, pattern)])

    def value(self, target: Flower, hub: Hub, day: int) -> float:
        """Marginal value of advancing ``target`` in ``hub`` today."""
        ft = self.types[target.flower_type]
        event_out = bool(ft.event) and not self.in_season(target.flower_type, day)
        v = 1.0
        if self.priority is not None and self.priority_done_day is None and target not in self.priority:
            v *= self.cfg.secondary_weight
        if hub.greenhouse:
            # Greenhouse capacity is the binding constraint: reserve it for work
            # nothing else can do. Extremophile work can never leave it; event
            # work can wait for its annual window outdoors, so it is deferred
            # more strongly the nearer that window is.
            if self.cfg.gh_priority == "offload_aware":
                if ft.extreme:
                    v *= 40.0  # must dominate every deferrable event bonus
                elif event_out:
                    wait = self.days_to_window(target.flower_type, day)
                    v *= 10.0 * min(1.0, max(0.15, wait / 180.0))
                else:
                    v *= 0.05
            else:
                v *= 10.0 if event_out else 0.05
        elif ft.event:  # in-season event flower outdoors: window is scarce
            v *= 8.0
        if target.pattern == "Solid":
            unlocks = self.missing_patterns_tc[(target.flower_type, target.color)]
            v *= 1.0 + 0.5 * unlocks
            if (ft.extreme and self.cfg.extreme_gardening == "auto" and not self.extreme_unlocked
                    and self.extreme_colors(target.flower_type) < self.cfg.extreme_colors_needed):
                v *= 40.0  # Extreme Gardening unlock moves extremophile work into the Greenhouse
            if self.cfg.root_priority:
                # This solid is the only way to fertilize its native pattern;
                # if that front has no donor yet, it gates the whole front.
                native = ft.default_pattern
                front = (target.color, native)
                if self.donor_count[front] == 0 and Flower(target.flower_type, target.color, native) in self.natives:
                    v *= 1.0 + len(self.front_targets.get(front, ()))
        else:
            # A finished target becomes a donor: favour thin, large fronts.
            v *= 1.0 + 0.3 * math.log1p(self.front_pressure(target.color, target.pattern, day))
            if ft.event:
                v *= 1.3  # out-of-season event donors transfer at 2% outdoors
        return v

    # ------------------------------------------------------------ assignment
    def candidate_entries(self, hub: Hub, donor: Flower, day: int, allow_dup: bool) -> list[tuple[float, Entry]]:
        """Sorted (weight, entry) candidates; cached per region/donor for 3 days.

        Assignment caps and completions are filtered lazily in ``pick_entries``.
        """
        key = (hub.region, hub.greenhouse, donor, day // 3, self._season_key)
        hit = self._cand_cache.get(key)
        if hit is not None:
            return hit
        out: list[tuple[float, Entry]] = []
        is_event_donor = bool(self.types[donor.flower_type].event) and not self.in_season(donor.flower_type, day)
        p_pat = (self.cfg.p_pattern_event_donor_outdoor
                 if (is_event_donor and not hub.greenhouse) else self.cfg.p_pattern)
        for t in self.front_targets.get((donor.color, donor.pattern), ()):
            if t.flower_type == donor.flower_type:
                continue
            rec = self._solid_of[t]
            if not self.ready(rec, day) or not self.spawn_ok(t, hub.region, hub.greenhouse, day):
                continue
            out.append((self.value(t, hub, day) * p_pat, Entry(t, rec, p_pat)))
        for t in self.solid_targets_by_color.get(donor.color, ()):
            if t.flower_type == donor.flower_type or not self.spawn_ok(t, hub.region, hub.greenhouse, day):
                continue
            options = [f for f in self._solids_of_type[t.flower_type] if f.color != t.color and self.ready(f, day)]
            if not options:
                continue
            # The base's color does not change the chance; use the most
            # plentiful one so rare colors stay free for jobs that need them.
            rec = max(options, key=self.base_rank) if self.cfg.base_most_copies else options[0]
            if rec is None:
                continue
            p = self.cfg.p_color_transfer
            out.append((self.value(t, hub, day) * p, Entry(t, rec, p)))
        out.sort(key=lambda x: -x[0])
        if len(self._cand_cache) > 200000:
            self._cand_cache.clear()
        self._cand_cache[key] = out
        return out

    def pick_entries(self, hub: Hub, cands: list[tuple[float, Entry]], taken_types: set[str],
                     allow_dup: bool = False) -> list[tuple[float, Entry]]:
        cap = self.cfg.tail_parallel if allow_dup else self.cfg.max_parallel_per_target
        chosen = []
        for w, e in cands:
            t = e.target
            if t.flower_type in taken_types or t not in self.remaining:
                continue
            t_cap = cap
            if (not hub.greenhouse and self.types[t.flower_type].event
                    and self.in_season(t.flower_type, self._season_day)):
                # The window is short and the outdoor farm is large: spread
                # each in-season event target over several hubs.
                t_cap = max(cap, self.cfg.window_parallel)
            if self.assigned[t] >= t_cap:
                continue
            chosen.append((w, e))
            taken_types.add(t.flower_type)
            if len(chosen) >= hub.recipient_slots:
                break
        return chosen

    def best_job(self, hub: Hub, day: int, allow_dup: bool) -> Job | None:
        best: tuple[float, Job] | None = None
        seen_fronts: set[tuple[str, str, str]] = set()
        for front_key, donors in self.donors_by_front.items():
          has_work = self.front_targets.get(front_key) or self.solid_targets_by_color.get(front_key[0])
          if not has_work:
            continue
          for donor in donors:
            # Donors of the same color/pattern differ only by excluded type and
            # event bonus; evaluate one per (color, pattern, eventness).
            key = (donor.color, donor.pattern, str(bool(self.types[donor.flower_type].event)))
            if key in seen_fronts:
                continue
            if not self.type_ok(donor.flower_type, hub.region) or not self.donor_free(donor, day):
                continue
            has_work = self.front_targets.get((donor.color, donor.pattern)) or self.solid_targets_by_color.get(donor.color)
            if not has_work:
                continue
            seen_fronts.add(key)
            chosen = self.pick_entries(hub, self.candidate_entries(hub, donor, day, allow_dup), set(), allow_dup)
            if not chosen:
                continue
            score = sum(w for w, _ in chosen) * hub.spawn_rate / max(1, hub.recipient_slots)
            tier = max(self.tier(e.target, hub, day) for _, e in chosen)
            # Priorities (season, location, preliminary) first; within a tier
            # the donor serving the most breeds on this plot, then value.
            key = (tier, len(chosen), score) if self.grouping() else (score,)
            if best is None or key > best[0]:
                best = (key, Job(hub, donor, [e for _, e in chosen]), tier, score)
        mix = self.best_mix_job(hub, day, allow_dup)
        if mix:
            mix_tier = self.tier(mix[1].entries[0].target, hub, day)
            if best is None:
                return mix[1]
            if self.grouping():
                if (mix_tier, mix[0]) > (best[2], best[3]):
                    return mix[1]
            elif mix[0] > best[3]:
                return mix[1]
        return best[1] if best else None

    def grouping(self) -> bool:
        if not self.cfg.group_by_breeds:
            return False
        return not (self.cfg.group_until_preliminary and self.priority is not None
                    and self.priority_done_day is not None)

    def base_rank(self, flower: Flower) -> int:
        """How plentiful a base (recipient) solid is: owned copies."""
        return self.copies.get(flower, 0)

    def tier(self, target: Flower, hub: Hub, day: int) -> tuple:
        """Priority tier by season, location and target set (higher first)."""
        ft = self.types[target.flower_type]
        primary = not (self.priority is not None and self.priority_done_day is None
                       and target not in self.priority)
        if (target.pattern == "Solid" and ft.extreme and self.cfg.extreme_gardening == "auto"
                and not self.extreme_unlocked
                and self.extreme_colors(target.flower_type) < self.cfg.extreme_colors_needed):
            kind = 4                     # unlocks Extreme Gardening
        elif hub.greenhouse:
            if ft.extreme:
                kind = 3
            elif ft.event and not self.in_season(target.flower_type, day):
                kind = 2
            else:
                kind = 0                 # anything the outdoor farm can do
        elif ft.event and self.in_season(target.flower_type, day):
            kind = 2                     # in-season event flowers: the window is short
        else:
            kind = 1
        return (primary, kind)

    def best_mix_job(self, hub: Hub, day: int, allow_dup: bool):
        cap = self.cfg.tail_parallel if allow_dup else self.cfg.max_parallel_per_target
        best = None
        for color, targets in self.solid_targets_by_color.items():
            for t in targets:
                if self.assigned[t] >= cap or not self.spawn_ok(t, hub.region, hub.greenhouse, day):
                    continue
                for a, b in parents_for_mix(color):
                    fa, fb = Flower(t.flower_type, a, "Solid"), Flower(t.flower_type, b, "Solid")
                    if self.ready(fa, day) and self.ready(fb, day):
                        # One pair: roughly the cells shared by donor and one recipient.
                        rate = hub.spawn_rate / max(1, hub.recipient_slots)
                        score = self.value(t, hub, day) * self.cfg.p_color_mix * rate
                        if best is None or score > best[0]:
                            best = (score, Job(hub, fa, [Entry(t, fb, self.cfg.p_color_mix)], kind="mix"))
                        break
        return best

    def assign(self, job: Job) -> None:
        self.jobs[id(job.hub)] = job
        if job.kind == "transfer":
            self.donor_busy[job.donor] += 1
        for e in job.entries:
            self.assigned[e.target] += 1

    def release(self, hub: Hub) -> None:
        job = self.jobs.pop(id(hub), None)
        if not job:
            return
        if job.kind == "transfer":
            self.donor_busy[job.donor] -= 1
        for e in job.entries:
            self.assigned[e.target] -= 1

    def refill(self, job: Job, day: int, allow_dup: bool) -> None:
        if job.kind != "transfer":
            return
        free = job.hub.recipient_slots - len(job.entries)
        if free <= 0:
            return
        taken = {e.target.flower_type for e in job.entries}
        chosen = self.pick_entries(job.hub, self.candidate_entries(job.hub, job.donor, day, allow_dup), taken, allow_dup)
        for _, e in chosen[:free]:
            job.entries.append(e)
            self.assigned[e.target] += 1

    # ------------------------------------------------------------- the loop
    def complete(self, target: Flower, day: int) -> None:
        self.remaining.discard(target)
        self.completed_day[target] = day
        self.owned_ready_day.setdefault(target, day + self.cfg.new_copy_lag_days)
        self.copies[target] = self.copies.get(target, 0) + 1
        self.version += 1
        if target.pattern == "Solid":
            self.solid_targets_by_color[target.color].discard(target)
        else:
            if self.copies[target] == 1:
                self.donor_count[(target.color, target.pattern)] += 1
                self.donors_by_front[(target.color, target.pattern)].append(target)
            if target in self.front_targets[(target.color, target.pattern)]:
                self.front_targets[(target.color, target.pattern)].discard(target)
                self.missing_patterns_tc[(target.flower_type, target.color)] -= 1
            self.natives.discard(target)

    def bed_allocation(self, day: int, idle_cells_by_slot: dict[str, int], sources: dict | None = None) -> dict[Flower, float]:
        """Allocate fertilizer cells to missing native patterns; return hazard/day."""
        hazard: dict[Flower, float] = defaultdict(float)
        natives = [t for t in self.natives if self.ready(Flower(t.flower_type, t.color, "Solid"), day)]
        if not natives:
            return hazard
        def priority(t: Flower) -> float:
            roots = self.donor_count[(t.color, t.pattern)] == 0
            return (10.0 if roots else 1.0) * (1 + len(self.front_targets.get((t.color, t.pattern), ())))
        natives.sort(key=lambda t: -priority(t))
        given: dict[Flower, int] = defaultdict(int)
        for slot, (region, beds) in self.beds_by_slot.items():
            cells = beds + idle_cells_by_slot.get(slot, 0)
            p = self.cfg.p_fertilize_daily
            for t in natives:
                if cells <= 0:
                    break
                if not self.type_ok(t.flower_type, region) or given[t] >= self.cfg.bed_cap_per_target:
                    continue
                n = min(cells, self.cfg.bed_cap_per_target - given[t])
                given[t] += n
                cells -= n
                h = 1 - (1 - p) ** n
                hazard[t] += h
                if sources is not None:
                    best = sources.get(t)
                    if best is None or h > best[0]:
                        sources[t] = (h, slot, "fertilize_pattern", (Flower(t.flower_type, t.color, "Solid"),))
        return hazard

    def remaining_by_kind(self) -> dict[str, int]:
        out: dict[str, int] = defaultdict(int)
        for t in self.remaining & self.required:
            ft = self.types[t.flower_type]
            group = "extreme" if ft.extreme else ("event" if ft.event else "regular")
            kind = "solid" if t.pattern == "Solid" else ("native" if t.pattern == ft.default_pattern else "transfer")
            out[f"{group}_{kind}"] += 1
        return dict(out)

    def run(self) -> dict:
        cfg = self.cfg
        day = 0
        last_full = -10**9
        prev_season = None
        stalled = 0
        while (self.remaining & self.required) and day < cfg.max_days:
            season = spawn_events(self.date(day)) if cfg.use_event_windows else ()
            self._season_key = season
            self.maybe_unlock_extreme(day)
            allow_dup = len(self.remaining) < len(self.hubs)
            if season != prev_season or day - last_full >= cfg.reassign_every_days:
                for hub in self.hubs:
                    self.release(hub)
                last_full, prev_season = day, season
            # Drop finished / no-longer-legal entries, refill, assign idle hubs.
            for hub in self.hubs:
                job = self.jobs.get(id(hub))
                if job:
                    keep = []
                    for e in job.entries:
                        if e.target in self.remaining and self.spawn_ok(e.target, hub.region, hub.greenhouse, day):
                            keep.append(e)
                        else:
                            self.assigned[e.target] -= 1
                    job.entries = keep
                    if not keep and job.kind == "mix":
                        self.release(hub)
                        job = None
                    elif job:
                        self.refill(job, day, allow_dup)
                        if not job.entries:
                            self.release(hub)
                            job = None
                retry_key = (day // (3 if hub.greenhouse else 15), season, allow_dup, self.extreme_unlocked)
                if job is None and self.no_job_version.get(id(hub)) != retry_key:
                    new = self.best_job(hub, day, allow_dup)
                    if new is None and not allow_dup and self.cfg.idle_parallel:
                        # Otherwise-idle hub: add a parallel attempt at a target
                        # already running elsewhere (uses spare capacity, e.g.
                        # the outdoor farm during an event window).
                        new = self.best_job(hub, day, True)
                    if new:
                        self.assign(new)
                    else:
                        self.no_job_version[id(hub)] = retry_key
            # Accumulate hazard.
            daily: dict[Flower, float] = defaultdict(float)
            sources: dict[Flower, tuple] = {}   # target -> (hazard, slot, method, parents), largest today
            idle_cells: dict[str, int] = defaultdict(int)
            busy_hubs = 0
            for hub in self.hubs:
                job = self.jobs.get(id(hub))
                if not job or not job.entries:
                    idle_cells[hub.slot] += self.hub_cells[id(hub)]
                    continue
                busy_hubs += 1
                per_slot = hub.spawn_rate / max(1, hub.recipient_slots)
                if hub.greenhouse:
                    for e in job.entries:
                        ft_e = self.types[e.target.flower_type]
                        cat = "extreme" if ft_e.extreme else ("event" if ft_e.event else "other")
                        self.gh_usage[cat] += per_slot
                for e in job.entries:
                    h = per_slot * e.prob
                    daily[e.target] += h
                    best = sources.get(e.target)
                    if best is None or h > best[0]:
                        method = ("color_mix" if job.kind == "mix" else
                                  "pattern_transfer" if e.target.pattern != "Solid" else "color_transfer")
                        sources[e.target] = (h, hub.slot, method, (job.donor, e.recipient))
                    if cfg.fertilize_recipients:
                        native = Flower(e.recipient.flower_type, e.recipient.color,
                                        self.types[e.recipient.flower_type].default_pattern)
                        if native in self.natives:
                            daily[native] += cfg.p_fertilize
            for t, h in self.bed_allocation(day, idle_cells, sources).items():
                daily[t] += h
            if self.priority is not None and self.priority_done_day is None and not (self.remaining & self.priority):
                self.priority_done_day = day
            done = []
            for t, h in daily.items():
                if t not in self.remaining:
                    continue
                self.hazard[t] += min(h, 50.0)
                if self.hazard[t] >= self.threshold[t]:
                    done.append(t)
            for t in done:
                src = sources.get(t)
                if src is not None:
                    self.completion_info[t] = {"slot": src[1], "method": src[2],
                                               "parents": [f.label() for f in src[3]],
                                               "daily_probability": round(min(1.0, daily[t]), 5)}
                self.complete(t, day)
            if self.on_progress is not None and day % self.progress_every == 0 and day:
                self.on_progress(self, day)
            if day % 30 == 0:
                self.trace.append({"day": day, "remaining": len(self.remaining), "busy_hubs": busy_hubs,
                                   "gh_spawns_cum": {k: round(v) for k, v in self.gh_usage.items()},
                                   "remaining_by_kind": self.remaining_by_kind(),
                                   "season": list(season)})
            stalled = 0 if done else stalled + 1
            if stalled > 1500:
                break
            if self.progress and day % 250 == 0:
                print(f"  day {day}: remaining {len(self.remaining)}", flush=True)
            day += 1
        left = self.remaining & self.required
        finish = (max((d for t, d in self.completed_day.items() if t in self.required), default=0) + 1
                  if not left else None)
        return {
            "finish_days": finish,
            "finish_date": self.date(finish).isoformat() if finish else None,
            "remaining": len(left),
            "remaining_sample": sorted(f.label() for f in list(left)[:20]),
            "days_simulated": day,
            "extreme_unlock_day": self.extreme_unlock_day,
            "trace": self.trace,
        }
