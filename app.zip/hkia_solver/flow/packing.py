"""Cell-level packing for FLOW's day-one plan.

The simulator thinks in fixed *hubs* (one donor, up to ~14 recipient seats and
the spawn cells between them). That is the right abstraction for a forecast,
but on a real farm many hubs only get one or two jobs today, which leaves the
rest of their seats and spawn cells empty. This module places breeding groups
and fertilizer-bed plants cell by cell instead, so freed space goes to more
work.

Validity rule (checked for every empty cell after every placement): every
compatible pair of plants touching an empty cell must be a *planned* pair
(donor x one of its recipients). Identical flowers may touch the same empty
cell (they only make another copy of themselves), except around a planned
spawn cell, where they would dilute the planned pair's chance.

Blockers (``Board.blocker_options`` set): where a new plant would make a
disallowed pair at an empty cell that is no planned spawn cell (typically
with a neighbouring group's plant), that cell may be filled with a *blocker*:
a solid that breeds with nothing around it. It is fertilized like a filler, so
it raises the spawn chance of the spawn cells it touches. Groups can then be
placed right against other groups instead of needing empty space around them.

Line groups (``max_donors`` > 1): a group may hold several copies of its
donor. Its spawn cells may then touch more than one of them; the donor x donor
pairs there are planned too (they make donor copies) and dilute the transfer
pairs, which ``group_value`` counts. Copies are added cell by cell where they
add value, so a group grows into a line, an L or a block as the space allows.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache

from ..models import Flower
from ..plots import PlotSlot, usable_cells

Cell = tuple[int, int]
PENDING = -1        # group id used while a placement is being evaluated
STABILITY = 0.5     # score bonus for reusing what a replanted plot already holds


@lru_cache(maxsize=200000)
def compatible(a: Flower, b: Flower) -> bool:
    """True when two touching flowers can breed into an empty plot.

    The wiki's rules (Flowers/Breeding): same type and same or mixable colors,
    whatever the patterns (a White Ombre and a Red Dandelily mix into Warm
    Pink); different types with at least one patterned; or both patterned.
    """
    from ..rules import mix_result

    pa, pb = a.pattern != "Solid", b.pattern != "Solid"
    if pa and pb:
        return True
    if a.flower_type != b.flower_type:
        return pa or pb
    return a.color == b.color or mix_result(a.color, b.color) is not None


def _ring(cell: Cell) -> set[Cell]:
    r, c = cell
    return {(r + dr, c + dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc}


@dataclass
class Group:
    """A donor (or mix parent A) with its recipients and reserved spawn cells."""

    gid: int
    donor_cell: Cell
    donor: Flower
    recipients: dict[Cell, object] = field(default_factory=dict)   # cell -> entry
    spawn: set[Cell] = field(default_factory=set)
    rate: float = 0.0
    donors: set[Cell] = field(default_factory=set)   # extra copies of the donor (line groups)
    blockers: dict[Cell, Flower] = field(default_factory=dict)   # cells the group plugged

    @property
    def donor_cells(self) -> list[Cell]:
        return [self.donor_cell, *sorted(self.donors)]


class Board:
    """One plot's cells: what is planted, which pairs are planned, which cells are reserved."""

    def __init__(self, slot: PlotSlot, outdoor_model: str = "wiki"):
        self.slot = slot
        self.greenhouse = slot.greenhouse
        self.outdoor_model = outdoor_model
        self.usable = frozenset(usable_cells(slot))
        self.nb = {c: frozenset(_ring(c) & self.usable) for c in self.usable}
        self.plant: dict[Cell, Flower] = {}
        self.pairs: dict[frozenset, int] = {}     # planned pair -> group id
        self.reserved: dict[Cell, int] = {}      # spawn cell -> group id
        self.groups: dict[int, Group] = {}
        self.beds: dict[Cell, Flower] = {}
        # What this plot held before a replant: among placements of similar
        # value, putting the same flower back in the same cell saves work.
        self.prior: dict[Cell, Flower] = {}
        # Solids a new group may plant as blockers, in order of preference (empty: none).
        self.blocker_options: list[Flower] = []
        self._next = 0

    # -------------------------------------------------------------- checks
    def free(self, cell: Cell) -> bool:
        return cell in self.usable and cell not in self.plant and cell not in self.reserved

    def _pair_ok(self, a: Cell, b: Cell, spawn_owner: int | None) -> bool:
        fa, fb = self.plant[a], self.plant[b]
        if not compatible(fa, fb):
            return True
        owner = self.pairs.get(frozenset((a, b)))
        if spawn_owner is not None:            # a planned spawn cell: only its own group's pairs
            return owner == spawn_owner
        return owner is not None or fa == fb   # elsewhere: planned pairs and self-copies

    def clean(self, cell: Cell, owner: int | None = None) -> bool:
        """Every compatible pair touching this empty cell is allowed.

        ``owner`` is the group the cell is (or will be) a spawn cell of.
        """
        if owner is None:
            owner = self.reserved.get(cell)
        around = [n for n in self.nb[cell] if n in self.plant]
        return all(self._pair_ok(a, b, owner) for i, a in enumerate(around) for b in around[i + 1:])

    def _around_ok(self, cell: Cell, spawn_only: bool = False) -> bool:
        """The plant at ``cell`` adds no disallowed pair at any empty neighbor.

        Only pairs involving the new plant are checked, so an existing
        imperfection elsewhere never blocks new work.
        """
        for e in self.nb[cell]:
            if e in self.plant:
                continue
            owner = self.reserved.get(e)
            if spawn_only and owner is None:
                continue
            for n in self.nb[e]:
                if n != cell and n in self.plant and not self._pair_ok(cell, n, owner):
                    return False
        return True

    def _plug(self, cell: Cell, keep: set[Cell]) -> list[tuple[Cell, Flower]] | None:
        """Make the plant at ``cell`` valid, with blockers if need be.

        Returns the blockers planted (already on the board; none if the plant
        was valid as it is), or None if it can't be made valid: a disallowed
        pair at a spawn cell (``keep``: the group's own, being planned) or a
        cell no blocker option fits. Undo with ``_unplug``.
        """
        if self._around_ok(cell):
            return []
        if not self.blocker_options:
            return None
        plugs: list[tuple[Cell, Flower]] = []
        for e in sorted(self.nb[cell]):
            if e in self.plant:
                continue
            owner = self.reserved.get(e)
            if all(n == cell or n not in self.plant or self._pair_ok(cell, n, owner) for n in self.nb[e]):
                continue
            flower = None if owner is not None or e in keep else self._blocker_for(e)
            if flower is None:
                self._unplug(plugs)
                return None
            self._put(e, flower)
            plugs.append((e, flower))
        if not self._around_ok(cell):
            self._unplug(plugs)
            return None
        return plugs

    def _blocker_for(self, cell: Cell) -> Flower | None:
        """The first blocker option that makes no disallowed pair at ``cell``."""
        for flower in self.blocker_options:
            self._put(cell, flower)
            ok = self._around_ok(cell)
            self._take(cell)
            if ok:
                return flower
        return None

    def _unplug(self, plugs) -> None:
        for e, _ in reversed(plugs):
            self.plant.pop(e, None)

    def chance(self, cell: Cell, extra: int = 0) -> float:
        if self.greenhouse:
            return 1.0
        if self.outdoor_model == "flat":
            return 0.10
        plants = sum(1 for n in self.nb[cell] if n in self.plant) + extra
        return min(0.80, 0.10 * plants)

    # ------------------------------------------------------------ mutation
    def _put(self, cell: Cell, flower: Flower) -> None:
        self.plant[cell] = flower

    def _take(self, cell: Cell) -> None:
        del self.plant[cell]

    def add_bed(self, cell: Cell, flower: Flower, spawn_only: bool = False) -> bool:
        """A fertilizer-bed plant. ``spawn_only`` (a plant already in the
        ground) only keeps it off breeding groups' spawn cells, so a planted
        bed is not dug up over a pair that slows no planned breeding."""
        if not self.free(cell):
            return False
        self._put(cell, flower)
        if not self._around_ok(cell, spawn_only=spawn_only):
            self._take(cell)
            return False
        self.beds[cell] = flower
        return True

    def _link(self, cell: Cell, others, gid: int) -> None:
        for o in others:
            if o != cell:
                self.pairs[frozenset((cell, o))] = gid

    def _unlink(self, cell: Cell, others) -> None:
        for o in others:
            self.pairs.pop(frozenset((cell, o)), None)

    def add_fixed_group(self, donor_cell: Cell, donor: Flower, recipients: dict[Cell, tuple[object, Flower]],
                        spawn: set[Cell] | None = None, tolerate_buffers: bool = False,
                        extra_donors: tuple[Cell, ...] = ()) -> Group | None:
        """Place a group at given cells (kept plantings, full hubs).

        ``spawn`` limits the spawn cells to a planned set; otherwise every clean
        empty cell touching a donor and a recipient is used. Returns None if
        the cells are taken or the placement would create an unplanned pair.
        ``tolerate_buffers`` (the simulator's hub layouts) only protects planned
        spawn cells: those layouts can leave a donor and a neighbouring hub's
        plant touching the same buffer cell, which may grow a stray flower but
        does not slow any planned pair. ``extra_donors``: the cells of a line
        group's other donor copies.
        """
        cells = [donor_cell, *extra_donors, *recipients]
        if any(not self.free(c) for c in cells) or len(set(cells)) != len(cells):
            return None
        group = self._new_group(donor_cell, donor)
        self._put(donor_cell, donor)
        for x in extra_donors:
            self._put(x, donor)
            group.donors.add(x)
        donors = group.donor_cells
        for rc, (_, flower) in recipients.items():
            self._put(rc, flower)
            group.recipients[rc] = None
        for i, x in enumerate(donors):
            self._link(x, [*recipients, *donors[i + 1:]], group.gid)
        if not all(self._around_ok(c, spawn_only=tolerate_buffers) for c in cells):
            self.remove_group(group)
            return None
        for rc, (entry, _) in recipients.items():
            group.recipients[rc] = entry
        candidates = set().union(*(self.nb[x] & self.nb[rc] for x in donors for rc in recipients)) if recipients else set()
        if spawn is not None:
            candidates &= spawn
        for s in sorted(candidates):
            if s in self.plant or s in self.reserved:
                continue
            if self.clean(s, owner=group.gid):
                self.reserved[s] = group.gid
                group.spawn.add(s)
        return group

    def add_propagator(self, cell: Cell, flower: Flower, min_spawn: int = 2,
                       spawn_only: bool = False, avoid: frozenset | set = frozenset()) -> Group | None:
        """A lone solid copying itself into the empty cells around it.

        Its spawn cells touch no other plant it (or anything else there) can
        breed with, so a copy is all that can grow there. ``spawn_only`` (a
        plant already in the ground) only keeps it off other groups' spawn
        cells. ``avoid``: cells never used as spawn cells (planted plants
        that are placed later). Returns None with fewer than ``min_spawn``
        spawn cells.
        """
        if not self.free(cell):
            return None
        group = self._new_group(cell, flower)
        self._put(cell, flower)
        if not self._around_ok(cell, spawn_only=spawn_only):
            self.remove_group(group)
            return None
        for s in sorted(self.nb[cell]):
            if s in self.plant or s in self.reserved or s in avoid:
                continue
            if self.clean(s, owner=group.gid):
                self.reserved[s] = group.gid
                group.spawn.add(s)
        if len(group.spawn) < min_spawn:
            self.remove_group(group)
            return None
        return group

    def _new_group(self, donor_cell: Cell, donor: Flower) -> Group:
        self._next += 1
        group = Group(self._next, donor_cell, donor)
        self.groups[group.gid] = group
        return group

    # ---------------------------------------------------- compact placement
    def _try_recipient(self, d: Cell, own: set[Cell], rc: Cell, flower: Flower,
                       gid: int, donors: list[Cell] | None = None
                       ) -> tuple[float, list[Cell], list[tuple[Cell, Flower]]] | None:
        """Score putting ``flower`` at ``rc`` for donor ``d`` (board restored afterwards).

        ``donors``: every cell holding the group's donor (a line group), else
        just ``d``. Returns (score, spawn cells, blockers it needs).
        """
        donors = donors or [d]
        shared = set().union(*(self.nb[x] for x in donors)) & self.nb[rc]
        spawn = [s for s in shared if s not in self.plant and (s in own or s not in self.reserved)]
        if not spawn:
            return None
        self._put(rc, flower)
        self._link(rc, donors, gid)
        check = set(spawn) | (own & self.nb[rc])
        plugs = self._plug(rc, check | own)
        ok = plugs is not None and all(self.clean(s, owner=gid) for s in check)
        score = sum(self.chance(s) for s in spawn) if ok else 0.0
        self._unplug(plugs or [])
        self._unlink(rc, donors)
        self._take(rc)
        if not ok or score <= 0:
            return None
        return score, spawn, plugs

    def _try_donor(self, x: Cell, donor: Flower, donors: list[Cell], recips: list[Cell], own: set[Cell],
                   gid: int) -> tuple[list[Cell], list[tuple[Cell, Flower]]] | None:
        """(new spawn cells, blockers it needs) if another donor copy goes at ``x``; None if it
        breaks a rule (board restored)."""
        self._put(x, donor)
        self._link(x, [*recips, *donors], gid)
        plugs = None
        try:
            spawn = [s for s in self.nb[x] if s not in self.plant and s not in own and s not in self.reserved
                     and any(rc in self.nb[s] for rc in recips)]
            check = set(spawn) | (own & self.nb[x])
            plugs = self._plug(x, check | own)
            if plugs is None or not all(self.clean(s, owner=gid) for s in check):
                return None
            return spawn, plugs
        finally:
            self._unplug(plugs or [])
            self._unlink(x, [*recips, *donors])
            self._take(x)

    def place_group(self, donor: Flower, entries: list[tuple[object, Flower, float]],
                    near: Cell | None = None, existing: dict[Cell, float] | None = None,
                    prefer: Cell | None = None, max_donors: int = 1) -> Group | None:
        """Place a donor and as many recipients as fit, as compactly as possible.

        ``entries`` is (entry, recipient flower, weight) in priority order.
        ``near`` fixes the donor cell (extending a placed group, whose
        recipients weigh ``existing``). ``prefer`` breaks ties toward a cell
        (a mix pair stays near the hub it was assigned to). ``max_donors``
        (> 1: a line group) caps the donor copies the group may hold, those
        it already has included. Returns the committed group, or None when
        not even one recipient fits.
        """
        if near is not None:
            starts = [near]
        else:
            starts = sorted(c for c in self.usable if self.free(c))
        best = None
        for d in starts:
            plan = self._plan_from(d, donor, entries, fixed=near is not None, existing=existing,
                                   max_donors=max_donors)
            if plan is None:
                continue
            value, cost, recips, spawn, new_donors, plugs = plan
            score = value / (cost + 4.0)
            if self.prior:
                plants = {d: donor, **{x: donor for x in new_donors}, **{rc: f for rc, (_, f) in recips.items()}}
                same = sum(1 for c, f in plants.items() if self.prior.get(c) == f)
                score *= 1.0 + STABILITY * same / len(plants)
            if prefer is not None:
                score /= 1.0 + 0.02 * max(abs(d[0] - prefer[0]), abs(d[1] - prefer[1]))
            if best is None or score > best[0]:
                best = (score, d, recips, spawn, new_donors, plugs)
        if best is None:
            return None
        _, d, recips, spawn, new_donors, plugs = best
        return self._commit(d, donor, recips, spawn, existing=near is not None, new_donors=new_donors,
                            plugs=plugs)

    def group_value(self, d: Cell, weights: dict[Cell, float], spawn: set[Cell],
                    donors: list[Cell] | None = None) -> float:
        """Expected value per day: each spawn cell yields at most one offspring.

        A spawn cell's daily chance comes from the plants around it; the
        offspring comes from one of the compatible pairs touching it, so its
        value is the mean weight of those pairs. With several donor copies
        (``donors``) touching a cell, each recipient pairs with every one of
        them, and each donor x donor pair (worth nothing here: it only makes
        a donor copy) takes its share of the spawns too.
        """
        total = 0.0
        for s in spawn:
            ws = [w for rc, w in weights.items() if rc in self.nb[s]]
            if not ws:
                continue
            nd = 1 if donors is None else max(1, sum(1 for x in donors if x in self.nb[s]))
            total += self.chance(s) * nd * sum(ws) / (nd * len(ws) + nd * (nd - 1) / 2)
        return total

    def _plan_from(self, d: Cell, donor: Flower, entries, fixed: bool, existing=None, max_donors: int = 1):
        own_spawn: set[Cell] = set()
        placed: dict[Cell, tuple[object, Flower]] = {}
        weights: dict[Cell, float] = {}
        donors: list[Cell] = [d]          # every cell holding the donor
        new_donors: list[Cell] = []
        plugs: list[tuple[Cell, Flower]] = []     # blockers planted for this plan
        gid = PENDING
        if fixed:
            group = next((g for g in self.groups.values() if g.donor_cell == d), None)
            if group is None:
                return None
            own_spawn = set(group.spawn)
            gid = group.gid
            weights = {rc: (existing or {}).get(rc, 1.0) for rc in group.recipients}
            donors = group.donor_cells
        else:
            self._put(d, donor)
            found = self._plug(d, set())
            if found is None:
                self._take(d)
                return None
            plugs.extend(found)
        line = max_donors > len(donors)
        value = self.group_value(d, weights, own_spawn, donors if line or len(donors) > 1 else None)
        cost = len(plugs)

        def put_plugs(found) -> None:
            for e, f in found:
                self._put(e, f)

        def best_donor():
            """The donor copy that adds the most value per cell it takes, or None."""
            if len(donors) >= max_donors or not weights:
                return None
            recips = list(weights)
            near = set()
            for c in own_spawn | {n for rc in recips for n in self.nb[rc]}:
                near |= self.nb[c]
            best = None
            for x in sorted(near):
                if x in own_spawn or not self.free(x) or x in self.plant:
                    continue
                trial = self._try_donor(x, donor, donors, recips, own_spawn, gid)
                if trial is None:
                    continue
                spawn, needed = trial
                self._put(x, donor)
                put_plugs(needed)
                gain = self.group_value(d, weights, own_spawn | set(spawn), donors + [x]) - value
                self._unplug(needed)
                self._take(x)
                if gain <= 0:
                    continue
                if self.prior.get(x) == donor:
                    gain *= 1.0 + STABILITY
                added = 1 + len(spawn) + len(needed)
                if best is None or gain / added > best[0]:
                    best = (gain / added, x, (spawn, needed), gain, added)
            return best

        def add_donor(found) -> None:
            nonlocal value, cost
            _, x, (spawn, needed), gain, added = found
            self._put(x, donor)
            put_plugs(needed)
            plugs.extend(needed)
            self._link(x, [*weights, *donors], gid)
            donors.append(x)
            new_donors.append(x)
            own_spawn.update(spawn)
            value += gain
            cost += added

        try:
            for entry, flower, weight in entries:
                while True:
                    best = None
                    for rc in self._recipient_cells(donors, own_spawn, placed):
                        trial = self._try_recipient(d, own_spawn, rc, flower, gid, donors)
                        if trial is None:
                            continue
                        spawn = own_spawn | set(trial[1])
                        self._put(rc, flower)
                        put_plugs(trial[2])
                        gain = self.group_value(d, {**weights, rc: weight}, spawn,
                                                donors if line or len(donors) > 1 else None) - value
                        self._unplug(trial[2])
                        self._take(rc)
                        added = 1 + len(set(trial[1]) - own_spawn) + len(trial[2])
                        if gain <= 0:
                            continue
                        if self.prior.get(rc) == flower:
                            gain *= 1.0 + STABILITY      # already planted here
                        if best is None or gain / added > best[0]:
                            best = (gain / added, rc, trial, gain, added)
                    # A line group: another donor copy first, when it is worth more per cell.
                    copy = best_donor() if line else None
                    if copy is not None and (best is None or copy[0] > best[0]):
                        add_donor(copy)
                        continue
                    break
                if best is None:
                    continue
                _, rc, (score, spawn, needed), gain, added = best
                placed[rc] = (entry, flower)
                weights[rc] = weight
                self._put(rc, flower)
                put_plugs(needed)
                plugs.extend(needed)
                self._link(rc, donors, gid)
                own_spawn |= set(spawn)
                value += gain
                cost += added
            while line and (copy := best_donor()) is not None:
                add_donor(copy)
            if not placed:
                return None
            footprint = (set(placed) | own_spawn | set(new_donors) | {e for e, _ in plugs}
                         | ({d} if not fixed else set()))
            ring = set()
            for s in own_spawn:
                ring |= {n for n in self.nb[s] if self.free(n) and n not in footprint}
            return (value, len(footprint) + 0.5 * len(ring), dict(placed), own_spawn, list(new_donors),
                    list(plugs))
        finally:
            self._unplug(plugs)
            for rc in placed:
                self._take(rc)
                self._unlink(rc, donors)
            for x in new_donors:
                self._take(x)
                self._unlink(x, [*weights, *donors])
            if not fixed:
                self._take(d)

    def _recipient_cells(self, donors: list[Cell], own_spawn: set[Cell], placed) -> list[Cell]:
        out = []
        seen = set(donors)
        for r0, c0 in donors:
            for r in range(r0 - 2, r0 + 3):
                for c in range(c0 - 2, c0 + 3):
                    cell = (r, c)
                    if cell in seen:
                        continue
                    seen.add(cell)
                    if cell in placed or cell in own_spawn or not self.free(cell):
                        continue
                    out.append(cell)
        return out

    def _commit(self, d: Cell, donor: Flower, recips: dict[Cell, tuple[object, Flower]],
                spawn: set[Cell], existing: bool, new_donors=(), plugs=()) -> Group:
        if existing:
            group = next(g for g in self.groups.values() if g.donor_cell == d)
        else:
            self._put(d, donor)
            group = self._new_group(d, donor)
        for e, flower in plugs:
            self._put(e, flower)
            group.blockers[e] = flower
        for x in new_donors:
            self._put(x, donor)
            group.donors.add(x)
        for rc, (entry, flower) in recips.items():
            self._put(rc, flower)
            group.recipients[rc] = entry
        donors = group.donor_cells
        for i, x in enumerate(donors):
            self._link(x, [*group.recipients, *donors[i + 1:]], group.gid)
        for s in spawn:
            if s not in self.plant:
                self.reserved[s] = group.gid
                group.spawn.add(s)
        return group

    def remove_group(self, group: Group) -> None:
        donors = group.donor_cells
        for rc in group.recipients:
            self.plant.pop(rc, None)
            self._unlink(rc, donors)
        for i, x in enumerate(donors):
            self._unlink(x, donors[i + 1:])
            self.plant.pop(x, None)
        for e in group.blockers:
            self.plant.pop(e, None)
        for s in group.spawn:
            self.reserved.pop(s, None)
        self.groups.pop(group.gid, None)

    def drop_recipient(self, group: Group, rc: Cell) -> None:
        """Remove one recipient and the spawn cells only it used."""
        group.recipients.pop(rc, None)
        self.plant.pop(rc, None)
        self._unlink(rc, group.donor_cells)
        for s in list(group.spawn):
            if not any(o in self.nb[s] for o in group.recipients):
                group.spawn.discard(s)
                self.reserved.pop(s, None)

    # ------------------------------------------------------------- reports
    def violations(self) -> list[Cell]:
        """Planned spawn cells touched by a pair that is not theirs (should be none)."""
        return [c for c in self.reserved if not self.clean(c)]

    def stray_cells(self) -> list[Cell]:
        """Buffer cells where an unplanned pair could grow a stray flower."""
        return [c for c in self.usable if c not in self.plant and c not in self.reserved and not self.clean(c)]

    def idle_cells(self) -> int:
        return sum(1 for c in self.usable if c not in self.plant and c not in self.reserved)
