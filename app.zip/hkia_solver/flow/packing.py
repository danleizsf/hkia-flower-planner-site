"""Cell-level packing for FLOW's day-one plan.

The simulator thinks in fixed *hubs* (one donor, up to ~14 recipient seats and
the spawn cells between them). That is the right abstraction for a forecast,
but on a real farm many hubs only get one or two jobs today, which leaves the
rest of their seats and spawn cells empty. This module places breeding groups
and fertilizer-bed plants cell by cell instead, so freed space goes to more
work.

Validity rule (checked for every empty cell after every placement): every
compatible pair of plants touching an empty cell must be a *planned* pair
(donor x one of its recipients). Identical flowers may touch the same empty
cell (they only make another copy of themselves), except around a planned
spawn cell, where they would dilute the planned pair's chance.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache

from ..models import Flower
from ..plots import PlotSlot, usable_cells

Cell = tuple[int, int]
PENDING = -1        # group id used while a placement is being evaluated
STABILITY = 0.5     # score bonus for reusing what a replanted plot already holds


@lru_cache(maxsize=200000)
def compatible(a: Flower, b: Flower) -> bool:
    """True when two touching flowers can breed into an empty plot.

    The wiki's rules (Flowers/Breeding): same type and same or mixable colors,
    whatever the patterns (a White Ombre and a Red Dandelily mix into Warm
    Pink); different types with at least one patterned; or both patterned.
    """
    from ..rules import mix_result

    pa, pb = a.pattern != "Solid", b.pattern != "Solid"
    if pa and pb:
        return True
    if a.flower_type != b.flower_type:
        return pa or pb
    return a.color == b.color or mix_result(a.color, b.color) is not None


def _ring(cell: Cell) -> set[Cell]:
    r, c = cell
    return {(r + dr, c + dc) for dr in (-1, 0, 1) for dc in (-1, 0, 1) if dr or dc}


@dataclass
class Group:
    """A donor (or mix parent A) with its recipients and reserved spawn cells."""

    gid: int
    donor_cell: Cell
    donor: Flower
    recipients: dict[Cell, object] = field(default_factory=dict)   # cell -> entry
    spawn: set[Cell] = field(default_factory=set)
    rate: float = 0.0


class Board:
    """One plot's cells: what is planted, which pairs are planned, which cells are reserved."""

    def __init__(self, slot: PlotSlot, outdoor_model: str = "wiki"):
        self.slot = slot
        self.greenhouse = slot.greenhouse
        self.outdoor_model = outdoor_model
        self.usable = frozenset(usable_cells(slot))
        self.nb = {c: frozenset(_ring(c) & self.usable) for c in self.usable}
        self.plant: dict[Cell, Flower] = {}
        self.pairs: dict[frozenset, int] = {}     # planned pair -> group id
        self.reserved: dict[Cell, int] = {}      # spawn cell -> group id
        self.groups: dict[int, Group] = {}
        self.beds: dict[Cell, Flower] = {}
        # What this plot held before a replant: among placements of similar
        # value, putting the same flower back in the same cell saves work.
        self.prior: dict[Cell, Flower] = {}
        self._next = 0

    # -------------------------------------------------------------- checks
    def free(self, cell: Cell) -> bool:
        return cell in self.usable and cell not in self.plant and cell not in self.reserved

    def _pair_ok(self, a: Cell, b: Cell, spawn_owner: int | None) -> bool:
        fa, fb = self.plant[a], self.plant[b]
        if not compatible(fa, fb):
            return True
        owner = self.pairs.get(frozenset((a, b)))
        if spawn_owner is not None:            # a planned spawn cell: only its own group's pairs
            return owner == spawn_owner
        return owner is not None or fa == fb   # elsewhere: planned pairs and self-copies

    def clean(self, cell: Cell, owner: int | None = None) -> bool:
        """Every compatible pair touching this empty cell is allowed.

        ``owner`` is the group the cell is (or will be) a spawn cell of.
        """
        if owner is None:
            owner = self.reserved.get(cell)
        around = [n for n in self.nb[cell] if n in self.plant]
        return all(self._pair_ok(a, b, owner) for i, a in enumerate(around) for b in around[i + 1:])

    def _around_ok(self, cell: Cell, spawn_only: bool = False) -> bool:
        """The plant at ``cell`` adds no disallowed pair at any empty neighbor.

        Only pairs involving the new plant are checked, so an existing
        imperfection elsewhere never blocks new work.
        """
        for e in self.nb[cell]:
            if e in self.plant:
                continue
            owner = self.reserved.get(e)
            if spawn_only and owner is None:
                continue
            for n in self.nb[e]:
                if n != cell and n in self.plant and not self._pair_ok(cell, n, owner):
                    return False
        return True

    def chance(self, cell: Cell, extra: int = 0) -> float:
        if self.greenhouse:
            return 1.0
        if self.outdoor_model == "flat":
            return 0.10
        plants = sum(1 for n in self.nb[cell] if n in self.plant) + extra
        return min(0.80, 0.10 * plants)

    # ------------------------------------------------------------ mutation
    def _put(self, cell: Cell, flower: Flower) -> None:
        self.plant[cell] = flower

    def _take(self, cell: Cell) -> None:
        del self.plant[cell]

    def add_bed(self, cell: Cell, flower: Flower, spawn_only: bool = False) -> bool:
        """A fertilizer-bed plant. ``spawn_only`` (a plant already in the
        ground) only keeps it off breeding groups' spawn cells, so a planted
        bed is not dug up over a pair that slows no planned breeding."""
        if not self.free(cell):
            return False
        self._put(cell, flower)
        if not self._around_ok(cell, spawn_only=spawn_only):
            self._take(cell)
            return False
        self.beds[cell] = flower
        return True

    def add_fixed_group(self, donor_cell: Cell, donor: Flower, recipients: dict[Cell, tuple[object, Flower]],
                        spawn: set[Cell] | None = None, tolerate_buffers: bool = False) -> Group | None:
        """Place a group at given cells (kept plantings, full hubs).

        ``spawn`` limits the spawn cells to a planned set; otherwise every clean
        empty cell touching the donor and a recipient is used. Returns None if
        the cells are taken or the placement would create an unplanned pair.
        ``tolerate_buffers`` (the simulator's hub layouts) only protects planned
        spawn cells: those layouts can leave a donor and a neighbouring hub's
        plant touching the same buffer cell, which may grow a stray flower but
        does not slow any planned pair.
        """
        cells = [donor_cell, *recipients]
        if any(not self.free(c) for c in cells):
            return None
        group = self._new_group(donor_cell, donor)
        self._put(donor_cell, donor)
        for rc, (_, flower) in recipients.items():
            self._put(rc, flower)
            self.pairs[frozenset((donor_cell, rc))] = group.gid
        if not all(self._around_ok(c, spawn_only=tolerate_buffers) for c in cells):
            self.remove_group(group)
            return None
        for rc, (entry, _) in recipients.items():
            group.recipients[rc] = entry
        candidates = set().union(*(self.nb[donor_cell] & self.nb[rc] for rc in recipients)) if recipients else set()
        if spawn is not None:
            candidates &= spawn
        for s in sorted(candidates):
            if s in self.plant or s in self.reserved:
                continue
            if self.clean(s, owner=group.gid):
                self.reserved[s] = group.gid
                group.spawn.add(s)
        return group

    def add_propagator(self, cell: Cell, flower: Flower, min_spawn: int = 2,
                       spawn_only: bool = False, avoid: frozenset | set = frozenset()) -> Group | None:
        """A lone solid copying itself into the empty cells around it.

        Its spawn cells touch no other plant it (or anything else there) can
        breed with, so a copy is all that can grow there. ``spawn_only`` (a
        plant already in the ground) only keeps it off other groups' spawn
        cells. ``avoid``: cells never used as spawn cells (planted plants
        that are placed later). Returns None with fewer than ``min_spawn``
        spawn cells.
        """
        if not self.free(cell):
            return None
        group = self._new_group(cell, flower)
        self._put(cell, flower)
        if not self._around_ok(cell, spawn_only=spawn_only):
            self.remove_group(group)
            return None
        for s in sorted(self.nb[cell]):
            if s in self.plant or s in self.reserved or s in avoid:
                continue
            if self.clean(s, owner=group.gid):
                self.reserved[s] = group.gid
                group.spawn.add(s)
        if len(group.spawn) < min_spawn:
            self.remove_group(group)
            return None
        return group

    def _new_group(self, donor_cell: Cell, donor: Flower) -> Group:
        self._next += 1
        group = Group(self._next, donor_cell, donor)
        self.groups[group.gid] = group
        return group

    # ---------------------------------------------------- compact placement
    def _try_recipient(self, d: Cell, own: set[Cell], rc: Cell, flower: Flower,
                       gid: int) -> tuple[float, list[Cell]] | None:
        """Score putting ``flower`` at ``rc`` for donor ``d`` (board restored afterwards)."""
        shared = self.nb[d] & self.nb[rc]
        spawn = [s for s in shared if s not in self.plant and (s in own or s not in self.reserved)]
        if not spawn:
            return None
        self._put(rc, flower)
        pair = frozenset((d, rc))
        self.pairs[pair] = gid
        check = set(spawn) | (own & self.nb[rc])
        ok = self._around_ok(rc) and all(self.clean(s, owner=gid) for s in check)
        score = sum(self.chance(s) for s in spawn) if ok else 0.0
        del self.pairs[pair]
        self._take(rc)
        if not ok or score <= 0:
            return None
        return score, spawn

    def place_group(self, donor: Flower, entries: list[tuple[object, Flower, float]],
                    near: Cell | None = None, existing: dict[Cell, float] | None = None,
                    prefer: Cell | None = None) -> Group | None:
        """Place a donor and as many recipients as fit, as compactly as possible.

        ``entries`` is (entry, recipient flower, weight) in priority order.
        ``near`` fixes the donor cell (extending a placed group, whose
        recipients weigh ``existing``). ``prefer`` breaks ties toward a cell
        (a mix pair stays near the hub it was assigned to). Returns the
        committed group, or None when not even one recipient fits.
        """
        if near is not None:
            starts = [near]
        else:
            starts = sorted(c for c in self.usable if self.free(c))
        best = None
        for d in starts:
            plan = self._plan_from(d, donor, entries, fixed=near is not None, existing=existing)
            if plan is None:
                continue
            value, cost, recips, spawn = plan
            score = value / (cost + 4.0)
            if self.prior:
                plants = {d: donor, **{rc: f for rc, (_, f) in recips.items()}}
                same = sum(1 for c, f in plants.items() if self.prior.get(c) == f)
                score *= 1.0 + STABILITY * same / len(plants)
            if prefer is not None:
                score /= 1.0 + 0.02 * max(abs(d[0] - prefer[0]), abs(d[1] - prefer[1]))
            if best is None or score > best[0]:
                best = (score, d, recips, spawn)
        if best is None:
            return None
        _, d, recips, spawn = best
        return self._commit(d, donor, recips, spawn, existing=near is not None)

    def group_value(self, d: Cell, weights: dict[Cell, float], spawn: set[Cell]) -> float:
        """Expected value per day: each spawn cell yields at most one offspring.

        A spawn cell's daily chance comes from the plants around it; the
        offspring comes from one of the planned pairs touching it, so its value
        is the mean weight of those pairs.
        """
        total = 0.0
        for s in spawn:
            ws = [w for rc, w in weights.items() if rc in self.nb[s]]
            if ws:
                total += self.chance(s) * sum(ws) / len(ws)
        return total

    def _plan_from(self, d: Cell, donor: Flower, entries, fixed: bool, existing=None):
        own_spawn: set[Cell] = set()
        placed: dict[Cell, tuple[object, Flower]] = {}
        weights: dict[Cell, float] = {}
        gid = PENDING
        if fixed:
            group = next((g for g in self.groups.values() if g.donor_cell == d), None)
            if group is None:
                return None
            own_spawn = set(group.spawn)
            gid = group.gid
            weights = {rc: (existing or {}).get(rc, 1.0) for rc in group.recipients}
        else:
            self._put(d, donor)
            if not self._around_ok(d):
                self._take(d)
                return None
        value = self.group_value(d, weights, own_spawn)
        cost = 0
        try:
            for entry, flower, weight in entries:
                best = None
                for rc in self._recipient_cells(d, own_spawn, placed):
                    trial = self._try_recipient(d, own_spawn, rc, flower, gid)
                    if trial is None:
                        continue
                    spawn = own_spawn | set(trial[1])
                    self._put(rc, flower)
                    gain = self.group_value(d, {**weights, rc: weight}, spawn) - value
                    self._take(rc)
                    added = 1 + len(set(trial[1]) - own_spawn)
                    if gain <= 0:
                        continue
                    if self.prior.get(rc) == flower:
                        gain *= 1.0 + STABILITY      # already planted here
                    if best is None or gain / added > best[0]:
                        best = (gain / added, rc, trial, gain, added)
                if best is None:
                    continue
                _, rc, (score, spawn), gain, added = best
                placed[rc] = (entry, flower)
                weights[rc] = weight
                self._put(rc, flower)
                self.pairs[frozenset((d, rc))] = gid
                own_spawn |= set(spawn)
                value += gain
                cost += added
            if not placed:
                return None
            footprint = set(placed) | own_spawn | ({d} if not fixed else set())
            ring = set()
            for s in own_spawn:
                ring |= {n for n in self.nb[s] if self.free(n) and n not in footprint}
            return value, len(footprint) + 0.5 * len(ring), dict(placed), own_spawn
        finally:
            for rc in placed:
                self._take(rc)
                self.pairs.pop(frozenset((d, rc)), None)
            if not fixed:
                self._take(d)

    def _recipient_cells(self, d: Cell, own_spawn: set[Cell], placed) -> list[Cell]:
        r0, c0 = d
        out = []
        for r in range(r0 - 2, r0 + 3):
            for c in range(c0 - 2, c0 + 3):
                cell = (r, c)
                if cell == d or cell in placed or cell in own_spawn or not self.free(cell):
                    continue
                out.append(cell)
        return out

    def _commit(self, d: Cell, donor: Flower, recips: dict[Cell, tuple[object, Flower]],
                spawn: set[Cell], existing: bool) -> Group:
        if existing:
            group = next(g for g in self.groups.values() if g.donor_cell == d)
        else:
            self._put(d, donor)
            group = self._new_group(d, donor)
        for rc, (entry, flower) in recips.items():
            self._put(rc, flower)
            self.pairs[frozenset((d, rc))] = group.gid
            group.recipients[rc] = entry
        for s in spawn:
            if s not in self.plant:
                self.reserved[s] = group.gid
                group.spawn.add(s)
        return group

    def remove_group(self, group: Group) -> None:
        for rc in group.recipients:
            self.plant.pop(rc, None)
            self.pairs.pop(frozenset((group.donor_cell, rc)), None)
        self.plant.pop(group.donor_cell, None)
        for s in group.spawn:
            self.reserved.pop(s, None)
        self.groups.pop(group.gid, None)

    def drop_recipient(self, group: Group, rc: Cell) -> None:
        """Remove one recipient and the spawn cells only it used."""
        group.recipients.pop(rc, None)
        self.plant.pop(rc, None)
        self.pairs.pop(frozenset((group.donor_cell, rc)), None)
        for s in list(group.spawn):
            if not any(o in self.nb[s] for o in group.recipients):
                group.spawn.discard(s)
                self.reserved.pop(s, None)

    # ------------------------------------------------------------- reports
    def violations(self) -> list[Cell]:
        """Planned spawn cells touched by a pair that is not theirs (should be none)."""
        return [c for c in self.reserved if not self.clean(c)]

    def stray_cells(self) -> list[Cell]:
        """Buffer cells where an unplanned pair could grow a stray flower."""
        return [c for c in self.usable if c not in self.plant and c not in self.reserved and not self.clean(c)]

    def idle_cells(self) -> int:
        return sum(1 for c in self.usable if c not in self.plant and c not in self.reserved)
