"""Use FLOW for Generate plan.

``run_solver.py`` first builds the regular plan (summary, feasibility, blocked
targets and the other fields the dashboard reads), then replaces the planting
recommendation (``first_wave`` and ``plot_jobs``) with FLOW's day-one plan for
today.

settings.json:
    "flow": {
        "cogimyun_wheatflour": true,   # Cogimyun's 5% fertilizer bonus in Wheatflour Wonderland
        "outdoor_model": "wiki",       # "wiki" (fertilizer stacking) or "flat" (v72's 10%)
        "preliminary_first": true      # extremophile pattern transfers wait for the preliminary target
    }
"""
from __future__ import annotations

import datetime as dt
from collections import Counter

from ..models import Flower
from ..plots import extreme_gardening_mode
from ..rules import FLOWER_TYPES
from .layouts import farm_layouts
from .plan_today import farm_propagation_needs, plan_today
from .scheduler import FlowConfig


def is_extreme_transfer(t: Flower) -> bool:
    ft = FLOWER_TYPES[t.flower_type]
    return ft.extreme and t.pattern not in ("Solid", ft.default_pattern)


def auxiliary_prerequisites(required: set[Flower], owned: dict[Flower, int]) -> set[Flower]:
    """Zero-copy prerequisites: recipient solids and missing front donors."""
    aux: set[Flower] = set()
    for t in required:
        if t.pattern != "Solid":
            solid = Flower(t.flower_type, t.color, "Solid")
            if owned.get(solid, 0) <= 0 and solid not in required:
                aux.add(solid)
    fronts = {(t.color, t.pattern) for t in required
              if t.pattern not in ("Solid", FLOWER_TYPES[t.flower_type].default_pattern)}
    have = {(f.color, f.pattern) for f, n in owned.items() if n > 0 and f.pattern != "Solid"}
    have |= {(t.color, t.pattern) for t in required
             if t.pattern != "Solid" and t.pattern == FLOWER_TYPES[t.flower_type].default_pattern}
    for color, pattern in fronts - have:
        for name, ft in FLOWER_TYPES.items():
            if ft.default_pattern == pattern and owned.get(Flower(name, color, "Solid"), 0) > 0:
                aux.add(Flower(name, color, pattern))
                break
    return aux


def _flow_inputs(planner, today: dt.date | None = None):
    """(owned, viable, aux, cfg, priority) for today's FLOW plan."""
    options = planner.settings.get("flow", {}) or {}
    inv = planner.inventory
    owned = {f: inv.physical_count(f) for f in inv.all if inv.counts.get(f, 1) > 0}
    viable = set(planner.missing_targets - planner.unreachable_required)
    priority = ({t for t in viable if not is_extreme_transfer(t)}
                if options.get("preliminary_first", True) else None)
    cfg = FlowConfig(
        outdoor_model=options.get("outdoor_model", "wiki"),
        cogimyun_ww=bool(options.get("cogimyun_wheatflour", False)),
        extreme_gardening=extreme_gardening_mode(planner.settings),
        start_date=today or dt.date.today(),
    )
    return owned, viable, auxiliary_prerequisites(viable, owned), cfg, priority


def refresh_plot(planner, plan: dict, slot: str, today: dt.date | None = None) -> list[dict]:
    """A fresh FLOW layout for one plot; the rest of the farm stays as planned.

    Plots never share cells, so the rest of the farm only matters for copies
    and for which targets are already being bred. The plot is planned on its
    own with the copies the other plots' plans leave over (a plot the plan
    leaves out counts its recorded plants), and with the other plots' targets
    counted toward the parallel-attempt limits. No copy can be double-booked,
    and a solid another plot already propagates gets no propagator here.
    """
    from .unified import plan_to_status

    slot = slot.upper()
    others = {
        "first_wave": [j for j in plan.get("first_wave", []) if j["slot"].upper() != slot],
        "plot_jobs": {s: js for s, js in plan.get("plot_jobs", {}).items() if s.upper() != slot},
    }
    def counts(record) -> Counter:
        return Counter(Flower(c["flower_type"], c["color"], c["pattern"], c.get("secondary_color"))
                       for c in record.get("cells", []))

    recorded = {name.upper(): counts(r) for name, r in (planner.plot_status or {}).get("plots", {}).items()}
    used: Counter = Counter()
    busy: Counter = Counter()
    planned_slots = set()
    for name, record in plan_to_status(others)["plots"].items():
        planned_slots.add(name.upper())
        # A plant still in the ground there is not spare, even if that plot's
        # plan clears it: plants never move from one plot to another.
        plan_counts, have = counts(record), recorded.get(name.upper(), Counter())
        used.update({f: max(plan_counts[f], have[f]) for f in set(plan_counts) | set(have)})
    def target(job) -> Flower:
        return Flower(job["target_type"], job["target_color"], job["target_pattern"],
                      job.get("target_secondary_color"))

    # Solids another plot propagates get no second propagator in this plot.
    propagating: set[Flower] = set()
    for job in others["first_wave"] + [j for js in others["plot_jobs"].values() for j in js]:
        if job.get("method") != "fertilize_pattern":
            busy[target(job)] += 1
        if job.get("method") == "propagate_solid":
            propagating.add(target(job))
    for name, record in (planner.plot_status or {}).get("plots", {}).items():
        if name.upper() != slot and name.upper() not in planned_slots:
            for cell in record.get("cells", []):
                used[Flower(cell["flower_type"], cell["color"], cell["pattern"], cell.get("secondary_color"))] += 1
            for job in [record.get("assignment") or {}] + list(record.get("jobs") or []):
                if job.get("method") == "propagate_solid" and job.get("target_type"):
                    propagating.add(target(job))
    owned, viable, aux, cfg, priority = _flow_inputs(planner, today)
    spare = {f: n - used[f] for f, n in owned.items() if n - used[f] > 0}
    mine = {k: v for k, v in (planner.plot_status or {}).get("plots", {}).items() if k.upper() == slot}
    result = plan_today(spare, viable, aux, {"plots": mine}, cfg, priority=priority, only_slots={slot},
                        busy_targets=busy, replant={slot}, propagating=propagating,
                        propagation_needs=farm_propagation_needs(owned, viable, aux, cfg, priority))
    if result["stats"]["copy_overuse"]:
        raise ValueError(f"FLOW plan uses more copies than owned: {result['stats']['copy_overuse']}")
    return ([j for j in result["first_wave"] if j["slot"].upper() == slot]
            + list(result["plot_jobs"].get(slot, [])))


def apply_flow_plan(planner, plan: dict, today: dt.date | None = None, replant_all: bool = False) -> dict:
    """Replace the plan's planting recommendation with FLOW's plan for today.

    ``replant_all`` plans every plot from scratch, ignoring what is planted
    (a farm-wide replant, e.g. at an event season change).
    """
    owned, viable, aux, cfg, priority = _flow_inputs(planner, today)
    every = {s.upper() for s in (planner.plot_status or {}).get("plots", {})} if replant_all else None
    # The plot layouts plan_today needs (searched once, then cached): first, as their own progress stage.
    farm_layouts(cfg.outdoor_model, cfg.extreme_gardening == "now")
    result = plan_today(owned, viable, aux, planner.plot_status, cfg, priority=priority, replant=every,
                        full_refresh=replant_all)
    if replant_all:
        result["stats"]["replant_all"] = True
    if result["stats"]["copy_overuse"]:
        raise ValueError(f"FLOW plan uses more copies than owned: {result['stats']['copy_overuse']}")
    plan["first_wave"] = result["first_wave"]
    plan["plot_jobs"] = result["plot_jobs"]
    plan["background_first_wave"] = []
    methods = Counter(j["method"] for j in result["first_wave"])
    methods.update(j["method"] for jobs in result["plot_jobs"].values() for j in jobs)
    plan.setdefault("method_counts", {})["first_wave"] = dict(sorted(methods.items()))
    summary = plan.setdefault("summary", {})
    summary["planner"] = "flow"
    summary["first_wave_job_count"] = sum(methods.values())
    summary["first_wave_physical_plots_used"] = result["stats"]["plots_used"]
    plan["flow"] = {**result["stats"], "as_of": cfg.start_date.isoformat(),
                    "outdoor_model": cfg.outdoor_model, "cogimyun_wheatflour": cfg.cogimyun_ww,
                    "preliminary_first": priority is not None}
    return plan
