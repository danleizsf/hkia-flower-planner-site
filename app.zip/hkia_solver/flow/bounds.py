"""Capacity lower bounds on the collection finish (expected spawn work / capacity).

These are *relaxations*: they ignore dependencies, donor availability and
integrality, so no schedule can beat them under the same mechanics model. They
tell us how far any heuristic schedule is from the physical limit.
"""
from __future__ import annotations

import datetime as dt

from ..models import Flower
from ..rules import FLOWER_TYPES
from .layouts import farm_layouts


def lower_bounds(viable: set[Flower], owned: dict[Flower, int], cfg) -> dict:
    from .scheduler import EVENT_WINDOWS, _spawn_window

    unlocked = cfg.extreme_gardening != "never"
    layouts = farm_layouts(cfg.outdoor_model, unlocked)
    gh_rate = sum(l.spawn_rate for l in layouts if l.slot.greenhouse)
    out_rate_by_region: dict[str, float] = {}
    for l in layouts:
        if not l.slot.greenhouse:
            out_rate_by_region[l.slot.region] = out_rate_by_region.get(l.slot.region, 0.0) + l.spawn_rate
    total_out = sum(out_rate_by_region.values())
    # One recipient seat per flower type per hub: in a window, an event flower
    # can use one seat in each legal outdoor hub.
    seat_rate_by_region: dict[str, float] = {}
    for l in layouts:
        if not l.slot.greenhouse:
            seat_rate_by_region[l.slot.region] = seat_rate_by_region.get(l.slot.region, 0.0) + sum(
                h.spawn_rate / max(1, h.recipient_slots) for h in l.hubs)

    best_solid = 1.0 / cfg.p_color_mix
    gh_only_work: dict[str, float] = {}   # event type -> spawns needed
    outdoor_work = 0.0
    extreme_plot_days: dict[str, float] = {}
    extreme_work = 0.0
    for t in viable:
        ft = FLOWER_TYPES[t.flower_type]
        if t.pattern != "Solid" and t.pattern == ft.default_pattern:
            continue  # fertilizer work, not spawn work
        need = best_solid if t.pattern == "Solid" else 1.0 / cfg.p_pattern
        if ft.extreme:
            # Native 6-cell plot at the 2% event-donor rate, or (after Extreme
            # Gardening) the Greenhouse at 1%.
            native_rate = out_rate_by_region.get(ft.native_region, 0.0)
            plot_need = best_solid if t.pattern == "Solid" else 1.0 / cfg.p_pattern_event_donor_outdoor
            extreme_plot_days[t.flower_type] = extreme_plot_days.get(t.flower_type, 0.0) + plot_need / max(native_rate, 1e-9)
            extreme_work += need
            continue
        if ft.event:
            gh_only_work[t.flower_type] = gh_only_work.get(t.flower_type, 0.0) + need
        else:
            # Best case: 2% event donor outdoors.
            outdoor_work += best_solid if t.pattern == "Solid" else 1.0 / cfg.p_pattern_event_donor_outdoor

    event_total = sum(gh_only_work.values()) + (extreme_work if unlocked else 0.0)
    # Event bound: greenhouse every day, plus each type's outdoor zones during its window.
    extreme_regions = {FLOWER_TYPES[n].native_region for n in FLOWER_TYPES if FLOWER_TYPES[n].extreme}
    # Native extremophile plots keep working at the 2% event-donor rate; in
    # 1%-spawn units that is rate x (2% / 1%). Only useful while extremophile
    # work remains, so cap it at the extremophile share.
    plot_rate_1pct = (sum(out_rate_by_region.get(r, 0.0) for r in extreme_regions)
                      * cfg.p_pattern_event_donor_outdoor / cfg.p_pattern) if unlocked else 0.0

    window_gain = cfg.p_pattern_event_donor_outdoor / cfg.p_pattern

    def event_capacity_until(days: int) -> float:
        cap = gh_rate * days + min(plot_rate_1pct * days, extreme_work if unlocked else 0.0)
        if not cfg.use_event_windows:
            return cap
        for d in range(days):
            day = cfg.start_date + dt.timedelta(days=d)
            for name, ft in FLOWER_TYPES.items():
                if ft.event and name in gh_only_work and _spawn_window(day, EVENT_WINDOWS.get(ft.event, ((1, 1), (0, 0)))):
                    # In-season event targets may use an out-of-season event
                    # donor outdoors: 2% per spawn, i.e. 2x in 1%-spawn units.
                    cap += window_gain * sum(r for reg, r in seat_rate_by_region.items() if reg in _zones(name))
        return cap

    lo, hi = 0, 200000
    while lo < hi:
        mid = (lo + hi) // 2
        if event_capacity_until(mid) >= event_total:
            hi = mid
        else:
            lo = mid + 1
    event_bound = lo
    total_bound = (event_total + outdoor_work) / max(1e-9, gh_rate + total_out)
    extreme_plot_bound = round(max(extreme_plot_days.values(), default=0.0))
    return {
        "extremophile_native_plot_days_at_2pct": {k: round(v) for k, v in extreme_plot_days.items()},
        "greenhouse_spawns_per_day": round(gh_rate, 1),
        "outdoor_spawns_per_day": round(total_out, 1),
        "event_only_spawn_work": round(event_total),
        "outdoor_capable_spawn_work_best_case": round(outdoor_work),
                "total_work_bound_days": round(total_bound),
        "greenhouse_bound_days": event_bound,
        "lower_bound_days": (max(event_bound, round(total_bound)) if unlocked
                             else max(event_bound, round(total_bound), extreme_plot_bound)),
        "note": ("Extremophile work may use the Greenhouse after Extreme Gardening (bound assumes unlocked from day 0)."
                 if unlocked else "Extremophiles confined to their 6-cell native plots."),
    }


def _zones(flower_type: str):
    from ..zones import flower_zones
    return flower_zones().get(flower_type, ())
