"""Donor-hub plot layouts for the front-based throughput planner.

A *hub* is one patterned donor (D), the recipient solids (R) around it and the
empty cells (E) that can only produce a donor x recipient spawn. A cell is a
*useful spawn cell* when it

* is empty,
* touches exactly one donor (two patterned flowers are always compatible, so a
  second donor would add wasted hybrid pairs), and
* touches at least one recipient, every one of which belongs to that donor's hub
  (a foreign recipient would add a pair whose outcome we did not plan).

Recipients in one hub are always distinct flower types, so recipient x
recipient pairs are incompatible and every compatible pair touching a useful
cell is a planned donor x recipient attempt.

Spawn chance per useful cell per day:

* Greenhouse: 1.0 (every empty plot touching a grown flower spawns).
* Outdoors (wiki rule): 10% per fertilized flower touching the plot, additive,
  capped at 80%. ``outdoor_model="flat"`` reproduces the v72 assumption of a
  flat 10% per cell so the two models can be compared.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from functools import lru_cache

from .. import progress
from ..plots import PlotSlot, all_slots, farm_plots_key, usable_cells

EMPTY, DONOR, RECIP, BED = 0, 1, 2, 3

Cell = tuple[int, int]


@dataclass(frozen=True)
class Hub:
    """One schedulable machine: a donor cell, its recipients and spawn cells."""

    slot: str
    region: str
    greenhouse: bool
    donor: Cell
    recipients: tuple[Cell, ...]
    spawn_cells: tuple[Cell, ...]
    spawn_rate: float  # expected spawns per day summed over spawn cells

    @property
    def recipient_slots(self) -> int:
        return len(self.recipients)


@dataclass(frozen=True)
class SlotLayout:
    slot: PlotSlot
    roles: dict[Cell, int]
    hubs: tuple[Hub, ...]
    bed_cells: tuple[Cell, ...]

    @property
    def spawn_rate(self) -> float:
        return sum(hub.spawn_rate for hub in self.hubs)


def _neighbors(cell: Cell, usable: frozenset[Cell]) -> tuple[Cell, ...]:
    r, c = cell
    return tuple(
        (r + dr, c + dc)
        for dr in (-1, 0, 1)
        for dc in (-1, 0, 1)
        if (dr or dc) and (r + dr, c + dc) in usable
    )


def _spawn_chance(plants: int, greenhouse: bool, outdoor_model: str) -> float:
    if greenhouse:
        return 1.0
    if outdoor_model == "flat":
        return 0.10
    return min(0.80, 0.10 * plants)


def evaluate(
    roles: dict[Cell, int],
    usable: frozenset[Cell],
    nbrs: dict[Cell, tuple[Cell, ...]],
    greenhouse: bool,
    outdoor_model: str,
) -> tuple[float, dict[Cell, tuple[Cell, set[Cell], float]]]:
    """Score a role assignment; return (total useful rate, useful cell map)."""
    # First pass: candidate useful cells and the donor that owns each.
    useful: dict[Cell, tuple[Cell, set[Cell], float]] = {}
    recipient_owner: dict[Cell, Cell | None] = {}
    for cell in usable:
        if roles[cell] != EMPTY:
            continue
        donors = [n for n in nbrs[cell] if roles[n] == DONOR]
        if len(donors) != 1:
            continue
        recips = {n for n in nbrs[cell] if roles[n] == RECIP}
        if not recips:
            continue
        plants = sum(1 for n in nbrs[cell] if roles[n] in (DONOR, RECIP))
        useful[cell] = (donors[0], recips, _spawn_chance(plants, greenhouse, outdoor_model))
        for r in recips:
            owner = recipient_owner.get(r, donors[0])
            recipient_owner[r] = owner if owner == donors[0] else None
    # Second pass: a recipient shared by two hubs invalidates the cells it touches.
    total = 0.0
    valid: dict[Cell, tuple[Cell, set[Cell], float]] = {}
    for cell, (donor, recips, chance) in useful.items():
        if all(recipient_owner[r] == donor for r in recips):
            valid[cell] = (donor, recips, chance)
            total += chance
    return total, valid


def _template(usable: frozenset[Cell], dr: int, dc: int, kind: int) -> dict[Cell, int]:
    roles: dict[Cell, int] = {}
    for r, c in usable:
        a, b = (r + dr) % 3, (c + dc) % 3
        center = a == 1 and b == 1
        corner = a != 1 and b != 1
        if center:
            roles[(r, c)] = DONOR
        elif (corner and kind == 0) or (not corner and kind == 1):
            roles[(r, c)] = RECIP
        else:
            roles[(r, c)] = EMPTY
    return roles


def optimize_slot(
    slot: PlotSlot,
    outdoor_model: str = "wiki",
    passes: int = 6,
    seed: int = 7,
    on_progress=None,
) -> SlotLayout:
    usable = frozenset(usable_cells(slot))
    nbrs = {cell: _neighbors(cell, usable) for cell in usable}
    best_roles: dict[Cell, int] | None = None
    best_score = -1.0
    for kind in (0, 1):
        for dr in range(3):
            for dc in range(3):
                roles = _template(usable, dr, dc, kind)
                score, _ = evaluate(roles, usable, nbrs, slot.greenhouse, outdoor_model)
                if score > best_score:
                    best_roles, best_score = roles, score
    assert best_roles is not None
    roles = dict(best_roles)
    rng = random.Random(seed)
    cells = sorted(usable)
    # First-improvement hill climbing over single-cell role changes.
    for _ in range(passes):
        improved = False
        rng.shuffle(cells)
        for cell in cells:
            current = roles[cell]
            for role in (EMPTY, DONOR, RECIP):
                if role == current:
                    continue
                roles[cell] = role
                score, _ = evaluate(roles, usable, nbrs, slot.greenhouse, outdoor_model)
                if score > best_score + 1e-9:
                    best_score, current, improved = score, role, True
                else:
                    roles[cell] = current
        if not improved:
            break
    if slot.greenhouse:
        # The Greenhouse is the binding resource: spend extra search on it.
        roles, best_score = _anneal(roles, best_score, usable, nbrs, outdoor_model, on_progress=on_progress)
    _, useful = evaluate(roles, usable, nbrs, slot.greenhouse, outdoor_model)
    hubs: dict[Cell, dict] = {}
    for cell, (donor, recips, chance) in useful.items():
        hub = hubs.setdefault(donor, {"recips": set(), "cells": [], "rate": 0.0})
        hub["recips"] |= recips
        hub["cells"].append(cell)
        hub["rate"] += chance
    used = set(hubs)
    for hub in hubs.values():
        used |= hub["recips"] | set(hub["cells"])
    # Cells that belong to no hub become fertilizer beds.
    beds = tuple(sorted(cell for cell in usable if cell not in used))
    for cell in beds:
        roles[cell] = BED
    return SlotLayout(
        slot=slot,
        roles=roles,
        hubs=tuple(
            Hub(
                slot=slot.slot,
                region=slot.region,
                greenhouse=slot.greenhouse,
                donor=donor,
                recipients=tuple(sorted(hub["recips"])),
                spawn_cells=tuple(sorted(hub["cells"])),
                spawn_rate=hub["rate"],
            )
            for donor, hub in sorted(hubs.items())
        ),
        bed_cells=beds,
    )


def _anneal(roles, score, usable, nbrs, outdoor_model, seeds=(0, 1, 2), iters=40000, on_progress=None):
    import math

    best_roles, best_score = dict(roles), score
    cells = sorted(usable)
    for run, seed in enumerate(seeds):
        rng = random.Random(seed)
        cur_roles = dict(roles)
        cur, _ = evaluate(cur_roles, usable, nbrs, True, outdoor_model)
        for i in range(iters):
            if on_progress is not None and i % 1000 == 0:
                on_progress((run + i / iters) / len(seeds))
            temp = 2.0 * (1 - i / iters) + 0.01
            cell = rng.choice(cells)
            old = cur_roles[cell]
            cur_roles[cell] = rng.choice([x for x in (EMPTY, DONOR, RECIP) if x != old])
            s, _ = evaluate(cur_roles, usable, nbrs, True, outdoor_model)
            if s >= cur or rng.random() < math.exp((s - cur) / temp):
                cur = s
                if cur > best_score:
                    best_roles, best_score = dict(cur_roles), cur
            else:
                cur_roles[cell] = old
    return best_roles, best_score


def farm_layouts(outdoor_model: str = "wiki", extreme: bool = False) -> tuple[SlotLayout, ...]:
    """Hub layouts for every plot the farm has unlocked.

    ``extreme``: plan the Greenhouse as it will be after the Extreme
    Gardening upgrade (a 10 x 10 one grows to 10 x 11).
    """
    return _farm_layouts(outdoor_model, extreme, farm_plots_key())


@lru_cache(maxsize=8)
def _farm_layouts(outdoor_model: str, extreme: bool, _plots_key: tuple) -> tuple[SlotLayout, ...]:
    """Cached on disk (the search takes ~10 s).

    The cache key covers this file's code and every plot's shape, so a code
    or plot change (or another farm's unlocked plots) recomputes it.
    """
    import dataclasses
    import hashlib
    import pickle
    from pathlib import Path

    slots = all_slots()
    for i, slot in enumerate(slots):
        if extreme and slot.greenhouse and (slot.rows, slot.cols) == (10, 10):
            # Extreme Gardening upgrade: 10 x 11 Greenhouse.
            slots[i] = dataclasses.replace(slot, cols=11, spots=slot.rows * 11)
    digest = hashlib.sha256(Path(__file__).read_bytes())
    digest.update(repr((outdoor_model, [(s.slot, s.rows, s.cols, s.greenhouse, sorted(usable_cells(s)))
                                         for s in slots])).encode())
    cache = Path(__file__).resolve().parents[2] / ".cache" / "flow_layouts" / f"{digest.hexdigest()[:24]}.pickle"
    try:
        with open(cache, "rb") as fh:
            return pickle.load(fh)
    except (OSError, pickle.PickleError, EOFError, AttributeError):
        pass
    # The Greenhouse's search (annealing) is ~90% of the time; the outdoor plots share the rest.
    gh_share = 0.9 if any(s.greenhouse for s in slots) else 0.0
    outdoor = [s for s in slots if not s.greenhouse]
    layouts = []
    for index, slot in enumerate(slots):
        if slot.greenhouse:
            start, span = 0.0, gh_share
        else:
            start = gh_share + (1 - gh_share) * outdoor.index(slot) / len(outdoor)
            span = (1 - gh_share) / len(outdoor)
        detail = f"{slot.plot} ({index + 1} of {len(slots)})"
        progress.report("layouts", start, detail)
        layouts.append(optimize_slot(slot, outdoor_model, on_progress=lambda f, start=start, span=span, detail=detail:
                                     progress.report("layouts", start + span * f, detail)))
    layouts = tuple(layouts)
    try:
        cache.parent.mkdir(parents=True, exist_ok=True)
        tmp = cache.with_suffix(f".{id(layouts)}.tmp")
        with open(tmp, "wb") as fh:
            pickle.dump(layouts, fh)
        tmp.replace(cache)
    except OSError:
        pass                      # a read-only install just recomputes
    return layouts


def render(layout: SlotLayout) -> str:
    glyph = {EMPTY: ".", DONOR: "D", RECIP: "r", BED: "b"}
    usable = usable_cells(layout.slot)
    lines = []
    for r in range(layout.slot.rows):
        lines.append("".join(
            glyph[layout.roles[(r, c)]] if (r, c) in usable else " "
            for c in range(layout.slot.cols)
        ))
    return "\n".join(lines)
