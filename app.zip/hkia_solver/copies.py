"""Flower copies: one count for the whole farm, whatever each plant is for.

A copy is a flower variant (type, color, pattern, secondary color). A plant's
role (breeding parent, filler, blocker, propagator, fertilizer bed) never
changes how it counts: every plant recorded in a plot holds one copy there.

- Owned copies are the inventory's recorded counts; a flower without a count
  has none.
- Only recorded plots hold copies (state planted or goal_reached). A
  Recommendation never changes the count until its plot is recorded.
- A plant stays with its plot until that plot is recorded: the plot's own
  plan may reuse it or clear it, other plots can't have it.
- Batch (Replant the whole farm): the plots being replanted *release* the
  plants their plans drop, and another plot may take one as a recorded
  *move* (dig it up there first). Recording a plot that takes a copy still
  in another plot's ground is refused until that plot is recorded.

Everything that counts copies goes through this module: the planner, Replant
plot, fillers, the Inventory tab and the recording checks.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Iterable, Mapping

from .models import Flower

IN_GROUND = frozenset({"planted", "goal_reached"})


def cell_flower(cell: Mapping) -> Flower:
    return Flower(cell["flower_type"], cell["color"], cell["pattern"], cell.get("secondary_color"))


def owned_counts(inventory) -> dict[Flower, int]:
    """Copies owned of every collected flower: its recorded count, else 0."""
    return {flower: inventory.counts.get(flower, 0) for flower in inventory.all}


def planted_by_plot(plot_status: Mapping | None) -> dict[str, Counter[Flower]]:
    """Copies in the ground, per recorded plot (every plant, whatever its role)."""
    by_plot: dict[str, Counter[Flower]] = {}
    for slot, record in (plot_status or {}).get("plots", {}).items():
        if record.get("state", record.get("status", "planted")) not in IN_GROUND:
            continue
        counts: Counter[Flower] = Counter()
        cells = record.get("cells")
        if isinstance(cells, list):
            counts.update(cell_flower(cell) for cell in cells)
        else:
            # A record from before plants were stored cell by cell.
            for job in [record.get("assignment") or record] + [j for j in record.get("jobs", []) if isinstance(j, dict)]:
                for parent, n in zip(job.get("parent_flowers", []), job.get("parent_copies", []), strict=False):
                    counts[cell_flower(parent)] += int(n)
        if counts:
            by_plot[slot.upper()] = counts
    return by_plot


def planted_counts(plot_status: Mapping | None) -> Counter[Flower]:
    """Copies in the ground, farm-wide."""
    total: Counter[Flower] = Counter()
    for counts in planted_by_plot(plot_status).values():
        total.update(counts)
    return total


class Copies:
    """The farm's copies while plans are made, read and written as one plot.

    ``pool`` holds the copies not planted anywhere, ``reserve[slot]`` the
    ones in that plot's ground. Inside ``at(slot)``, reading a flower gives
    what that plot can plant (the pool, its own plants and, in a batch, what
    the released plots don't use) and writing takes or gives back copies in
    that order: its own first, then the pool, then a released plot's (a move).
    Taking more than there is is a shortage: that plot (and the farm) reads
    negative, other plots don't lose anything. Outside any plot, reads and
    writes cover the whole farm.
    """

    def __init__(self, owned: Mapping[Flower, int], planted: Mapping[str, Mapping[Flower, int]],
                 release: Iterable[str] = ()):
        total: Counter[Flower] = Counter()
        for counts in planted.values():
            total.update(counts)
        self.pool: Counter[Flower] = Counter({f: max(0, n - total[f]) for f, n in owned.items() if n > 0})
        self.reserve: dict[str, Counter[Flower]] = defaultdict(Counter)
        for slot, counts in planted.items():
            self.reserve[slot.upper()].update(counts)
        # All plots' reserves summed, kept in step with ``reserve``: reads
        # outside a plot are the hottest call in planning.
        self.held: Counter[Flower] = Counter()
        for counts in self.reserve.values():
            self.held.update(counts)
        self.released: frozenset[str] = frozenset(s.upper() for s in release)
        # What the released plots hold, summed (same reason as ``held``).
        self.loose: Counter[Flower] = Counter()
        for slot in self.released:
            self.loose.update(self.reserve.get(slot, ()))
        self.from_pool: dict[str | None, Counter[Flower]] = defaultdict(Counter)
        self.from_reserve: dict[str, Counter[Flower]] = defaultdict(Counter)
        self.moves: Counter[tuple[str, str, Flower]] = Counter()     # (from plot, to plot, flower)
        self._moved_in: dict[tuple[str, Flower], Counter[str]] = {}   # (to plot, flower) -> from plots
        self.short: dict[str | None, Counter[Flower]] = defaultdict(Counter)
        self.short_total: Counter[Flower] = Counter()
        self.slot: str | None = None

    @classmethod
    def from_status(cls, owned: Mapping[Flower, int], plot_status: Mapping | None,
                    release: Iterable[str] = ()) -> "Copies":
        return cls(owned, planted_by_plot(plot_status), release)

    # ---- reads and writes, as the current plot
    def __getitem__(self, f: Flower) -> int:
        # .get, not [f]: a missing key in a Counter costs a Python-level __missing__ call.
        # A shortage counts against the plot that took it (and the farm), so
        # what is left reads negative there, as the planner's overuse check expects.
        slot = self.slot
        if slot is None:
            return self.pool.get(f, 0) + self.held.get(f, 0) - self.short_total.get(f, 0)
        n = self.pool.get(f, 0) + self.reserve[slot].get(f, 0) - self.short[slot].get(f, 0)
        if self.released:
            n += self.loose.get(f, 0) - (self.reserve[slot].get(f, 0) if slot in self.released else 0)
        return n

    def __setitem__(self, f: Flower, value: int) -> None:
        delta = value - self[f]
        if delta < 0:
            self._take(f, -delta)
        elif delta > 0:
            self._give(f, delta)

    def get(self, f: Flower, default: int = 0) -> int:
        return self[f]

    def items(self):
        keys = set(self.pool) | set(self.short_total) | {f for r in self.reserve.values() for f in r}
        saved, self.slot = self.slot, None
        try:
            return [(f, self[f]) for f in keys]
        finally:
            self.slot = saved

    def _from_reserve(self, slot: str, f: Flower, need: int) -> int:
        take = min(need, self.reserve[slot].get(f, 0))
        if take:
            self.reserve[slot][f] -= take
            self.held[f] -= take
            if slot in self.released:
                self.loose[f] -= take
        return take

    def _take(self, f: Flower, need: int) -> None:
        slot = self.slot
        for s in ([slot] if slot is not None else list(self.reserve)):
            take = self._from_reserve(s, f, need)
            self.from_reserve[s][f] += take
            need -= take
        take = min(need, self.pool.get(f, 0))
        self.pool[f] -= take
        self.from_pool[slot][f] += take
        need -= take
        if need and slot is not None and self.loose.get(f, 0) > 0:
            for source in sorted(self.released - {slot}):
                take = self._from_reserve(source, f, need)
                if take:
                    self.moves[(source, slot, f)] += take
                    self._moved_in.setdefault((slot, f), Counter())[source] += take
                    need -= take
                if not need:
                    break
        if need:
            # More than there is: a shortage, held against this plot only.
            self.short[slot][f] += need
            self.short_total[f] += need

    def _give(self, f: Flower, n: int) -> None:
        slot = self.slot
        back = min(n, self.short[slot][f])
        self.short[slot][f] -= back
        self.short_total[f] -= back
        n -= back
        moved_in = self._moved_in.get((slot, f)) if n else None
        if moved_in:
            for source in sorted(moved_in, reverse=True):
                back = min(n, moved_in[source])
                moved_in[source] -= back
                self.moves[(source, slot, f)] -= back
                self.reserve[source][f] += back
                self.held[f] += back
                self.loose[f] += back
                n -= back
                if not n:
                    break
        back = min(n, self.from_pool[slot][f])
        self.from_pool[slot][f] -= back
        self.pool[f] += back
        n -= back
        if n and slot is not None:
            back = min(n, self.from_reserve[slot][f])
            self.from_reserve[slot][f] -= back
            self.reserve[slot][f] += back
            self.held[f] += back
            if slot in self.released:
                self.loose[f] += back
            n -= back
        self.pool[f] += n

    def at(self, slot: str | None):
        """Context manager: plan as plot ``slot``."""
        copies = self

        class _At:
            def __enter__(self_inner):
                self_inner.saved = copies.slot
                copies.slot = slot.upper() if slot else None

            def __exit__(self_inner, *exc):
                copies.slot = self_inner.saved

        return _At()

    def plant(self, slot: str, flowers: Iterable[Flower]) -> None:
        """Take one copy of each flower for ``slot``."""
        with self.at(slot):
            for f, n in Counter(flowers).items():
                self._take(f, n)

    def plant_all(self, plans: Mapping[str, Iterable[Flower]]) -> None:
        """Take every plot's plants: first what each finds in its own ground,
        then the rest (the pool, then a released plot's: a move). Each plot
        keeping its own plants first means a batch moves only what it must."""
        wants = {slot.upper(): Counter(flowers) for slot, flowers in plans.items()}
        rest: dict[str, Counter[Flower]] = {}
        for slot, want in sorted(wants.items()):
            own = self.reserve.get(slot, Counter())
            mine = Counter({f: min(n, own.get(f, 0)) for f, n in want.items()})
            self.plant(slot, mine.elements())
            rest[slot] = want - mine
        for slot, want in sorted(rest.items()):
            self.plant(slot, want.elements())

    # ---- what the plan asks of the farm
    def move_list(self) -> list[dict]:
        """Plants a batch takes from another plot: [{from, to, flower, count}]."""
        return [{"from": source, "to": dest, "flower": flower, "count": n}
                for (source, dest, flower), n in sorted(self.moves.items(),
                                                        key=lambda kv: (kv[0][1], kv[0][0], kv[0][2].label()))
                if n > 0]

    def shortages(self) -> dict[str, Counter[Flower]]:
        """Per plot, copies its plan takes that don't exist."""
        return {slot: Counter({f: n for f, n in counts.items() if n > 0})
                for slot, counts in self.short.items() if slot is not None and any(n > 0 for n in counts.values())}


def recording_shortfalls(owned: Mapping[Flower, int], before: Mapping | None, after: Mapping | None
                         ) -> dict[Flower, tuple[int, int]]:
    """Flowers a recording plants beyond the copies owned: {flower: (in ground, owned)}.

    Only flowers whose shortfall the recording makes worse: an inventory
    that is already short elsewhere doesn't block an unrelated plot.
    """
    was, now = planted_counts(before), planted_counts(after)
    out = {}
    for f, n in now.items():
        have = owned.get(f, 0)
        if n > have and n - have > max(0, was.get(f, 0) - have):
            out[f] = (n, have)
    return out
