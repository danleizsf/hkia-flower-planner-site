from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path

from .rules import COLORS


VALID_PATTERNS = (
    "Solid",
    "Ombre",
    "Alternate",
    "Confetti",
    "Cosmic",
    "Crystal",
    "Frost",
    "Glitter",
    "Glow",
    "Iridescent",
    "Molten",
    "Patch",
    "Ring",
    "Speckled",
    "Striped",
    "Sunbeam",
    "Trim",
)

EFFECT_PATTERNS = frozenset({
    "Cosmic", "Crystal", "Frost", "Glitter", "Glow", "Iridescent", "Molten", "Sunbeam",
})
COLORED_PATTERNS = frozenset(set(VALID_PATTERNS) - EFFECT_PATTERNS - {"Solid"})


@dataclass(frozen=True)
class InventoryUpdate:
    flower_type: str
    color: str
    pattern: str
    count: int | None = None
    secondary_color: str | None = None

    def label(self) -> str:
        quantity = f" × {self.count}" if self.count is not None else ""
        secondary = f" & {self.secondary_color}" if self.secondary_color else ""
        return f"{self.color}{secondary} {self.flower_type} ({self.pattern}){quantity}"

    def count_key(self) -> str:
        parts = [self.flower_type, self.color, self.pattern]
        if self.secondary_color:
            parts.append(self.secondary_color)
        return "|".join(parts)


def _match(value: str, choices: tuple[str, ...], label: str) -> str:
    cleaned = value.strip().casefold()
    exact = [choice for choice in choices if choice.casefold() == cleaned]
    if exact:
        return exact[0]
    prefixes = [choice for choice in choices if choice.casefold().startswith(cleaned)]
    if len(prefixes) == 1:
        return prefixes[0]
    if not prefixes:
        raise ValueError(f"Unknown {label}: {value!r}")
    raise ValueError(f"Ambiguous {label} {value!r}: {', '.join(prefixes)}")


def normalize_update(
    data: dict,
    flower_type: str,
    color: str,
    pattern: str,
    count: int | None = None,
    secondary_color: str | None = None,
) -> list[InventoryUpdate]:
    if count is not None and count < 0:
        raise ValueError("count cannot be negative")
    flowers = tuple(data["flower_order"])
    colors = tuple(data["visible_color_order"])
    flower = _match(flower_type, flowers, "flower type")
    normalized_color = _match(color, colors, "color")
    pattern_value = pattern.strip().casefold()
    if pattern_value in {"both", "b"}:
        patterns = ("Solid", "Ombre")
    else:
        normalized_pattern = _match(pattern, VALID_PATTERNS, "pattern")
        patterns = (normalized_pattern,)
    normalized_secondary: str | None = None
    if secondary_color and secondary_color.strip().casefold() not in {"default", "none"}:
        normalized_secondary = _match(secondary_color, colors, "secondary color")
    updates = []
    for item in patterns:
        if item in EFFECT_PATTERNS or item == "Solid":
            if normalized_secondary:
                raise ValueError(f"{item} does not have a secondary color")
            item_secondary = None
        else:
            item_secondary = normalized_secondary
            if item_secondary == normalized_color:
                raise ValueError("primary and secondary colors must be different")
        updates.append(InventoryUpdate(flower, normalized_color, item, count, item_secondary))
    return updates


def ensure_color_schema(data: dict) -> tuple[dict, bool]:
    """Bring an older inventory file up to the current canonical color schema.

    Brown was enabled after the original screenshot-derived inventory format was
    created, so older installs can legitimately have 29 colors while the
    solver targets 30. Missing canonical colors are added as empty rows without
    changing any existing ownership/count metadata.
    """
    required = {"flower_order", "visible_color_order", "solid_rows", "ombre_rows"}
    if not required <= set(data):
        return data, False

    changed = False
    flower_count = len(data["flower_order"])
    visible = list(data["visible_color_order"])
    for color in COLORS:
        if color not in visible:
            visible.append(color)
            changed = True
        for section in ("solid_rows", "ombre_rows"):
            if color not in data[section]:
                data[section][color] = "0" * flower_count
                changed = True
    if changed:
        data["visible_color_order"] = visible
    return data, changed


def load_inventory_data(path: Path) -> dict:
    data = json.loads(path.read_text(encoding="utf-8"))
    data, _ = ensure_color_schema(data)
    flower_count = len(data["flower_order"])
    for section in ("solid_rows", "ombre_rows"):
        for color, bits in data[section].items():
            if len(bits) != flower_count or set(bits) - {"0", "1"}:
                raise ValueError(f"Invalid {section} row for {color}")
    return data


def apply_updates(data: dict, updates: list[InventoryUpdate]) -> tuple[dict, list[InventoryUpdate]]:
    changed: list[InventoryUpdate] = []
    flower_positions = {name: index for index, name in enumerate(data["flower_order"])}
    variant_counts = data.setdefault("variant_counts", {})
    other_variants = data.setdefault("other_patterned_variants", [])
    hybrid_variants = data.setdefault("hybrid_patterned_variants", [])
    other_keys = {
        (row["flower_type"], row["color"], row["pattern"])
        for row in other_variants
    }
    hybrid_keys = {
        (row["flower_type"], row["color"], row["pattern"], row["secondary_color"])
        for row in hybrid_variants
    }
    uncollected = set(data.setdefault("uncollected_variants", []))
    for update in updates:
        row_changed = False
        key = update.count_key()
        if key in uncollected:
            uncollected.remove(key)
            data["uncollected_variants"] = sorted(uncollected)
            row_changed = True
        if update.secondary_color:
            variant_key = (
                update.flower_type, update.color, update.pattern, update.secondary_color
            )
            if variant_key not in hybrid_keys:
                hybrid_variants.append({
                    "flower_type": update.flower_type,
                    "color": update.color,
                    "pattern": update.pattern,
                    "secondary_color": update.secondary_color,
                })
                hybrid_keys.add(variant_key)
                row_changed = True
        elif update.pattern in {"Solid", "Ombre"}:
            section = "solid_rows" if update.pattern == "Solid" else "ombre_rows"
            bits = list(data[section][update.color])
            index = flower_positions[update.flower_type]
            if bits[index] == "0":
                bits[index] = "1"
                data[section][update.color] = "".join(bits)
                row_changed = True
        else:
            variant_key = (update.flower_type, update.color, update.pattern)
            if variant_key not in other_keys:
                other_variants.append({
                    "flower_type": update.flower_type,
                    "color": update.color,
                    "pattern": update.pattern,
                })
                other_keys.add(variant_key)
                row_changed = True
        if update.count is not None:
            key = update.count_key()
            previous_count = variant_counts.get(key)
            if previous_count is None or int(previous_count) != update.count:
                variant_counts[key] = update.count
                row_changed = True
        if row_changed:
            changed.append(update)
    return data, changed


def mark_uncollected(data: dict, update: InventoryUpdate) -> tuple[dict, bool]:
    """Remove a zero-count variant from the owned collection.

    A tombstone is retained so an assumed donor with the same identity does not
    immediately reappear as collected. Any later Set/Add update clears it.
    """
    changed = False
    flower_positions = {name: index for index, name in enumerate(data["flower_order"])}
    key = update.count_key()

    variant_counts = data.setdefault("variant_counts", {})
    if key in variant_counts:
        if int(variant_counts[key]) != 0:
            raise ValueError("Only zero-count flowers can be marked uncollected")
        del variant_counts[key]
        changed = True

    if update.secondary_color:
        rows = data.setdefault("hybrid_patterned_variants", [])
        before = len(rows)
        rows[:] = [
            row for row in rows
            if not (
                row["flower_type"] == update.flower_type
                and row["color"] == update.color
                and row["pattern"] == update.pattern
                and row.get("secondary_color") == update.secondary_color
            )
        ]
        changed = changed or len(rows) != before
    elif update.pattern in {"Solid", "Ombre"}:
        section = "solid_rows" if update.pattern == "Solid" else "ombre_rows"
        bits = list(data[section][update.color])
        index = flower_positions[update.flower_type]
        if bits[index] == "1":
            bits[index] = "0"
            data[section][update.color] = "".join(bits)
            changed = True
    else:
        rows = data.setdefault("other_patterned_variants", [])
        before = len(rows)
        rows[:] = [
            row for row in rows
            if not (
                row["flower_type"] == update.flower_type
                and row["color"] == update.color
                and row["pattern"] == update.pattern
            )
        ]
        changed = changed or len(rows) != before

    tombstones = set(data.setdefault("uncollected_variants", []))
    if key not in tombstones:
        tombstones.add(key)
        data["uncollected_variants"] = sorted(tombstones)
        changed = True
    return data, changed


def recorded_count(data: dict, update: InventoryUpdate) -> int:
    key = update.count_key()
    if key in data.get("variant_counts", {}):
        return int(data["variant_counts"][key])
    if update.secondary_color:
        key = (update.flower_type, update.color, update.pattern, update.secondary_color)
        return 1 if any(
            (
                row["flower_type"], row["color"], row["pattern"], row["secondary_color"]
            ) == key
            for row in data.get("hybrid_patterned_variants", [])
        ) else 0
    if update.pattern in {"Solid", "Ombre"}:
        section = "solid_rows" if update.pattern == "Solid" else "ombre_rows"
        index = data["flower_order"].index(update.flower_type)
        return 1 if data[section][update.color][index] == "1" else 0
    key = (update.flower_type, update.color, update.pattern)
    return 1 if any(
        (row["flower_type"], row["color"], row["pattern"]) == key
        for row in data.get("other_patterned_variants", [])
    ) else 0


def increment_update(data: dict, update: InventoryUpdate, amount: int) -> InventoryUpdate:
    if amount < 1:
        raise ValueError("amount must be at least 1")
    return InventoryUpdate(
        update.flower_type,
        update.color,
        update.pattern,
        recorded_count(data, update) + amount,
        update.secondary_color,
    )


def save_inventory_atomic(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            json.dump(data, handle, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


