"""A brand-new, empty farm: what a first-time player starts from.

The default settings and map layout from data/default_farm, nothing
collected (no assumed donors either) and nothing planted.
Onboarding (web/onboarding.js) then asks for the rest.
"""
from __future__ import annotations

import json
import shutil
from datetime import date
from pathlib import Path

from .paths import FARM_DATA_DIR, tool_data_path
from .rules import COLORS, FLOWER_TYPES


def empty_inventory() -> dict:
    return {
        "format": "color_rows_v1",
        "count_semantics": "total_physical_copies_including_planted_parents",
        "notes": "New farm: nothing collected yet.",
        "flower_order": list(FLOWER_TYPES),
        "visible_color_order": list(COLORS),
        "solid_rows": {},
        "ombre_rows": {},
        "variant_counts": {},
        "other_patterned_variants": [],
        "hybrid_patterned_variants": [],
        "uncollected_variants": [],
    }


def create_empty_farm(root: Path) -> Path:
    """Write an empty farm into ``root`` (refuses to overwrite a farm)."""
    farm = Path(root) / FARM_DATA_DIR
    if (farm / "inventory.json").exists():
        raise ValueError(f"There is already a farm in {root}")
    farm.mkdir(parents=True, exist_ok=True)
    template = tool_data_path("default_farm")
    shutil.copy2(template / "ui_map_layouts.json", farm / "ui_map_layouts.json")
    # The template settings describe the farm they were written for: start this one's own.
    settings = json.loads((template / "settings.json").read_text(encoding="utf-8"))
    settings.update(as_of=date.today().isoformat(), platform=None, month_of_meh_ended=None)
    (farm / "settings.json").write_text(json.dumps(settings, indent=2), encoding="utf-8")
    # The template's donor list is assumptions about one particular farm; a new player owns none.
    (farm / "other_patterned_donors.json").write_text(json.dumps({"donors": []}, indent=2), encoding="utf-8")
    (farm / "plot_status.json").write_text(json.dumps({"plots": {}}, indent=2), encoding="utf-8")
    (farm / "inventory.json").write_text(json.dumps(empty_inventory(), indent=2), encoding="utf-8")
    return farm
