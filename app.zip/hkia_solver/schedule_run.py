"""One run of HypergraphOptimizer.schedule(): an event-driven rollout.

Free plots are filled with ready breeding jobs, then the simulation jumps to
the next expected completion, marks that target owned, releases its plot and
parents, and refills. The first fill is the plan's visible first wave; the
rollout estimates when every reachable target finishes.
"""
from __future__ import annotations

import heapq
import math
from collections import Counter, defaultdict, deque

from . import progress
from .models import Flower
from .optimizer import Route
from .plot_layout_optimizer import (
    add_makespan_reducing_pairs,
    choose_zone_batch,
    pair_placements,
)
from .plot_status import effective_stock_goal
from .plots import PlotSlot, neighboring_cells, usable_cells
from .route_concurrency_optimizer import (
    SchedulerScorePolicy,
    combine_daily_probabilities,
    farm_makespan_after_attempt,
)
from .rules import BREED_PROBABILITY, parents_for_mix
from .zones import flower_zones


PLOT_LAYOUT_STRATEGY = {
    "algorithm": "bounded_joint_cell_outcome",
    "first_wave_route_limit_per_plot": 5,
    "later_route_limit_per_plot_fill": 1,
    "later_fill_slots": "plots whose jobs completed plus regions of targets affected by newly owned flowers or released parents",
    "candidate_safe_zones": 24,
    "beam_width": 12,
    "maximum_marginal_extra_pairs_per_plot_fill": 1,
    "round_robin_plot_fills": True,
    "minimum_extra_pair_finish_gain": 0.02,
    "shared_cell_chance": "split across distinct possible goal outcomes; active-pair neighbor cells are protected",
    "greenhouse_fanout_policy": "share one patterned donor across two ready Greenhouse-compatible recipients only when donor copies are scarce and recipient-specific cells reduce their paired finish time; reserve the donor and shared cells until both finish",
    "fertilizer_policy": "only after no ready breeding route can use the plot cells",
    "propagation_policy": "on demand after collection breeding zones",
}


class _SelectionPool:
    """The ready targets one plot-fill pass may choose from."""

    def __init__(self, ready_by_priority, ready_queues, greenhouse_queues, in_progress):
        self.ready_by_priority = ready_by_priority
        self.ready_queues = ready_queues
        self.greenhouse_queues = greenhouse_queues
        self.in_progress = in_progress


class ScheduleRun:
    def __init__(
        self,
        optimizer,
        slots: list[PlotSlot],
        strategy: str,
        score_policy: SchedulerScorePolicy | None,
        busy_seed: Counter[Flower] | None,
    ):
        opt = self.opt = optimizer
        self.strategy = strategy
        self.score_policy = score_policy
        zones = flower_zones()
        # Reserve greenhouse capacity first for event-only species; larger outdoor
        # patches then receive the highest-value remaining ready actions.
        self.slots = sorted(
            slots,
            key=lambda slot: (
                sum(slot.region in zones.get(flower_type, ()) for flower_type in opt.flower_types),
                slot.greenhouse,
                slot.spots,
                slot.slot,
            ),
        )
        self.slot_map = {slot.slot: slot for slot in self.slots}
        self.slot_regions = {slot.region for slot in self.slots}
        self.locked = {
            slot: assignment
            for slot, assignment in opt.locked_assignments.items()
            if slot in self.slot_map
        }
        self.free_slots = [slot for slot in self.slots if slot.slot not in self.locked]
        # Each physical plot (including the single shared Greenhouse grid) can
        # run distinct goals concurrently when the cell layout has safe pair
        # zones. These reservations use the same event queue so projected finish
        # reflects the usable layout concurrency instead of artificial lanes.
        self.outdoor_zones = {
            slot.slot: pair_placements(slot, 24, quick=opt.quick)
            for slot in self.slots
        }
        self.active_zones: dict[str, dict[Flower, set[int]]] = defaultdict(dict)
        self.fertilizer_busy_cells: Counter[str] = Counter()
        self.greenhouse_fanout_remaining: dict[str, int] = {}
        self.greenhouse_fanout_donor: dict[str, Flower] = {}
        self.greenhouse_fanout_group_by_target: dict[Flower, str] = {}
        self.owned = set(opt.initial_owned)
        # Actual planting does not lock recommendation locations, but its parent
        # plants are still physically occupied and therefore unavailable to a
        # newly generated recommendation. Keep that farm reservation as a
        # permanent baseline while simulated recommendation jobs reserve/release
        # additional copies around it.
        self.planted_busy: Counter[Flower] = Counter(busy_seed or {})
        self.busy: Counter[Flower] = Counter(self.planted_busy)
        self.in_progress: set[Flower] = set()
        self.forced_in_progress: set[Flower] = set()
        self.active_attempts_by_target: dict[Flower, list[dict]] = defaultdict(list)
        self.active_probability_by_target: dict[Flower, float] = {}
        self.active_generation: Counter[Flower] = Counter()
        self.type_load: Counter[str] = Counter()
        # (finish day, event id, target, generation) for each target's combined attempt.
        self.queue: list[tuple[float, int, Flower, int]] = []
        self.first_wave: list[dict] = []
        self.background_first_wave: list[dict] = []
        self.completed_jobs: list[dict] = []
        self.decision_log: list[dict] = []
        self.decision_step = 0
        self.preserved_plot_jobs: dict[str, list[dict]] = {}
        self.sequence = 0
        self.event_sequence = 0
        self.extra_pairs_limit = 0
        self.now = 0.0
        self.concurrency_phase = "distinct"
        self.rescue_mode = False
        self.readiness_rechecks = 0
        self.chance_floor = opt.finish_time_config.target_daily_chance_floor
        self.dependents = self._dependents()
        self.ready_by_priority: dict[int, set[Flower]] = defaultdict(set)
        self.ready_queues: dict[tuple[int, str], deque[Flower]] = defaultdict(deque)
        self.greenhouse_ready_queues: dict[int, deque[Flower]] = defaultdict(deque)
        self.ready_regions_by_target: dict[Flower, set[str]] = defaultdict(set)
        self.retry_regions_epoch = -1
        self.retry_regions_cache: dict[Flower, set[str]] = {}

    def run(self) -> dict:
        opt = self.opt
        self._seed_locked_assignments()
        self.add_ready_targets(opt.reachable)
        self.fill_slots(max_rounds=2 if opt.quick else 5)
        self.concurrency_phase = "retry"
        self.refresh_in_progress()
        if not opt.quick:
            self.fill_slots(max_rounds=24, retry_only=True)

        # The visible first wave must be plantable *now*, so it cannot consume
        # copies occupied by Actual. Once that replacement wave is modeled as
        # planted, those old Actual parents would have been physically lifted
        # and can participate in the long-horizon completion estimate. Keep the
        # baseline reservation for final first-wave packing below, but release
        # it from the rollout simulation here.
        for flower, count in self.planted_busy.items():
            self.busy[flower] = max(0, self.busy[flower] - count)
        self.concurrency_phase = "rollout"
        self.refresh_in_progress()
        self._simulate()
        return self._result()

    # -- target bookkeeping -------------------------------------------------

    def refresh_in_progress(self) -> None:
        self.in_progress.clear()
        self.in_progress.update(self.forced_in_progress)
        self.in_progress.update(
            target for target, chance in self.active_probability_by_target.items()
            if chance >= self.chance_floor
        )

    def mark_scheduled_target(self, target: Flower) -> None:
        if self.concurrency_phase == "distinct" or target in self.forced_in_progress:
            self.in_progress.add(target)
        elif self.active_probability_by_target.get(target, 0.0) >= self.chance_floor:
            self.in_progress.add(target)
        else:
            self.in_progress.discard(target)

    def add_target_attempt(
        self,
        slot: PlotSlot | None,
        route: Route,
        probability: float,
        eligible: int,
        copies: tuple[int, ...],
        assignment: dict,
        *,
        forced: bool = False,
        delay: float | None = None,
        fanout_group: str | None = None,
    ) -> None:
        """Start one attempt at a target and queue the target's new combined finish."""
        target = route.target
        attempts = self.active_attempts_by_target[target]
        chance_before = self.active_probability_by_target.get(target, 0.0)
        attempt = {
            "slot": slot,
            "route": route,
            "probability": max(0.0, min(1.0, float(probability))),
            "eligible": int(eligible),
            "copies": tuple(int(value) for value in copies),
            "assignment": assignment,
            "fanout_group": fanout_group,
        }
        attempts.append(attempt)
        combined = self.active_probability_by_target[target] = combine_daily_probabilities(
            row["probability"] for row in attempts
        )
        if forced:
            self.forced_in_progress.add(target)
        self.mark_scheduled_target(target)
        self.active_generation[target] += 1
        self.event_sequence += 1
        modeled_days = (
            float(delay)
            if delay is not None and len(attempts) == 1
            else 1.0 / combined
            if combined > 0
            else math.inf
        )
        for active_attempt in attempts:
            active_attempt["assignment"]["target_daily_probability"] = combined
            active_attempt["assignment"]["target_expected_days"] = (
                1.0 / combined if combined > 0 else math.inf
            )
        self._log_decision(
            slot, route, probability, eligible, attempt["copies"], assignment,
            forced, chance_before, combined, modeled_days,
        )
        heapq.heappush(
            self.queue,
            (self.now + modeled_days, self.event_sequence, target, self.active_generation[target]),
        )

    def _log_decision(
        self, slot, route, probability, eligible, copies, assignment,
        forced, chance_before, combined, modeled_days,
    ) -> None:
        opt = self.opt
        target = route.target
        self.decision_step += 1
        if slot is None:
            decision_reason = "Plot-free background fertilization was available."
            selected_score = 0.0
        elif forced or assignment.get("locked"):
            decision_reason = "Preserved an already planted job as active work."
            selected_score = 0.0
        else:
            decision_reason = {
                "distinct": "Selected as a distinct collection goal during the initial plot fill.",
                "retry": "Added as a concurrent attempt after the farm-finish improvement gate passed.",
            }.get(
                self.concurrency_phase,
                "Selected after a completion or unlock made plot capacity available.",
            )
            selected_score = opt._job_score(
                route, slot, self.owned, self.busy, self.type_load, self.strategy
            )
        self.decision_log.append({
            "step": self.decision_step,
            "scheduled_day": round(self.now, 2),
            "phase": self.concurrency_phase,
            "target": target.label(),
            "method": route.method,
            "parents": [parent.label() for parent in route.parents],
            "parent_copies": list(copies),
            "slot": slot.slot if slot else "BACKGROUND",
            "plot": slot.plot if slot else "Background fertilization",
            "region": slot.region if slot else "No breeding slot",
            "eligible_cells": int(eligible),
            "attempt_chance_per_day": round(float(probability), 8),
            "target_chance_before": round(chance_before, 8),
            "target_chance_after": round(combined, 8),
            "target_expected_days_after": round(1.0 / combined, 4) if combined else None,
            "projected_target_finish_day": round(self.now + modeled_days, 2),
            "selection_score": round(float(selected_score), 8),
            "descendant_count": int(opt.descendants.get(target, 0)),
            "critical_tail_days": round(max(0.0, float(opt.critical_tail.get(target, 0.0))), 4),
            "pool_unlocks": opt._strategic_unlocks(target, self.owned),
            "parent_free_copies_before": [
                max(0, opt._capacity(parent, self.owned) - self.busy[parent])
                for parent in route.parents
            ],
            "ready_target_count": sum(len(items) for items in self.ready_by_priority.values()),
            "free_plot_count": len(self.free_slots),
            "score_policy": self.score_policy.as_dict() if self.score_policy else self.strategy,
            "reason": decision_reason,
        })

    def _dependents(self) -> dict[Flower, set[Flower]]:
        """Every target each flower could be a parent or donor for.

        Tracks every possible parent relationship, not only the one shortest
        route selected for the dependency DAG. This lets an alternate recipe
        become ready immediately when one of its parents is acquired.
        """
        opt = self.opt
        dependents: dict[Flower, set[Flower]] = defaultdict(set)
        for child in opt.reachable:
            if child.pattern == "Solid":
                for color_a, color_b in parents_for_mix(child.color):
                    dependents[Flower(child.flower_type, color_a, "Solid")].add(child)
                    dependents[Flower(child.flower_type, color_b, "Solid")].add(child)
                for donor in opt._patterned_by_color.get(child.color, ()):
                    if donor.flower_type != child.flower_type:
                        dependents[donor].add(child)
                for color in opt.colors:
                    if color != child.color:
                        dependents[Flower(child.flower_type, color, "Solid")].add(child)
            else:
                solid = Flower(child.flower_type, child.color, "Solid")
                dependents[solid].add(child)
                for donor in opt._pattern_by_color.get((child.pattern, child.color), ()):
                    if donor.flower_type != child.flower_type:
                        dependents[donor].add(child)
        return dependents

    def add_ready_targets(self, candidates) -> None:
        opt = self.opt
        for target in sorted(
            candidates,
            key=lambda item: opt._target_order_rank.get(item, (10**9, 10**9)),
        ):
            if target in self.owned or target in self.in_progress:
                continue
            if opt._has_owned_route(target, self.owned):
                priority = opt.target_priorities.get(target, 99)
                if target not in self.ready_by_priority[priority]:
                    self.ready_by_priority[priority].add(target)
                    if target in opt._greenhouse_exclusive_targets:
                        self.greenhouse_ready_queues[priority].append(target)
                # Queue only newly discovered regions where some currently-
                # owned recipe can work. This avoids scanning unrelated
                # plots at every completion event.
                regions = opt._owned_route_regions(target, self.owned) & self.slot_regions
                for region in regions - self.ready_regions_by_target[target]:
                    self.ready_regions_by_target[target].add(region)
                    if target not in opt._greenhouse_exclusive_targets:
                        self.ready_queues[(priority, region)].append(target)

    def _seed_locked_assignments(self) -> None:
        """Model jobs already planted on the farm as active work from day 0."""
        opt = self.opt
        for slot_id, stored in sorted(self.locked.items()):
            slot = self.slot_map[slot_id]
            assignment = dict(stored)
            locked_jobs = assignment.pop("locked_jobs", [])
            locked_target = Flower(
                assignment["target_type"], assignment["target_color"],
                assignment["target_pattern"], assignment.get("target_secondary_color"),
            )
            desired_goal, desired_reason = opt._stock_goal(locked_target)
            if assignment.get("method") == "propagate_solid" or assignment.get("propagation"):
                # A propagation layout already physically planted keeps its
                # explicit incremental goal. Do not silently invalidate work the
                # user has already set up.
                assignment["stock_goal"] = max(
                    int(assignment.get("stock_goal", 1)), desired_goal
                )
                assignment.setdefault("stock_goal_reason", desired_reason)
            else:
                # v30 deliberately discards the old speculative downstream
                # propagation goal on ordinary breeding jobs. Any future clone
                # must be justified from the live farm state instead.
                assignment["propagation_goal"] = 1
                assignment["propagation_goal_reason"] = desired_reason
                assignment["stock_goal"] = 1
                assignment["stock_goal_reason"] = "first successful copy"
            assignment["farm_state"] = "planted_locked"
            assignment["locked"] = True
            self.first_wave.append(assignment)
            if locked_jobs:
                self.preserved_plot_jobs[slot_id] = []
            for locked_job in [assignment] + locked_jobs:
                job = dict(locked_job)
                job["farm_state"] = "planted_locked"
                job["locked"] = True
                if job is not assignment and job.get("supplemental"):
                    self.preserved_plot_jobs[slot_id].append(job)
                parents = tuple(
                    Flower(
                        parent["flower_type"], parent["color"], parent["pattern"],
                        parent.get("secondary_color"),
                    )
                    for parent in job["parent_flowers"]
                )
                copies = tuple(int(count) for count in job["parent_copies"])
                route = Route(
                    Flower(
                        job["target_type"], job["target_color"], job["target_pattern"],
                        job.get("target_secondary_color"),
                    ),
                    job["method"],
                    parents,
                )
                for parent, copy_count in zip(parents, copies, strict=True):
                    self.busy[parent] += copy_count
                self.in_progress.add(route.target)
                self.forced_in_progress.add(route.target)
                self.ready_by_priority[
                    opt.target_priorities.get(route.target, 99)
                ].discard(route.target)
                self.type_load[route.target.flower_type] += 1
                current_count = opt.inventory.physical_count(route.target)
                remaining = max(1, effective_stock_goal(job) - current_count)
                duration = float(job.get("expected_days", 1.0)) * remaining
                self.sequence += 1
                self.add_target_attempt(
                    slot,
                    route,
                    float(job.get("daily_probability", 0.0)),
                    int(job.get("eligible_cells", slot.eligible_cells)),
                    copies,
                    job,
                    forced=True,
                    delay=duration,
                )

    # -- filling free plots -------------------------------------------------

    def fill_slots(
        self,
        max_rounds: int = 1,
        eligible_slot_ids: set[str] | None = None,
        *,
        retry_only: bool = False,
    ) -> None:
        if eligible_slot_ids is not None and not eligible_slot_ids:
            return
        # Round-robin passes reserve one distinct goal per plot before
        # allowing any plot to spend spare parent copies on extra attempts.
        for round_index in range(max(1, int(max_rounds))):
            before = self.sequence
            self.extra_pairs_limit = 1 if round_index == max_rounds - 1 else 0
            self._fill_slots_once(eligible_slot_ids, retry_only=retry_only)
            if self.sequence == before:
                break

    def _fill_slots_once(
        self,
        eligible_slot_ids: set[str] | None = None,
        *,
        retry_only: bool = False,
    ) -> None:
        if self.retry_regions_epoch != len(self.owned):
            self.retry_regions_cache.clear()
            self.retry_regions_epoch = len(self.owned)
        attempts_by_slot = defaultdict(list)
        for attempts in self.active_attempts_by_target.values():
            for attempt in attempts:
                if attempt.get("slot") is not None:
                    attempts_by_slot[attempt["slot"].slot].append(attempt)
        pool = self._retry_pool() if retry_only else _SelectionPool(
            self.ready_by_priority, self.ready_queues,
            self.greenhouse_ready_queues, self.in_progress,
        )
        still_free: list[PlotSlot] = []
        # Progress: passes repeat until nothing more fits, each a smaller share (never goes back).
        passes = getattr(self, "_progress_passes", 0)
        self._progress_passes = passes + 1
        for index, slot in enumerate(self.free_slots):
            progress.report("schedule", (passes + index / max(len(self.free_slots), 1)) / (passes + 2), slot.plot)
            if eligible_slot_ids is not None and slot.slot not in eligible_slot_ids:
                still_free.append(slot)
                continue
            if self._fill_slot(slot, attempts_by_slot, pool, retry_only):
                still_free.append(slot)
        self.free_slots[:] = still_free

    def _retry_pool(self) -> _SelectionPool:
        """Targets that may take one more concurrent attempt: active, below the
        chance floor, and under the per-target attempt limit."""
        opt = self.opt
        self.refresh_in_progress()
        pool = _SelectionPool(defaultdict(set), defaultdict(deque), defaultdict(deque), None)
        for target, chance in self.active_probability_by_target.items():
            if (
                target in self.owned
                or target in self.forced_in_progress
                or not opt.finish_time_config.applies(target, opt.flower_types)
                or chance >= self.chance_floor
                or len(self.active_attempts_by_target[target])
                >= opt.finish_time_config.max_concurrent_attempts_per_target
            ):
                continue
            priority = opt.target_priorities.get(target, 99)
            pool.ready_by_priority[priority].add(target)
            if target in opt._greenhouse_exclusive_targets:
                pool.greenhouse_queues[priority].append(target)
            else:
                if target not in self.retry_regions_cache:
                    self.retry_regions_cache[target] = (
                        opt._owned_route_regions(target, self.owned) & self.slot_regions
                    )
                for region in self.retry_regions_cache[target]:
                    pool.ready_queues[(priority, region)].append(target)
        pool.in_progress = set(self.forced_in_progress) | {
            target for target, chance in self.active_probability_by_target.items()
            if chance >= self.chance_floor
        }
        return pool

    def _reserved_zone_ids(self, slot_id: str) -> set[int]:
        return {
            zone_index
            for indexes in self.active_zones[slot_id].values()
            for zone_index in indexes
        }

    def _fill_slot(self, slot: PlotSlot, attempts_by_slot, pool: _SelectionPool, retry_only: bool) -> bool:
        """Place new jobs on one plot. Returns whether it still has free zones."""
        all_zones = self.outdoor_zones.get(slot.slot, ())
        slot_usable_cells = usable_cells(slot)
        reserved = self._reserved_zone_ids(slot.slot)
        available_zones = [zone for zone in all_zones if zone.zone_index not in reserved]
        if not available_zones:
            return False

        # A small beam chooses a joint route-to-zone layout for the
        # visible first wave. Later event fills use a smaller batch to
        # keep the 10k-target rollout bounded.
        batch_limit = min(len(available_zones), 5 if self.now == 0.0 else 1)
        occupied_parent_cells = {
            cell
            for indexes in self.active_zones[slot.slot].values()
            for zone_index in indexes
            for cell in all_zones[zone_index].pair
        }
        occupied_target_cells: set[tuple[int, int]] = set()
        # Fertilize Pattern jobs have explicit plant cells too. Keep
        # those cells out of later breeding pairs in this same plot.
        for active_attempt in attempts_by_slot.get(slot.slot, ()):
            parent_cells, target_cells = self.opt._job_layout_cells(active_attempt["assignment"])
            occupied_parent_cells.update(parent_cells)
            occupied_target_cells.update(target_cells)
        available_zones = [
            zone for zone in available_zones
            if not (set(zone.pair) & (occupied_parent_cells | occupied_target_cells))
            and not (set(zone.protected_cells) & occupied_parent_cells)
            and not any(
                zone_parent in neighboring_cells(target_cell, slot_usable_cells)
                for zone_parent in zone.pair
                for target_cell in occupied_target_cells
            )
        ]
        if not available_zones:
            return False
        candidate_routes, deferred_fertilizer = self._candidate_routes(slot, pool, batch_limit)

        # One physical Greenhouse can fan one scarce patterned donor
        # out to two distinct recipients. Reserve its exact cells in
        # the same shared grid, then let the regular batch pack other
        # ready jobs into the remaining safe zones.
        if slot.greenhouse and not retry_only and candidate_routes:
            fanout = self._place_greenhouse_fanout(
                slot, candidate_routes, all_zones, slot_usable_cells, pool,
                occupied_parent_cells, occupied_target_cells,
            )
            if fanout is not None:
                reserved_fanout_zones, fanout_targets = fanout
                available_zones = [
                    zone for zone in available_zones
                    if zone.zone_index not in reserved_fanout_zones
                ]
                candidate_routes = [
                    row for row in candidate_routes
                    if row[0].target not in fanout_targets
                ]

        batch = self._place_batch(
            slot, candidate_routes, available_zones, batch_limit,
            occupied_parent_cells, pool, retry_only,
        )
        # Fertilization can use the physical plot only after no ordinary
        # breeding route can be assigned there. It consumes plant cells,
        # not a pair zone; the plot is released when that fallback job
        # finishes so the event scheduler remains conservative.
        if not batch and deferred_fertilizer is not None:
            self._place_fertilizer(slot, deferred_fertilizer, pool)

        reserved = self._reserved_zone_ids(slot.slot)
        return any(zone.zone_index not in reserved for zone in all_zones)

    def _candidate_routes(
        self, slot: PlotSlot, pool: _SelectionPool, batch_limit: int,
    ) -> tuple[list[tuple[Route, float, float]], Route | None]:
        """Up to batch_limit ready targets for this plot, each expanded to its
        workable routes as (route, score, per-cell daily chance), plus the
        first fertilizer route seen (used only if no breeding route fits)."""
        opt = self.opt
        candidate_routes: list[tuple[Route, float, float]] = []
        provisional_busy = Counter(self.busy)
        blocked_targets: set[Flower] = set()
        deferred_fertilizer: Route | None = None
        for _candidate_index in range(batch_limit):
            route = opt._select_job(
                slot, self.owned, pool.in_progress, provisional_busy, self.type_load,
                self.strategy, pool.ready_by_priority, blocked_targets,
                pool.ready_queues, pool.greenhouse_queues,
                allow_ready_fallback=(self.now == 0.0 or self.rescue_mode),
                candidate_scan_limit=96 if self.now == 0.0 else 8,
                candidate_feasible_limit=16 if self.now == 0.0 else 2,
            )
            if route is None:
                break
            blocked_targets.add(route.target)
            if route.method.startswith("fertilize_"):
                if deferred_fertilizer is None:
                    deferred_fertilizer = route
                continue
            if len(route.parents) < 2:
                continue
            route_options = opt._ready_routes(
                route.target,
                self.owned,
                provisional_busy,
                slot,
                limit=opt.finish_time_config.max_routes_per_target,
            )
            if not route_options:
                route_options = [route]
            for route_option in route_options:
                route_weight = opt._job_score(
                    route_option, slot, self.owned, provisional_busy,
                    self.type_load, self.strategy,
                )
                if route_weight <= 0:
                    continue
                per_spawn = BREED_PROBABILITY[route_option.method]
                if (
                    route_option.method == "pattern_transfer"
                    and not slot.greenhouse
                    and opt._uses_inactive_event_patterned_parent(route_option)
                ):
                    per_spawn = 0.02
                cell_chance = per_spawn * (
                    1.0 if slot.greenhouse else opt.settings[
                        "outdoor_spawn_probability_fertilized"
                    ]
                )
                candidate_routes.append((route_option, route_weight, cell_chance))
            for parent in route.parents[:2]:
                provisional_busy[parent] += 1
        return candidate_routes, deferred_fertilizer

    def _place_greenhouse_fanout(
        self, slot, candidate_routes, all_zones, slot_usable_cells, pool,
        occupied_parent_cells, occupied_target_cells,
    ) -> tuple[set[int], set[Flower]] | None:
        """Start the first worthwhile shared-donor pair of Greenhouse jobs.

        Returns the zones it reserved and its targets, or None if no
        candidate has a fanout partner.
        """
        opt = self.opt
        for fanout_route, _weight, _rate in candidate_routes:
            if fanout_route.method != "pattern_transfer":
                continue
            fanout = opt._greenhouse_fanout_partner(
                fanout_route, slot, self.owned, self.in_progress, self.busy,
                self.type_load, self.ready_by_priority, self.strategy,
                occupied_parent_cells=occupied_parent_cells,
                occupied_target_cells=occupied_target_cells,
            )
            if fanout is None:
                continue
            partner_route, fanout_layout = fanout
            group_id = f"GH.F{self.sequence + 1:04d}"
            donor = fanout_route.parents[0]
            fanout_jobs = (
                (fanout_route, fanout_layout["primary"], (1, 1)),
                (partner_route, fanout_layout["secondary"], (0, 1)),
            )
            fanout_parents = {
                tuple(cell)
                for job in fanout_jobs
                for key in ("parent_a_cells", "parent_b_cells", "shared_parent_a_cells")
                for cell in job[1].get(key, [])
            }
            fanout_targets_cells = {
                tuple(cell)
                for _route, layout, _copies in fanout_jobs
                for cell in layout.get("target_cells", [])
            }
            fanout_target_halo = set().union(*(
                neighboring_cells(cell, slot_usable_cells)
                for cell in fanout_targets_cells
            )) if fanout_targets_cells else set()
            fanout_parent_halo = set().union(*(
                neighboring_cells(cell, slot_usable_cells)
                for cell in fanout_parents
            )) if fanout_parents else set()
            reserved_fanout_zones = {
                zone.zone_index for zone in all_zones
                if set(zone.pair) & (
                    fanout_parents | fanout_targets_cells | fanout_target_halo
                )
                or set(zone.protected_cells) & (
                    fanout_parents | fanout_parent_halo
                )
            }
            fanout_targets: set[Flower] = set()
            for fanout_job, job_layout, copies in fanout_jobs:
                eligible_cells = len(job_layout["target_cells"])
                per_spawn = BREED_PROBABILITY[fanout_job.method]
                probability = 1.0 - (1.0 - per_spawn) ** eligible_cells
                duration = 1.0 / probability if probability else math.inf
                assignment = opt._assignment(
                    slot, fanout_job, probability, eligible_cells,
                    duration, copies,
                )
                assignment["layout"] = {
                    **job_layout,
                    "greenhouse_fanout_group": group_id,
                    "shared_donor_cell": fanout_layout["donor_cell"],
                }
                assignment["greenhouse_fanout_group"] = group_id
                assignment["layout_search"] = "bounded_joint_cell_outcome"
                self.sequence += 1
                self.add_target_attempt(
                    slot, fanout_job, probability, eligible_cells,
                    copies, assignment, fanout_group=group_id,
                )
                self.active_zones[slot.slot].setdefault(
                    fanout_job.target, set()
                ).update(reserved_fanout_zones)
                pool.ready_by_priority[
                    opt.target_priorities.get(fanout_job.target, 99)
                ].discard(fanout_job.target)
                self.type_load[fanout_job.target.flower_type] += 1
                self.greenhouse_fanout_group_by_target[fanout_job.target] = group_id
                fanout_targets.add(fanout_job.target)
                if self.now == 0.0:
                    self.first_wave.append(assignment)
            self.greenhouse_fanout_remaining[group_id] = 2
            self.greenhouse_fanout_donor[group_id] = donor
            self.busy[donor] += 1
            self.busy[fanout_route.parents[1]] += 1
            self.busy[partner_route.parents[1]] += 1
            occupied_parent_cells.update(fanout_parents)
            occupied_target_cells.update(fanout_targets_cells)
            return reserved_fanout_zones, fanout_targets
        return None

    def _place_batch(
        self, slot, candidate_routes, available_zones, batch_limit,
        occupied_parent_cells, pool, retry_only,
    ) -> list[dict]:
        """Choose and start the best joint route-to-zone layout for this plot."""
        opt = self.opt
        batch = choose_zone_batch(
            slot, candidate_routes,
            available_zones,
            max_jobs=batch_limit,
            beam_width=min(3, opt.finish_time_config.beam_width) if opt.quick else opt.finish_time_config.beam_width,
            occupied_parent_cells=occupied_parent_cells,
            parent_capacities={
                parent: max(0, opt._capacity(parent, self.owned) - self.busy[parent])
                for route, _weight, _rate in candidate_routes
                for parent in route.parents[:2]
            },
            critical_tail=opt.critical_tail,
        )
        if not batch:
            return batch
        cell_rates = {route: rate for route, _weight, rate in candidate_routes}
        free_parent_copies = {
            parent: max(0, opt._capacity(parent, self.owned) - self.busy[parent])
            for route, _weight, _rate in candidate_routes
            for parent in route.parents[:2]
        }
        add_makespan_reducing_pairs(
            slot,
            batch,
            available_zones,
            cell_rates,
            free_parent_copies,
            opt.critical_tail,
            max_extra_pairs=self.extra_pairs_limit,
            occupied_parent_cells=occupied_parent_cells,
        )
        for item in batch:
            route = item["route"]
            selected_zones = item.get("zones", [item["zone"]])
            probability = float(item["probability"])
            eligible = int(item["eligible_cells"])
            if probability <= 0:
                continue
            if retry_only and farm_makespan_after_attempt(
                self.active_probability_by_target,
                opt.critical_tail,
                route.target,
                probability,
                chance_floor=self.chance_floor,
            ) is None:
                continue
            copies = (len(selected_zones), len(selected_zones))
            duration = 1.0 / probability
            assignment = opt._assignment(
                slot, route, probability, eligible, duration, copies
            )
            assignment["layout"] = {
                "parent_a_cells": [list(zone.pair[0]) for zone in selected_zones],
                "parent_b_cells": [list(zone.pair[1]) for zone in selected_zones],
                "target_cells": [
                    list(cell)
                    for cell in sorted(set(item["unique_cells"]) | set(item["shared_cells"]))
                ],
                "shared_target_cells": [
                    list(cell) for cell in sorted(item["shared_cells"])
                ],
            }
            assignment["layout_search"] = "bounded_joint_cell_outcome"
            self.sequence += 1
            self.add_target_attempt(
                slot, route, probability, eligible, copies, assignment
            )
            self.active_zones[slot.slot].setdefault(route.target, set()).update({
                zone.zone_index for zone in selected_zones
            })
            priority = opt.target_priorities.get(route.target, 99)
            pool.ready_by_priority[priority].discard(route.target)
            if retry_only:
                if self.active_probability_by_target.get(route.target, 0.0) >= self.chance_floor:
                    pool.in_progress.add(route.target)
                    pool.ready_by_priority[priority].discard(route.target)
                else:
                    pool.ready_by_priority[priority].add(route.target)
            self.type_load[route.target.flower_type] += 1
            for parent, copy_count in zip(route.parents, copies, strict=True):
                self.busy[parent] += copy_count
            if self.now == 0.0:
                self.first_wave.append(assignment)
        return batch

    def _place_fertilizer(self, slot: PlotSlot, route: Route, pool: _SelectionPool) -> None:
        opt = self.opt
        active_slot_jobs = [
            attempt["assignment"]
            for attempts in self.active_attempts_by_target.values()
            for attempt in attempts
            if attempt.get("slot") is not None
            and attempt["slot"].slot == slot.slot
        ]
        requested_cells = min(
            max(0, opt._capacity(route.parents[0], self.owned) - self.busy[route.parents[0]]),
            slot.spots,
        )
        fertilizer_cells = opt._choose_fertilizer_parent_cells(
            slot, requested_cells, active_slot_jobs
        )
        eligible = len(fertilizer_cells)
        probability = 1.0 - (1.0 - BREED_PROBABILITY[route.method]) ** eligible
        if eligible <= 0 or probability <= 0:
            return
        copies = (eligible,)
        duration = 1.0 / probability
        self.sequence += 1
        assignment = opt._assignment(
            slot, route, probability, eligible, duration, copies
        )
        assignment["layout"] = {
            "parent_a_cells": [list(cell) for cell in fertilizer_cells],
            "parent_b_cells": [],
            "target_cells": [],
        }
        assignment["layout_search"] = "bounded_joint_cell_outcome"
        self.add_target_attempt(
            slot, route, probability, eligible, copies, assignment
        )
        # Fertilizer consumes only its planted cells. It does not
        # claim safe breeding zones, and its cell budget is
        # deducted from the plot until this expected-duration job
        # finishes.
        self.active_zones[slot.slot].setdefault(route.target, set())
        self.fertilizer_busy_cells[slot.slot] += eligible
        pool.ready_by_priority[opt.target_priorities.get(route.target, 99)].discard(
            route.target
        )
        self.type_load[route.target.flower_type] += 1
        self.busy[route.parents[0]] += eligible
        if self.now == 0.0:
            self.first_wave.append(assignment)

    # -- the rollout ---------------------------------------------------------

    def _simulate(self) -> None:
        """Advance completion by completion until every reachable target is owned."""
        opt = self.opt
        provisional_events = 0
        while True:
            if opt.quick and provisional_events >= 2:
                break
            if opt.progress_callback is not None and provisional_events % 64 == 0:
                opt.progress_callback({
                    "phase": "simulating", "completed_jobs": len(self.completed_jobs),
                    "remaining_targets": len(opt.reachable - self.owned),
                    "modeled_day": round(self.now, 2),
                })
            provisional_events += 1
            if not self.queue:
                # Exhausting event hints is not proof that no work is feasible.
                # Rebuild the full ready queues after all parents are released.
                self.ready_by_priority.clear()
                self.ready_queues.clear()
                self.greenhouse_ready_queues.clear()
                self.ready_regions_by_target.clear()
                self.refresh_in_progress()
                self.add_ready_targets(opt.reachable - self.owned)
                self.readiness_rechecks += 1
                self.free_slots[:] = [slot for slot in self.slots if slot.slot not in self.locked]
                self.rescue_mode = True
                self.fill_slots(max_rounds=24)
                self.rescue_mode = False
                if not self.queue:
                    break
            # Each target has one current event representing the combined
            # chance of all its concurrent routes. Adding an attempt makes the
            # prior event stale by increasing active_generation[target].
            finish, _event_id, first_target, generation = heapq.heappop(self.queue)
            if (
                generation != self.active_generation[first_target]
                or not self.active_attempts_by_target.get(first_target)
            ):
                continue
            self.now = finish
            finished_targets = {first_target}
            while self.queue and abs(self.queue[0][0] - finish) < 1e-9:
                _same_finish, _same_id, target, target_generation = heapq.heappop(self.queue)
                if (
                    target_generation == self.active_generation[target]
                    and self.active_attempts_by_target.get(target)
                ):
                    finished_targets.add(target)
            completed_plot_slots: set[str] = set()
            affected_targets: set[Flower] = set()
            for target in sorted(finished_targets, key=lambda item: item.label()):
                self._complete_target(target, completed_plot_slots, affected_targets)
            newly_feasible_regions: set[str] = set()
            for target in affected_targets:
                if target in self.owned or target in self.in_progress:
                    continue
                newly_feasible_regions.update(self.ready_regions_by_target.get(target, ()))
            eligible_slot_ids = completed_plot_slots | {
                slot.slot for slot in self.free_slots
                if slot.region in newly_feasible_regions
            }
            self.fill_slots(max_rounds=1, eligible_slot_ids=eligible_slot_ids)
            self.concurrency_phase = "retry"
            self.refresh_in_progress()
            self.fill_slots(
                max_rounds=1,
                eligible_slot_ids=eligible_slot_ids,
                retry_only=True,
            )
            self.concurrency_phase = "rollout"
            self.refresh_in_progress()
            if opt.reachable <= self.owned:
                break

    def _complete_target(self, target: Flower, completed_plot_slots: set[str], affected_targets: set[Flower]) -> None:
        """Mark a target owned and release every attempt's parents and plot zones."""
        opt = self.opt
        attempts = self.active_attempts_by_target.pop(target, [])
        if not attempts:
            return
        self.owned.add(target)
        self.ready_by_priority[opt.target_priorities.get(target, 99)].discard(target)
        self.in_progress.discard(target)
        self.forced_in_progress.discard(target)
        self.active_probability_by_target.pop(target, None)
        self.active_generation[target] += 1
        slots_to_release: set[str] = set()
        for attempt in attempts:
            slot = attempt["slot"]
            route = attempt["route"]
            copies = attempt["copies"]
            if slot is not None:
                completed_plot_slots.add(slot.slot)
            affected_targets.update(self.dependents.get(route.target, ()))
            for parent in route.parents:
                affected_targets.update(self.dependents.get(parent, ()))
            if slot is None:
                self.completed_jobs.append({
                    "finish_day": round(self.now, 2),
                    **opt._background_assignment(route, attempt["probability"], attempt["eligible"]),
                })
                continue

            self.type_load[route.target.flower_type] -= 1
            fanout_group = attempt["fanout_group"]
            if slot.greenhouse and fanout_group:
                self._release_fanout_attempt(route, copies, fanout_group)
            else:
                for parent, copy_count in zip(route.parents, copies, strict=True):
                    self.busy[parent] -= copy_count
                if not slot.greenhouse and route.method.startswith("fertilize_"):
                    self.fertilizer_busy_cells[slot.slot] = max(
                        0, self.fertilizer_busy_cells[slot.slot] - attempt["eligible"]
                    )
            slots_to_release.add(slot.slot)
            self.completed_jobs.append({
                "finish_day": round(self.now, 2),
                **attempt["assignment"],
            })

        # Sorted: free_slots order decides which plot is filled first, and set
        # order of strings changes with Python's per-run hash seed.
        for slot_id in sorted(slots_to_release):
            self.active_zones[slot_id].pop(target, None)
            occupied_zone_ids = self._reserved_zone_ids(slot_id)
            if slot_id not in self.locked and any(
                zone.zone_index not in occupied_zone_ids
                for zone in self.outdoor_zones.get(slot_id, ())
            ) and all(item.slot != slot_id for item in self.free_slots):
                self.free_slots.append(self.slot_map[slot_id])
        self.add_ready_targets(self.dependents.get(target, ()))

    def _release_fanout_attempt(self, route: Route, copies, fanout_group: str) -> None:
        self.greenhouse_fanout_group_by_target.pop(route.target, None)
        donor = self.greenhouse_fanout_donor[fanout_group]
        for parent, copy_count in zip(route.parents, copies, strict=True):
            if parent != donor:
                self.busy[parent] -= copy_count
        remaining_group_jobs = self.greenhouse_fanout_remaining[fanout_group] - 1
        if remaining_group_jobs > 0:
            self.greenhouse_fanout_remaining[fanout_group] = remaining_group_jobs
        else:
            # The shared patterned donor remains reserved
            # until the last recipient target is acquired.
            self.busy[donor] -= 1
            self.greenhouse_fanout_remaining.pop(fanout_group, None)
            self.greenhouse_fanout_donor.pop(fanout_group, None)

    # -- result ---------------------------------------------------------------

    def _result(self) -> dict:
        opt = self.opt
        plot_jobs = opt._pack_outdoor_first_wave(
            self.first_wave,
            self.preserved_plot_jobs,
            busy_seed=self.planted_busy,
            preserve_scheduled_layouts=True,
        )
        first_wave = _split_supplemental_jobs(self.first_wave, plot_jobs)
        supplemental = [job for jobs in plot_jobs.values() for job in jobs]
        background_first_wave = self.background_first_wave
        missing_after = sorted((opt.reachable - self.owned), key=lambda flower: flower.label())
        if missing_after and not opt.quick:
            raise RuntimeError(
                "Scheduler invariant failed: route-proven targets were not completed: "
                + ", ".join(target.label() for target in missing_after[:10])
            )
        method_counts = Counter(row["method"] for row in self.completed_jobs)
        first_method_counts = Counter(row["method"] for row in first_wave + supplemental + background_first_wave)
        unique_plots = {row["plot"] for row in first_wave + supplemental}
        return {
            "strategy": self.strategy,
            "plot_layout_strategy": dict(PLOT_LAYOUT_STRATEGY),
            "estimated_completion_days": round(self.now, 1),
            "completed_target_count": len(opt.reachable & self.owned),
            "unscheduled_targets": [flower.label() for flower in missing_after],
            "readiness_rechecks": self.readiness_rechecks,
            "rollout_diagnostics": {
                "parents_ready_but_unscheduled": sum(opt._has_owned_route(target, self.owned) for target in missing_after),
                "active_targets_at_stop": len(self.active_attempts_by_target),
                "reserved_copies_at_stop": sum(self.busy.values()),
                "free_plots_at_stop": len(self.free_slots),
            },
            "stop_reason": ("provisional first-wave preview" if opt.quick and missing_after else "all reachable targets completed" if not missing_after else "no feasible job after full readiness recheck"),
            "provisional": bool(opt.quick and missing_after),
            "graph_nodes": len(opt.targets | opt.initial_owned),
            "graph_routes_selected": len(opt.best_routes),
            "usable_physical_plots": len({slot.plot for slot in self.slots}),
            "first_wave_physical_plots_used": len(unique_plots),
            "first_wave_job_count": len(first_wave) + len(supplemental) + len(background_first_wave),
            "first_wave_method_counts": dict(sorted(first_method_counts.items())),
            "full_schedule_method_counts": dict(sorted(method_counts.items())),
            "first_wave": first_wave,
            "background_first_wave": background_first_wave,
            "plot_jobs": plot_jobs,
            "completion_schedule": self.completed_jobs,
            "decision_log": self.decision_log,
            "score_policy": self.score_policy.as_dict() if self.score_policy else None,
        }


def _split_supplemental_jobs(first_wave: list[dict], plot_jobs: dict[str, list[dict]]) -> list[dict]:
    """Keep one primary first-wave row per slot; move the rest into plot_jobs.

    The public plan schema has one primary row per slot. The UI and persisted
    Actual reconciliation use plot_jobs for the other goals on a multi-target
    plot. The simulation still queued every job concurrently; this is only a
    serialization boundary.
    """
    primary_first_wave: list[dict] = []
    primary_slots: set[str] = set()
    extra_first_wave_by_slot: dict[str, list[dict]] = defaultdict(list)
    for assignment in first_wave:
        slot_id = str(assignment.get("slot", "")).upper()
        if slot_id not in primary_slots:
            primary_first_wave.append(assignment)
            primary_slots.add(slot_id)
            continue
        extra = dict(assignment)
        extra["supplemental"] = True
        extra["job_id"] = extra.get("job_id") or (
            f"{slot_id}.S{len(extra_first_wave_by_slot[slot_id]) + 1:02d}"
        )
        extra_first_wave_by_slot[slot_id].append(extra)
    for slot_id, jobs in extra_first_wave_by_slot.items():
        plot_jobs.setdefault(slot_id, []).extend(jobs)
    return primary_first_wave
