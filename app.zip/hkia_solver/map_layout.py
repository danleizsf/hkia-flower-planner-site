from __future__ import annotations

import json
import os
from pathlib import Path

from .paths import farm_data_path


def _migrate_layout(data: dict) -> bool:
    """Add newly surfaced regions without discarding customized map details."""
    order = data.setdefault("region_order", [])
    regions = data.setdefault("regions", {})
    changed = False
    hothead = regions.get("Mount Hothead", {})
    hothead_positions = hothead.get("positions", {})

    if "Caldera" not in regions:
        position = hothead_positions.pop("MH7", [5, 1, 4])
        caldera = {
            "travel_label": "Via Mount Hothead",
            "location_hint": "Caldera extremophile flower patch",
            "map_rows": 1,
            "positions": {"MH7": position},
        }
        for key in ("plot_names", "plot_locations", "locked_positions"):
            value = hothead.get(key, {}).pop("MH7", None)
            if value is not None:
                caldera[key] = {"MH7": value}
        regions["Caldera"] = caldera
        if hothead_positions:
            hothead["map_rows"] = max(
                1, *(int(values[1]) for values in hothead_positions.values())
            )
        changed = True
    elif "MH7" in hothead_positions:
        regions["Caldera"].setdefault("positions", {}).setdefault(
            "MH7", hothead_positions.pop("MH7")
        )
        changed = True

    if "Caldera" not in order:
        try:
            index = order.index("Mount Hothead") + 1
        except ValueError:
            index = len(order)
        order.insert(index, "Caldera")
        changed = True
    return changed


def load_map_layout(project_root: Path) -> dict:
    path = farm_data_path(project_root, "ui_map_layouts.json")
    data = json.loads(path.read_text(encoding="utf-8"))
    if _migrate_layout(data):
        temporary = path.with_name(f".{path.name}.migration-tmp")
        temporary.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        os.replace(temporary, path)
    order = data.get("region_order", [])
    regions = data.get("regions", {})
    if set(order) != set(regions):
        raise ValueError("ui_map_layouts.json region_order must list every region exactly once")
    return data


def region_sort_key(layout: dict, region: str) -> tuple[int, str]:
    try:
        return (layout["region_order"].index(region), region)
    except ValueError:
        return (len(layout["region_order"]), region)


def plot_position(layout: dict, region: str, slot: str) -> dict:
    values = layout.get("regions", {}).get(region, {}).get("positions", {}).get(slot)
    if not values:
        return {"column": 1, "row": 1, "span": 4}
    column, row, span = values
    return {"column": int(column), "row": int(row), "span": int(span)}


def plot_display_name(layout: dict, region: str, slot: str, default: str) -> str:
    return str(
        layout.get("regions", {}).get(region, {}).get("plot_names", {}).get(slot)
        or default
    )


def plot_location(layout: dict, region: str, slot: str) -> str:
    return str(
        layout.get("regions", {}).get(region, {}).get("plot_locations", {}).get(slot)
        or ""
    )
