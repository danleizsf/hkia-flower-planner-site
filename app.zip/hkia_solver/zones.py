from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path

from . import plots
from .models import Flower
from .plots import PlotSlot


def flower_zones() -> dict[str, frozenset[str]]:
    """Where each flower type may grow; with the Extreme Greenhouse, extremophiles also grow there."""
    return _flower_zones(plots.greenhouse_level() == plots.EXTREME_GREENHOUSE_LEVEL)


@lru_cache(maxsize=2)
def _flower_zones(extreme_greenhouse: bool) -> dict[str, frozenset[str]]:
    from .rules import FLOWER_TYPES

    path = Path(__file__).resolve().parents[1] / "data" / "flower_zones.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    return {
        flower_type: frozenset(zones) | (
            {"Greenhouse"} if extreme_greenhouse and FLOWER_TYPES[flower_type].extreme else frozenset())
        for flower_type, zones in data["flower_zones"].items()
    }


def flower_type_allowed(flower_type: str, slot: PlotSlot) -> bool:
    return slot.region in flower_zones().get(flower_type, frozenset())


def flower_allowed(flower: Flower, slot: PlotSlot) -> bool:
    return flower_type_allowed(flower.flower_type, slot)


def route_allowed(target: Flower, parents: tuple[Flower, ...], slot: PlotSlot) -> bool:
    return flower_allowed(target, slot) and all(flower_allowed(parent, slot) for parent in parents)


