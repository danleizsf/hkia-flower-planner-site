from __future__ import annotations

import hashlib
import json
import os
import tempfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from .models import Flower


def assignment_signature(assignment: dict) -> str:
    """Identify the exact planting instructions attached to one plot slot."""
    payload = {
        "slot": assignment["slot"],
        "target": assignment["target"],
        "method": assignment["method"],
        "parents": assignment["parents"],
        "parent_copies": assignment["parent_copies"],
        "job_id": assignment.get("job_id"),
        "layout": assignment.get("layout"),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def legacy_assignment_signature(assignment: dict) -> str:
    """Signature written before multi-target layout metadata was introduced."""
    payload = {
        "slot": assignment["slot"],
        "target": assignment["target"],
        "method": assignment["method"],
        "parents": assignment["parents"],
        "parent_copies": assignment["parent_copies"],
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def assignment_identity(assignment: dict) -> tuple:
    """Return the physical breeding job identity, independent of A/B ordering."""
    parents = [
        (str(parent), int(count))
        for parent, count in zip(
            assignment.get("parents", []), assignment.get("parent_copies", []), strict=False
        )
    ]
    return (
        assignment.get("target_type"),
        assignment.get("target_color"),
        assignment.get("target_pattern"),
        assignment.get("target"),
        assignment.get("method"),
        tuple(sorted(parents)),
    )


def assignments_equivalent(first: dict, second: dict) -> bool:
    return assignment_identity(first) == assignment_identity(second)


def assignment_groups_equivalent(first: list[dict], second: list[dict]) -> bool:
    return sorted(assignment_identity(item) for item in first) == sorted(
        assignment_identity(item) for item in second
    )



def effective_stock_goal(assignment: dict) -> int:
    """Goal currently required from a planted job.

    v8 breeding jobs stop after the first successful copy. Older v7 records may
    still carry a larger stock_goal; preserve that number as the later
    propagation goal rather than forcing the original parents to keep running.
    """
    if assignment.get("method") == "propagate_solid" or assignment.get("propagation"):
        return max(1, int(assignment.get("stock_goal", 1)))
    return 1


def propagation_goal(assignment: dict) -> int:
    if assignment.get("method") == "propagate_solid" or assignment.get("propagation"):
        return max(1, int(assignment.get("stock_goal", 1)))
    # v30: ordinary breeding jobs never carry a speculative future stock target.
    # Any extra solid copy must be justified again from the live farm state.
    return 1

def load_plot_status(path: Path) -> dict:
    if not path.exists():
        return {"plots": {}}
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data.get("plots"), dict):
        raise ValueError("plot status file must contain a 'plots' object")
    _collapse_legacy_greenhouse_records(data)
    return data


def _legacy_greenhouse_job_layout(assignment: dict, cells: list[dict]) -> tuple[dict, list[dict]]:
    """Rebuild exact cells when merging a v70 GHxx record into shared GH."""
    normalized = dict(assignment)
    old_slot = str(normalized.get("slot", "")).upper()
    normalized["slot"] = "GH"
    if isinstance(normalized.get("layout"), dict):
        return normalized, cells

    parents = list(normalized.get("parent_flowers", []))
    method = str(normalized.get("method", ""))
    matched: list[list[tuple[int, int]]] = [[] for _ in parents]
    enriched = [dict(cell) for cell in cells]
    for cell in enriched:
        coordinate = (int(cell["row"]), int(cell["col"]))
        signature = (
            cell.get("flower_type"), cell.get("color"), cell.get("pattern", "Solid"),
            cell.get("secondary_color"),
        )
        role = str(cell.get("parent_role", ""))
        preferred = 0 if role == "A" else 1 if role == "B" else None
        parent_index = None
        if preferred is not None and preferred < len(parents):
            parent = parents[preferred]
            if signature == (
                parent.get("flower_type"), parent.get("color"),
                parent.get("pattern", "Solid"), parent.get("secondary_color"),
            ):
                parent_index = preferred
        if parent_index is None:
            for index, parent in enumerate(parents):
                expected = (
                    parent.get("flower_type"), parent.get("color"),
                    parent.get("pattern", "Solid"), parent.get("secondary_color"),
                )
                if signature == expected and coordinate not in matched[index]:
                    parent_index = index
                    break
        if parent_index is None:
            continue
        matched[parent_index].append(coordinate)
        cell["parent_role"] = "A" if parent_index == 0 else "B"
        cell["job_id"] = normalized.get("job_id")

    copies = [max(1, int(value)) for value in normalized.get("parent_copies", [])]
    parent_a = matched[0][:copies[0]] if matched and copies else []
    parent_b = matched[1][:copies[1]] if len(matched) > 1 and len(copies) > 1 else []

    # Older installations always wrote exact cell coordinates for planted
    # Greenhouse parents. If those are missing, recover that old micro-slot's
    # deterministic pair so the migrated job remains drawable and editable.
    if len(parents) > 1 and (not parent_a or not parent_b):
        try:
            index = int(old_slot[2:]) - 1
            row, col = (index // 3) * 3, (index % 3) * 4
            parent_a = parent_a or [(row, col)]
            parent_b = parent_b or [(row, col + 1)]
        except (ValueError, IndexError):
            pass

    target_cells: list[tuple[int, int]] = []
    if method.startswith("fertilize_"):
        parent_b = []
    elif parent_a and parent_b:
        a, b = parent_a[0], parent_b[0]
        neighborhood = lambda cell: {
            (cell[0] + dr, cell[1] + dc)
            for dr in (-1, 0, 1)
            for dc in (-1, 0, 1)
            if (dr or dc)
            and 0 <= cell[0] + dr < 10
            and 0 <= cell[1] + dc < 10
        }
        occupied = set(parent_a) | set(parent_b)
        candidates = sorted((neighborhood(a) & neighborhood(b)) - occupied)
        target_cells = candidates[:max(0, int(normalized.get("eligible_cells", 0)))]

    normalized["layout"] = {
        "parent_a_cells": [list(cell) for cell in parent_a],
        "parent_b_cells": [list(cell) for cell in parent_b],
        "target_cells": [list(cell) for cell in target_cells],
    }
    return normalized, enriched


def _collapse_legacy_greenhouse_records(data: dict) -> None:
    """Merge v70's twelve scheduler records into the one physical Greenhouse.

    Existing cells and target metadata are retained. Assignments are rewritten
    to the canonical ``GH`` slot so older farms reopen as one editable plot.
    """
    plots = data.setdefault("plots", {})
    keys = [key for key in list(plots) if str(key).upper() == "GH"
            or str(key).upper().startswith("GH") and str(key)[2:].isdigit()]
    if not keys:
        return
    keys.sort(key=lambda key: (str(key).upper() != "GH", str(key).upper()))
    records = [plots[key] for key in keys if isinstance(plots.get(key), dict)]
    if len(keys) == 1 and str(keys[0]).upper() == "GH":
        record = records[0]
        assignment = assignment_from_record(record)
        if assignment:
            assignment["slot"] = "GH"
            record["assignment"] = assignment_snapshot(assignment)
            for job in record.get("jobs", []):
                if isinstance(job, dict):
                    job["slot"] = "GH"
            record.pop("plan_signature", None)
        return

    assignments: list[dict] = []
    cells_by_position: dict[tuple, dict] = {}
    job_states: dict = {}
    for record in records:
        assignment = assignment_from_record(record)
        candidates = ([assignment] if assignment else []) + [
            row for row in record.get("jobs", []) if isinstance(row, dict)
        ]
        old_job_states = record.get("job_states", {})
        record_state = record.get("state", record.get("status", "planted"))
        for candidate_index, candidate in enumerate(candidates):
            normalized = dict(candidate)
            old_job_id = normalized.get("job_id")
            if not normalized.get("job_id"):
                normalized["job_id"] = f"migrated-{len(assignments) + 1:02d}"
            record_cells = [
                dict(cell) for cell in record.get("cells", [])
                if isinstance(cell, dict) and "row" in cell and "col" in cell
            ]
            normalized, record_cells = _legacy_greenhouse_job_layout(
                normalized, record_cells
            )
            assignments.append(normalized)
            old_state_key = old_job_id or ("primary" if candidate_index == 0 else "")
            state_row = old_job_states.get(old_state_key, {}) if isinstance(old_job_states, dict) else {}
            if (
                record_state == "goal_reached"
                or isinstance(state_row, dict) and state_row.get("state") == "goal_reached"
            ):
                job_states[normalized["job_id"]] = {
                    "state": "goal_reached",
                    **({"goal_reached_at": state_row["goal_reached_at"]}
                       if isinstance(state_row, dict) and state_row.get("goal_reached_at")
                       else {"goal_reached_at": record.get("goal_reached_at")}
                       if record.get("goal_reached_at") else {}),
                }
            for cell in record_cells:
                cell.setdefault("job_id", normalized.get("job_id"))
                signature = (
                    int(cell["row"]), int(cell["col"]), cell.get("flower_type"),
                    cell.get("color"), cell.get("pattern"), cell.get("secondary_color"),
                )
                cells_by_position.setdefault(signature, cell)
        for cell in record.get("cells", []):
            if not isinstance(cell, dict) or "row" not in cell or "col" not in cell:
                continue
            signature = (
                int(cell["row"]), int(cell["col"]), cell.get("flower_type"),
                cell.get("color"), cell.get("pattern"), cell.get("secondary_color"),
            )
            cells_by_position.setdefault(signature, dict(cell))

    merged = dict(records[0]) if records else {"state": "planted", "status": "planted"}
    if assignments:
        primary = assignments[0]
        merged["assignment"] = assignment_snapshot(primary)
        merged.update({key: primary[key] for key in (
            "target", "method", "parents", "parent_copies"
        ) if key in primary})
        merged["jobs"] = [assignment_snapshot(row) for row in assignments[1:]]
    else:
        merged.pop("assignment", None)
        merged.pop("jobs", None)
    if cells_by_position:
        merged["cells"] = [cells_by_position[key] for key in sorted(cells_by_position)]
    if job_states:
        merged["job_states"] = job_states
    else:
        merged.pop("job_states", None)
    merged["state"] = merged["status"] = (
        "goal_reached" if records and all(
            row.get("state", row.get("status", "planted")) == "goal_reached"
            for row in records
        ) else "planted"
    )
    for field in ("manual_layout", "layout_edited", "target_management_locked",
                  "target_tracking_explicit"):
        if any(bool(row.get(field)) for row in records):
            merged[field] = True
    if records:
        merged["planted_at"] = min(
            (row.get("planted_at") for row in records if row.get("planted_at")),
            default=merged.get("planted_at"),
        )
    merged.pop("plan_signature", None)
    for key in keys:
        plots.pop(key, None)
    plots["GH"] = merged


def save_plot_status(path: Path, data: dict, *, compact: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=path.parent
    )
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            if compact:
                # dumps() uses the C encoder; dump() streams through the
                # pure-Python one (~1 s for the plan file). Same bytes.
                handle.write(json.dumps(data, separators=(",", ":")))
            else:
                json.dump(data, handle, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary_path, path)
    finally:
        if temporary_path.exists():
            temporary_path.unlink()


def first_wave_by_slot(plan: dict) -> dict[str, dict]:
    return {row["slot"].upper(): row for row in plan["first_wave"]}


def first_wave_jobs_by_slot(plan: dict) -> dict[str, list[dict]]:
    """Return primary plus supplemental jobs without changing legacy callers."""
    result = {
        slot: [assignment]
        for slot, assignment in first_wave_by_slot(plan).items()
    }
    for slot, jobs in plan.get("plot_jobs", {}).items():
        result.setdefault(slot.upper(), []).extend(jobs)
    return result


ASSIGNMENT_FIELDS = (
    "slot",
    "plot",
    "region",
    "plot_spots",
    "eligible_cells",
    "target",
    "target_type",
    "target_color",
    "target_pattern",
    "target_secondary_color",
    "method",
    "parents",
    "parent_flowers",
    "parent_patterns",
    "parent_copies",
    "daily_probability",
    "expected_days",
    "event_only",
    "stock_goal",
    "stock_goal_reason",
    "propagation_goal",
    "propagation_goal_reason",
    "propagation",
    "propagation_zone_count",
    "job_id",
    "supplemental",
    "greenhouse_fanout_group",
    "layout",
    "manual_target",
    "manual_target_source",
    "manual_target_verified",
)


def assignment_snapshot(assignment: dict) -> dict:
    return {key: assignment[key] for key in ASSIGNMENT_FIELDS if key in assignment}


def assignment_from_record(record: dict) -> dict | None:
    assignment = record.get("assignment")
    if isinstance(assignment, dict):
        return assignment
    # Compatibility with status files written by the earlier CLI.
    required = {"slot", "target", "method", "parents", "parent_copies"}
    if required <= set(record):
        return {key: record[key] for key in ASSIGNMENT_FIELDS if key in record}
    return None


def record_planted(
    data: dict,
    assignments: list[dict],
    planted_at: str | None = None,
    cells_by_slot: dict[str, list[dict]] | None = None,
) -> None:
    timestamp = planted_at or datetime.now(timezone.utc).isoformat(timespec="seconds").replace(
        "+00:00", "Z"
    )
    plots = data.setdefault("plots", {})
    for assignment in assignments:
        snapshot = assignment_snapshot(assignment)
        slot = assignment["slot"].upper()
        record = {
            "state": "planted",
            "status": "planted",
            "planted_at": timestamp,
            "target": assignment["target"],
            "method": assignment["method"],
            "parents": assignment["parents"],
            "parent_copies": assignment["parent_copies"],
            "plan_signature": assignment_signature(assignment),
            "assignment": snapshot,
        }
        if cells_by_slot and slot in cells_by_slot:
            record["cells"] = cells_by_slot[slot]
            record["layout_edited"] = False
        plots[slot] = record


def clear_status(data: dict, slots: list[str]) -> int:
    plots = data.setdefault("plots", {})
    removed = 0
    for slot in slots:
        if plots.pop(slot.upper(), None) is not None:
            removed += 1
    return removed


def status_for(assignment: dict, data: dict) -> tuple[str, dict | None]:
    record = data.get("plots", {}).get(assignment["slot"].upper())
    if not record:
        return "not_recorded", None
    stored_signature = record.get("plan_signature")
    valid_signatures = {
        assignment_signature(assignment),
        legacy_assignment_signature(assignment),
    }
    if stored_signature not in valid_signatures:
        recorded_assignments = [assignment_from_record(record)]
        recorded_assignments.extend(
            item for item in record.get("jobs", []) if isinstance(item, dict)
        )
        if not any(
            recorded is not None
            and (
                assignment_signature(recorded) in valid_signatures
                or legacy_assignment_signature(recorded) in valid_signatures
                or assignments_equivalent(recorded, assignment)
            )
            for recorded in recorded_assignments
        ):
            return "plan_changed", record
    if record.get("layout_edited"):
        return "plan_changed", record
    if record.get("state") == "goal_reached":
        return "goal_reached", record
    return "planted", record


def actual_assignments(data: dict, states: set[str] | None = None) -> dict[str, dict]:
    allowed = states or {"planted", "goal_reached"}
    result: dict[str, dict] = {}
    for slot, record in data.get("plots", {}).items():
        state = record.get("state", record.get("status", "planted"))
        assignment = assignment_from_record(record)
        if state in allowed and assignment:
            result[slot.upper()] = assignment
    return result


def actual_jobs_by_slot(data: dict, states: set[str] | None = None) -> dict[str, list[dict]]:
    allowed = states or {"planted", "goal_reached"}
    result: dict[str, list[dict]] = {}
    for slot, record in data.get("plots", {}).items():
        state = record.get("state", record.get("status", "planted"))
        primary = assignment_from_record(record)
        if state not in allowed or not primary:
            continue
        jobs = [primary]
        jobs.extend(
            assignment for assignment in record.get("jobs", [])
            if isinstance(assignment, dict)
        )
        result[slot.upper()] = jobs
    return result


def reserved_parent_counts_by_plot(
    data: dict,
    states: set[str] | None = None,
) -> dict[str, Counter[Flower]]:
    """Return exact planted-parent counts grouped by their recorded plot."""
    by_plot: dict[str, Counter[Flower]] = {}
    allowed = states or {"planted", "goal_reached"}
    for slot, record in data.get("plots", {}).items():
        state = record.get("state", record.get("status", "planted"))
        if state not in allowed:
            continue
        reserved: Counter[Flower] = Counter()
        cells = record.get("cells")
        if isinstance(cells, list):
            for cell in cells:
                reserved[Flower(
                    cell["flower_type"], cell["color"], cell["pattern"],
                    cell.get("secondary_color"),
                )] += 1
        else:
            assignments = [assignment_from_record(record)]
            assignments.extend(
                row for row in record.get("jobs", []) if isinstance(row, dict)
            )
            for assignment in assignments:
                if assignment:
                    for parent, count in zip(
                        assignment.get("parent_flowers", []),
                        assignment.get("parent_copies", []),
                        strict=False,
                    ):
                        reserved[Flower(
                            parent["flower_type"], parent["color"], parent["pattern"],
                            parent.get("secondary_color"),
                        )] += int(count)
        if reserved:
            by_plot[slot.upper()] = reserved
    return by_plot


def reserved_parent_counts(data: dict, states: set[str] | None = None) -> Counter[Flower]:
    reserved: Counter[Flower] = Counter()
    for plot_counts in reserved_parent_counts_by_plot(data, states).values():
        reserved.update(plot_counts)
    return reserved


def record_cell_counts(record: dict) -> Counter[Flower]:
    counts: Counter[Flower] = Counter()
    for cell in record.get("cells", []):
        if cell.get("filler"):      # fillers are never parents
            continue
        counts[Flower(
            cell["flower_type"], cell["color"], cell["pattern"],
            cell.get("secondary_color"),
        )] += 1
    return counts


def assignment_parent_counts(assignment: dict) -> Counter[Flower]:
    counts: Counter[Flower] = Counter()
    for parent, count in zip(
        assignment.get("parent_flowers", []),
        assignment.get("parent_copies", []),
        strict=False,
    ):
        counts[Flower(
            parent["flower_type"], parent["color"], parent["pattern"],
            parent.get("secondary_color"),
        )] += int(count)
    return counts


def mark_goal_reached(data: dict, slot: str, reached_at: str | None = None) -> None:
    record = data.get("plots", {}).get(slot.upper())
    if not record:
        raise ValueError(f"Plot {slot.upper()} is not recorded as planted")
    record["state"] = "goal_reached"
    record["goal_reached_at"] = reached_at or datetime.now(timezone.utc).isoformat(
        timespec="seconds"
    ).replace("+00:00", "Z")
