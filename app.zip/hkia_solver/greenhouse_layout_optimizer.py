"""Small bounded layout helpers for the single shared Greenhouse plot."""
from __future__ import annotations

from functools import lru_cache
from itertools import combinations

from .plots import PlotSlot, neighboring_cells, usable_cells


def single_job_layout(
    slot: PlotSlot,
    occupied_parent_cells=(),
    occupied_target_cells=(),
    *,
    fertilizer: bool = False,
) -> dict | None:
    """Build a deterministic, non-overlapping layout for one GH assignment.

    Unlike the older artificial GH subplots, this finds cells on the shared
    physical grid. Existing planted and target cells stay protected so a fast
    refresh cannot place a new job on top of live work.
    """
    if not slot.greenhouse:
        return None
    usable = usable_cells(slot)
    parents = {tuple(map(int, cell)) for cell in occupied_parent_cells}
    targets = {tuple(map(int, cell)) for cell in occupied_target_cells}
    neighbors = {cell: neighboring_cells(cell, usable) for cell in usable}
    if fertilizer:
        free = sorted(usable - parents - targets)
        return ({"parent_a_cells": [list(free[0])], "parent_b_cells": [],
                 "target_cells": [], "shared_target_cells": []} if free else None)

    # Existing offspring cells are reserved for their own pair, but their
    # neighboring empty cells remain usable for a separate pair. Requiring a
    # full halo around every old target over-constrains the dense shared GH
    # and can make refresh impossible despite dozens of physically free cells.
    forbidden_parents = parents | targets
    forbidden_targets = parents | targets
    candidates = []
    for first in sorted(usable - forbidden_parents):
        for second in sorted(neighbors[first] - forbidden_parents):
            if first >= second:
                continue
            spawn = sorted((neighbors[first] & neighbors[second]) - {first, second} - forbidden_targets)
            if not spawn:
                continue
            candidates.append((len(spawn), tuple(-v for v in first), tuple(-v for v in second), first, second, spawn))
    if not candidates:
        return None
    _count, _f, _s, first, second, spawn = max(candidates)
    return {"parent_a_cells": [list(first)], "parent_b_cells": [list(second)],
            "target_cells": [list(cell) for cell in spawn], "shared_target_cells": []}


def pattern_transfer_fanout_layout(
    slot: PlotSlot,
    occupied_parent_cells=(),
    occupied_target_cells=(),
) -> dict | None:
    """Find a fan-out layout that does not interfere with planted GH jobs.

    The scheduler can call this after existing Actual jobs have reserved cells.
    Normalize those sets here so the bounded search remains cacheable.
    """
    return _cached_pattern_transfer_fanout_layout(
        slot,
        tuple(sorted(tuple(cell) for cell in occupied_parent_cells)),
        tuple(sorted(tuple(cell) for cell in occupied_target_cells)),
    )


@lru_cache(maxsize=128)
def _cached_pattern_transfer_fanout_layout(
    slot: PlotSlot,
    occupied_parent_cells: tuple[tuple[int, int], ...],
    occupied_target_cells: tuple[tuple[int, int], ...],
) -> dict | None:
    """Find a safe one-donor/two-recipient pattern-transfer arrangement.

    The layout is searched on the full greenhouse grid rather than anchored to
    one of the old twelve fixed micro-slots. Each recipient receives its own
    spawn cells: one physical cell never counts as a spawn opportunity for two
    different target goals.
    """
    if not slot.greenhouse:
        return None
    usable = usable_cells(slot)
    neighbor_map = {cell: neighboring_cells(cell, usable) for cell in usable}
    occupied_parents = set(occupied_parent_cells)
    occupied_targets = set(occupied_target_cells)
    # Keep a newly assigned offspring cell away from existing parents so it
    # cannot become a second, ambiguously shared spawn opportunity. Likewise,
    # don't plant over an existing target cell or right beside it.
    existing_parent_halo = set().union(*(
        neighbor_map.get(cell, set()) for cell in occupied_parents
    )) if occupied_parents else set()
    existing_target_halo = set().union(*(
        neighbor_map.get(cell, set()) for cell in occupied_targets
    )) if occupied_targets else set()
    forbidden_plants = occupied_parents | occupied_targets | existing_target_halo
    forbidden_targets = (
        occupied_parents | occupied_targets | existing_parent_halo
    )
    candidates = []
    for donor in sorted(usable):
        if donor in forbidden_plants:
            continue
        adjacent = sorted(neighbor_map[donor])
        adjacent = [cell for cell in adjacent if cell not in forbidden_plants]
        for first_recipient, second_recipient in combinations(adjacent, 2):
            plants = {donor, first_recipient, second_recipient}
            first_cells = (neighbor_map[donor] & neighbor_map[first_recipient]) - plants
            second_cells = (neighbor_map[donor] & neighbor_map[second_recipient]) - plants
            first_cells -= forbidden_targets
            second_cells -= forbidden_targets
            # A cell beside both recipients would give two goals credit for the
            # same physical spawn. Drop it from both lanes.
            shared = first_cells & second_cells
            first_cells -= shared
            second_cells -= shared
            # A cell adjacent to the other recipient is also ambiguous even
            # when it is not common to the two pair intersections.
            first_cells = {
                cell for cell in first_cells
                if second_recipient not in neighbor_map[cell]
            }
            second_cells = {
                cell for cell in second_cells
                if first_recipient not in neighbor_map[cell]
            }
            if len(first_cells) < 2 or len(second_cells) < 2:
                continue
            first_targets = sorted(first_cells)
            second_targets = sorted(second_cells)
            score = (
                len(first_targets) + len(second_targets),
                min(len(first_targets), len(second_targets)),
                tuple(-value for value in donor),
                tuple(-value for value in first_recipient),
                tuple(-value for value in second_recipient),
            )
            candidates.append((score, donor, first_recipient, second_recipient,
                               first_targets, second_targets))
    if not candidates:
        return None
    _score, donor, first_recipient, second_recipient, first_targets, second_targets = max(
        candidates, key=lambda item: item[0]
    )
    return {
        "donor_cell": list(donor),
        "primary": {
            "parent_a_cells": [list(donor)],
            "parent_b_cells": [list(first_recipient)],
            "target_cells": [list(cell) for cell in first_targets],
            "shared_target_cells": [],
        },
        "secondary": {
            "parent_a_cells": [],
            "parent_b_cells": [list(second_recipient)],
            "shared_parent_a_cells": [list(donor)],
            "target_cells": [list(cell) for cell in second_targets],
            "shared_target_cells": [],
        },
    }


def fanout_reduces_donor_wait(ready_goals: int, free_donor_copies: int) -> bool:
    """Use fan-out only when compatible ready work exceeds donor copies."""
    return int(ready_goals) > max(0, int(free_donor_copies))
