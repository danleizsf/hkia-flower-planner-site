from __future__ import annotations

from .models import Flower, FlowerType


# These switches define collection *scope*, not scheduler priority. v19 keeps
# only two hard scheduling constraints: native extremophile solids own their
# tiny native plots while any of those solids are still missing, and
# non-default-secondary hybrids remain out of scope.
TARGET_CATEGORY_DEFAULTS = {
    "extremophile_solids": True,
    "other_solids": True,
    "default_patterns_effects": True,
    "non_default_secondary_patterns": False,
}

TARGET_CATEGORY_ORDER = (
    "extremophile_solids",
    "other_solids",
    "default_patterns_effects",
    "non_default_secondary_patterns",
)

TARGET_CATEGORY_LABELS = {
    "extremophile_solids": "Extremophile solids",
    "other_solids": "Other solids",
    "default_patterns_effects": "Default-secondary patterns and effects",
    "non_default_secondary_patterns": "Non-default-secondary patterns",
}


def normalized_target_categories(settings: dict) -> dict[str, bool]:
    configured = settings.get("target_categories", {})
    result = {
        key: bool(configured.get(key, default))
        for key, default in TARGET_CATEGORY_DEFAULTS.items()
    }
    # The inventory can store these hybrids, but the combinatorial target graph
    # is intentionally out of scope until its search can be bounded safely.
    result["non_default_secondary_patterns"] = False
    return result


def target_category(flower: Flower, flower_types: dict[str, FlowerType]) -> str:
    if flower.pattern == "Solid":
        return (
            "extremophile_solids"
            if flower_types[flower.flower_type].extreme
            else "other_solids"
        )
    if flower.secondary_color is None:
        return "default_patterns_effects"
    return "non_default_secondary_patterns"


def target_priority(flower: Flower, flower_types: dict[str, FlowerType]) -> int:
    """Scheduling bucket kept for backwards compatibility.

    v19 intentionally puts all enabled collection targets in one ordinary
    bucket. Native extremophile-slot protection is enforced by the physical
    scheduler, not by a global solids-before-patterns ladder.
    """
    return 0


