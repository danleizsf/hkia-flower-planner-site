"""Pack the first wave's outdoor plots: HypergraphOptimizer._pack_outdoor_first_wave.

Each plot is filled in priority order: the scheduled primary job keeps one
pair; spare safe zones go first to other ready goals, then to extra pairs for
active goals, then to on-demand propagation. Fertilizer jobs only take cells
left over after all of that. Locked/manual work is never resized.
"""
from __future__ import annotations

import math
from collections import Counter, defaultdict

from .models import Flower
from .optimizer import Route
from .plots import PlotSlot, isolated_pair_zones
from .rules import BREED_PROBABILITY


def _flower(row: dict) -> Flower:
    return Flower(row["flower_type"], row["color"], row["pattern"], row.get("secondary_color"))


def _target(job: dict) -> Flower:
    return Flower(
        job["target_type"], job["target_color"],
        job["target_pattern"], job.get("target_secondary_color"),
    )


def _is_locked(job: dict) -> bool:
    return bool(
        job.get("locked")
        or job.get("manual_target")
        or job.get("farm_state") == "planted_locked"
    )


class _SlotPacking:
    """Per-plot working state while one outdoor plot is packed."""

    def __init__(self, slot: PlotSlot, first_wave: list[dict], packed: dict, claimed_zones: set):
        self.slot = slot
        self.zones = isolated_pair_zones(slot, 999)
        self.primary_jobs = [
            row for row in first_wave
            if str(row.get("slot", "")).upper() == slot.slot
        ]
        self.packed = packed
        self.claimed_zones = claimed_zones
        # Only jobs created or resized by this pass may receive extra pairs
        # or cells; preserved/Actual layouts constrain the plot but stay
        # under the user's control.
        self.mutable_jobs: list[dict] = []
        self.mutable_fertilizers: list[dict] = []

    def current_jobs(self) -> list[dict]:
        return self.primary_jobs + self.packed.get(self.slot.slot, [])

    def next_job_id(self) -> str:
        return f"{self.slot.slot}.J{len(self.packed.get(self.slot.slot, [])) + 1:02d}"


class FirstWavePacker:
    def __init__(
        self,
        optimizer,
        slots: list[PlotSlot],
        first_wave: list[dict],
        preserved: dict[str, list[dict]] | None,
        slots_to_repack: set[str] | None,
        candidate_order: list[Flower] | None,
        busy_seed: Counter[Flower] | None,
        in_progress_seed: set[Flower] | None,
        preserve_scheduled_layouts: bool,
    ):
        opt = self.opt = optimizer
        self.slot_map = {slot.slot: slot for slot in slots}
        self.first_wave = first_wave
        self.preserved = {slot: list(jobs) for slot, jobs in (preserved or {}).items()}
        self.slots_to_repack = slots_to_repack
        self.busy_seed = busy_seed
        self.preserve_scheduled_layouts = preserve_scheduled_layouts
        self.busy: Counter[Flower] = Counter(busy_seed or {})
        self.in_progress: set[Flower] = set(in_progress_seed or set())
        self.owned = set(opt.initial_owned)
        self.packed: dict[str, list[dict]] = self.preserved
        self.unusable_primary_ids: set[int] = set()
        self.ordered_candidates: list[Flower] | None = None
        if candidate_order is not None:
            self.ordered_candidates = list(dict.fromkeys(candidate_order))
        self.fertilizer_candidate_order = (
            list(self.ordered_candidates)
            if self.ordered_candidates is not None
            else sorted(
                (
                    target for target in opt.reachable
                    if target.pattern != "Solid"
                    and target.secondary_color is None
                    and opt.flower_types[target.flower_type].default_pattern == target.pattern
                ),
                key=lambda target: (
                    -opt.descendants.get(target, 0),
                    -opt.critical_tail.get(target, 0.0),
                    target.label(),
                ),
            )
        )
        self.fertilizer_cursor_by_slot: dict[str, int] = defaultdict(int)

    def _repacking(self, slot_id: str) -> bool:
        return self.slots_to_repack is None or slot_id in self.slots_to_repack

    def pack(self) -> dict[str, list[dict]]:
        self._reserve_existing_work()
        self._shrink_primary_copies()
        preclaimed_zones_by_slot, prepacked_slots = self._preclaimed_zones()
        for primary in sorted(self.first_wave, key=lambda row: row["slot"]):
            slot = self.slot_map[primary["slot"]]
            if not self._repacking(slot.slot):
                continue
            if slot.slot in prepacked_slots:
                # These jobs and cells were selected together by the finish-time
                # search. A second greedy pass would change parent counts and
                # spawn chances after the completion rollout, so preserve this
                # plot exactly as simulated.
                continue
            if slot.greenhouse:
                continue
            claimed = set(preclaimed_zones_by_slot.get(slot.slot, set()))
            self._pack_slot(_SlotPacking(slot, self.first_wave, self.packed, claimed), primary)
        return self._finish()

    def _reserve_existing_work(self) -> None:
        """Count the parents and targets of every job already on the plan."""
        # For a one-plot refresh, busy_seed/in_progress_seed already describe
        # the authoritative commitments on every *other* plot (actual planted
        # parents where present, otherwise unplanted recommendations). Counting
        # the saved recommendations again would both double-reserve some parents
        # and, worse, ignore parents that are physically planted under a changed
        # recommendation. Only the plot being repacked is added here.
        seeded_local_repack = self.busy_seed is not None and self.slots_to_repack is not None
        for assignment in self.first_wave + [job for jobs in self.preserved.values() for job in jobs]:
            if seeded_local_repack and str(assignment.get("slot", "")).upper() not in self.slots_to_repack:
                continue
            self.in_progress.add(_target(assignment))
            for parent, count in zip(
                assignment["parent_flowers"], assignment["parent_copies"], strict=False
            ):
                self.busy[_flower(parent)] += int(count)

    def _shrink_primary_copies(self) -> None:
        """Release extra copies the scheduler gave primaries evaluated in isolation.

        The initial scheduler evaluates each first-wave route in isolation, so
        a primary outdoor job can reserve several pairs before packing sees
        competing goals. Release the extra copies up front; they can be used
        by distinct ready goals, or returned to active jobs in the balancing
        pass. A locked/manual layout remains exactly as recorded.
        """
        opt = self.opt
        for primary in self.first_wave:
            slot_id = str(primary.get("slot", "")).upper()
            if not self._repacking(slot_id):
                continue
            slot = self.slot_map.get(slot_id)
            method = str(primary.get("method", ""))
            if (
                slot is None
                or slot.greenhouse
                or method == "propagate_solid"
                or primary.get("layout_search") == "bounded_joint_cell_outcome"
                or _is_locked(primary)
            ):
                continue
            requested = [int(value) for value in primary.get("parent_copies", [])]
            if method.startswith("fertilize_"):
                if (
                    requested
                    and requested[0] > 1
                    and isolated_pair_zones(slot, 1)
                    and opt._capacity(
                        _flower(primary["parent_flowers"][0]), set(opt.initial_owned)
                    ) >= requested[0]
                ):
                    self.busy[_flower(primary["parent_flowers"][0])] -= requested[0] - 1
                    primary["parent_copies"] = [1]
                continue
            pair_count = min(requested, default=0)
            if pair_count <= 1 or not isolated_pair_zones(slot, 1):
                continue
            for parent_row, count in zip(
                primary.get("parent_flowers", []), requested, strict=False
            ):
                self.busy[_flower(parent_row)] -= max(0, count - 1)
            primary["parent_copies"] = [1 for _ in requested]

    def _preclaimed_zones(self) -> tuple[dict[str, set[tuple]], set[str]]:
        """Pairs already fixed by saved layouts, and plots the scheduler packed itself.

        New v57 scheduler batches have already selected a joint safe-zone
        layout. Preserve those exact coordinates through the recommendation
        packer and reserve them before it considers supplemental work.
        """
        all_jobs = self.first_wave + [job for jobs in self.preserved.values() for job in jobs]
        prepacked_slots = {
            str(row.get("slot", "")).upper()
            for row in all_jobs
            if row.get("layout_search") == "bounded_joint_cell_outcome"
        } if self.preserve_scheduled_layouts else set()
        preclaimed_zones_by_slot: dict[str, set[tuple]] = defaultdict(set)
        for row in all_jobs:
            layout = row.get("layout")
            if not isinstance(layout, dict):
                continue
            for first, second in zip(
                layout.get("parent_a_cells", []),
                layout.get("parent_b_cells", []),
                strict=False,
            ):
                preclaimed_zones_by_slot[str(row.get("slot", "")).upper()].add(
                    ((int(first[0]), int(first[1])), (int(second[0]), int(second[1])))
                )
        return preclaimed_zones_by_slot, prepacked_slots

    # -- one plot ---------------------------------------------------------------

    def _pack_slot(self, sp: _SlotPacking, primary: dict) -> None:
        self._claim_primary_layout(sp, primary)
        while True:
            remaining_zones = self.opt._available_outdoor_zones(
                sp.slot, sp.zones, sp.current_jobs(), sp.claimed_zones
            )
            # Real collection work gets first claim on every safe zone.
            # Propagation is a fallback only when no currently breedable
            # target can use this remaining space.
            if self._add_supplemental_job(sp, remaining_zones):
                continue
            if remaining_zones and self._add_extra_pair(sp, remaining_zones):
                continue
            # A live propagation decision gets the remaining safe zones
            # before fertilizer plants use any otherwise-open cells.
            if remaining_zones and self._add_propagation_job(sp, remaining_zones):
                continue
            break
        # Freeze collection placement first. This expands every
        # unambiguous spawn cell before fertilizer is allowed to claim
        # any physical cell.
        self.opt._expand_outdoor_target_cells(sp.slot, sp.current_jobs())
        self._place_fertilizer_cells(sp)
        self._settle_fertilizers(sp)

    def _claim_primary_layout(self, sp: _SlotPacking, primary: dict) -> None:
        """Give the plot's primary job its cells and mark the zones it uses."""
        opt = self.opt
        zones = sp.zones
        if primary.get("method") == "propagate_solid":
            used = min(
                len(zones),
                int(primary.get("propagation_zone_count", primary["parent_copies"][0])),
            )
            # Keep the clone-specific one-parent layout generated by
            # propagation_assignment_for_target.
            sp.claimed_zones.update(tuple(zone[0]) for zone in zones[:used])
            if used < len(zones):
                primary["layout"] = {
                    "parent_a_cells": primary.get("layout", {}).get("parent_a_cells", []),
                    "parent_b_cells": [],
                    "target_cells": primary.get("layout", {}).get("target_cells", []),
                }
        elif primary["method"].startswith("fertilize_"):
            # Fertilizing does not need a breeding zone. Delay mutable
            # fertilizer placement until all collection pairs and useful
            # spawn cells on this plot have been assigned.
            requested = int(primary["parent_copies"][0])
            if _is_locked(primary) and isinstance(primary.get("layout"), dict):
                parent_cells = [
                    (int(row), int(col))
                    for row, col in primary["layout"].get("parent_a_cells", [])
                ][:requested]
                used = len(parent_cells)
                primary["layout"] = {
                    "parent_a_cells": [list(cell) for cell in parent_cells],
                    "parent_b_cells": [],
                    "target_cells": [],
                }
                if used < requested:
                    self.busy[_flower(primary["parent_flowers"][0])] -= requested - used
                    primary["parent_copies"] = [used]
            else:
                primary["layout"] = {
                    "parent_a_cells": [],
                    "parent_b_cells": [],
                    "target_cells": [],
                }
                primary["pending_reserved_copies"] = requested
                sp.mutable_fertilizers.append(primary)
        elif (
            isinstance(primary.get("layout"), dict)
            and primary.get("layout_search") == "bounded_joint_cell_outcome"
        ):
            layout = primary["layout"]
            sp.claimed_zones.update(zip(
                [tuple(map(int, cell)) for cell in layout.get("parent_a_cells", [])],
                [tuple(map(int, cell)) for cell in layout.get("parent_b_cells", [])],
                strict=False,
            ))
        elif _is_locked(primary) and isinstance(primary.get("layout"), dict):
            layout = primary["layout"]
            sp.claimed_zones.update(zip(
                [(int(row), int(col)) for row, col in layout.get("parent_a_cells", [])],
                [(int(row), int(col)) for row, col in layout.get("parent_b_cells", [])],
                strict=False,
            ))
        else:
            used = min(len(zones), min(int(value) for value in primary["parent_copies"]))
            if used:
                primary["layout"] = opt._zone_layout(zones[:used])
                primary["eligible_cells"] = sum(len(targets) for _pair, targets in zones[:used])
            sp.claimed_zones.update(tuple(zone[0]) for zone in zones[:used])

        if _is_locked(primary):
            return
        if not str(primary.get("method", "")).startswith("fertilize_"):
            sp.mutable_jobs.append(primary)
        elif primary not in sp.mutable_fertilizers:
            # A locked fertilizer job was handled using its saved cell list;
            # a mutable one can safely receive more cells after pair jobs.
            sp.mutable_fertilizers.append(primary)
            primary["pending_reserved_copies"] = min(
                int(value) for value in primary.get("parent_copies", [1])
            )

    def _select_supplemental(self, slot: PlotSlot) -> Route | None:
        opt = self.opt
        if self.ordered_candidates is None:
            return opt._select_job(
                slot, self.owned, self.in_progress, self.busy, Counter(), "projected_finish",
            )
        for target in self.ordered_candidates:
            if target in self.owned or target in self.in_progress or target not in opt.reachable:
                continue
            route = opt._ready_route(target, self.owned, self.busy, slot)
            if route is not None:
                return route
        return None

    def _finish_priority(self, target: Flower) -> float:
        """Weight for finish-time gains: targets that unlock more, or sit on
        a longer critical path, matter more."""
        return (
            1.0
            + 0.55 * math.log1p(self.opt.descendants.get(target, 0))
            + 0.30 * math.log1p(self.opt.critical_tail.get(target, 0.0))
        )

    def _outdoor_cell_chance(self, route: Route) -> float:
        opt = self.opt
        per_spawn = BREED_PROBABILITY[route.method]
        if (
            route.method == "pattern_transfer"
            and opt._uses_inactive_event_patterned_parent(route)
        ):
            per_spawn = 0.02
        return per_spawn * opt.settings["outdoor_spawn_probability_fertilized"]

    def _add_supplemental_job(self, sp: _SlotPacking, remaining_zones) -> bool:
        """Start another distinct ready goal on this plot, if one fits."""
        opt = self.opt
        route = self._select_supplemental(sp.slot)
        if route is None:
            return False
        selected_zones = ()
        if route.method.startswith("fertilize_"):
            available = max(0, opt._capacity(route.parents[0], self.owned) - self.busy[route.parents[0]])
            if available <= 0:
                return False
            # Reserve one copy and the target, then place it
            # only after collection zones are fully assigned.
            copies = (1,)
            eligible = 1
            probability = 1.0 - (1.0 - BREED_PROBABILITY[route.method]) ** eligible
            layout = {"parent_a_cells": [], "parent_b_cells": [], "target_cells": []}
        else:
            if not remaining_zones:
                return False
            available_pairs = min(
                max(0, opt._capacity(parent, self.owned) - self.busy[parent])
                for parent in route.parents
            )
            # Give a distinct ready goal its first pair before
            # increasing another goal's copy count.
            zone_count = min(len(remaining_zones), available_pairs, 1)
            if zone_count <= 0:
                return False
            selected_zones = remaining_zones[:zone_count]
            copies = (zone_count, zone_count)
            eligible = sum(len(zone[1]) for zone in selected_zones)
            probability = 1.0 - (1.0 - self._outdoor_cell_chance(route)) ** eligible
            layout = opt._zone_layout(tuple(selected_zones))
        job = opt._assignment(
            sp.slot, route, probability, eligible, 1.0 / probability, copies
        )
        job.update({
            "job_id": sp.next_job_id(),
            "supplemental": True,
            "layout": layout,
        })
        self.packed.setdefault(sp.slot.slot, []).append(job)
        if not route.method.startswith("fertilize_"):
            sp.mutable_jobs.append(job)
        else:
            sp.mutable_fertilizers.append(job)
            job["pending_reserved_copies"] = int(copies[0])
        self.in_progress.add(route.target)
        for parent, count in zip(route.parents, copies, strict=False):
            self.busy[parent] += count
        sp.claimed_zones.update(tuple(zone[0]) for zone in selected_zones)
        return True

    def _add_extra_pair(self, sp: _SlotPacking, remaining_zones) -> bool:
        """Give the next zone to the active job whose expected wait it cuts most.

        This lets a plot with only one ready goal keep its old throughput
        while preventing that goal from taking every pair before other ready
        goals get a first pair.
        """
        opt = self.opt
        next_zone_target_count = len(remaining_zones[0][1])
        extra_options: list[tuple[float, str, dict, tuple[Flower, ...]]] = []
        for job in sp.mutable_jobs:
            method = str(job.get("method", ""))
            if method.startswith("fertilize_") or method == "propagate_solid":
                continue
            parent_rows = job.get("parent_flowers", [])[:2]
            if len(parent_rows) < 2:
                continue
            parents = tuple(_flower(row) for row in parent_rows)
            if min(opt._capacity(parent, self.owned) - self.busy[parent] for parent in parents) <= 0:
                continue
            target = _target(job)
            per_cell = self._outdoor_cell_chance(Route(target, method, parents))
            eligible = max(0, int(job.get("eligible_cells", 0)))
            old_probability = 1.0 - (1.0 - per_cell) ** eligible
            new_probability = 1.0 - (1.0 - per_cell) ** (eligible + next_zone_target_count)
            if old_probability <= 0 or new_probability <= 0:
                continue
            days_saved = (1.0 / old_probability) - (1.0 / new_probability)
            extra_options.append((
                days_saved * self._finish_priority(target), target.label(), job, parents
            ))
        if not extra_options:
            return False
        _gain, _label, job, parents = max(extra_options, key=lambda item: (item[0], item[1]))
        pair, spawn_cells = remaining_zones[0]
        layout = job.setdefault("layout", {})
        layout.setdefault("parent_a_cells", []).append(list(pair[0]))
        layout.setdefault("parent_b_cells", []).append(list(pair[1]))
        layout.setdefault("target_cells", []).extend(
            [list(cell) for cell in sorted(spawn_cells)]
        )
        eligible = int(job.get("eligible_cells", 0)) + len(spawn_cells)
        job["eligible_cells"] = eligible
        route = Route(_target(job), str(job["method"]), parents)
        probability = 1.0 - (1.0 - self._outdoor_cell_chance(route)) ** eligible
        job["daily_probability"] = probability
        job["expected_days"] = 1.0 / probability if probability > 0 else math.inf
        job["parent_copies"] = [int(value) + 1 for value in job.get("parent_copies", [])]
        for parent in parents:
            self.busy[parent] += 1
        sp.claimed_zones.add(tuple(pair))
        return True

    def _select_propagation(self, slot: PlotSlot) -> tuple[Flower, int, str, tuple[str, ...]] | None:
        opt = self.opt
        # A local one-plot repack has an explicit candidate order and
        # must not invent unrelated clone work as filler. The refresh
        # path can choose an on-demand propagation job explicitly.
        if self.ordered_candidates is not None:
            return None
        # v30: only consider cloning after ordinary breeding has no use
        # for the remaining safe zones. Demand must be live, location-
        # aware, and greater than the free copies already available.
        candidates: list[tuple[int, int, str, Flower, int, str, tuple[str, ...]]] = []
        for target in opt.initial_owned:
            if target.pattern != "Solid" or target in self.in_progress:
                continue
            if not opt._route_allowed_for_season(
                Route(target, "propagate_solid", (target,)), slot
            ):
                continue
            need = opt._on_demand_propagation_need(target, self.owned, self.busy, self.in_progress)
            if need is None:
                continue
            goal, reason, regions = need
            if max(0, opt._capacity(target, self.owned) - self.busy[target]) <= 0:
                continue
            candidates.append((
                len(regions), opt.descendants.get(target, 0), target.label(),
                target, goal, reason, regions,
            ))
        if not candidates:
            return None
        candidates.sort(key=lambda item: (-item[0], -item[1], item[2]))
        _region_count, _desc, _label, target, goal, reason, regions = candidates[0]
        return target, goal, reason, regions

    def _add_propagation_job(self, sp: _SlotPacking, remaining_zones) -> bool:
        """Clone a solid that live demand needs more copies of, one zone at a time."""
        opt = self.opt
        slot = sp.slot
        propagation = self._select_propagation(slot)
        if propagation is None:
            return False
        propagation_target, goal, reason, demand_regions = propagation
        current = opt.inventory.physical_count(propagation_target)
        available = max(0, opt._capacity(propagation_target, self.owned) - self.busy[propagation_target])
        # One incremental copy per planning pass is the core v30 rule.
        needed = max(0, goal - current)
        zone_count = min(len(remaining_zones), available, needed, 1)
        if zone_count <= 0:
            return False
        selected_zones = remaining_zones[:zone_count]
        parent_cells = [list(zone[0][0]) for zone in selected_zones]
        target_cells = [
            list(cell)
            for pair, shared in selected_zones
            for cell in sorted(set(shared) | {pair[1]})
        ]
        eligible = len(target_cells)
        per_cell = opt.settings["outdoor_spawn_probability_fertilized"]
        probability = 1.0 - (1.0 - per_cell) ** eligible if eligible else 0.0
        if probability <= 0:
            return False
        self.packed.setdefault(slot.slot, []).append({
            "slot": slot.slot,
            "plot": slot.plot,
            "region": slot.region,
            "plot_spots": slot.spots,
            "eligible_cells": eligible,
            "target": propagation_target.label(),
            "target_type": propagation_target.flower_type,
            "target_color": propagation_target.color,
            "target_pattern": propagation_target.pattern,
            "target_secondary_color": propagation_target.secondary_color,
            "method": "propagate_solid",
            "parents": [propagation_target.label()],
            "parent_flowers": [{
                "flower_type": propagation_target.flower_type,
                "color": propagation_target.color,
                "pattern": propagation_target.pattern,
                "secondary_color": propagation_target.secondary_color,
            }],
            "parent_patterns": [propagation_target.pattern],
            "parent_copies": [zone_count],
            "daily_probability": probability,
            "expected_days": 1.0 / probability,
            "event_only": opt._is_event_only(propagation_target),
            "stock_goal": goal,
            "stock_goal_reason": reason,
            "propagation_goal": goal,
            "propagation_goal_reason": reason,
            "propagation": True,
            "propagation_zone_count": zone_count,
            "propagation_demand_regions": list(demand_regions),
            "farm_state": "recommended",
            "locked": False,
            "job_id": sp.next_job_id(),
            "supplemental": True,
            "layout": {
                "parent_a_cells": parent_cells,
                "parent_b_cells": [],
                "target_cells": target_cells,
            },
        })
        self.in_progress.add(propagation_target)
        self.busy[propagation_target] += zone_count
        sp.claimed_zones.update(tuple(zone[0]) for zone in selected_zones)
        return True

    def _select_supplemental_fertilizer(self, slot: PlotSlot) -> Route | None:
        """Find native-pattern collection work for genuine spare cells."""
        opt = self.opt
        candidates = self.fertilizer_candidate_order
        cursor = self.fertilizer_cursor_by_slot[slot.slot]
        while cursor < len(candidates):
            target = candidates[cursor]
            cursor += 1
            self.fertilizer_cursor_by_slot[slot.slot] = cursor
            if target in self.owned or target in self.in_progress:
                continue
            solid = Flower(target.flower_type, target.color, "Solid")
            if opt._capacity(solid, self.owned) - self.busy[solid] <= 0:
                continue
            route = Route(target, "fertilize_pattern", (solid,))
            if not opt._route_allowed_for_season(route, slot):
                continue
            return route
        return None

    def _place_fertilizer_cells(self, sp: _SlotPacking) -> None:
        """Hand leftover cells to fertilizer jobs, one cell at a time.

        Fertilizer has no spawn-zone requirement, so it uses only cells
        outside all possible safe pair zones and active spawn halos.
        """
        opt = self.opt
        slot = sp.slot
        while True:
            current_jobs = sp.current_jobs()
            fertilizer_options: list[tuple[float, str, dict, Flower]] = []
            for job in sp.mutable_fertilizers:
                if not job.get("parent_flowers"):
                    continue
                parent_cells = job.get("layout", {}).get("parent_a_cells", [])
                # The route's original copy request can be stale by
                # packing time: earlier jobs may have released spare
                # inventory. Let the live inventory check below and
                # actual open cells determine the current cap.
                if len(parent_cells) >= slot.spots:
                    continue
                parent = _flower(job["parent_flowers"][0])
                needs_reserved_copy = len(parent_cells) < int(job.get("pending_reserved_copies", 0))
                if (
                    not needs_reserved_copy
                    and opt._capacity(parent, self.owned) - self.busy[parent] <= 0
                ):
                    continue
                eligible = len(parent_cells)
                per_cell = BREED_PROBABILITY[str(job.get("method", ""))]
                old_probability = 1.0 - (1.0 - per_cell) ** eligible
                new_probability = 1.0 - (1.0 - per_cell) ** (eligible + 1)
                if new_probability <= 0:
                    continue
                target = _target(job)
                priority = self._finish_priority(target)
                marginal_gain = (
                    priority * 1_000_000.0
                    if needs_reserved_copy
                    else ((1.0 / old_probability) - (1.0 / new_probability)) * priority
                )
                fertilizer_options.append((marginal_gain, target.label(), job, parent))
            if not fertilizer_options:
                route = self._select_supplemental_fertilizer(slot)
                if route is None:
                    return
                parent_cells = opt._choose_fertilizer_parent_cells(slot, 1, current_jobs)
                if not parent_cells:
                    return
                per_cell = BREED_PROBABILITY[route.method]
                job = opt._assignment(slot, route, per_cell, 1, 1.0 / per_cell, (1,))
                job.update({
                    "job_id": sp.next_job_id(),
                    "supplemental": True,
                    "layout": {
                        "parent_a_cells": [list(parent_cells[0])],
                        "parent_b_cells": [],
                        "target_cells": [],
                    },
                    "pending_reserved_copies": 0,
                })
                self.packed.setdefault(slot.slot, []).append(job)
                sp.mutable_fertilizers.append(job)
                self.in_progress.add(route.target)
                self.busy[route.parents[0]] += 1
                continue
            _gain, _label, job, parent = max(fertilizer_options, key=lambda item: (item[0], item[1]))
            parent_cells = opt._choose_fertilizer_parent_cells(slot, 1, current_jobs)
            if not parent_cells:
                return
            parent_layout = job.setdefault("layout", {})
            parent_layout.setdefault("parent_a_cells", []).append(list(parent_cells[0]))
            job["parent_copies"] = [len(parent_layout["parent_a_cells"])]
            job["eligible_cells"] = len(parent_layout["parent_a_cells"])
            per_cell = BREED_PROBABILITY[str(job["method"])]
            probability = 1.0 - (1.0 - per_cell) ** job["eligible_cells"]
            job["daily_probability"] = probability
            job["expected_days"] = 1.0 / probability if probability > 0 else math.inf
            if len(parent_layout["parent_a_cells"]) > int(job.get("pending_reserved_copies", 0)):
                self.busy[parent] += 1

    def _settle_fertilizers(self, sp: _SlotPacking) -> None:
        """Release reserved fertilizer copies that never got a cell."""
        primary_ids = {id(row) for row in self.first_wave}
        for job in sp.mutable_fertilizers:
            parent_cells = job.get("layout", {}).get("parent_a_cells", [])
            missing_reserved = max(0, int(job.get("pending_reserved_copies", 0)) - len(parent_cells))
            if missing_reserved:
                self.busy[_flower(job["parent_flowers"][0])] -= missing_reserved
            job["parent_copies"] = [len(parent_cells)]
            if not parent_cells:
                if id(job) in primary_ids:
                    self.unusable_primary_ids.add(id(job))
                else:
                    self.packed[sp.slot.slot] = [
                        row for row in self.packed.get(sp.slot.slot, []) if row is not job
                    ]
            job.pop("pending_reserved_copies", None)

    # -- whole plan ---------------------------------------------------------------

    def _finish(self) -> dict[str, list[dict]]:
        first_wave = self.first_wave
        packed = self.packed
        if self.unusable_primary_ids:
            first_wave[:] = [
                row for row in first_wave if id(row) not in self.unusable_primary_ids
            ]
        # Fertilizer primaries can lose every cell to useful breeding work.
        # Keep a valid primary for any plot whose supplemental jobs survive,
        # so the resulting recommendation remains selectable and applicable.
        primary_slots = {str(row.get("slot", "")).upper() for row in first_wave}
        for slot_id, jobs in packed.items():
            if jobs and slot_id.upper() not in primary_slots and self._repacking(slot_id.upper()):
                first_wave.append(jobs.pop(0))
                primary_slots.add(slot_id.upper())
        grouped_primary: dict[str, list[dict]] = defaultdict(list)
        for row in first_wave:
            grouped_primary[str(row.get("slot", "")).upper()].append(row)
        for slot_id, primary_jobs in grouped_primary.items():
            if not self._repacking(slot_id):
                continue
            slot = self.slot_map.get(slot_id)
            if slot is not None and not slot.greenhouse:
                self.opt._expand_outdoor_target_cells(slot, primary_jobs + packed.get(slot_id, []))
        # Never publish a mutable recommendation with a copy reservation but
        # no actual parent cells. This can happen when a fertilizer route was
        # considered before the final mixed-plot packing found a legal cell.
        for slot_id, jobs in list(packed.items()):
            packed[slot_id] = [
                job for job in jobs
                if not (
                    str(job.get("method", "")).startswith("fertilize_")
                    and not _is_locked(job)
                    and not job.get("layout", {}).get("parent_a_cells")
                )
            ]
            if not packed[slot_id]:
                del packed[slot_id]
        return packed
