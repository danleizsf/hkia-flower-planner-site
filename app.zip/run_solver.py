"""Generate output/latest_plan.json. The dashboard runs this for Generate Plan."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from hkia_solver import CollectionPlanner, progress
from hkia_solver.flow.integrate import apply_flow_plan
from hkia_solver.paths import default_data_root, has_farm_data

PROGRESS_FILE = "plan_progress.json"   # in output/; the dashboard's plan status reads it


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate the HKIA farm plan.")
    parser.add_argument(
        "--thorough",
        action="store_true",
        help="Compare all scheduling rollouts (slower)",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=None,
        help="Folder holding farm_data/ and output/ (default: ~/HKIA Flower Planner Data)",
    )
    parser.add_argument(
        "--quick",
        action="store_true",
        help="Fast initial recommendation; leave deeper search to background refinement",
    )
    parser.add_argument(
        "--replant-all",
        action="store_true",
        help="Plan every plot from scratch, ignoring what is planted (e.g. at an event season change)",
    )
    return parser.parse_args(argv)


def write_progress_file(path: Path):
    """A progress listener for the dashboard: the latest update in ``path`` (replaced atomically)."""
    def listener(update: dict) -> None:
        tmp = path.with_name(path.name + ".tmp")
        try:
            tmp.write_text(json.dumps(update), encoding="utf-8")
            tmp.replace(path)
        except OSError:
            pass                      # progress is a nicety; never fail the plan over it
    return listener


def main() -> None:
    args = parse_args()
    root = (args.data_dir or default_data_root()).expanduser().resolve()
    if not has_farm_data(root):
        raise SystemExit(f"No farm data found in {root}. Run import_farm_data.py first.")
    progress_file = root / "output" / PROGRESS_FILE
    if not progress.listening():      # the browser version listens itself
        progress_file.parent.mkdir(parents=True, exist_ok=True)
        progress.set_listener(write_progress_file(progress_file))
    progress.report("farm")
    planner = CollectionPlanner(root, thorough=args.thorough and not args.quick, quick=args.quick)
    json_path, plan = planner.write_outputs()
    plan = apply_flow_plan(planner, plan, replant_all=args.replant_all)
    progress.report("save")
    json_path.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    print(f"FLOW plan: {plan['flow']['breeding_jobs']} breeding jobs in "
          f"{plan['flow']['hubs_used']}/{plan['flow']['hubs_total']} hubs "
          f"({plan['flow']['kept_jobs']} kept as planted), "
          f"{plan['flow']['fertilizer_jobs']} fertilizer beds.")
    summary = plan["summary"]
    print(
        f"Owned {summary['owned_targets']}/{summary['total_targets']} in-scope targets; "
        f"{summary['missing_targets']} missing, {summary['blocked_targets']} blocked by inputs."
    )
    print(
        f"First wave: {summary['first_wave_job_count']} jobs using "
        f"{summary['first_wave_physical_plots_used']}/{summary['usable_physical_plots']} plots."
    )
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
